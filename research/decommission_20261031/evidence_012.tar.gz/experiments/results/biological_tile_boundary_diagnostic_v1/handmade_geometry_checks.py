"""Meaningful source-integrator checks with handcrafted probabilities/labels only."""
import ast,hashlib,json
from pathlib import Path
import types,numpy as np
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN');OUT=Path(__file__).resolve().parent
text=(OUT/'analyze.py').read_text();checks=[]
ns={'ROOT':ROOT,'OUT':OUT,'np':np,'types':types}
ns.update(BOUNDARIES=np.arange(250000.,1750001.,250000.),BANDS=('[0,10000)','[10000,25000)','[25000,50000)','[50000,125000]','>125000_terminal_accounting'))
scorer=ROOT/'scripts/train_ancestralpaths_biological_v1.py'
tree=ast.parse(scorer.read_text())
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('intersections','boundary_match','tracts','length_summary','full_span_score')]
helper={'np':np};exec(compile(ast.Module(body=functions,type_ignores=[]),str(scorer),'exec'),helper)
ns['helpers']=helper;ns['cfg']=json.loads((ROOT/'configs/biological_candidate_pilot_v1.json').read_text())
fragment=text[text.index('# Exact physical regions:'):text.index('\nresults=[];supports=')]
exec(compile(fragment,str(OUT/'analyze.py'),'exec'),ns)
def check(name,value):
 assert value,name;checks.append(name)
regions=ns['regions']
check('interior_band_total1_75Mb_and_terminal250kb',sum(r-l for region in regions[:4] for l,r in region)==1750000. and sum(r-l for l,r in regions[4])==250000.)
check('no_domain_edge_artificial_boundaries',0. not in ns['BOUNDARIES'] and 2000000. not in ns['BOUNDARIES'])
check('intersections_split_predictions_and_truth_exactly',ns['tw'].sum()==2000000.)
W=ns['region_weights'](np.array([0.,247500.,1875000.]),np.array([100.,252500.,2000000.]))
check('outer_domain_is_accounting_only',np.array_equal(W[0],np.array([0.,0.,0.,0.,100.])))
check('near_boundary_split_both_sides_exact',np.array_equal(W[1],np.array([5000.,0.,0.,0.,0.])))
check('right_terminal_full125kb_counted',np.array_equal(W[2],np.array([0.,0.,0.,0.,125000.])))
parent={'edges':np.array([0.,1000000.,2000000.]),'cohorts':np.array(['present_day']*64+['ancient']*56),
 'query_slots':np.arange(120),'samples':[{'sample_id':f'handmade_pair_{i//2}'} for i in range(120)],
 'coverage_original':np.array([0.,2000000.]),'retained_indexes':list(range(20000))}
truth=types.SimpleNamespace(intervals=np.array([[0.,1000000.],[1000000.,2000000.]]),c4=np.array([[0]*120,[1]*120]))
prob=np.tile(np.array([.7,.1,.1,.1]),(2,120,1));bands,total,replay=ns['scores'](prob,parent,truth)
check('symmetric_handmade_truth_half_accuracy_each_band',all(abs(x['accuracy']-.5)<1e-12 for x in bands))
check('overall_denominator128M_primary_query_bp',total['denominator_query_bp']==128000000.)
check('exact_nll_no_floor',abs(total['nll']+(.5*np.log(.7)+.5*np.log(.1)))<1e-12)
check('original_scorer_and_strata_match',total['accuracy']==replay['accuracy'] and total['denominator_query_bp']==replay['denominator_query_bp'])
prob=np.tile(np.array([1.,0.,0.,0.]),(2,120,1));bands,total,replay=ns['scores'](prob,parent,truth)
check('zero_native_probability_keeps_infinite_nll',total['NLL_is_infinite'] and total['nll'] is None and total['infinite_nll_query_bp']==64000000.)
check('every_band_infinite_mass_preserved',all(x['NLL_is_infinite'] and x['nll'] is None and x['infinite_nll_query_bp']==x['denominator_query_bp']/2 for x in bands))
(OUT/'handmade_geometry_checks.json').write_text(json.dumps({'status':'passed','count':len(checks),'checks':checks,'actual_prediction_or_truth_arrays_opened':False,'analysis_source_sha256':hashlib.sha256(text.encode()).hexdigest()},indent=2)+'\n')
print(json.dumps({'status':'passed','count':len(checks)}))
