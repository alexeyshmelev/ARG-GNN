# TreeLoom resource-only successor, 2026-10-22

Status: prepared and metadata-validated; not dispatched.

The frozen October 21 fitter failed in the first complete-parent trunk backward during checkpoint recomputation of `_second`, at `_base.up_gate`. PyTorch had 15.90 GiB allocated under a 16 GiB allocator cap; the device still had 32.29 GiB free. The failed next allocation was 40 MiB, which does not bound the remaining backward demand. All 10,000 focal decoder gradients had completed, but no optimizer update or checkpoint had completed. The retained failed output has an empty checkpoint directory and must not be used as a resume source.

`fit_v2.py` changes only the allocator cap to 32 GiB, the corresponding validator and wording, the versioned module/schema identity, and the explicit import of the unchanged October 21 checkpoint module. It keeps physical GPU5, UUID GPU-3db85505-d061-e45d-d154-e7e8c1cad497, 512 GiB RSS, the original 352 GiB compact pool and 128 GiB headroom, all 20 original parents, 30 passes and 600 optimizer updates, full parent computation, full BPTT, RNG handling and rolling checkpoints.

32 GiB is a provisional bounded cap, not a proven sufficient peak. Only a genuine complete-parent trunk backward and optimizer update can establish initial sufficiency. `task_resource_patch_v2.json` records the matching proposed queue limit and 40 GiB minimum free GPU admission. It is a prepared patch description, not an executable or modified live plan. A fresh output scope and null resume checkpoint are required for this failed attempt. The active ARGformer MLM has not been changed, signaled or interrupted.

Metadata acceptance passed with all 20 original parents. The test compares the entire source against the exact permitted replacements, checks the historical fitter and checkpoint hashes, verifies all inherited source references, and compares actual old/new factory descriptors after normalizing only the permitted resource and identity differences. No model, real data array, truth payload, run_fit call or CUDA initialization was used. The prior exact-resume CPU test remains historical evidence for the unchanged checkpoint implementation; it was not rerun here.

The first acceptance attempt lacked the src import path and failed before factory execution. The retained `.log` records that error. The corrected visible command was:

```bash
cd /workspace-SR003.nfs2/ARG-GNN
PYTHONPATH="$PWD/src:$PWD" .runtime/env/bin/python -B -m research.repairs.benchmark_followup_20261022.treeloom.metadata_acceptance_v2
```

The successful receipt is `metadata_acceptance_v2.result.json`; the successful captured output is `metadata_acceptance_v2.with_src.log`. `fit_v2.diff` records the exact source change. `source_manifest_v2.json` binds the executable sources and acceptance receipt. This preparation does not modify the historical fitter, numerical sources, prior evidence, queue policy or live jobs.
