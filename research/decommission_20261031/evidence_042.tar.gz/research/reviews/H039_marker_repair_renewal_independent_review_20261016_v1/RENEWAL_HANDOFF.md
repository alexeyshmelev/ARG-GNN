# H039 marker-repair expiry renewal: independent PASS

Verdict: PASS for the exact sealed renewal helper/bootstrap and narrow pool/admission integration. This is a source-only review; it grants no execution authority. The progress observer is reviewed separately.

The old authority actually expired at 2026-10-15T21:36:04.459612+00:00. The new mechanism preserves those historical bytes and changes only the exact authority's returned expiry after real-UTC certificate validation on every effective view. Exact certificate, renewal source, bootstrap, old authority, old repair source and old terminal barrier bytes are all revalidated. It preserves full 15,000,000-byte charge, zero accounting credit, bad-key future-write/relaunch revocation and every allocation expiry.

Fresh reserve/worker direct bindings include the renewal source/bootstrap/certificate. Controller/worker integration installs before canonical guard imports; bootstrap handles each new worker. No old consumer or running C3/native GPU5 is patched. Existing pool supervision remains under its separate base PASS; AST comparison found only _launch_queue changed among controller methods.

Validation: 17 author pure cases plus 30 independent in-memory-file/mocked-loader cases pass; four relevant sources compile without import. No actual guard hook, admission, install, job, process/GPU probe, scientific payload/checkpoint read, wait, signal or Git operation occurred.

Exact source hashes, preserved base PASS, AST delta and receipts are recorded in renewal_review_receipt_v1.json. Root may issue a separately hash-bound active certificate within the reviewed narrow scope; none was created or activated by this review.
