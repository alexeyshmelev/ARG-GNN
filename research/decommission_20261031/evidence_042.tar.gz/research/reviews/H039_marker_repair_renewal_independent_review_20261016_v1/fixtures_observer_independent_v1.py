"""Mock loader composition and scalar-only observer verification; no scientific imports."""
from pathlib import Path
import ast,contextlib,functools,hashlib,io,json,runpy,types
ROOT_REAL=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    base=runpy.run_path(str(HERE/"fixtures_renewal_independent_v1.py"),run_name="__mock_renewal_setup__")
renew=base["ns"];FakeLoader=base["FakeLoader"];fake_sys=base["fake_sys"]
fake_sys.modules={};calls=[];events=[];stub_calls=[];response=[dict(whole_parent_optimizer_updates=1)]
failure=RuntimeError("original-only-failure")
def stub(*args,**kwargs):
    stub_calls.append((args,kwargs))
    if response[0] is failure:raise failure
    return response[0]
def base_exec(loader,module):
    calls.append(loader.path)
    module._base_was_called=True
    if loader.path==str(renew["ROOT"]/renew["OLD_SOURCE_REF"]["path"]):module._bound=base["bound"]
    elif loader.path.endswith("/trainer_prefetch_v1.py"):module.checkpointed_complete_parent_step_v1=stub
FakeLoader.exec_module=base_exec
renew["install_renewal_v1"](base["ref"])
renewal_hook=FakeLoader.exec_module
source_rel="research/reviews/GPU45_C3cache_H050_pool_successor_20261016_v1/c3_progress_observer_v1.py"
source=(ROOT_REAL/source_rel).read_text()
obs=dict(Path=base["MemoryPath"],functools=functools,hashlib=hashlib,json=json,
    os=types.SimpleNamespace(getpid=lambda:4321,environ={"ARGGNN_LOGICAL_JOB_NAME":"C3-GNN-cachev3-shared-TRAIN-v1"}),
    sys=fake_sys,importlib=base["fake_importlib"],
    print=lambda raw,**kwargs:events.append(json.loads(raw)))
nodes=[n for n in ast.parse(source).body if isinstance(n,(ast.Assign,ast.FunctionDef))]
module=ast.Module(body=nodes,type_ignores=[]);ast.fix_missing_locations(module)
exec(compile(module,"<isolated_observer_functions>","exec"),obs)
target=str(obs["ROOT"]/obs["TRAINER_REF"]["path"])
base["put"](obs["TRAINER_REF"]["path"],(ROOT_REAL/obs["TRAINER_REF"]["path"]).read_bytes())
results=[]
def passed(name,ok=True):
    assert ok,name;results.append(dict(case=name,passed=True))
def rejects(name,call):
    try:call()
    except ValueError:passed(name)
    else:raise AssertionError(name)
obs["install_progress_observer_v1"]()
combined_hook=FakeLoader.exec_module
passed("observer_composes_after_existing_renewal_mock_hook",combined_hook is not renewal_hook)
marker_path=str(renew["ROOT"]/renew["OLD_SOURCE_REF"]["path"])
marker=types.SimpleNamespace(__file__=marker_path)
FakeLoader(marker_path).exec_module(marker)
passed("renewal_marker_load_still_delegates_once_and_renews",
    calls==[marker_path] and marker._bound(renew["OLD_AUTHORITY_REF"])["expires_at_utc"]==base["cert"]["renewed_expires_at_utc"])
trainer=types.SimpleNamespace(__file__=target)
FakeLoader(target).exec_module(trainer)
passed("trainer_load_delegates_once_then_wraps_exact_global",
    calls==[marker_path,target] and hasattr(trainer,"_C3_operational_progress_observer_v1"))
class UninspectableScience:
    def __getattribute__(self,name):raise AssertionError("scientific argument inspection")
model=UninspectableScience();optimizer=UninspectableScience()
returned=response[0];value=trainer.checkpointed_complete_parent_step_v1(model,optimizer=optimizer)
passed("original_once_same_arguments_return_identity_without_scientific_inspection",
    value is returned and len(stub_calls)==1 and stub_calls[0][0][0] is model
    and stub_calls[0][1]["optimizer"] is optimizer)
passed("first_success_event_scalar_only",events==[dict(event="C3_shared_complete_parent_progress_v1",pid=4321,
    job=obs["JOB"],successful_whole_parent_optimizer_updates=1)])
invalid=[True,0,1.0,-1,None,2]
for value in invalid:
    response[0]=dict(whole_parent_optimizer_updates=value)
    returned=response[0];assert trainer.checkpointed_complete_parent_step_v1(model) is returned
for value in [{},None,[],(1,),"success"]:
    response[0]=value;assert trainer.checkpointed_complete_parent_step_v1(model) is value
passed("bool_zero_float_missing_nondict_and_other_counts_do_not_increment",len(events)==1 and len(stub_calls)==12)
response[0]=failure
try:trainer.checkpointed_complete_parent_step_v1(model)
except RuntimeError as error:passed("original_exception_identity_and_no_increment",error is failure and len(events)==1 and len(stub_calls)==13)
else:raise AssertionError("original exception swallowed")
response[0]=dict(whole_parent_optimizer_updates=1)
for i in range(614):assert trainer.checkpointed_complete_parent_step_v1(model) is response[0]
passed("only_successes_count_and_events_bound_at600",
    [e["successful_whole_parent_optimizer_updates"] for e in events]==[1]+list(range(10,601,10))
    and all(set(e)=={"event","pid","job","successful_whole_parent_optimizer_updates"} for e in events))
passed("every_stub_invocation_delegates_exactly_once",len(stub_calls)==627)
obs["install_progress_observer_v1"]()
passed("same_observer_hook_install_is_idempotent",FakeLoader.exec_module is combined_hook)
original_wrapped=trainer.checkpointed_complete_parent_step_v1
obs["wrap_trainer_v1"](trainer)
passed("same_trainer_wrap_is_idempotent",trainer.checkpointed_complete_parent_step_v1 is original_wrapped)
unrelated=types.SimpleNamespace(__file__="/fixture/unrelated.py")
FakeLoader("/fixture/unrelated.py").exec_module(unrelated)
passed("unrelated_load_delegates_once_without_observer",calls==[marker_path,target,"/fixture/unrelated.py"]
    and not hasattr(unrelated,"_C3_operational_progress_observer_v1"))
def broken_emit(value):raise KeyboardInterrupt("output-only failure")
isolated=types.SimpleNamespace(__file__=target,checkpointed_complete_parent_step_v1=stub)
obs["wrap_trainer_v1"](isolated,emit=broken_emit)
passed("emission_baseexception_never_changes_original_return",isolated.checkpointed_complete_parent_step_v1(model) is response[0])
FakeLoader.exec_module=base_exec
obs["os"].environ["ARGGNN_LOGICAL_JOB_NAME"]="different"
rejects("wrong_logical_job_rejected_before_hook_mutation",obs["install_progress_observer_v1"])
passed("wrong_job_keeps_mock_loader_unmodified",FakeLoader.exec_module is base_exec)
obs["os"].environ["ARGGNN_LOGICAL_JOB_NAME"]=obs["JOB"]
fake_sys.modules={"already":types.SimpleNamespace(__file__=target)}
rejects("already_loaded_trainer_rejected",obs["install_progress_observer_v1"])
passed("existing_trainer_rejection_keeps_mock_loader_unmodified",FakeLoader.exec_module is base_exec)
print(json.dumps(dict(schema="C3_observer_independent_pure_fixtures_v1",cases=results,cases_passed=len(results),
    actual_Torch_scientific_imports_hooks_model_steps_jobs_processes_probes_waits_signals_admissions_or_Git=0),indent=2,sort_keys=True))
