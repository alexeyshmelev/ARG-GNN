"""AST-isolated renewal verification against an in-memory filesystem only."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone,timedelta
import ast,copy,hashlib,io,json,types
ROOT_REAL=Path("/workspace-SR003.nfs2/ARG-GNN")
SOURCE_REL="research/reviews/H039_marker_repair_renewal_source_20261016_v1/marker_repair_renewal_v1.py"
source=(ROOT_REAL/SOURCE_REL).read_text()
files={};reads=[];symlinks=set()
class MemoryPath(PurePosixPath):
    def resolve(self):return self
    def is_file(self):return str(self) in files
    def is_symlink(self):return str(self) in symlinks
    def read_bytes(self):
        reads.append(str(self));return files[str(self)]
    def open(self,mode):
        assert mode=="rb"
        reads.append(str(self));return io.BytesIO(files[str(self)])
class FakeLoader:
    calls=[]
    def __init__(self,path):self.path=path
    def exec_module(self,module):
        self.calls.append(self.path)
        module._bound=bound
original_exec=FakeLoader.exec_module
fake_importlib=types.SimpleNamespace(machinery=types.SimpleNamespace(SourceFileLoader=FakeLoader))
fake_sys=types.SimpleNamespace(modules={})
ns=dict(Path=MemoryPath,datetime=datetime,timezone=timezone,timedelta=timedelta,
    copy=copy,hashlib=hashlib,json=json,importlib=fake_importlib,sys=fake_sys)
nodes=[n for n in ast.parse(source).body if isinstance(n,(ast.Assign,ast.FunctionDef))]
module=ast.Module(body=nodes,type_ignores=[]);ast.fix_missing_locations(module)
exec(compile(module,"<isolated_real_renewal_functions>","exec"),ns)
def put(rel,raw):files[str(ns["ROOT"]/rel)]=raw
for rel in (ns["SOURCE"],ns["BOOTSTRAP"],ns["OLD_SOURCE_REF"]["path"],
        ns["OLD_AUTHORITY_REF"]["path"],ns["OLD_BARRIER_REF"]["path"]):
    put(rel,(ROOT_REAL/rel).read_bytes())
now=datetime.now(timezone.utc)
cert=dict(schema="H039_marker_repair_expiry_renewal_root_certificate_v1",active=True,root_authorizer="root_agent",
    project_root=str(ns["ROOT"]),source_ref=ns["reference"](ns["SOURCE"]),
    bootstrap_ref=ns["reference"](ns["BOOTSTRAP"]),old_authority_ref=ns["OLD_AUTHORITY_REF"],
    old_repair_source_ref=ns["OLD_SOURCE_REF"],old_activation_barrier_ref=ns["OLD_BARRIER_REF"],
    reservation_sha256=ns["RESERVATION_SHA"],retained_allowance_bytes=15000000,accounting_credit_bytes=0,
    issued_at_utc=(now-timedelta(minutes=1)).isoformat(),renewed_expires_at_utc=(now+timedelta(days=1)).isoformat(),
    read_only_marker_authority_expiry_renewal=True,fresh_admissions_and_existing_read_close_authorized=True,
    all_allocation_expiries_unchanged=True,historical_journal_mutation_authorized=False,
    historical_source_or_binding_mutation_authorized=False,global_rebase_authorized=False,
    malformed_key_future_writes_or_relaunch_authorized=False,old_terminal_barrier_reused_without_new_absence_claim=True)
cert_path="fixture/certificate.json"
def certificate_ref():
    put(cert_path,json.dumps(cert,sort_keys=True).encode())
    return ns["reference"](cert_path)
ref=certificate_ref()
old=json.loads(files[str(ns["ROOT"]/ns["OLD_AUTHORITY_REF"]["path"])])
allocation=dict(expires_at_utc="original_allocation_expiry",allowance_bytes=123)
bound_calls=[]
def bound(record):
    bound_calls.append(copy.deepcopy(record))
    if record==ns["OLD_AUTHORITY_REF"]:return ns["_json"](record)
    return allocation
results=[]
def passed(name,ok=True):
    assert ok,name;results.append(dict(case=name,passed=True))
def rejects(name,call):
    try:call()
    except (ValueError,TypeError):passed(name)
    else:raise AssertionError(name)
ns["validate_certificate_v1"](ref)
passed("real_json_and_reference_validate_exact_in_memory_certificate")
target=str(ns["ROOT"]/ns["OLD_SOURCE_REF"]["path"])
private=types.SimpleNamespace(__file__=target,_bound=bound)
ns["_wrap_private_marker_v1"](private,ref)
before=copy.deepcopy(files);reads.clear();bound_calls.clear()
renewed=private._bound(ns["OLD_AUTHORITY_REF"])
passed("only_expiry_changed_and_original_reader_called_once",
    len(bound_calls)==1 and renewed["expires_at_utc"]==cert["renewed_expires_at_utc"]
    and {k:v for k,v in renewed.items() if k!="expires_at_utc"}=={k:v for k,v in old.items() if k!="expires_at_utc"})
expected=[ref["path"],ns["SOURCE"],ns["BOOTSTRAP"],ns["OLD_SOURCE_REF"]["path"],
    ns["OLD_AUTHORITY_REF"]["path"],ns["OLD_BARRIER_REF"]["path"]]
passed("every_effective_view_reads_all_six_exact_pins",
    all(str(ns["ROOT"]/p) in reads for p in expected))
passed("all_virtual_original_bytes_unchanged_after_view",files==before)
for name,path in [
    ("certificate",ref["path"]),("renewal_source",ns["SOURCE"]),("bootstrap",ns["BOOTSTRAP"]),
    ("old_repair_source",ns["OLD_SOURCE_REF"]["path"]),("old_authority",ns["OLD_AUTHORITY_REF"]["path"]),
    ("old_terminal_barrier",ns["OLD_BARRIER_REF"]["path"])]:
    key=str(ns["ROOT"]/path);saved=files[key];files[key]=saved+b"\n"
    rejects("every_view_rejects_changed_"+name+"_bytes",lambda:private._bound(ns["OLD_AUTHORITY_REF"]))
    files[key]=saved
passed("unrelated_allocation_return_identity_and_expiry_preserved",
    private._bound(dict(path="fixture/allocation.json",sha256="a"*64)) is allocation
    and allocation["expires_at_utc"]=="original_allocation_expiry")
for name,value in [
    ("renewed_expires_at_utc",(now-timedelta(seconds=1)).isoformat()),
    ("issued_at_utc",(now+timedelta(hours=1)).isoformat()),
    ("renewed_expires_at_utc",(now+timedelta(days=8)).isoformat()),
    ("renewed_expires_at_utc",now.replace(tzinfo=None).isoformat())]:
    saved=cert[name];cert[name]=value;bad_ref=certificate_ref()
    rejects("reject_time_"+str(len(results)),lambda:ns["validate_certificate_v1"](bad_ref))
    cert[name]=saved
ref=certificate_ref()
private=types.SimpleNamespace(__file__=target,_bound=bound)
ns["_wrap_private_marker_v1"](private,ref)
for name,value in [("retained_allowance_bytes",14999999),("accounting_credit_bytes",1),
    ("malformed_key_future_writes_or_relaunch_authorized",True),
    ("all_allocation_expiries_unchanged",False),("historical_journal_mutation_authorized",True)]:
    saved=cert[name];cert[name]=value;bad_ref=certificate_ref()
    rejects("reject_scope_"+name,lambda:ns["validate_certificate_v1"](bad_ref));cert[name]=saved
ref=certificate_ref()
rejects("reject_extra_ref_key",lambda:ns["_json"](dict(ref,extra=True)))
rejects("reject_wrong_certificate_sha",lambda:ns["_json"](dict(ref,sha256="0"*64)))
rejects("reject_bounded_json_read",lambda:ns["_json"](ref,1))
symlinks.add(str(ns["ROOT"]/cert_path))
rejects("reject_symlink",lambda:ns["_json"](ref));symlinks.clear()
rejects("reject_uncontained_path",lambda:ns["_file"]("/outside.json"))
rejects("reject_nondict_ref",lambda:ns["_json"]("not a ref"))
FakeLoader.exec_module=original_exec
ns["install_renewal_v1"](ref)
fresh=types.SimpleNamespace(__file__=target)
FakeLoader(target).exec_module(fresh)
passed("future_exact_mock_loader_wrapped_and_delegated_once",
    FakeLoader.calls==[target] and fresh._bound(ns["OLD_AUTHORITY_REF"])["expires_at_utc"]==cert["renewed_expires_at_utc"])
other=types.SimpleNamespace(__file__="/fixture/other.py")
FakeLoader("/fixture/other.py").exec_module(other)
passed("unrelated_mock_loader_unchanged",not hasattr(other,"_root_expiry_renewal_ref"))
FakeLoader.exec_module=original_exec
fake_sys.modules={"old":types.SimpleNamespace(__file__=target)}
rejects("existing_marker_consumer_rejected_without_mutation",lambda:ns["install_renewal_v1"](ref))
passed("mock_loader_unchanged_after_existing_consumer_rejection",FakeLoader.exec_module is original_exec)
print(json.dumps(dict(schema="H039_renewal_independent_pure_fixtures_v1",cases=results,cases_passed=len(results),
    actual_guard_imports_import_hooks_installs_admissions_jobs_or_mutable_state_reads=0),indent=2,sort_keys=True))
