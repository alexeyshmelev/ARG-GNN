# LAI bottleneck and one conditional next design

17 October 2026. Source/literature work only.

**The current record does not establish tree-constant readout as the dominant ancestry bottleneck. One precise untested representation choice is the reset of aligned raw-marker history at every inferred-tree interval.** The candidate below removes those resets while keeping the same native-hold output locations and complete graph computation. It is an implementable application hypothesis assembled from established operations. No new general GNN operator, predictive gain or architecture priority is established. Complete the already owned H058/ordered-marker results before deciding whether this additional test earns implementation.

## What the completed evidence actually says

Selected H050 stable-leaf memory has Present182 span accuracy 97.077844 ± 0.567395% and 1 kb boundary F1 18.380657 ± 1.3141%. Its continuation control has 97.000028 ± 0.497841% and 19.048847 ± 1.4275%. These are eight reused development parents, one optimizer seed and separately selected checkpoints. The small accuracy gain and lower F1 do not diagnose oversmoothing. Current-release ARGMix 94.4461 ± 1.1491% and the derived AP endpoint 93.7830 ± 0.8385% are pipeline comparisons with disclosed differences, not publication reproductions.

Native-hold output is a genuine restriction: a model cannot place a new switch strictly inside one hold. But three distinct questions must remain separate:

| Question | Existing answer and limit |
|---|---|
| Does a finer output partition permit more correctly classified span? | H057's completed 32-TRAIN-parent oracle gives Present182 99.892032 ± 0.009986% on native holds and 99.996475 ± 0.000208% on the original 100 bp grid. The paired headroom is only 0.104443 ± 0.009838 percentage points. This is a TRAIN representability result, not achievable gain or a H050 residual attribution. |
| Does native geometry exclude some 1 kb boundary matches? | Historical H038 has 1,094/4,008 true changes without an allowed hold edge within 1 kb, giving a class-agnostic geometric recall ceiling about 72.70%. This cannot be transferred numerically to H050 or treated as a span-accuracy ceiling. |
| Are all other misses explained by recognition? | H038 still missed 2,195 true changes with a nearby allowed candidate. It predicted 6,729 changes against 4,008 true changes. False internal islands ≤10 kb explained 35.46 ± 2.71% of extra boundaries. This supports a recognition/fragmentation problem as well as a location restriction. It does not identify its biological cause in H050. |

H044 localized SNP boxes barely changed accuracy (+0.005260 points) and reduced F1 from 18.674979% to 15.537416%. H046's support-excluded flank gain was only +0.011573 accuracy points. H048 graph-conditioned persistence lost to its matched confidence control on accuracy and F1. H043/H045 foreign states, H047 risk balancing and H050 higher-order history failed their registered utility rules. H040's tensor gain did not survive H042's stronger local-topology control. Preserve these negative findings.

Thus a claim that poor tracts are mainly caused by tree-constant prediction is too strong. A useful manuscript statement is: “Predictions are restricted to inferred-tree intervals. Their contribution to the remaining tract errors is unresolved.” No saved H050 geometry/typed-tract decomposition was opened or inferred here.

## The untested representation choice

The original SNP route encodes each sample's allele against eight source×age reference-frequency/mask channels and panel features, then mean/max pools within each native hold. Complete tree sweeps, structural residuals, sample EMA and the final genomic BiGRU remain important existing information routes.

H058 adds same-marker allele/source/age/path alignment before pooling. The separately owned ordered_marker_placement_v2 design retains the order of those 24 aligned channels through width-eight forward/reverse GRUs. Actual source explicitly initializes both hidden states to zero inside each hold and says they “reset only at a native hold.” Its protocol also says physical marker gaps are unused. Both placement arms reset identically. The final BiGRU connects holds only after their raw marker series has been summarized.

The missing comparison is therefore **same-query marker-state continuity across inferred-tree changes versus identical within-hold recurrence**. It is not “no SNPs,” “no LD,” “no order,” missing sample identity generally, or lack of a genomic recurrent layer. Nor is it a claim that fixed-width summaries mathematically cannot encode every relevant pattern. The source establishes a reset and the absence of this matched test; it does not establish that the reset causes errors.

Biologically, a change in genealogy need not change source ancestry. FLARE explicitly distinguishes pre-admixture donor switches from post-admixture events that can alter ancestry. Conversely, genuine ancestry transitions can occur near inferred-tree changes. Carry may preserve informative multi-marker continuity, or may wash out precisely the transitions that matter. Inferred trees and allele evidence derive from the same observations and are not independent likelihood factors.

## ONE candidate: sample-aligned marker carry before tree sweep two

Retain the complete selected TreeLoom body: all observed nodes/samples, both structural residuals, stable-leaf EMA, two shared complete-tree traversals, full genomic BiGRU and constant-native-hold readout. Keep the original H058 24-channel aligned marker construction and common mean/max residual identical in all added-route arms. No donor-copying latent state, ancestral-ID correspondence, CRF, truth feature or new output grid is introduced.

For original marker s, query q and native hold t(s), let phi_sq in R^24 be the existing aligned observed marker feature. Use the existing ordered module's weights:

    u_sq = tanh(P phi_sq),                  P:24 -> 8, no bias
    a_sq = GRU_forward(u_sq, a_previous,q)
    b_sq = GRU_reverse(u_sq, b_next,q)
    delta_tq = O tanh(V [a_last(t),q ; b_first(t),q]),
                                             V:16 -> 8, O:8 -> 32, no bias.

The proposed change is exactly the state join across consecutive native holds. Within a hold, block order, masking and marker consumption remain the original ordered-v2 algebra. Use true query identity across holds, not internal tree-node identity. Add delta at that query's actual sampled node before the second complete graph sweep, together with the unchanged common structural/sample-memory/marker injections.

At chromosome or connected-coverage endpoints initialize states to zero. Artificial compute blocks never reset or detach history. A hold with no markers consumes no recurrent step and passes the carry unchanged; its ordered injection remains zero. Missing marker rows and unavailable-evidence output masks follow the existing v2 rules in every arm. Do not add a learned gap gate or physical decay in this test: that would confound the reset question. No physical-distance invariance or calibrated ancestry persistence is claimed.

The ordered module retains 1,440 parameters (192 input, 864 recurrent, 128 rank-input, 256 output); H058 contributes 714. With the selected 32,325-parameter full body, the proposed added-route arms have analytically 34,479 parameters each. These counts and state-key integration are uninstantiated here. The intended common initializer is H050 stable_leaf_memory.pass_30, metadata SHA dbe458c394584eabf3de20d39063ea66dd58fbd0406a939da09835ce09e32cd7. Completed TRAIN and evaluation metadata agree on this reference; the checkpoint itself was not opened (COMMON_INITIALIZER_METADATA.v1.json). Both new output maps start zero, so the algebra preserves the common initializer; ROOT must qualify actual initialization and gradients separately.

## Decisive controls and a prospective test

Do not alter H058, the existing marker-placement test, H059 or H060. A distinct future registration must identify this new condition and its stronger common initializer. Four arms are sufficient:

1. **Identity carry:** the specified same-query joins.
2. **Native-hold reset:** exactly the same added route and weights, zero state at each original hold.
3. **Permuted carry:** same carried state and arithmetic, but at each native-hold boundary permute query states within permitted observed sampling-age groups using a fixed, outcome-independent nonidentity bijection. Leave each hold's marker evidence, tree, labels and output identities unchanged. Reverse traversal uses the inverse boundary join. Record moved/immovable support; if the null barely changes joins, do not interpret a tie as an informative identity test.
4. **Full continuation:** the unmodified full TreeLoom body trained from that same initializer for the same new budget. Its different parameter count is explicit; it controls extra training/common added evidence, while arms 1–3 isolate the join.

A carry/reset tie rejects useful cross-hold history at this budget. A carry/permuted tie rejects a sample-identity interpretation even if carry beats reset. Beating only continuation cannot establish the join mechanism.

For a future exploratory European test, freeze 32 full TRAIN parents, all 952 haplotypes/686 query outputs, every observed marker/tree and original physical support. Use fresh independent matched AdamW, seed101 and the original 30 passes/960 full-parent updates per arm (3,840 total). Preserve the original accuracy/lower-NLL/earlier-pass selection at passes5/10/15/20/25/30. All 192 arm×checkpoint×eightVAL prediction products precede any VAL truth. This is a proposed contract, not a registration or launch authorization.

A suitable frozen primary gate is at least +1.00 percentage point equal-parent Present182 1 kb boundary F1 over EACH control, no more than 0.05 point span-accuracy loss, no mean NLL regression and no loss of uncensored true ≤10 kb tract recall. Report paired parent effects/sample SD, correctly typed transitions, missed/matched/extra counts, false islands and false-switched bp/Mb. Gains obtained by deleting true short tracts fail. One optimizer seed on reused VAL remains discovery evidence. Independent dense-label parents and additional seeds would be required after a useful pilot. American sparse focals cannot establish dense boundary fidelity.

Implementation can reuse the existing positive-marker backend and directional GRU consumers, but whole-hold-only checkpointing is insufficient once carry crosses holds. A source integration must checkpoint/recompute marker blocks while retaining boundary states in autograd and pooling only the required hold endpoint summaries. Added recurrent work is O(S Q k(24+k)) for k=8, plus the inherited tree evidence/GNN work. There is no Q×reference state or pair tensor. Forward streaming state is O(Qk); full gradient/checkpoint/bidirectional storage remains additional and can scale with marker blocks. No runtime, peak memory or fit has been measured. ROOT owns feasibility, source review and actual admission.

## Primary-source prior art and novelty decision

| Primary text actually inspected | Consequence |
|---|---|
| Cho et al.2014, “Learning Phrase Representations using RNN Encoder–Decoder for Statistical Machine Translation,” arXiv1406.1078v3, §§2.1–2.3. [Text](https://arxiv.org/html/1406.1078v3) | Variable-length recurrent encoding and reset/update gated hidden state are established. Carrying this GRU across a boundary is not a new recurrence. |
| Rossi et al.2020, “Temporal Graph Networks for Deep Learning on Dynamic Graphs,” arXiv2006.10637v3, memory/message/embedding modules. [Text](https://arxiv.org/html/2006.10637v3) | Persistent entity memory combined with graph operators and GRU memory updates is explicit. Genomic position is not causal event time, so no TGN forecasting guarantee transfers. |
| Whitehouse, Ray and Schrider2024, “Tree Sequences as a General-Purpose Tool for Population Genetic Inference,” DOI10.1093/molbev/msae223, “GCN Architecture and Training,” Fig1. [Primary](https://pmc.ncbi.nlm.nih.gov/articles/PMC11600592/) | Complete marginal-tree graph learning followed by node/tree GRUs already exists. Its tree-sequence pooling task differs from per-query raw-marker carry returned before a second tree sweep; generic ordered-tree GNN priority is unavailable. |
| Browning, Waples and Browning2023, “Fast, accurate local ancestry inference with FLARE,” DOI10.1016/j.ajhg.2022.12.010, “Hidden Markov model.” [Primary](https://pmc.ncbi.nlm.nih.gov/articles/PMC9943733/) | Marker-wise continuity and separating donor changes from ancestry changes are established biological modeling principles. This candidate has no explicit donor/source posterior and supplies none of FLARE's probabilistic interpretation. |

**Established:** all primitives, stable identity carry and graph/recurrent composition. **Possible application contribution:** an independently useful, controlled coupling of tree-aligned marker history across native inferred-tree transitions, fed back into complete-tree inference. **Actually new and evidenced here:** the project-specific untested condition is precisely specified; no architecture priority or efficacy is evidenced. This bounded check is not an exhaustive publication-priority search. Failed RFMix/UnifiedLAI retrievals are retained and supply no claims.

**Decision:** keep as one conditional utility design, not the qualified novel operator the broader project still needs. Await current aligned-marker/placement outcomes and their frozen tract diagnostics. If ROOT then elects to pursue it, the next scientific action is a new prospectively registered carry/reset/permuted/continuation comparison after independent source review and actual feasibility. Do not launch from this document, replay an answered pilot or turn an unsuccessful primitive audit into a novelty claim.

Scope: only instructions, source/manuscript text, concise completed metadata/reviews and public literature were read. Only this directory was written. No scientific arrays, new truth/test/checkpoints, model import, numerical/scientific experiment, process/resource/GPU/guard/state inspection, installation, accounting or Git operation occurred. Primary excerpt hashes and internal source hashes accompany this report.
