"""Root-only5MiB archive administration under current storage guard."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,hashlib,json,os,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE=ROOT/"research/reviews/American_C3_native_MLM_amendment_v10"
ADMIN=HERE/"root_execution_admin_v2"
WRITES=ADMIN/"worker_metadata"
ARCHIVE=ROOT/"research/reviews/American_C3_native_MLM_full_fit_v8/v8_failed_root_archive_v10"
CAP=5242880
sys.path[:0]=[str(HERE),str(ROOT),str(ROOT/"src")]
from research.reviews.H047_GPU45_cohort_risk_root_source_v1 import root_common_v1 as c
def ref(path):
 p=Path(path)
 if not p.is_absolute():p=ROOT/p
 assert p.resolve()==p and p.is_relative_to(ROOT)
 return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(record):
 assert set(record)=={"path","sha256"} and ref(record["path"])==record
 return json.loads((ROOT/record["path"]).read_text())
def save(name,value):
 path=(WRITES if WRITES.exists() else ADMIN)/name
 raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
 assert len(raw)<65536
 with path.open("xb") as f:
  f.write(raw)
  f.flush()
  os.fsync(f.fileno())
 return ref(path)
def closure():
 d=read(ref(HERE/"execution_source_closure.json"))
 assert len(d["source_sha256"])==48
 for path,digest in d["source_sha256"].items():
  assert ref(path)["sha256"]==digest
 return d
def admit():
 d=closure()
 assert not ADMIN.exists() and not ARCHIVE.exists()
 ADMIN.mkdir()
 now=datetime.now(timezone.utc)
 expiry=(now+timedelta(hours=18)).isoformat()
 runtime=save("runtime.json",dict(root_authorizer="root_agent",job_id="native-v10-preserve-failed-v8-admin-v1",
  CPU_only=True,GPU_authorized=False,archive_allowance_bytes=CAP,expires_at_utc=expiry))
 m,_=c.load_guard_v1(consumer=False)
 with m.budget.v4.mutex(ROOT):state=m._state_locked(c.CORE,c.BASE,fresh=True)
 actual=[ref(path) for path in d["source_sha256"] if path.startswith(str(HERE.relative_to(ROOT))+"/")]
 consumers=c.unique([*state[3].values(),*actual,ref(__file__),runtime,ref(HERE/"execution_source_closure.json"),
  ref(HERE/"source_handoff.json"),ref(HERE/"opaque_metadata_root_approval.inactive.json"),
  ref(HERE/"limited_writer_state.inactive.json"),ref(HERE/"root_archive_authority.inactive.json"),
  ref(HERE/"execution_authority.inactive.json"),ref("research/reviews/H047_GPU45_cohort_risk_root_source_v1/root_common_v1.py"),
  ref("research/reviews/H042_GPU45_clade_flags_root_source_v1/root_driver.py"),c.V4_REF,c.MEMO_REF])
 request=dict(key="H041/native-v10-preserve-failed-v8-admin-v2",output=str(ARCHIVE),
  auxiliary_scopes=[str(WRITES)],reserved_bytes=CAP,consumer_bindings=consumers)
 assert len(consumers)<=64
 m.budget.v4.scope_spec(ROOT,request)
 auth=m.operation_draft_v1("reserve",request,expected_before=m._pins(state[2]),bindings=state[3])
 auth.update(active=True,expires_at_utc=expiry)
 ar=save("reserve_authority.json",auth)
 receipt=m.apply_reserve_v1(ar,expected_source_sha256=c.CORE,expected_launcher_sha256=c.BASE)
 save("reserve_receipt.json",receipt)
 storage=dict(kind="project_budget_v9_storage_record",active=True,consumer_uses_v9_guard=True,accounting_mode=m.MODE,
  job_id="native-v10-preserve-failed-v8-admin-v1",output_directory=str(ARCHIVE.relative_to(ROOT)),reserved_new_bytes=CAP,
  reservation=receipt["value"],expires_at_utc=expiry,initial_ledger_pins=receipt["initial_ledger_pins"],
  completed_overlay_policy_ref=c.POLICY_REF,
  budget_components=dict(implementation=ref(m.budget.SOURCE_REL),launcher=ref(m.budget.LAUNCHER_REL),consumer_adapter=c.GUARD_REF))
 sr=save("storage.json",storage)
 print(json.dumps(dict(event="native_v10_archive_admin_admitted",storage_ref=sr,reserved_bytes=CAP)),flush=True)
def archive():
 closure()
 storage=read(ref(ADMIN/"storage.json"))
 assert ref(__file__) in storage["reservation"]["consumer_bindings"]
 m,_=c.load_guard_v1(consumer=True)
 m.budget_check_v9(storage,boundary=True,required_write_bytes=65536)
 assert not WRITES.exists()
 WRITES.mkdir()
 import current_writer_proof_v10 as proof
 import terminal_namespace_v10 as ns
 from root_archive_v10 import preserve_failed_v8
 policy=json.loads((HERE/"opaque_metadata_root_approval.inactive.json").read_text())
 policy.update(active=True,root_accepts_exact_opaque_metadata_residual_uncertainty=True,
  all_future_v8_v9_launch_resume_write_capabilities_cooperatively_revoked=True)
 policy_ref=save("opaque_metadata_root_approval.active.json",policy)
 policy=proof.read_exception_approval(policy_ref)
 observed=proof.observe_current_state()
 proof._validate_observation(observed,policy)
 sockets=ns.socket_candidates(proof.TMP)
 paths=[row["path"] for row in sockets]
 matches=ns.kernel_listeners(paths,Path("/proc/net/unix").read_text())
 assert not matches
 cert=json.loads((HERE/"limited_writer_state.inactive.json").read_text())
 cert.update(active=True,current_writer_observation=observed,exact_old_kernel_listener_paths=paths,
  exact_old_kernel_listener_matches=matches,root_exception_approval_ref=policy_ref)
 proof.validate_static_certificate(cert)
 cert_ref=save("limited_writer_state.active.json",cert)
 auth=json.loads((HERE/"root_archive_authority.inactive.json").read_text())
 auth.update(active=True,archive_failed_v8_by_same_filesystem_rename=True,narrow_dead_socket_cleanup_after_metadata=True,
  old_writer_absence_ref=cert_ref,root_exception_approval_ref=policy_ref)
 save("root_archive_authority.active.json",auth)
 receipt=preserve_failed_v8(ARCHIVE,authority=auth)
 rr=ref(ARCHIVE/"archive_receipt.json")
 m.budget_check_v9(storage,boundary=True)
 execution=json.loads((HERE/"execution_authority.inactive.json").read_text())
 execution.update(active=True,all_v8_launch_resume_write_capabilities_cooperatively_revoked=True,
  all_future_v8_v9_launch_resume_write_capabilities_cooperatively_revoked=True,
  archive_receipt_ref=rr,old_writer_absence_ref=cert_ref,root_exception_approval_ref=policy_ref,
  dead_owned_socket_cleanup_after_preserved_metadata_authorized=True,
  checkpoint_latest_regular_copy_after_drain_authorized=True)
 er=save("execution_authority.active.json",execution)
 print(json.dumps(dict(event="native_v10_failed_v8_preserved_execution_ready",
  archive_receipt_ref=rr,execution_authority_ref=er,
  retained_archive_and_metadata_bytes=receipt["retained_archive_and_metadata_bytes"],
  GPU_execution_started=False)),flush=True)
def main():
 p=argparse.ArgumentParser()
 g=p.add_mutually_exclusive_group(required=True)
 g.add_argument("--admit",action="store_true")
 g.add_argument("--archive",action="store_true")
 a=p.parse_args()
 if a.admit:admit()
 else:archive()
if __name__=="__main__":main()
