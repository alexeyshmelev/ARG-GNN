"""Focused pure checks for v10 exact opaque-field root exception."""
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import ast,copy,hashlib,importlib.util,json,os,sys,time,unittest
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(HERE))
def load():
 spec=importlib.util.spec_from_file_location("current_writer_proof_v10",HERE/"current_writer_proof_v10.py")
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def fixture():
 m=load();proof=json.loads((HERE/"actual_observable_inventory_for_root_review_v10.json").read_text())
 policy=json.loads((HERE/"opaque_metadata_root_approval.inactive.json").read_text())
 policy.update(active=True,root_accepts_exact_opaque_metadata_residual_uncertainty=True,
  all_future_v8_v9_launch_resume_write_capabilities_cooperatively_revoked=True)
 cert=json.loads((HERE/"limited_writer_state.inactive.json").read_text())
 cert.update(active=True,root_exception_approval_ref={"path":"synthetic/root.json","sha256":"0"*64},
  current_writer_observation=proof,exact_old_kernel_listener_paths=[m.TMP+"/mlm/pymp-own/listener-own"],
  exact_old_kernel_listener_matches=[])
 return m,proof,policy,cert
class Focused(unittest.TestCase):
 def test_partial_permission_metadata_retains_readable_ties(self):
  m,proof,policy,cert=fixture()
  metadata=(b"python\0"+(m.OLD_REL+"/native_child_v1.py").encode()+b"\0",b"",{},("environ","fd_targets"))
  with patch.object(m,"_identity",return_value=(7,"S")),patch.object(Path,"lstat",return_value=NS(st_uid=1000)),patch.object(m,"_metadata",return_value=metadata):
   reasons,denied=m._classify(123,7,1000,time.monotonic()+10)
  self.assertIn("exact_old_source_token",reasons);self.assertEqual(denied,["environ","fd_targets"])
  with patch.object(m,"_snapshot",return_value={123:7}),patch.object(m,"_classify",return_value=([],denied)):
   result=m.scan_observable_same_uid()
  self.assertFalse(result["all_same_uid_metadata_fields_readable"])
  self.assertFalse(result["complete_old_writer_absence_claimed"])
  self.assertEqual(result["opaque_processes"],[{"pid":123,"start_ticks":7,"denied_fields":denied}])
  self.assertNotIn("python",json.dumps(result))
 def test_exact_opaque_identity_fields_and_no_observable_match(self):
  m,proof,policy,cert=fixture();m._validate_observation(proof,policy)
  for change in ("PID","start","field","match","historical"):
   bad=copy.deepcopy(proof)
   if change=="PID":bad["current_same_uid_inventory"]["opaque_processes"][0]["pid"]+=1
   if change=="start":bad["current_same_uid_inventory"]["opaque_processes"][0]["start_ticks"]+=1
   if change=="field":bad["current_same_uid_inventory"]["opaque_processes"][0]["denied_fields"]=["environ"]
   if change=="match":bad["current_same_uid_inventory"]["current_observable_exact_tie_matches"]=[{"pid":123}]
   if change=="historical":bad["historical_ids_complete"]=True
   with self.assertRaises(ValueError):m._validate_observation(bad,policy)
 def test_inactive_root_approval_blocks_and_actual_kernel_check_unwaivable(self):
  m,proof,policy,cert=fixture()
  directive={"schema":"native_MLM_v10_narrow_root_directive_v1","complete_metadata_absence_claim_revoked":True}
  def root_read(record):return directive if record==m.DIRECTIVE_REF else policy
  with patch.object(m,"_read_json_ref",side_effect=root_read):
   m.read_exception_approval(cert["root_exception_approval_ref"])
   policy["active"]=False
   with self.assertRaises(ValueError):m.read_exception_approval(cert["root_exception_approval_ref"])
   policy["active"]=True
  import terminal_namespace_v10 as ns
  def gone(*args):raise ProcessLookupError()
  with patch.object(m,"read_exception_approval",return_value=policy),patch.object(m,"scan_observable_same_uid",return_value=proof["current_same_uid_inventory"]),patch.object(m.os,"kill",side_effect=gone) as kp,patch.object(m.os,"killpg",side_effect=gone) as kg,patch.object(Path,"read_text",return_value=""),patch.object(ns,"kernel_listeners",return_value=[]):
   out=m.prove_permitted_observable_state(cert)
   self.assertEqual(kp.call_count,8);self.assertEqual(kg.call_count,8)
   self.assertTrue(all(c.args[1]==0 for c in kp.call_args_list+kg.call_args_list))
   self.assertFalse(out["complete_old_writer_absence_claimed"])
  with patch.object(m,"read_exception_approval",return_value=policy),patch.object(m,"observe_current_state",return_value=proof),patch.object(Path,"read_text",return_value=""),patch.object(ns,"kernel_listeners",return_value=["own-live"]):
   with self.assertRaises(ValueError):m.prove_permitted_observable_state(cert)
 def test_fail_closed_churn_and_caps(self):
  m,_,_,_=fixture()
  with patch.object(m,"_snapshot",side_effect=[{1:1},{2:2}]*3),patch.object(m,"_classify",return_value=([],[])):
   with self.assertRaises(ValueError):m.scan_observable_same_uid()
  with patch.object(m.os,"open",return_value=10),patch.object(m.os,"close"),patch.object(m.os,"read",side_effect=[b"abc",b"def"]):
   with self.assertRaises(ValueError):m._read(Path("/synthetic"),4)
  with patch.object(m.os,"kill",return_value=None):
   with self.assertRaises(ValueError):m.observe_known_roots_and_groups()
 def test_direct_wiring_no_live_rescan_and_science_preserved(self):
  for name in ("amendment_v10.py","root_archive_v10.py","root_native_driver_v1.py"):
   s=(HERE/name).read_text();tree=ast.parse(s)
   for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=="prove_permitted_observable_state":
     self.assertEqual(len(node.args),1,name)
  s=(HERE/"amendment_v10.py").read_text();tree=ast.parse(s)
  for name in ("validate_authority","check_lifetime"):
   fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
   self.assertNotIn("prove_permitted_observable_state",ast.get_source_segment(s,fn))
  archive=(HERE/"root_archive_v10.py").read_text()
  self.assertNotIn("prove_old_writers_absent",archive);self.assertIn("original+renamed",archive)
  old=HERE.with_name("American_C3_native_MLM_amendment_v9")
  def function(path,name):
   tree=ast.parse(path.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
   return ast.dump(node,include_attributes=False)
  for name in ("_io_config","optimizer_counter_evidence"):
   self.assertEqual(function(HERE/"native_child_v1.py",name),function(old/"native_child_v1.py",name))
  self.assertEqual((HERE/"owned_lifecycle_v2.py").read_bytes(),(old/"owned_lifecycle_v2.py").read_bytes())
  def cls(path,name):
   return ast.dump(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name==name),include_attributes=False)
  self.assertEqual(cls(HERE/"context_factory_v1.py","_PrimitiveJSONWriter"),cls(old/"context_factory_v1.py","_PrimitiveJSONWriter"))
 def test_frozen_v8_v9_and_current_sources_exact(self):
  old=HERE.with_name("American_C3_native_MLM_amendment_v9")
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
  self.assertEqual(sha(old/"source_handoff.json"),"a89af75d833a8b6cb4c7b805017c5693b07fe33b2b0b16b4750c3ae5fc0a1d9b")
  self.assertEqual(sha(old/"execution_source_closure.json"),"61c36c6b7fba57526ceb135a7cfe3222849e17ee69fd0f50210beede89ba4a43")
  for path,digest in json.loads((old/"execution_source_closure.json").read_text())["source_sha256"].items():
   self.assertEqual(sha(ROOT/path),digest)
  for path,digest in json.loads((HERE/"execution_source_closure.json").read_text())["source_sha256"].items():
   self.assertEqual(sha(ROOT/path),digest)
  for name in ("opaque_metadata_root_approval.inactive.json","limited_writer_state.inactive.json","root_archive_authority.inactive.json","execution_authority.inactive.json"):
   self.assertFalse(json.loads((HERE/name).read_text())["active"])
if __name__=="__main__":unittest.main()
