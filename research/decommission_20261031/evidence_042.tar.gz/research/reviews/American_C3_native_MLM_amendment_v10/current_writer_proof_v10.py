"""V10 limited observable metadata inventory under exact root-approved opaque identities.

No complete metadata or complete old-writer absence claim is made. Inert on import.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat,time
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
PROC=Path("/proc")
KEY="H041/American-C3-native-MLM-full30mb-mlm-fit-v8"
JOB="American-C3-native-MLM-full30mb-mlm-fit-v8"
KNOWN_ROOTS=(2817234,2817625,2817931,2818200)
KNOWN_GROUPS=KNOWN_ROOTS
DIRECTIVE_REF={"path":"research/reviews/American_C3_native_MLM_v10_root_directive_v1/directive.json",
 "sha256":"9c762e3d267435519baad40c08509d75a38f020ed9203f2766f15a8f1bc24634"}
OLD_REL="research/reviews/American_C3_native_MLM_full_fit_v8"
OUTPUT=str(ROOT/"experiments/results/American_C3_native_MLM_full30mb_mlm_fit_v8")
TMP=str(ROOT/".runtime/tmp/c3full8/f")
AUX=str(ROOT/OLD_REL/"admitted_mlm_v1/worker_aux")
SOURCE_TOKENS={"arggnn.american_c3_native_mlm_full_fit_v8","src/arggnn/american_c3_native_mlm_full_fit_v8.py",
 str(ROOT/"src/arggnn/american_c3_native_mlm_full_fit_v8.py")}
for name in ("root_native_driver_v1.py","supervisor_v1.py","native_child_v1.py"):
 SOURCE_TOKENS.update({OLD_REL+"/"+name,str(ROOT/OLD_REL/name)})
# Frozen inactive v9 entrypoints are also cooperatively revoked old capabilities.
V9_REL="research/reviews/American_C3_native_MLM_amendment_v9"
for name in ("root_native_driver_v1.py","entry_v9.py","launcher_v9.py","supervisor_v1.py","native_child_v1.py"):
 SOURCE_TOKENS.update({V9_REL+"/"+name,str(ROOT/V9_REL/name)})
SCOPES=(OUTPUT,TMP,AUX)
MAX_PROCESSES=8192
MAX_FDS=4096
MAX_SECONDS=15.
class Changed(RuntimeError):pass
def require(value,message):
 if not value:raise ValueError(message)
def _time_limit(deadline):
 require(time.monotonic()<=deadline,"Current observable metadata deadline exceeded")
def _read(path,cap):
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 try:
  chunks=[];total=0
  while True:
   block=os.read(fd,min(65536,cap+1-total))
   if not block:break
   chunks.append(block);total+=len(block)
   require(total<=cap,"Metadata cap exceeded; no truncated prefix accepted")
  return b"".join(chunks)
 finally:os.close(fd)
def _identity(pid):
 values=_read(PROC/str(pid)/"stat",8192).decode().rsplit(")",1)[1].split()
 return int(values[19]),values[0]
def _snapshot(uid,deadline):
 _time_limit(deadline);dirs=[]
 for path in PROC.iterdir():
  if not path.name.isdecimal():continue
  dirs.append(path);require(len(dirs)<=MAX_PROCESSES,"Complete bounded current PID enumeration")
 result={}
 for path in dirs:
  _time_limit(deadline)
  try:
   if path.lstat().st_uid!=uid:continue
   start,state=_identity(int(path.name))
   if path.lstat().st_uid!=uid:raise Changed("UID changed")
   result[int(path.name)]=start
  except FileNotFoundError:continue
 return result
def _fd_targets(pid,deadline):
 result={};opaque=False;count=0
 try:
  with os.scandir(PROC/str(pid)/"fd") as entries:
   for entry in entries:
    _time_limit(deadline);count+=1
    require(count<=MAX_FDS,"Complete per-process fd enumeration cap")
    try:result[entry.name]=os.readlink(entry.path)
    except PermissionError:opaque=True
    except FileNotFoundError:raise Changed("FD membership changed")
 except PermissionError:opaque=True
 return result,opaque
def _metadata(pid,deadline):
 _time_limit(deadline);denied=[];parts=[]
 for name,cap in (("cmdline",131072),("environ",1048576)):
  try:parts.append(_read(PROC/str(pid)/name,cap))
  except PermissionError:parts.append(b"");denied.append(name)
 fds,opaque=_fd_targets(pid,deadline)
 if opaque:denied.append("fd_targets")
 return parts[0],parts[1],fds,tuple(sorted(denied))
def _under(value,scope):return value==scope or value.startswith(scope+"/")
def _path_reasons(value):
 if value.endswith(" (deleted)"):value=value[:-10]
 result=[]
 if value in SOURCE_TOKENS:result.append("exact_old_source_token")
 if any(_under(value,s) for s in SCOPES):result.append("exact_old_scope_path")
 if any(_under(value,s[len(str(ROOT))+1:]) for s in SCOPES):result.append("exact_old_relative_scope_path")
 return result
def _classify(pid,start,uid,deadline):
 try:
  first,state=_identity(pid)
  if first!=start or (PROC/str(pid)).lstat().st_uid!=uid:raise Changed("PID identity/UID changed")
  if state in ("Z","X"):return [],[]
  one=_metadata(pid,deadline);two=_metadata(pid,deadline)
  last,_=_identity(pid)
  if one!=two or last!=start or (PROC/str(pid)).lstat().st_uid!=uid:raise Changed("Observable metadata changed")
 except FileNotFoundError:raise Changed("Process vanished during observation")
 argv,env,fds,denied=one;reasons=set()
 for raw in argv.split(bytes([0])):
  if not raw:continue
  value=raw.decode("utf-8",errors="surrogateescape")
  if value in (JOB,"--job="+JOB):reasons.add("exact_old_job_argv")
  reasons.update(_path_reasons(value))
 for raw in env.split(bytes([0])):
  if b"=" not in raw:continue
  key,value=raw.split(b"=",1);value=value.decode("utf-8",errors="surrogateescape")
  if key in (b"ARGGNN_JOB_NAME",b"ARGGNN_LOGICAL_JOB_NAME") and value==JOB:
   reasons.add("exact_old_job_environment")
  reasons.update(_path_reasons(value))
 for value in fds.values():reasons.update(_path_reasons(value))
 return sorted(reasons),list(denied)
def scan_observable_same_uid():
 uid=os.geteuid();deadline=time.monotonic()+MAX_SECONDS
 for attempt in range(3):
  try:
   before=_snapshot(uid,deadline);matches=[];opaque=[]
   for pid,start in sorted(before.items()):
    reasons,denied=_classify(pid,start,uid,deadline)
    if reasons:matches.append(dict(pid=pid,start_ticks=start,match_reasons=reasons))
    if denied:opaque.append(dict(pid=pid,start_ticks=start,denied_fields=denied))
   after=_snapshot(uid,deadline)
   if before!=after:raise Changed("Same-UID PID/start membership changed")
   return dict(complete_stable_same_uid_PID_start_enumeration=True,
    all_same_uid_metadata_fields_readable=not opaque,complete_old_writer_absence_claimed=False,
    observer_effective_uid=uid,same_uid_processes_enumerated=len(before),
    current_observable_exact_tie_matches=matches,opaque_processes=opaque,
    unrelated_process_contents_recorded=False,attempts=attempt+1,
    process_scope="proc directory owner uid equals observer effective uid",
    bounds=dict(max_processes=MAX_PROCESSES,max_fds_per_process=MAX_FDS,
     cmdline_bytes=131072,environ_bytes=1048576,seconds=MAX_SECONDS))
  except Changed:
   if attempt==2:raise ValueError("Observable process inventory unstable; no permitted state claimed")
 raise ValueError("No stable observable inventory")
def observe_known_roots_and_groups():
 roots=[];groups=[];now=lambda:datetime.now(timezone.utc).isoformat()
 for pid in KNOWN_ROOTS:
  try:os.kill(pid,0)
  except ProcessLookupError:roots.append(dict(pid=pid,absent=True,method="targeted os.kill(pid,0) ESRCH",checked_utc=now()))
  else:raise ValueError("Known old root present/reused; blocked")
 for group in KNOWN_GROUPS:
  try:os.killpg(group,0)
  except ProcessLookupError:groups.append(dict(group=group,absent=True,method="targeted os.killpg(group,0) ESRCH",checked_utc=now()))
  else:raise ValueError("Known original process group remains; blocked")
 return roots,groups
def observe_current_state():
 observe_known_roots_and_groups();scan=scan_observable_same_uid()
 roots,groups=observe_known_roots_and_groups()
 return dict(schema="native_MLM_limited_observable_writer_inventory_v10",
  checked_utc=datetime.now(timezone.utc).isoformat(),historical_ids_complete=False,
  historical_descendant_ids_lost=True,native_wait_exit="UNKNOWN",actual_optimizer_updates="UNKNOWN",
  known_old_roots=roots,known_original_groups=groups,current_same_uid_inventory=scan,
  complete_old_writer_absence_claimed=False,opaque_metadata_outside_observation=True,
  external_NFS_other_UID_and_remote_host_writers_outside_observation=True)
def _read_json_ref(record):
 require(type(record) is dict and set(record)=={"path","sha256"},"Exact bounded root metadata ref")
 path=ROOT/record["path"]
 require(path.resolve()==path and path.is_relative_to(ROOT),"Canonical own root metadata")
 s=path.lstat()
 require(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=65536,"Bounded regular root metadata")
 raw=_read(path,65536)
 require(hashlib.sha256(raw).hexdigest()==record["sha256"],"Exact root metadata bytes")
 return json.loads(raw)
def read_exception_approval(record):
 policy=_read_json_ref(record)
 directive=_read_json_ref(DIRECTIVE_REF)
 require(directive["schema"]=="native_MLM_v10_narrow_root_directive_v1"
  and directive["complete_metadata_absence_claim_revoked"] is True,"Exact root source exception")
 require(policy["schema"]=="native_MLM_v10_exact_opaque_metadata_root_approval_v1"
  and policy["root_authorizer"]=="root_agent" and policy["active"] is True
  and policy["key"]==KEY and policy["source_directive_ref"]==DIRECTIVE_REF
  and policy["root_accepts_exact_opaque_metadata_residual_uncertainty"] is True
  and policy["complete_old_writer_absence_claimed"] is False
  and policy["historical_ids_complete"] is False and policy["historical_descendant_ids_lost"] is True
  and policy["all_future_v8_v9_launch_resume_write_capabilities_cooperatively_revoked"] is True,
  "Explicit root approval of exact opaque identities; no blanket permission waiver")
 rows=policy["opaque_process_allowlist"]
 require(type(rows) is list and len(rows)<=32 and all(set(r)=={"pid","start_ticks","denied_fields"}
  and type(r["pid"]) is int and r["pid"]>0 and type(r["start_ticks"]) is int and r["start_ticks"]>0
  and r["denied_fields"]==sorted(set(r["denied_fields"])) and r["denied_fields"]
  and set(r["denied_fields"])<={"cmdline","environ","fd_targets"} for r in rows)
  and len({(r["pid"],r["start_ticks"]) for r in rows})==len(rows),"Exact bounded opaque identity/field allowlist")
 return policy
def _validate_observation(proof,policy):
 require(proof["schema"]=="native_MLM_limited_observable_writer_inventory_v10"
  and proof["historical_ids_complete"] is False and proof["historical_descendant_ids_lost"] is True
  and proof["native_wait_exit"]=="UNKNOWN" and proof["actual_optimizer_updates"]=="UNKNOWN"
  and proof["complete_old_writer_absence_claimed"] is False
  and [r["pid"] for r in proof["known_old_roots"]]==list(KNOWN_ROOTS)
  and [r["group"] for r in proof["known_original_groups"]]==list(KNOWN_GROUPS)
  and all(r["absent"] is True for r in proof["known_old_roots"]+proof["known_original_groups"])
  and proof["current_same_uid_inventory"]["complete_stable_same_uid_PID_start_enumeration"] is True
  and proof["current_same_uid_inventory"]["current_observable_exact_tie_matches"]==[]
  and proof["current_same_uid_inventory"]["unrelated_process_contents_recorded"] is False,
  "Known roots/groups absent and no observable exact old ties")
 rows=proof["current_same_uid_inventory"]["opaque_processes"]
 key=lambda r:(r["pid"],r["start_ticks"],tuple(r["denied_fields"]))
 require(sorted(map(key,rows))==sorted(map(key,policy["opaque_process_allowlist"])),
  "Exact observed opaque PID/start/field set differs from root approval; blocked")
 return proof
def validate_static_certificate(cert):
 require(cert["schema"]=="native_MLM_limited_current_writer_root_certificate_v10"
  and cert["root_authorizer"]=="root_agent" and cert["active"] is True and cert["key"]==KEY
  and cert["historical_ids_complete"] is False and cert["historical_descendant_ids_lost"] is True
  and cert["complete_old_writer_absence_claimed"] is False
  and cert["native_wait_exit"]=="UNKNOWN" and cert["actual_optimizer_updates"]=="UNKNOWN"
  and cert["exact_old_kernel_listener_matches"]==[]
  and type(cert["exact_old_kernel_listener_paths"]) is list
  and 1<=len(cert["exact_old_kernel_listener_paths"])<=256
  and all(type(x) is str and _under(x,TMP) for x in cert["exact_old_kernel_listener_paths"])
  and cert["external_NFS_writers_outside_observation"] is True,"Honest limited current-state root certificate")
 policy=read_exception_approval(cert["root_exception_approval_ref"])
 _validate_observation(cert["current_writer_observation"],policy)
 return cert
def read_certificate(record):return validate_static_certificate(_read_json_ref(record))
def prove_permitted_observable_state(cert):
 """Actual unwaivable roots/groups/kernel checks plus root-permitted limited inventory."""
 validate_static_certificate(cert);policy=read_exception_approval(cert["root_exception_approval_ref"])
 proof=observe_current_state();_validate_observation(proof,policy)
 from terminal_namespace_v10 import kernel_listeners
 matches=kernel_listeners(cert["exact_old_kernel_listener_paths"],Path("/proc/net/unix").read_text())
 require(matches==[],"Exact old own kernel listener remains; exception cannot waive this")
 proof["exact_old_kernel_listener_matches"]=matches
 proof["exact_old_kernel_listener_paths"]=cert["exact_old_kernel_listener_paths"]
 proof["root_exception_approval_ref"]=cert["root_exception_approval_ref"]
 proof["root_accepts_exact_opaque_metadata_residual_uncertainty"]=True
 return proof
