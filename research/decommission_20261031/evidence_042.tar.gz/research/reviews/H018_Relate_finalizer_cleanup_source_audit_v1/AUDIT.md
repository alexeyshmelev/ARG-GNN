# H018 Relate finalizer cleanup source audit

The retained v2 native process genuinely exited 1 during final cleanup. This review does not accept that exit, reuse its outputs, or authorize replay. Its failed reservation remains charged. The strongest source-backed explanation is an open painting-reader descriptor combined with NFS unlink semantics. The actual errno and installed binary/source identity are unknown.

## Evidence and causal chain

- Retained `worker_aux_v2/relate.log` reports 40 haplotypes, all 512 SNPs, topology and branch inference in section 0, combining, and finalization with zero nonmapping/flipped SNPs, followed by `Could not delete directory native/chunk_0/paint/.`. The direct OS wait is 256, actual exit 1, and the owned group drained. The controller reports no converter wait and no completion.
- Exact-commit `filesystem.cpp` lines 25–37 calls POSIX `rmdir(sPath)`, prints no errno, retries zero times, and exits 1 on failure. The final dot is message punctuation. The argument from `Finalize.cpp` line 287 is `native/chunk_0/paint/`.
- `BuildTopology.cpp` line 34 points at `native/chunk_0/paint/relate`. `anc_builder.cpp` lines 59 and 221 open section painting files as local `FILE* pFile`. Neither complete repaint method closes that handle. The ordinary path is reached through `BuildTopology` (398–434), `DistanceMeasure` initialization (`anc_builder.hpp` 78–100), and `GetMatrix` (109–112). No class field owns the local handle.
- `InferBranchLengths.cpp` lines 60–75 unlinks painting files before branch inference. `Relate.cpp` lines 274–287 runs topology, inference and finalization in one `All` process. The writer in `Paint.cpp` closes its own handles, and the similar unlink block in `FindEquivalentBranches.cpp` is disabled by `if(0)`.
- On NFS, unlinking an open file can retain a silly-renamed `.nfs*` entry until its descriptor closes. That would make the final `rmdir` fail with ENOTEMPTY. Process exit closes the leaked descriptors, explaining an empty directory afterward. This fits the reported filesystem location and post-exit observation, but no failure-time directory listing or errno was captured. Other rmdir errors are not excluded.

All public C++ sources use commit `b54ede259cbb0be095bc9c9a8bd18cdaf7e88b74`. They diagnose a plausible source-level mechanism; they do not prove the exact release binary was built from that commit. The installed official release binary remains unchanged and pinned.

## Fresh prospective operational correction

Use the existing author binary's seven supported CLI modes in separate directly supervised processes. The installed author `scripts/RelateParallel/RelateParallel.sh` uses these modes and propagates sample ages, seed, map and scientific parameters at the relevant stages. It is evidence for the CLI interface and will not be executed.

Fresh order: MakeChunks; Paint for chunk 0; BuildTopology for chunk 0, full section range 0–0; FindEquivalentBranches for chunk 0; InferBranchLengths for chunk 0, full range 0–0; CombineSections for chunk 0; Finalize once; unchanged ConvertToTreeSequence. Every child must actually exit 0 and its group must drain before the next child can start. In particular topology exit closes its descriptors before inference unlinks painting files.

Preserve the entire prior Relate option vector on every mode: haps, sample, sample_ages, map, mutation_rate 1.25e-8, effectiveN 10000, memory 0.05, seed 20261015, and output basename native. Unused options remain parsed but unused. Use the exact prior fixture-generation/helper and date/support-verification code and unchanged binaries. Do not add postprocessing, filters, genotype reattachment, time edits, or alternative map/age conversions.

Read only new bounded parameter headers after MakeChunks and require global (N,L,chunks)=(40,512,1), start/end=(0,512), and chunk (N,L,boundary_count)=(40,512,2), boundaries=(0,512). Use explicit first_section=0,last_section=0 for both stochastic stages. This also avoids the standalone BuildTopology fallback's missing output-directory prefix (`Relate.cpp` 104–114).

Both `BuildTopology.cpp` 75–85 and `InferBranchLengths.cpp` 30–40 reset their own C RNG from the explicit seed and identical chunk/first_section offset. One full-range invocation per chunk therefore preserves the pinned `All` source's seed initialization and traversal. Do not adopt the wrapper's per-section invocation pattern as a general equivalence claim: splitting a multi-section C RNG stream can change draws. No installed-binary bitwise-equivalence test is claimed.

The v3 implementation remains source-only and inert pending root registration, actual runtime preflight, admission and execution. Use fresh v3 admission/output/aux/job/key, unchanged 50 MB reservation, original aggregate 300-second Relate budget, 120-second converter budget, 600-second controller budget, original RSS/file/byte/CPU limits, and aggregate 2 MB captured-log limit across all eight children. Each actual prelaunch and direct wait is retained separately. No exit-1 tolerance, retries, failed-run continuation or old-artifact conversion is introduced.

## Alternative source fix

Closing pFile immediately after each method's complete N-record read loop would address the demonstrated source lifetime defect without changing inference formulas. That would require a newly disclosed build, provenance and separate authorization. No source or binary patch was made. Rmdir retry alone cannot release a handle still open in the same process.

## Work performed

Only source and explicitly retained evidence reads, public source downloads into this folder, and 15 stdlib source/JSON checks were performed. No failed-directory probe, native/model/data execution, process action, installation, guard/accounting action or Git action was performed. Exact bytes and SHA references are in source_and_evidence_refs.json. The operational v3 source implementation is handed off separately in the original qualifier source folder.
