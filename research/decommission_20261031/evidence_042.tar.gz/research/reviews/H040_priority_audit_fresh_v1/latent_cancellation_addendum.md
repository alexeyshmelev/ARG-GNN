# Additional source deduction: incidence coverage versus latent cancellation

This is an algebraic deduction only. No new data or model test was run.

In frozen anonymous_clade_gnn_v1.py:47-50, write a for the shared-sample conditioner and b,c for old/new upward node states. If Vb=Vc and Wb=Wc, the tensor difference (Vb)*(Wc)-(Vc)*(Wb) is exactly zero. The eventMLP inputs a+Vb+Wc and a+Vc+Wb are then identical, so their GELU difference is also exactly zero. The sufficient condition b=c gives both projection equalities. Any nonzero event weights and arbitrary anchor a cannot rescue the forward message.

This can occur for differently leaf-labelled but equally colored/aged isomorphic clades when the upstream invariant aggregation collapses them to the same state. It is a conditional counterexample, not a claim that balanced clades always collide. Heterogeneous observed SNP, date, mutation and proxy-reference features can distinguish endpoints. No biological identifiability follows from their possible presence.

This limitation is distinct from K4's incidence blind spot. K4 can emit no event because a changed clade has no landmark witness. Here, even full rooted-triplet coverage can emit valid changed incidences while the learned endpoint message is zero. Rooted topological difference is not guaranteed to survive an upstream state bottleneck.

Exact changed-clade flags preserve a structural indicator independently of those endpoint embeddings. With the specified local adapter, a gained/lost flag can cause a nonzero injection at equal nonzero node states because the channel-conditioned V/W maps differ. That is a possible useful separation in this architecture, not strict expressivity dominance: zero node states, projection nullspaces, zero O at initialization and learned cancellation can also make the local adapter vanish. The unchanged query GRU can still use other genomic context; neither source argument establishes performance or a general ML theorem.
