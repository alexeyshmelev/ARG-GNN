# H058 fixed ROOT operational successor v2

Source-only immutable successor to blocked ROOT v1. It batches exactly P1 finite cleanup/unknown-wait/pre-expiry-evidence handling and P2 executed NVTOP helper source authentication. See implementation_corrections.source_only.v2.json and ROOT_RECIPE.md. The scientifically reviewed H058 v2 source stays sealed and unchanged.

Concrete --admit/--execute/owned worker/context routes remain. Actual root admission/execution/source-review closure are not claimed. Request/caps/direct-attachment authority templates remain inactive. Metadata alias compatibility is ROOT-owned; no source gate relaxation or qualifier rerun occurs.

The direct borrowed-physical-inode helper body, C3 envelope26GiB, H058 cap<=28GiB plus2GiB margin, actual external/headroom checks, original guard/renewal/writer, and current C3/controller/cap/lifecycle stay unchanged apart from the fresh source namespace. This driver still never claims controller inheritance or owns its exclusive physical lock.

Finite cleanup is in root_driver_v1.execute_v1, fixed to this admitted H058 worker. Its unchanged _RAMLog/_subreaper/_children/rss_identity helpers retain original AST; original OwnedTree/PIDFD modules remain pinned. The direct module still exports attach_v1, install_before_torch_v1, check_attachment_v1, capacity_v1, held_writable_probe_v1 and base_v1. It is H058-specific; native use requires its own truthful source/authority/schema adaptation.

No project/scientific imports, numerical fixtures, scientific payload reads/hashes, GPU/process probes, jobs, guard/accounting/admission calls or Git were performed. Default invocation remains inert. Independent successor review and real ROOT slot/runtime/capacity/admission remain necessary.
