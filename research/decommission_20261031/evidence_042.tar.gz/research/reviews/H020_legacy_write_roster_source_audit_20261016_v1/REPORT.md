# H020 seed202 original scoped-writer roster

**The original evidence now identifies every Python root on the pinned training route, including the previously missing fit start identity. It supports a source-complete cooperative scoped-writer roster for a future retirement proof. It does not establish historical whole-descendant drain or perform present absence, revocation, measurement or settlement.**

Exact key: `biological_mechanism_controls_v1/seed202`. Original charge: **52,321,048,576 bytes**. Preserve the entire original output `results/biological_mechanism_controls_v1_seed202` and auxiliary `.runtime/tmp/bio_mechanisms_seed202_v1` scopes.

## Authenticated identities and direct waits

| Role | PID | Start ticks | Authentic identity source |
|---|---:|---:|---|
| Root launch supervisor | 1230669 | 435395390 | original launch.json and exit.json |
| Budget/GPU launcher | 1230670 | 435395396 | original launch.json and exit.json |
| Sole seven-model fit and scientific writer | 1230680 | **435395427** | original concurrency_verified.json, seed202 worker |

The concurrency record is contemporaneous running-state evidence, not completion evidence. Its seed202 row agrees with the original CUDA qualification PID, process title and GPU2. This is historical GPU2 evidence only and authorizes no new GPU2 use.

Original `launch_supervisor.py:17-24` starts one launcher and records actual `child.wait(timeout=86400)` before `exit.json`. The authentic terminal records returncode0, watchdog false and matching launcher/supervisor identities. Original `budgeted_gpu_launcher_v1.py:43-65` privately loads the exact original GPU launcher, changes only storage preflight, calls `runtime.main()` and propagates its result. Original `scripts/launch_gpu.py:74-87` starts exactly one fit child, returns its actual `child.wait()`, and finally closes its lease. The unchanged runner calls `controls.train()` directly at60-64 and returns0 at67.

Together these sources and original terminal support the direct fit-child wait0 through launcher to supervisor. They do not establish the external original tool's exit status or comprehensive descendant drain. The launcher and fit each use `start_new_session=True`, so their groups/sessions equal their own PIDs by source. Do not relabel those source-derived group identities as contemporaneous recorded group fields. The supervisor's original group is not established here.

## Why seven model fits are one writer

Pinned `biological_mechanism_controls_v1.py:315-501` calls `configure_fit` once at335, creates seven local model/optimizer states at345-361, and iterates them in the same process at387-402. Prediction/checkpoint/metric/receipt writes are synchronous in that process. Final completed status is assigned at493 and original `receipt.json` written at500. The runner's exception writes are also in that same process. There are **not seven independently spawned fit PIDs**.

The finite original config source map still matches actual bytes. Its Python sources contain no DataLoader, multiprocessing, ProcessPool, ThreadPool, forkserver or explicit fork training path. `load_bank` and `sealed_prediction` synchronously load, forward and write in the fit process. Prepared genealogy banks are reused. The Relate launch function present in a bound preparation file is not called by this training route.

The actual route contains synchronous metadata commands rather than configured scientific writer workers. `configure_fit:169-176` calls `nvtop_snapshot` once. The helper at245-279 executes the pinned NVTOP binary with only `--snapshot`, captured pipes and a bounded synchronous subprocess.run. The parent fit process writes its snapshot files after that call. `resources.py:53-73` invokes nvidia-smi query commands synchronously. The historical du helper at25-41 is read-only, and this launcher's storage preflight replaces it. None receives a scientific output file path or callback. Their historical PIDs/start identities were not recorded here, and no complete historical descendant inventory is claimed.

Accordingly, the known long-lived scoped writer roster is the three identities above, with the fit as sole scientific writer. Unknown metadata-helper descendants must not be invented as writing DataLoader workers. This is a source-based cooperative authority conclusion, not an OS-level proof that no same-UID process could ever write these paths. It does not justify a blanket unknown-process exclusion.

## Completion and remaining root actions

The original completion artifact is **receipt.json**, size10,169,131 bytes, SHA256 `271ada740e7b5804129b3e44b2599748658374693635cd11b97d8585bfcfa7b8`. The prior independent completion audit authenticated seven completed positive-step fits, with steps352,352,352,480,352,480,352. That receipt was not reread in this source audit. Launch-time empty/running model snapshots are not completion proof.

Root still needs a fresh exact PID/start and applicable known-group absence certificate, explicit permanent cooperative revocation of all original scoped write/resume/relaunch authorities, original reservation/open-state authentication, and a separately reviewed legacy-proof branch over frozen accounting parents. Preserve unknown outer status and missing historical drain explicitly. The unchanged ordinary close contract requires a producer completed.json below1MiB and cannot accept this original receipt. Do not manufacture, compress, copy or rename a completion marker into the old output.

Only after those gates may root conservatively measure **all original output plus auxiliary bytes** under the unchanged owned-scope measurement, retaining all artifacts. Any credit is52,321,048,576 minus that actual retained total, subject to the successor's exact contract. Historical accounted-write bytes23,372,410,880 are not a retained-scope measurement. This report grants no execution, accounting or credit authority.

## Compact evidence pins

| Original or prior evidence | SHA256 |
|---|---|
| root folder launch.json | `6d9591143204ad9e6580a43b245489d5e4cd3da554d7b36458bc4500d519c8e2` |
| root folder exit.json | `4786f2f68e3ed95582be6aaf868db9b36bf70e10839ce3e6d2935ba4c21708bf` |
| root folder concurrency_verified.json | `ec97b4cd4a9e4689b1857a4628a1d9e237c07b4d46faf70032ae2ed47705f37f` |
| root folder launch_supervisor.py | `6183a08441c0321b8fa6c524fe3b86f35102bc8390fb2e95637fb083b96ba13f` |
| configs/biological_mechanism_controls_v1.json | `67d7aba454d3cc57b11faa32151dd6af397210fa89d9b56b5fcd0014f662f1b4` |
| src/arggnn/biological_mechanism_controls_v1.py | `28f3e7d3f28a48eeee0944b2e4ad55e3ea6ebb314d8b0342bd785facb08dcbeb` |
| src/arggnn/budgeted_gpu_launcher_v1.py | `d7eeaa568685ffc367242010a7035b6cc0a868493fa7dd279914189ab47358ff` |
| scripts/launch_gpu.py | `f07324053d8e649e27d66cbca9799bb6ea237c92c247853e2d45e6d440a2c094` |
| scripts/train_biological_mechanism_controls_v1.py | `f19bdead17a135a42ad70513f1522cef2a9fd58dc159d04f189adbe08de67dec` |
| prior completion review.v1.json | `914922cecfdc560739c0776642b0c9cfad47178b05cb2f9c1f6033d70f25c074` |

Root folder is `experiments/results/biological_mechanisms_seed202_parallel_v1_root`. Prior completion review is `research/reviews/H020_legacy_completion_normalization_review_20261016_v1/review.v1.json`. Additional dependency pins remain in the unchanged config source map.

No activation, process/proc scan, absence probe, lease probe, scope measurement, numerical work, guard implementation, accounting mutation, Git operation or scientific payload read was performed. Only this fresh report was written.
