# H056 native, preparation and application runtime binding proposal

This is a bounded source-only proposal. It creates no executable controller, active request, reservation, admission or launch. Acquisition is owned by the separate H056 acquisition worker and is outside this packet. No source/numerical module, fixture, native program or model was imported or executed, and no genotype/tree/checkpoint/prediction payload was read or hashed.

The fixed H056 protocol and sealed H36 implementation are dependencies, not targets for editing. Root owns independent source review, real counts, map qualification, numerical qualification, resource policy selection, admission and execution. The positive registered EHG/CHG contrasts and every frozen scientific choice remain unchanged.

## Minimal reuse, with exact edit boundaries

1. Native operations reuse `H018_observed2074_native_inference_source_v2/root_inference.py`. Preserve its immutable bounded reads, configured guard calls, process limits, single owned child/session, `direct_wait_owned`, `supervise`, stable inventory, genuine per-stage waits, expiry, failure preservation and cleanup ordering. Root's later reviewed integration changes only SETTINGS/source/config/manifest/request identity gates and the calls listed below. Do not clone this50KB controller into a new generic framework.
2. Preparation reuses bank packing from `H018_empirical_preparation_root_v3/root_driver.py:104` under the existing monitored CPU IO envelope in `rootH018_IO_v1/root_io_v1.py`. The old preparation launcher alone does not provide the required owned-drain certificate; its old childexit1 and recovery records are excluded.
3. Application reuses `rootH018_IO_v1/root_io_v1.py` startup pipe, owned PID/start-tick/session seeding before compute, aggregate RSS polling, configured guard, immutable reader, exclusive fsynced writer, first postwait minimal receipt and owned-group drain. Root's later specific integration adds exactly two known worker operations: H056 preparation packing and `apply_h36_v1.execute_v1(ctx)`. No arbitrary producer/command dispatch or new authority/admission mechanism is proposed.

The companion inactive JSON contains exact API/config/context skeletons and the source-pinned field delta. Null values are deliberate unresolved root bindings. All execution flags are false; it cannot be used as runtime authority.

## A. Native Relate: bind fresh actual inputs before launch

For one chromosome at a time, root receives the acquisition worker's actual C/S/K seal, immutable source VCF/QC refs and completed bridge assets. Validate C>=S>=1000,0<=K<=S and exact chromosome20/21/22. The relevant names are `baseline.haps,baseline.sample,sample_ages.generations,qualified.regional.map,frozen_site_identities.json,polarization_equivalence.json`. Native CLI reads the first four from one fresh, immutable project bridge directory; no old H40 directory or input copy is substituted.

Bind the independently qualified chromosome-specific GRCh37 map seal, build, physical/genetic units, source identity, original bracketing, exact qualified map bytes and absolute/local position join. A map URL or a previously successful chromosome22 map is insufficient. These are explicit prerequisites from the acquisition/map owner; this packet does not acquire or inspect maps.

Require the new serialized readback's exact asset hashes, retained sites, panel constants, original nucleotide-vector and constant-position digests, phase/order and sample/haplotype/date joins, and qualified-map/local-site join. Root alone adds `preparation_actual_wait_ref,root_preparation_wait_verified=True,root_owned_group_absent=True` after the acquisition/bridge worker's genuine direct wait0 and owned drain. Never turn an unverified child assertion into those root facts.

Preserve installed tool/runtime/license/author split-CLI/cleanup qualification refs and original CPU4 limits. The immutable native profile is N30000,mutation1.25e-8,years28,seed414855340,native memory2GB,pre-size only,zero population-size iterations. The inherited numeric seed is not rederived. The2GB argument is native RAM, not durable storage.

The minimal science-call delta is:

```python
# Future root runtime only; these calls were not run for this proposal.
base = {"candidate_sites": C, "sites": S, "constants": K}
observed = core.expected_observations_v1(
    immutable_bridge_bytes, roster_raw, root_sealed_readback,
    chromosome=chromosome, counts=base)
stages = core.cli_stages_v1(binary_paths, bridge_directory, scientific_options)
# Reuse existing exact native Popen/supervise/direct_wait/inventory loop.
# After MakeChunks wait0 and drain, read headers through bounded immutable reads:
headers = core.parse_headers_v1(
    global_header_raw, chunk_header_raw, counts=base, max_chunks=J)
stages.extend(core.cli_stages_v1(binary_paths, bridge_directory, scientific_options, headers))
```

J is an explicit finite root cap with1<=J<=S. Global header cap is20+8J bytes; each chunk header cap is16+4S bytes. Every header records actual chunks/sections. The exact child sequence is MakeChunks, five original stages/chunk, Finalize and converter: at most5J+3 children. Do not split a full section range into new RNG-resetting calls, add post-size stages or search seeds.

No T/node/edge/forest count is guessed before native conversion. After every declared native child has genuine wait0/drain and immutable outputs exist, root loads the actual graph under its separately reviewed CPU verification step. Root seals:
`native_trees=ts.num_trees,native_nodes=ts.num_nodes,native_edges=ts.num_edges`, and `vertex_occurrences` as the sum, over all marginal trees, of the explicit36-sample ancestor-union sizes. Counting reads only node/edge/sample topology, not variants or ancestry labels. The independent descriptor records how those actual counts were obtained. The native binary-tree source format gives planning ceilings T<=S,N_global<=36+35S,E<=70S,N_occ<=71S when its unchanged binary conversion contract holds; actual counts and graph proofs, not those ceilings, qualify the graph.

Rebuild the pure original observation descriptor from the same immutable bridge bytes with all seven sealed count keys before verification, because the verifier requires `observed["counts"]==counts`:

```python
observed_full = core.expected_observations_v1(
    immutable_bridge_bytes, roster_raw, root_sealed_readback,
    chromosome=chromosome, counts=actual_graph_counts)
facts = core.verify_native_v1(
    immutable_bridge_bytes, observed_full, anc_raw, mut_raw, ts,
    chromosome=chromosome, counts=actual_graph_counts)
```

Preserve actual `strict_GT_actual_status` and the full strict facts. Root's H056 acceptance gate is the new independent `facts["graph_only_ready"] is True` plus genuine stage waits, map/readback and actual-count/support proofs. This deliberately replaces the old controller's hardcoded H018 strict-success status; it does not force or rewrite strict GT success. Record the actual status even when graph-only readiness passes. Failures preserve all partial outputs and never trigger an automatic recovery, replay or phase resume.

Root seals the mapping from `facts["native_sample_haplotype_date_mapping"]` exactly, with `source_native_facts_ref`. Root's graph contract schema is `H056_graph_structure_plus_original_GT_v1`, with protocol/chromosome/full counts, actual graph/facts refs, genuine coverage, immutable_original_GT_features=True, graph_only_ready=True and the exact strict status. No old failed-GT/recovery fact enters H056.

## B. Preparation: use the existing monitored CPU envelope

Before import or empirical array work, root binds the actual reader source manifest, H056 reader config, native count/facts/mapping/graph-contract seals, immutable original source VCF, frozen site identities, bridge/sample/ages, readback and exact shared36-row roster. The reader manifest has schema `H056_H36_reader_source_manifest_v1`, exact protocol/observation refs and all27 required scientific source pins:21 unchanged plus the six new runtime files.

The actual root Reader must expose `root,read(ref),decode_json(ref)`. Preserve canonical project-only paths, O_NOFOLLOW/stable identity/SHA checks and exact per-ref allowlisting. Unlike the old single-bank Reader, the preparation capability explicitly permits only the named original VCF/haps/sample/ages/native-graph bytes and bound JSON/source refs, with role-specific positive caps. It permits no checkpoint, other native tables, query ancestry truth, network or arbitrary file.

The exact scientific context is:

```python
result = reader_h36_v1.prepare_from_root_context_v1({
    "root_authorizer": "root_agent", "admitted": True,
    "cfg": cfg, "config_ref": actual_config_ref,
    "reader": actual_bounded_reader, "before_stage": actual_root_before_stage,
})
```

Only root's separately admitted config changes the inactive status to `root_admitted_observation_preparation` and `preparation_authorized=True`. The companion template lists every field required by the current source, including exact feature semantics and the five caps. Root's stage callback applies the existing storage guard and actual RSS/deadline checks before reads, graph projection, array/flag preparation and serialization. Native facts/mapping/coverage/strict status and all site/phase/date/GT joins must match; no scientific re-QC or readout change occurs.

Pack exactly the returned original dataclass tensors and flags:

```python
payload = {
    "schema": "H056_empirical_CPU_observation_bank_v1",
    "protocol_ref": PROTOCOL_REF, "chromosome": chromosome,
    "input_ref": actual_preparation_input_ref,
    "bank_tensors": {f.name: getattr(result["bank"], f.name)
                     for f in dataclasses.fields(result["bank"])},
    "flag_node_flags": result["flags"].node_flags,
    "metadata": result["metadata"],
}
# Existing admitted exclusive/fsynced project writer; no uncharged temp copy.
bank_ref = output.save("observation_bank.pt", payload, kind="torch")
```

The child writes a candidate completion only after a successful bank write, using schema `H056_empirical_CPU_preparation_completed_v1`, status `completed_observation_preparation`, exact protocol/chromosome/counts/input/bank refs and identical result metadata, with no-query-truth/no-model-or-checkpoint/no-GPU booleans true. This file becomes a consumable completion only together with the root's genuine subsequent direct wait0/drain seal. An exit1 with an existing child JSON remains a failure.

Preserve the monitored IO parent's startup ticket: seed exact owned PID/start ticks/PGID/session and initial aggregate RSS before releasing the child to configure/import/compute. The first postwait write is the small fsynced actual wait receipt, before guards, stdout processing or drain claims. Then require resolved owned groups using the existing owned-identity helpers; retain failure evidence if absent status is unresolved. Root writes the final wait alias with the current application's required fields:
`actual_exit_code=0,actual_direct_wait_observed=True,process_group_drained=True,completed_ref=actual_completion_ref`, and links the real minimal-wait/outer-drain refs. Do not fabricate a return code or relabel old receipts.

## C. Frozen H045 CPU application

Root binds all three new genuinely completed banks, their new completion/wait seals, exact shared roster, actual count seals and genuine coverage. All chromosomes are required. Every bank's metadata already binds the new native/readback chain. The application config schema is `H056_H36_CPU_application_config_v1`; the inactive JSON lists its exact fields.

Use the same existing root monitored IO route with its specific H056 producer pin, new config/runtime/manifest/input refs and count-derived writer/read caps. The Reader's exact payload allowlist becomes the three bank refs plus the single unchanged checkpoint ref. The frozen raw TSV roster source is allowed only by the exact protocol-pinned `ROSTER_REF` as a transitive capability; each application roster JSON is the identical36-row metadata identity. All other non-JSON payload requests fail.

The package map must contain installed non-null versions only. A proposed exact CPU subset from existing runtime metadata is numpy2.4.6,torch2.6.0+cu124,torch_geometric2.7.0,tskit1.0.3. Root must actually qualify and reseal this subset; do not copy tsdate/tsinfer:null because `apply_h36_v1` performs exact `importlib.metadata.version` checks. Keep the same existing interpreter/prefix and no installation. Empty CUDA visibility is mandatory; no CUDA API is used.

After root has actual admission, construct exactly:

```python
ctx = dict(
    root_authorizer="root_agent", admitted=True,
    input_ref=actual_input_ref, source_ref=H056_APPLY_REF,
    config_ref=actual_config_ref, runtime_ref=actual_runtime_ref, cfg=cfg,
    consumer_bindings=actual_storage["reservation"]["consumer_bindings"],
    io_context_ref=actual_pinned_root_IO_ref,
    resource_binding_refs=actual_resource_binding_refs,
    reader=actual_bounded_reader, writer=actual_exclusive_fsynced_writer,
    before_stage=actual_root_before_stage,
)
completion_ref = apply_h36_v1.execute_v1(ctx)
```

The root input uses schema `H056_H36_CPU_application_root_v1`, hypothesis_id=H056,registered=True,protocol_ref,actual producer/config/runtime/output/expiry refs and explicit CPU-only/no-optimization/root-enforcement flags. Its authority is separate from the scientific registration, which remains execution_authorized=False. The worker's returned completion is not an OS-exit certificate; root separately requires actual outer wait0 and owned drain.

Process chromosomes sequentially; each full-window GRU resets only at the chromosome boundary. Keep the unchanged strict checkpoint provenance/load and31,812 finite FP32 state values. Emit full(T,20,4) probabilities/genuine intervals/query IDs per chromosome and the fixed span→haplotype-pair→covered-bp chromosome pool→equal-person era summary. No new bank/checkpoint copy, PCA, plots or optional prediction variant is produced.

## Direct source closure and project writes

Keep the original allowed direct suffixes .py/.sh/.json and at most64 unique path/SHA refs. Build and inspect the actual deduplicated union before admission:27 scientific pins, the specific root IO/native integration source, existing monitor/common/resource/policy/helper refs, exact config/runtime/manifest, protocol/descriptor, selection summary/TRAIN completion/config and three bank completions/waits. Use one exact shared roster ref for all three. Data/native binaries/raw TSV/license/checkpoint/bank refs remain fully named in direct JSON descriptors and are transitively allowlisted; they are never silently dropped or incorrectly bound as direct forbidden suffixes. Exclude every H018 failed-wait/recovery metadata ref. If the complete actual union exceeds64, stop for a reviewed binding correction; do not omit required refs or change the guard.

All new paths are fresh disjoint scopes under the project root. Native cwd is the admitted per-chromosome work directory. Set Python-B, PYTHONDONTWRITEBYTECODE=1, PYTHONNOUSERSITE=1, empty CUDA visibility and CPU4 environment. Bind TMPDIR/TMP/TEMP/cache scratch, if needed, to the charged project auxiliary scope. Use the inherited stable immutable readers and O_EXCL/fsynced writers. No symlinked outside writes, generic temp directory, source mutation, install, automatic deletion, accounting credit or Git operation is proposed.

## Storage: small H36 payloads, explicit fail-closed caps

`storage_formulas.v1.json` separates durable storage from RAM. Acquisition's separately proposed64MiB/chromosome scope is not duplicated here. Inputs are immutable references; native/preparation/application do not make another VCF/map/checkpoint copy.

The old native route's eight terminal-inventory JSON records (metadata only) show a largest sampled durable output7,256,647B for H40/S2074, and3218B final auxiliary logs. These values are provenance for scale, not an H056 capacity guarantee or within-stage peak. They justify starting with tens of MiB count-derived output ceilings rather than treating native memory2GB as a storage reservation.

Let S=actual sites,T=actual holds,N=actual summed forest vertices,J=root chunk cap. Use ceil-to-MiB. Suggested initial ceilings, subject to root's independent bounded fit review, are:

- Native workspace:8MiB+8192*S+header allowance; facts1MiB+1024*S+2048*T (prelaunch reserve with T_upper=S); logs min(16,000,000,1,000,000*(5J+3)); packet/provenance ceilMiB(1MiB+32768*(5J+3)). Workspace/facts caps are explicit abort ceilings, not proven native allocation bounds.
- Preparation tensor plan B=256*N+640*S+65536; flags2*N; metadata1MiB+1024*T; serialization/index allowance2MiB. Bank ceiling is their sum rounded to MiB, plus1MiB completion/root metadata and512KiB auxiliary. No duplicate bank/temp serialization is reserved.
- Per-chromosome probability archive:384*T+65536 bytes (raw arrays are at most360*T+1024 before NPZ headers/compression). Provenance/episode metadata use1MiB+512*T/chromosome and one additional MiB for summary/completion/root receipt. Add512KiB auxiliary and1MiB allocation/writer slack.

For an explicitly hypothetical S=2000,T=500,N=71*T,J=1, these ceilings are about41MiB native,16MiB preparation and8MiB for one three-chromosome application. They are illustrations, not observations or assumed site density. Three such native+bank scopes plus the separately proposed192MiB acquisition total about371MiB. Actual formulas are evaluated only after genuine count seals; no multi-GB disk allocation follows from original2GB/3GB/4GB RAM limits.

Retain original CPU supervision limits until root separately qualifies tighter ones: native per-process AS3GB/combined RSS4GB, CPU4 and existing1200s native/300s converter/2400s controller envelopes; preparation/application aggregate RSS2GB with the existing outer1800s envelope as an initial root review bound. These are RAM/time limits, not storage. Preparation's retained-tensor-plus-flag allowance remains B+2058*N+5120. Application episode payload requires18*N+4*T. Real RSS/elapsed fit is unqualified here.

## Root acceptance checklist

Root must still pin the current policy/guard/source/runtime/tool identities; independently review this delta; qualify the single deferred synthetic H36 fixture separately if desired; get fresh acquisition/map/readback and genuine waits; seal actual native dimensions and strict/graph-only facts; evaluate the explicit caps; inspect the complete direct closure; and separately admit each stage through the existing route. Before any real application, require all three new bank completions plus genuine wait0/drain. Overflow, source/hash mismatch, missing person/chromosome or unresolved wait/drain stops without scientific substitutions.
