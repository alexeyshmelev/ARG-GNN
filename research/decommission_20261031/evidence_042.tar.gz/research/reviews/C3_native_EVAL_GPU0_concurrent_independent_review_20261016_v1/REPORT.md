# Concurrent native ARGformer + C3 EVAL: independent source review

Verdict: BLOCKED FOR ACTIVATION by one missing direct-authority closure. Preserve this sealed v1. The numerical call chain, GPU0 resource gates and finite catalogue otherwise have no new source blocker found in this review. A fresh minimal source successor should bind the actual admission bridge and its explicit authority/closure refs before reservation and require them at the runtime boundary. No admission or execution is approved by this report.

Input seal: research/reviews/C3_native_EVAL_GPU0_concurrent_source_20261016_v1/source_handoff.v1.json, SHA2568d9d1450eca3c902627f11c04b09933370cee7fa6b31dc3afddad563b292b7a4.

## Blocking finding F1: actual concurrent admission authority is outside the direct union

native_v1/root_prepare_native_concurrent_v1.py:32-42 consumes the new family handoff and the actual native execution approval, authenticates the new pool/launcher/bridge and later changes the private admission contract's SHARED_POOL_SOURCE and SHARED_POOL_LAUNCHER at71-72 before driver.admit at73. This is the actual new operational admission producer. The unchanged native driver's admit function constructs its consumers from its original fixed direct roles and17 ancestors. It has no hook adding these new authority refs. The published native-science48-role union excludes them; so do the other published unions.

The exact omitted roles are:

1. This family's native_v1/root_prepare_native_concurrent_v1.py, the actual admission/metadata override source.
2. This family's source_handoff.v1.json, the explicit concurrent source authority accepted by the ROOT approval and bridge.
3. This family's full_source_manifest.v1.json, the142-ref indirect family closure anchor named by that handoff.
4. The actual fixed-path native GPU0_successor_execution_approval.root_active_v3.json, including its three concurrent fields. Its SHA is genuinely future ROOT evidence and is not fabricated here. It appears in the native scientific source map transitively, but not in the direct consumer union.

The actual new pool and launcher are truthfully written to the admitted native input and are direct in the outer/controller scopes. That fixes metadata truthfulness but does not bind the producer/approval that authorizes this override. The controller's own metadata construction helpers are already direct, so treating the analogous native bridge as an unbound documentation file is inconsistent with the required operational-authority closure. Existing green48/44/35/52/41 count manifests do not establish completeness.

Minimal remedy: in a fresh narrow bridge successor, authenticate these exact actual refs, append them to the actual native-science consumer list before the unchanged guard reserve call, and validate their presence at the finite/native runtime boundary. Keep all original48 refs, the17 actual ancestors and the original64 ceiling. Four additional distinct roles make the illustrated native-science union52, leaving room without dropping authority. Recompute all actual affected unions rather than copying this illustrative count. Do not edit sealed v1/native science or wrap/change root guard mutations. Add no reservation until the original C3 TRAIN and current controller closure prerequisites are genuinely satisfied.

The142-ref manifest is currently a ROOT_RECIPE step, not a manifest loaded automatically by a new source routine. Per-method runtime source maps are checked before scientific imports. The successor should authenticate the complete family manifest at the actual ROOT preflight/bridge boundary, retain the real verification and bind its anchor; this review's hash pass is not a future-runtime receipt.

## Actual call chain and unchanged science

I traced bootstrap -> exact new canonical pool -> declared worker -> new dispatcher -> native_gpu0_operational_v3.invoke_job_v1 OR entry_eval_v1.invoke_job_v1. Neither method re-enters the dispatcher. The native route uses the sealed original v3 driver/launcher/supervisor/child/IPC route. Its new bridge changes only operational metadata globals. Source retains the same original corpus/counts/order, seed17, BF16, batch512, five epochs,227990updates,40GiB CUDA,384GiB RSS,259200s, fresh separately charged7GiB scope and absolute expiry2026-10-18T23:41:32.476768+00:00. The previous failed7GiB artifacts/charge and genuine failed wait remain. No fit completion or expiry extension is invented.

EVAL directly calls the frozen predict_one_original_VAL_v1 hook and existing complete bidirectional parent predictor. It bypasses the old50GB worker. The8GiB allocator fraction is installed before configure_fit's first CUDA tensor. Input contracts preserve all original30Mb trees/samples/focals, six epochs5/10/15/20/25/30 and genuine primary TRAIN30epochs/600complete-parent updates/6000000exposures over20original2Mb parents. Each EVAL produces six ordinary seals accepted by the unchanged scorer's all5parents x6checkpoints barrier. No scorer, truth or TEST call is added. No measured fit, accuracy or feasibility claim follows from an operational cap.

## GPU identity, concurrency and prerequisites

Only physical0 and UUID GPU-ff06ca1f-403a-f2d0-b584-71e177452667 are eligible. Exact inherited canonical lease/title checks precede Torch; configure_fit verifies actual Torch/driver UUID. Native scheduling reserves43GiB, EVAL reserves8GiB+2GiB margin, and the inherited memory gate adds4GiB global headroom plus actual external/unattributed occupancy. It checks actual free memory and owned overruns, never terminates external jobs and preserves ownership-safe waits/drain. The queue's C3 launching/running/draining test permits at most one EVAL, with at most two logical jobs total. Individual queued, Popen-boundary and active-job absolute expiries remain enforced. These are source checks, not actual availability observations.

The new finite contract requires the exact current controller identity/capability, genuine consumed direct terminal, closed registry, every started job's wait/drain, permanent future-writer revocation, targeted old PID/group ESRCH and canonical lease release. Its only original C3 row must genuinely succeed, and the bound completion must be the actual outer TRAIN product. EVAL additionally binds that outer product to the exact inner primary six-checkpoint completion through a bounded locator. Native bridge validates the closed handover before admission. Current C3 status was not probed; this report does not assert those future prerequisites have occurred.

The catalogue contains NATIVE_MLM and C3_EVAL_000..004 only. Its actual immutable job map accepts native plus1..5 distinct actually admitted ready EVALs; no live capability mutation exists. I authenticated the six metadata refs for each initially ready000/001 parent, their preparation/plan wait0 and immutable plan-close facts. Pending002/003/004 have no fabricated completion SHA. Runtime parent validation requires their genuine completed/closed plans before inclusion. A partial ready subset cannot bypass all30 seals.

## Verification and limits

All142 full-manifest source/JSON/document refs match actual bytes, as do12 family and11 EVAL advertised refs. All9 new Python sources parse/compile without import. I independently reconstructed and parsed the generated startup, queue, active-resource and CLI source strings from their original sources and documented substitutions. Every published static direct plan retains all17 unique actual ancestor refs and is<=64; F1 is the completeness failure despite those counts.

Only standard-library source/JSON/hash/AST reads and this fresh review-folder write occurred. No scientific/project imports, numerical fixtures, array/tree/checkpoint/truth payload reads or hashes, process/GPU/lease/namespace probes, guard state/accounting, admissions, jobs, source edits, registration or Git occurred. Genuine waits, resource availability, predictions and metrics remain ROOT-owned future observations.
