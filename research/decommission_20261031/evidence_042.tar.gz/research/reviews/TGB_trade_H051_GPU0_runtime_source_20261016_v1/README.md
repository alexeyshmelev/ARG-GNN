# TGB H051 GPU0 runtime bridge — source only

No admissions, jobs, GPU/guard calls, numerical imports, labels, payloads,
checkpoints or Git actions were performed by this author. Root's existing
observed_archive_v1.py, three-arm100epoch trainer, dataset/model/H051 operator,
writer, evaluator and accounting/checker sources remain unchanged.

TRAIN entry: runtime_train_v1.invoke_job_v1(j). Its prepare_v1(protocol) is usable
only inside that exact active finite job. It supplies the pinned root RAM-only
observed archive, original TRAIN-only target method, original writer subclass,
lightweight resource callback and logical cuda:0. TRAIN imports no heldout reader
or evaluator and accepts no heldout capability. The frozen source protocol's
inactive flags remain provenance; actual active root execution authority is in
the separate exact input and runtime_binding.json.

Both phases require physical GPU0, UUID
GPU-ff06ca1f-403a-f2d0-b584-71e177452667, canonical held singleton lease/title,
Torch2.6.0+cu124/PyG2.7.0,2GiB CUDA reserved/allocated,8GiB current/peak RSS,
2hour deadline and32MiB total fresh output with no auxiliary scopes. Host/device
fit and first scheduled optimizer-step qualification are root responsibilities;
this source packet claims neither.

The raw primary payload is5462100bytes. Four raw116351-parameter FP32 states
(one initialization plus three finals) total1861616bytes; combined raw output is
7323716bytes before original format/JSON/metadata.32MiB is a root cap, not a
measured fit. All original methods are called unchanged.

## Explicit unchanged checker reuse

Root expressly authorized the unchanged ControllerMetadataScopeV1 at
research/reviews/GPU45_TRAIN_controller_execution_override_20261016_v1/controller_metadata_scope_check_v1.py
SHA2621353de0dc56f328f7f308ba17a341425ef2fc02d54739b6ccfc7d1a6ce2cf
for the complete charged TGB model/prediction scope, despite its historical
controller-metadata name. It is not used to claim other scopes or global credit.

Its constructor performs the one original full startup guard. Before each actual
artifact file write, the writer subclass checks planned exact RAM serialization
length plus64KiB format/block/directory growth through the original checker.
Original super methods emit all scientific bytes; an own-scope check follows each
artifact. No checker source, accounting API, allowance, projection or guard is
changed. Every checker call preserves original source/journal/expiry/open-reserve
checks and original scope measurement/cap inequality. Global projection is not
recomputed or claimed by these later checks. Epoch/year callbacks check only the
actual canonical lease/title, deadline, self RSS and CUDA caps.

Memo lifecycle: the outer operational worker must finish/uninstall its own
reviewed memo before invoking the method. The future-pool worker author has
implemented this. TGB installs its own checker once and uninstalls its reviewed
memo on normal/error exit. The separate controller process is unaffected.

## Root binding/run sequence after genuine predecessor drain

The existing controller must finish with actual controller wait0/owned drain and
no future writer authority. The fresh reviewed finite pool acquires GPU0 itself.
This packet performs no lifecycle or reservation operation.

1. Root authors a fresh active TGB_H051_GPU0_metadata_binding_request_v1 JSON:
   root_authorizer=root_agent; status=active; phase=train; fresh job_id and
   experiments/results/...TGB... output; aware created_at_utc/expires_at_utc
   at most7200seconds apart; output_cap_bytes=33554432;
   max_cuda_reserved_bytes=2147483648; max_cpu_rss_bytes=8589934592;
   operational_deadline_seconds=7200;
   scope_checker_reuse_for_complete_model_prediction_scope_root_authorized=true.
   runtime_source_refs supplies exact future pool/launcher/bootstrap/
   declared_runtime/finite_job_contract role refs.
   pool_required_source_refs contains every actual finite-pool required source
   (at least the native-style12ref closure). original_guard_binding_refs should
   contain the current original guard's required binding values from root's
   reviewed inspection; these are incorporated directly. No TRAIN split/eval cap.

2. Exact metadata call on the remote project root:

       from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import binding_v1 as b, common_v1 as c
       ready=b.prepare_input_metadata_v1(c.ref(ROOT_REQUEST_PATH),FRESH_BINDING_FOLDER)

   ready contains input_draft_ref, exact consumer_bindings,33554432 reserved
   bytes and auxiliary_scopes=[]; nothing is admitted or launched.

3. Root uses its original reviewed prospective980 inspection/authority/
   apply_reserve_v1 flow, current fresh journal pins and all original required
   guard bindings to admit this exact fresh32MiB/noaux scientific scope. Root
   writes the ordinary v9 storage record with matching job/output/expiry.

4. Exact final input call:

       input_ref=b.finalize_input_v1(ready["input_draft_ref"],ROOT_STORAGE_REF,FRESH_BINDING_FOLDER)

5. Bind the finite TGB_TRAIN method job to original scientific module
   research.reviews.TGB_trade_H051_training_source_20261016_v1.driver_v1
   and its exact source ref; runtime_entry_ref is runtime_train_v1.py here.
   Use input_ref, original storage_ref and cuda_caps_ref from the prepared
   input.refs.cuda_caps. Method cuda_cap_bytes=2147483648,
   cpu_rss_cap_bytes=8589934592, operational_deadline_seconds=7200, and args:

       ["--execute","--input",input_ref["path"],"--expected-input-sha256",input_ref["sha256"]]

   The method input schema is TGB_H051_GPU0_root_input_v1; phase=train;
   frozen_scientific_handoff_ref is exact193d58c1fc29b9dbb28e8aa9c5056fb31ab769b770cdcd5aec5f2318a061f8db.
   Attach this unchanged method job through the reviewed future controller's
   original operational request/envelope route. Controller admission/launch/
   genuine terminal consumption belongs to root and that separate source packet.

## Separate future evaluation

runtime_evaluate_v1.py is a separately bound entry for phase=evaluate, split=VAL
or TEST, fit_authorized=false, with the same2GiB/8GiB/2h limits and a new isolated
32MiB/noaux output reservation. Its original scientific entry is evaluation_v1.py.
No evaluator or target release runs automatically after fitting.

fit_terminal_v1.bind_fit_terminal_v1(root_request_ref,fresh_folder) can bind a
TGB_H051_GPU0_fit_terminal_certificate_v1 only after authentic root METHOD wait0,
leader/adopted waits0, owned drain, immutable registry/controller identities and
exact cap->outer envelope->request->original method/input/storage resolution.
Actual tool schema is GPU0_declared_actual_method_terminal_v1: command wait or
direct_supervisor_wait, actual_exit_code integer0, actual_terminal_consumed=true,
actual_root_exec_or_write_stdin_terminal provenance, exec_session_id,
terminal_chunk_id, capability_ref, logical_job, controller_identity and exact
terminal_job. Submit/run launch acknowledgments are rejected.

The binder request schema TGB_H051_GPU0_root_fit_terminal_binding_request_v1
requires root_authorizer/root_agent,status/active and logical_job,capability_ref,
registry_snapshot_ref,actual_tool_terminal_ref,pool_source_ref,scientific_input_ref,
fit_completed_ref,prediction_seal_ref,runtime_binding_ref. It never waits, signals,
polls, invents tool provenance or converts submit0 into completion.

A separate active TGB_H051_explicit_heldout_target_capability_v1 must bind split,
exact fit_terminal_certificate_ref,prediction_seal_ref,heldout_reader_ref,
allowed_target_years (VAL2010–2013 or TEST2014–2016), expires_at_utc and
complete_all255_predictions_before_target_source_selection=true.
VAL needs VAL_release_authorized=true. TEST needs TEST_release_authorized=true
plus frozen_confirmation_decision_ref: root TGB_H051_confirmation_decision_frozen_v1,
status=frozen, TEST_closed_when_frozen=true, same fit certificate, explicit
decision string and selection_on_TEST=false.

Before label access the separate heldout reader authenticates genuine full fit,
all255 seal axes/arms/years and both NPY artifact and raw score payload hashes.
It reconstructs the original SealedPrimaryPredictionsV1 from the retained5.46MB
payload and metadata. No model, checkpoint load, replay or refit occurs.
It rejects other split years before opening labels and filters each CSV row's
year before decoding country/source-presence/weight. Original evaluate_sealed_split_v1
and exact pinned H052/sklearn1.9.1 NDCG@10 results/metric are used unchanged.

Root must author/activate these capabilities independently after actual fit0.
Prerequisite-dependent eval inputs may require a later fresh finite map/controller
after predecessor drain; immutable current capabilities are never patched.
