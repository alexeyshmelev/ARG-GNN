"""TGB GPU0 bridge metadata/runtime primitives; import is standard-library only."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,importlib.util,io,json,math,os,resource,sys,time
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1"
SCIENCE="research/reviews/TGB_trade_H051_training_source_20261016_v1"
DATA="research/reviews/TGB_trade_H051_data_integration_root_20261016_v1"
GPU0="research/reviews/GPU0_shared_execution_source_20261016_v1"
SOURCE=HERE+"/common_v1.py"
GUARD0=GPU0+"/gpu0_native_guard_v1.py"
CHECKER="research/reviews/GPU45_TRAIN_controller_execution_override_20261016_v1/controller_metadata_scope_check_v1.py"
BUDGET_GUARD="research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py"
POLICY="research/reviews/prospective_980GB_capacity_source_v1/activation_policy.root_active_v1.json"
REPAIR="research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json"
PROTOCOL=SCIENCE+"/protocol.source_frozen.inactive.v1.json"
FROZEN_HANDOFF=dict(path=SCIENCE+"/source_handoff.v1.json",sha256="193d58c1fc29b9dbb28e8aa9c5056fb31ab769b770cdcd5aec5f2318a061f8db")
OUTPUT_CAP=32*2**20
CUDA_CAP=2*2**30
RSS_CAP=8*2**30
DEADLINE=7200
UUID="GPU-ff06ca1f-403a-f2d0-b584-71e177452667"
PINS={'research/reviews/GPU0_shared_execution_source_20261016_v1/gpu0_native_guard_v1.py': '3a08d3bd84adc95aafd332bc224fdb7aa38730d6c2f48dee8108944251b7ee69', 'research/reviews/GPU45_TRAIN_controller_execution_override_20261016_v1/controller_metadata_scope_check_v1.py': '2621353de0dc56f328f7f308ba17a341425ef2fc02d54739b6ccfc7d1a6ce2cf', 'research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py': 'fc71030865e0a3d5da31120d4daa2caa0b2d39ec7dd212b8c46c476b5a866d56', 'research/reviews/prospective_980GB_capacity_source_v1/activation_policy.root_active_v1.json': 'eb3408004a508136aa434c0a2e02a9d14a5598a96b8483c264c93026f9326018', 'research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json': 'f6f2d628199e8be73db8b5d90d428570d8afdefeab9dc5cd94bb5eafb39247db', 'research/reviews/TGB_trade_H051_data_integration_root_20261016_v1/observed_archive_v1.py': 'b5a3c3587cb02ef688852e14d3e3ef2b60f687e935df7fbe7910e2bbe1836b5f', 'research/reviews/TGB_trade_H051_data_integration_root_20261016_v1/actual_TRAIN_operator_support.root_v1.json': 'a8d7ce2e6fb73777d136332d2419fe8e30dba66100fb88c3e04c95d0ab41b74d', 'research/reviews/TGB_trade_H051_data_integration_root_20261016_v1/actual_model_FP32_CPU_qualification.root_v1.json': 'ad2eaeff409f68b36a7137c542e1f98356bedb55242a32da15b253c66cd65f3c', 'research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py': 'c972e9a779d424ceafdb258848614bf40994d1004e2c73fc5cd225ae99621364', 'src/arggnn/project_budget_v4.py': 'a093c7d86f57fee569cb99f4712250e9505a1119f3950fa44282c7ba8c57df47', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/driver_v1.py': 'd0aa60c43836063f1976fb2f0eb709945e4d34bc7f313f1e1b9bf2d8de71b7bf', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/trainer_v1.py': '28f13996b9cce564ee5da8a8296a8061efc56fe6e01a43139b41538400516936', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/artifact_writer_v1.py': 'e7e6aa1ca3dc89106244d2127544b2525d7e185e01ee8a4daa3c8b54ffc45bf7', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/evaluation_v1.py': '5a0b76b13ca14380d56bf783ba991a31d97e8bed5e3c6428a548c02bc80317ef', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/targets_and_metrics_v1.py': 'a37d4c6444ebbcf351a05d5394b19324224aa45f435c855b02a22a636e1fe846', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/preparation_v1.py': '891b1a9a842cabb97f386e17bdd98c377aacc51ef11027826e95f9a37013c7d6', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/model_v1.py': '5967c964d59f1f18eb85066b1941260d8d0696dc7498b62720d04e2663f463f0', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/protocol.source_frozen.inactive.v1.json': 'a2253a9aec4d8405a14262d9dc69f9ee2bcff14ea36e0fbef466ba94424acb6e', 'research/reviews/TGB_trade_H051_training_source_20261016_v1/source_handoff.v1.json': '193d58c1fc29b9dbb28e8aa9c5056fb31ab769b770cdcd5aec5f2318a061f8db'}
BUDGET_PATHS=("scripts/project_budget_v9.py","scripts/launch_reserved_gpu_v6.py",
 "src/arggnn/project_storage_cpu_closed_scopes_v1.py","src/arggnn/project_storage_terminal_scopes_v1.py",
 "src/arggnn/project_storage_terminal_success_scopes_v1.py","src/arggnn/project_storage_terminal_retired_scopes_v1.py",
 "research/reviews/concurrent_completed_scope_credits_v3/completed_scope_credits_v3.py",
 "research/reviews/completed_scope_credits_root_activation_20261015_v1/activation_policy.json")

def require(ok,message):
    if not ok:raise ValueError(message)

def path(name):
    require(isinstance(name,str) and ".." not in Path(name).parts,"Canonical contained path")
    p=Path(name) if Path(name).is_absolute() else ROOT/name
    require(p.resolve()==p and p.is_relative_to(ROOT) and not p.is_symlink(),"Canonical non-symlink project path")
    return p

def is_ref(r):
    return isinstance(r,dict) and set(r) in ({"path","sha256"},{"path","sha256","bytes"}) and isinstance(r["path"],str) and isinstance(r["sha256"],str) and len(r["sha256"])==64 and all(x in "0123456789abcdef" for x in r["sha256"])

def ref(name):
    p=path(name);require(p.is_file(),"Existing source/metadata")
    return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def same_ref_v1(a,b):
    return is_ref(a) and is_ref(b) and path(a["path"])==path(b["path"]) and a["sha256"]==b["sha256"]

def checked(r,limit=32*2**20):
    require(is_ref(r),"Exact path/hash metadata or original writer artifact ref")
    p=path(r["path"]);require(p.is_file() and p.stat().st_size<=limit,"Bounded immutable artifact")
    raw=p.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==r["sha256"] and ("bytes" not in r or r["bytes"]==len(raw)),"Actual artifact SHA/length")
    return raw

def read(r):return json.loads(checked(r))

def exact(name):
    require(PINS.get(name)==ref(name)["sha256"],"Frozen source changed:"+name)
    return path(name).read_text()

def load(name,label):
    if name in PINS:exact(name)
    s=importlib.util.spec_from_file_location(label,path(name));m=importlib.util.module_from_spec(s);sys.modules[label]=m;s.loader.exec_module(m);return m

def protocol_v1():return json.loads(exact(PROTOCOL))

def unique(rows):
    result=[]
    for r in rows:
        if r not in result:result.append(r)
    return result

def validate_protocol_v1(value):
    require(value==protocol_v1(),"Frozen three-arm seed17 full100epoch protocol is unchanged")
    return value

def expiry_v1(spec):
    created=datetime.fromisoformat(spec["created_at_utc"]);end=datetime.fromisoformat(spec["expires_at_utc"])
    require(created.tzinfo is not None and end.tzinfo is not None and 0<(end-created).total_seconds()<=DEADLINE
        and created.timestamp()<=time.time()<end.timestamp(),"Explicit active at-most2h scientific authority")
    return end.timestamp()

def required_refs_v1(spec):
    rows=spec["runtime_source_refs"]
    require(isinstance(rows,dict) and all(is_ref(r) and not Path(r["path"]).is_absolute() for r in rows.values()),"Exact explicit runtime source refs")
    closure=read(spec["transitive_source_closure_ref"])
    require(closure.get("schema")=="TGB_H051_GPU0_exact_source_closure_v1"
        and closure["source_sha256"]==spec["source_sha256"] and closure["runtime_source_refs"]==rows
        and closure["frozen_scientific_handoff_ref"]==FROZEN_HANDOFF,"Exact transitive original and actual source closure")
    require(len(spec["pool_required_source_refs"])>=12 and all(is_ref(r) and spec["source_sha256"].get(r["path"])==r["sha256"] for r in spec["pool_required_source_refs"]),
        "All root finite-pool required sources include native-style12ref closure")
    for r in list(rows.values())+[FROZEN_HANDOFF,ref(PROTOCOL),ref(GUARD0),ref(CHECKER),ref(SOURCE)]:
        require(spec["source_sha256"].get(r["path"])==r["sha256"],"Actual entry/helper/guard/checker/science in exact closure")
    direct=[spec["transitive_source_closure_ref"],spec["refs"]["config"],spec["refs"]["runtime"],spec["refs"]["cuda_caps"],
        spec["runtime_entry_ref"],spec["scientific_entry_ref"],ref(SOURCE),ref(CHECKER),ref(GUARD0),ref(BUDGET_GUARD),
        ref(POLICY),ref(REPAIR),ref("research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py"),
        ref("src/arggnn/project_budget_v4.py")]+[ref(p) for p in BUDGET_PATHS]+list(rows.values())
    direct=unique(direct)
    require(len(direct)<=64 and all(Path(r["path"]).suffix in (".json",".py",".sh") for r in direct),"Original64direct source/metadata binding ceiling")
    return direct

def validate_spec_v1(spec,j=None):
    require(spec.get("schema")=="TGB_H051_GPU0_root_input_v1" and spec.get("root_authorizer")=="root_agent"
        and spec.get("status")=="active" and spec.get("phase") in ("train","evaluate")
        and spec.get("physical_gpu")==0 and spec.get("gpu_uuid")==UUID and spec.get("device")=="cuda"
        and spec.get("scope_checker_reuse_for_complete_model_prediction_scope_root_authorized") is True
        and spec.get("fit_authorized") is (spec["phase"]=="train") and spec.get("pyg_authorized") is True
        and spec.get("frozen_scientific_handoff_ref")==FROZEN_HANDOFF
        and spec.get("max_cuda_reserved_bytes")==CUDA_CAP and spec.get("max_cpu_rss_bytes")==RSS_CAP
        and spec.get("output_cap_bytes")==OUTPUT_CAP and spec.get("operational_deadline_seconds")==DEADLINE,
        "Explicit fixed TGB GPU0/root/science/resource authority")
    expiry_v1(spec)
    require(read(spec["refs"]["config"])==protocol_v1(),"Actual configuration is exact frozen scientific protocol")
    caps=read(spec["refs"]["cuda_caps"])
    require(caps["max_cuda_reserved_bytes"]==CUDA_CAP and caps["max_cpu_rss_bytes"]==RSS_CAP
        and caps["operational_deadline_seconds"]==DEADLINE,"Bound exact TGB CUDA/RSS/time caps")
    runtime=read(spec["refs"]["runtime"])
    require(all(runtime[k]==spec[k] for k in ("job_id","output_directory","physical_gpu","gpu_uuid","expires_at_utc","operational_deadline_seconds")),
        "Exact runtime/input identity and expiry")
    for name,sha in spec["source_sha256"].items():
        require(ref(name)==dict(path=name,sha256=sha),"Every source/metadata in actual declared closure unchanged")
    require(spec["runtime_source_refs"].get("runtime")==spec["runtime_entry_ref"]
        and spec["runtime_source_refs"].get("common")==ref(SOURCE)
        and spec["runtime_source_refs"].get("guard")==ref(GUARD0)
        and spec["runtime_source_refs"].get("scope_checker")==ref(CHECKER),"Exact actual bridge and unchanged canonical guard/scope checker")
    storage=read(spec["refs"]["storage"]);bindings=storage["reservation"]["consumer_bindings"]
    require(storage.get("kind")=="project_budget_v9_storage_record" and storage.get("active") is True
        and storage.get("consumer_uses_v9_guard") is True and storage.get("accounting_mode")=="prospective_980gb_v1"
        and storage["job_id"]==spec["job_id"] and storage["output_directory"]==spec["output_directory"]
        and storage["reserved_new_bytes"]==storage["reservation"]["reserved_bytes"]==OUTPUT_CAP
        and storage["reservation"]["auxiliary_scopes"]==[]
        and storage["reservation"]["output"]==str(path(spec["output_directory"]))
        and storage["expires_at_utc"]==spec["expires_at_utc"] and len(bindings)<=64
        and all(r in bindings for r in required_refs_v1(spec)),"Exactly charged isolated32MiB/noaux original v9 scientific scope")
    if j is not None:
        require(j["job_id"]==spec["job_id"] and j["input_ref"]==spec["input_ref"]
            and j["storage_ref"]==spec["refs"]["storage"] and j["runtime_entry_ref"]==spec["runtime_entry_ref"]
            and j["module_ref"]==spec["scientific_entry_ref"] and j["cuda_caps_ref"]==spec["refs"]["cuda_caps"]
            and j["cuda_cap_bytes"]==CUDA_CAP and j["cpu_rss_cap_bytes"]==RSS_CAP
            and j["operational_deadline_seconds"]==DEADLINE
            and j["args"]==["--execute","--input",j["input_ref"]["path"],"--expected-input-sha256",j["input_ref"]["sha256"]],
            "Exact finite method job/input/source/caps/storage/args")
    return storage

def runtime_v1(spec,j):
    storage=validate_spec_v1(spec,j)
    require(not path(spec["output_directory"]).exists(),"Fresh scientific output only; no resume or overwrite")
    g=load(GUARD0,"_TGB_exact_GPU0_canonical_guard");g.install_before_torch_v1()
    lease=g.validate_lease();g.apply_and_validate_title()
    require(lease["physical_gpu"]==0 and lease["visible_gpu_uuid"]==UUID
        and os.environ.get("ARGGNN_LOGICAL_JOB_NAME")==spec["job_id"],"Actual inherited canonical singleton GPU0 logical lease/title")
    # Fresh-controller bootstrap has already installed its exact reviewed marker
    # renewal before storage-guard imports. No source or accounting API is replaced.
    guard=load(BUDGET_GUARD,"_TGB_original_980_storage_guard");guard.configure_v2(ref(REPAIR),policy_ref=ref(POLICY))
    checker_module=load(CHECKER,"_TGB_unchanged_scope_checker")
    checker=checker_module.ControllerMetadataScopeV1(guard,storage)
    # Exactly one original full startup storage guard occurs inside checker init.
    started=time.monotonic();expires=expiry_v1(spec)
    torch_module=None
    def check(stage):
        require(isinstance(stage,str) and stage,"Explicit scientific boundary")
        require(time.monotonic()-started<DEADLINE and time.time()<expires,"Original finite TGB deadline and input expiry")
        current=g.validate_lease();g.apply_and_validate_title()
        require(current["physical_gpu"]==0 and current["visible_gpu_uuid"]==UUID
            and current["lease_metadata_sha256"]==lease["lease_metadata_sha256"],"Same actual canonical GPU0 lease")
        status=Path("/proc/self/status").read_text()
        rss=next(int(line.split()[1])*1024 for line in status.splitlines() if line.startswith("VmRSS:"))
        require(rss<=RSS_CAP and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=RSS_CAP,"Current and peak8GiB RSS")
        if torch_module is not None:
            require(torch_module.cuda.memory_reserved(0)<=CUDA_CAP and torch_module.cuda.memory_allocated(0)<=CUDA_CAP,"Actual logical2GiB CUDA reserved/allocated cap")
        # No project-wide disk guard or own-scope stat in the epoch/year callback.
    check("before_numerical_imports")
    import torch,torch_geometric
    require(torch.__version__=="2.6.0+cu124" and torch_geometric.__version__=="2.7.0","Pinned Torch/PyG runtime")
    require(torch.cuda.device_count()==1,"Exactly one UUID-visible logical GPU")
    device=torch.device("cuda:0");torch.cuda.set_device(device)
    torch.cuda.set_per_process_memory_fraction(min(1.,CUDA_CAP/torch.cuda.get_device_properties(device).total_memory),device)
    torch_module=torch;check("after_device_qualification_before_data")
    return dict(checker=checker,runtime_check=check,device=device,storage=storage,started=started)

def writer_v1(spec,operational):
    """Original writer subclass: only operational prewrite checks are added.

    State/npy serializer lengths are calculated in RAM using the original pinned
    serializers, then the original writer emits the artifact. An extra64KiB per
    file bounds format/block/directory growth; the complete32MiB scope is checked
    again after every artifact. No model, score or protocol math is changed.
    """
    original=load(SCIENCE+"/artifact_writer_v1.py","_TGB_original_artifact_writer")
    checker=operational["checker"];runtime_check=operational["runtime_check"]
    def prewrite(size):
        runtime_check("before_actual_artifact_write")
        require(type(size) is int and 0<=size<=OUTPUT_CAP-65536,"Bounded planned artifact serialization")
        checker.check(required=size+65536)
    class ScopeWriterV1(original.DirectoryArtifactWriterV1):
        def _json(self,name,value):
            raw=json.dumps(value,indent=2,sort_keys=True)+"\n";prewrite(len(raw.encode()))
            result=super()._json(name,value);checker.check(required=0);return result
        def begin_run(self,protocol):
            prewrite(0);result=super().begin_run(protocol)
            self._json("runtime_binding.json",dict(schema="TGB_H051_GPU0_actual_runtime_binding_v1",
                input_ref=spec["input_ref"],storage_ref=spec["refs"]["storage"],runtime_entry_ref=spec["runtime_entry_ref"],
                scientific_entry_ref=spec["scientific_entry_ref"],frozen_scientific_handoff_ref=FROZEN_HANDOFF,
                source_closure_ref=spec["transitive_source_closure_ref"],output_cap_bytes=OUTPUT_CAP,
                canonical_GPU0_uuid=UUID,original_scope_checker_ref=ref(CHECKER),
                scope_checker_reuse_for_complete_model_and_prediction_scope_root_authorized=True,
                scientific_protocol_source_inactive_status_is_provenance_only=True,
                actual_execution_authority_is_separate_active_input=True))
            return result
        def save_initial(self,seed,state,metadata):
            import torch
            buf=io.BytesIO();torch.save(state,buf);prewrite(buf.tell());del buf
            result=super().save_initial(seed,state,metadata);checker.check(required=0);return result
        def save_final(self,seed,arm,state,metadata,history):
            import torch
            buf=io.BytesIO();torch.save(state,buf);prewrite(buf.tell());del buf
            result=super().save_final(seed,arm,state,metadata,history);checker.check(required=0);return result
        def seal_predictions(self,scores,metadata):
            import numpy as np
            buf=io.BytesIO();np.save(buf,scores.numpy(),allow_pickle=False);prewrite(buf.tell());del buf
            result=super().seal_predictions(scores,metadata);checker.check(required=0);return result
    return ScopeWriterV1(path(spec["output_directory"]))
