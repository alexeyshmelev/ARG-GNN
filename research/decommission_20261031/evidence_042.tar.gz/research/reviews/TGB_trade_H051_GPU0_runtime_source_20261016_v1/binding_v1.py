"""Future root-only metadata assembly; no storage admission, guard or job calls."""
import copy,json
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import common_v1 as c
SOURCE=c.HERE+"/binding_v1.py"

def source_plan_v1(phase,runtime_source_refs,pool_required_source_refs,request_ref):
    c.require(phase in ("train","evaluate") and isinstance(runtime_source_refs,dict),"Finite phase/source declaration")
    entry=c.HERE+("/runtime_train_v1.py" if phase=="train" else "/runtime_evaluate_v1.py")
    rows=dict(runtime_source_refs,runtime=c.ref(entry),common=c.ref(c.SOURCE),guard=c.ref(c.GUARD0),
        scope_checker=c.ref(c.CHECKER),binding=c.ref(SOURCE),archive_reader=c.ref(c.DATA+"/observed_archive_v1.py"))
    c.require({"pool","launcher","bootstrap","declared_runtime","finite_job_contract"}<=set(rows),"All five exact finite-controller execution roles")
    if phase=="evaluate":
        rows.update(heldout_reader=c.ref(c.HERE+"/heldout_targets_v1.py"),fit_terminal=c.ref(c.HERE+"/fit_terminal_v1.py"))
    sources=dict(c.PINS)
    for r in c.protocol_v1()["source_refs"].values():sources[r["path"]]=r["sha256"]
    original=c.read(c.ref(c.SCIENCE+"/source_pins.v1.json"))
    for r in original["original_refs"]:sources[r["path"]]=r["sha256"]
    # These are pinned source/metadata declarations. No scientific payload or
    # H052 result values are read by this metadata assembler.
    extras=list(rows.values())+list(pool_required_source_refs)+[request_ref,c.FROZEN_HANDOFF,c.ref(SOURCE)]
    for r in extras:
        c.require(c.is_ref(r),"Exact declared source ref")
        c.require(not r["path"].startswith("/") and c.path(r["path"]).suffix in (".py",".json",".sh"),"Metadata/source closure only")
        if r["path"] in sources:c.require(sources[r["path"]]==r["sha256"],"No source pin override")
        sources[r["path"]]=r["sha256"]
    return rows,sources

def prepare_input_metadata_v1(request_ref,folder):
    req=c.read(request_ref)
    c.require(req.get("schema")=="TGB_H051_GPU0_metadata_binding_request_v1"
        and req.get("root_authorizer")=="root_agent" and req.get("status")=="active"
        and req.get("phase") in ("train","evaluate")
        and req.get("output_cap_bytes")==c.OUTPUT_CAP and req.get("max_cuda_reserved_bytes")==c.CUDA_CAP
        and req.get("max_cpu_rss_bytes")==c.RSS_CAP and req.get("operational_deadline_seconds")==c.DEADLINE
        and req.get("scope_checker_reuse_for_complete_model_prediction_scope_root_authorized") is True,
        "Explicit root32MiB/2GiB/8GiB/2h and authorized unchanged ownscope checker reuse")
    target=c.path(folder);c.require(not target.exists() and target.parent.is_dir(),"Fresh root metadata folder")
    c.require(req["output_directory"].startswith("experiments/results/") and "TGB" in c.path(req["output_directory"]).name and not c.path(req["output_directory"]).exists(),"Fresh TGB scientific output")
    c.require(len(req["pool_required_source_refs"])>=12,"Complete native-style12ref finite-pool closure")
    declared=dict(req["runtime_source_refs"])
    for index,r in enumerate(req.get("original_guard_binding_refs",[])):declared["original_guard_%03d"%index]=r
    rows,sources=source_plan_v1(req["phase"],declared,req["pool_required_source_refs"],request_ref)
    module=c.SCIENCE+("/driver_v1.py" if req["phase"]=="train" else "/evaluation_v1.py")
    spec=dict(schema="TGB_H051_GPU0_root_input_v1",status="active",root_authorizer="root_agent",
        phase=req["phase"],job_id=req["job_id"],created_at_utc=req["created_at_utc"],expires_at_utc=req["expires_at_utc"],
        physical_gpu=0,gpu_uuid=c.UUID,device="cuda",fit_authorized=req["phase"]=="train",pyg_authorized=True,
        frozen_scientific_handoff_ref=c.FROZEN_HANDOFF,scientific_entry_ref=c.ref(module),runtime_entry_ref=rows["runtime"],
        max_cuda_reserved_bytes=c.CUDA_CAP,max_cpu_rss_bytes=c.RSS_CAP,output_cap_bytes=c.OUTPUT_CAP,
        operational_deadline_seconds=c.DEADLINE,output_directory=req["output_directory"],
        scope_checker_reuse_for_complete_model_prediction_scope_root_authorized=True,
        runtime_source_refs=rows,pool_required_source_refs=req["pool_required_source_refs"],source_sha256=sources,
        operational_pool_source_ref=rows["pool"],operational_launcher_ref=rows["launcher"],
        operational_GPU0_runtime_ref=rows["runtime"],operational_GPU0_guard_ref=rows["guard"],
        root_binding_request_ref=request_ref)
    if req["phase"]=="evaluate":
        c.require(req.get("split") in ("VAL","TEST") and c.is_ref(req.get("heldout_target_capability_ref"))
            and c.is_ref(req.get("fit_terminal_certificate_ref")),"Independent explicit split target/fit capabilities")
        for key in ("split","heldout_target_capability_ref","fit_terminal_certificate_ref"):spec[key]=req[key]
    else:c.require(not any(k in req for k in ("heldout_target_capability_ref","fit_terminal_certificate_ref","split")),"TRAIN has no held-out capability")
    c.expiry_v1(spec)
    target.mkdir()
    def save(name,value):
        p=target/name;c.require(not p.exists(),"Fresh metadata only");p.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n");return c.ref(str(p.relative_to(c.ROOT)))
    runtime={k:spec[k] for k in ("job_id","output_directory","physical_gpu","gpu_uuid","expires_at_utc","operational_deadline_seconds")}
    runtime.update(process_title="AI Auto Research Pipeline Test",status="active",created_at_utc=spec["created_at_utc"])
    caps=dict(max_cuda_reserved_bytes=c.CUDA_CAP,max_cpu_rss_bytes=c.RSS_CAP,operational_deadline_seconds=c.DEADLINE)
    spec["refs"]=dict(config=c.ref(c.PROTOCOL),runtime=save("runtime.json",runtime),cuda_caps=save("cuda_caps.json",caps))
    spec["transitive_source_closure_ref"]=save("source_closure.json",dict(schema="TGB_H051_GPU0_exact_source_closure_v1",
        frozen_scientific_handoff_ref=c.FROZEN_HANDOFF,runtime_source_refs=rows,source_sha256=sources))
    bindings=c.required_refs_v1(spec)
    draft=save("input_draft_without_storage.json",spec)
    return dict(schema="TGB_H051_GPU0_metadata_ready_not_admitted_v1",input_draft_ref=draft,
        consumer_bindings=bindings,reserved_new_bytes=c.OUTPUT_CAP,auxiliary_scopes=[],
        no_guard_admission_or_execution=True)

def finalize_input_v1(draft_ref,storage_ref,folder):
    spec=copy.deepcopy(c.read(draft_ref));c.require("storage" not in spec["refs"],"Fresh metadata draft only")
    spec["refs"]["storage"]=storage_ref;c.validate_spec_v1(spec)
    p=c.path(folder)/"input.json";c.require(not p.exists(),"Fresh final root input")
    p.write_text(json.dumps(spec,indent=2,sort_keys=True)+"\n")
    return c.ref(str(p.relative_to(c.ROOT)))
