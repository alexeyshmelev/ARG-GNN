"""Finite TGB TRAIN runtime. No held-out target reader or evaluator is imported."""
from pathlib import Path
import json,sys
from types import SimpleNamespace
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import common_v1 as c
SOURCE=c.HERE+"/runtime_train_v1.py"
_ACTIVE=None

def prepare_v1(protocol):
    c.validate_protocol_v1(protocol)
    c.require(_ACTIVE is not None,"prepare_v1 requires the exact active finite TRAIN job")
    spec,j,operational=_ACTIVE
    c.require(spec["phase"]=="train" and "heldout_target_capability_ref" not in spec
        and "fit_terminal_certificate_ref" not in spec,"TRAIN has no held-out evaluation capability")
    operational["runtime_check"]("before_actual_observed_archive")
    reader=c.load(c.DATA+"/observed_archive_v1.py","_TGB_exact_root_TRAIN_archive")
    archive=reader.download_observations_v1()
    c.require(archive.train_label_member_opened is False,"No labels before original TRAIN-only callback")
    dataset=archive.dataset_v1()
    operational["runtime_check"]("after_actual_observations_before_TRAIN_targets")
    return dict(dataset=dataset,load_train_target_year=archive.load_train_target_year_v1,
        writer=c.writer_v1(spec,operational),runtime_check=operational["runtime_check"],device=operational["device"])

def invoke_job_v1(j):
    global _ACTIVE
    c.require(_ACTIVE is None and j.get("worker_kind",j.get("kind"))=="TGB"
        and j.get("runtime_entry_ref")==c.ref(SOURCE)
        and j.get("module_ref")==c.ref(c.SCIENCE+"/driver_v1.py"),"Exact finite frozen TGB TRAIN entry")
    spec=c.read(j["input_ref"]);spec["input_ref"]=j["input_ref"]
    c.require(spec.get("phase")=="train" and spec.get("runtime_entry_ref")==c.ref(SOURCE)
        and spec.get("scientific_entry_ref")==c.ref(c.SCIENCE+"/driver_v1.py")
        and "heldout_target_capability_ref" not in spec and "fit_terminal_certificate_ref" not in spec,
        "Only actual TRAIN input without held-out capability")
    operational=c.runtime_v1(spec,j)
    _ACTIVE=(spec,j,operational)
    try:
        driver=c.load(c.SCIENCE+"/driver_v1.py","research.reviews.TGB_trade_H051_training_source_20261016_v1.driver_v1")
        bundle=driver.run_root_adapter_v1(SimpleNamespace(prepare_v1=prepare_v1))
        operational["runtime_check"]("after_primary_fit")
        operational["checker"].check(required=0)
        print(json.dumps(dict(status="TGB_primary_full_budget_predictions_sealed",input_ref=j["input_ref"],
            prediction_seal_ref=bundle.seal_ref,fit_receipt_ref=bundle.fit_receipt_ref,
            actual_execution=True,heldout_metrics_computed=False)),flush=True)
        return 0
    finally:
        _ACTIVE=None
        operational["checker"].memo.uninstall()
