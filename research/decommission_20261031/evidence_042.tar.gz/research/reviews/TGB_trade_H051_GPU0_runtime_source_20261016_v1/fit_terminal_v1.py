"""Authentic future finite-pool fit terminal proof and retained payload loader."""
import math,hashlib,io,json
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import common_v1 as c
SOURCE=c.HERE+"/fit_terminal_v1.py"
CERT_SCHEMA="TGB_H051_GPU0_fit_terminal_certificate_v1"
TOOL_SCHEMA="GPU0_declared_actual_method_terminal_v1"

def identity(v):
    return isinstance(v,dict) and type(v.get("pid")) is int and v["pid"]>0 and type(v.get("uid")) is int and v["uid"]>=0 and type(v.get("start_ticks")) is int and v["start_ticks"]>0

def successful_job(job):
    c.require(job.get("state")=="succeeded" and type(job.get("exit_code")) is int and job["exit_code"]==0
        and job.get("leader_wait_status_known") is True and job.get("owned_drain_observed") is True,
        "Actual successful leader wait0 and owned drain")
    c.require(type(job.get("pid")) is int and job["pid"]>0 and type(job.get("leader_start_ticks")) is int and job["leader_start_ticks"]>0,
        "Actual leader PID/start identity")
    ids=job.get("process_identities")
    c.require(isinstance(ids,list) and ids and all(identity(v) for v in ids)
        and any(v["pid"]==job["pid"] and v["start_ticks"]==job["leader_start_ticks"] for v in ids),
        "Same leader and finite captured owned identities")
    c.require(len({(v["pid"],v["start_ticks"]) for v in ids})==len(ids),"Unique process identities")
    c.require(isinstance(job.get("descendant_waits"),list) and all(
        identity(dict(w,uid=next((v["uid"] for v in ids if v["pid"]==w.get("pid") and v["start_ticks"]==w.get("start_ticks")),-1)))
        and any(v["pid"]==w.get("pid") and v["start_ticks"]==w.get("start_ticks") for v in ids)
        and w.get("wait_status_known") is True and type(w.get("returncode")) is int and w["returncode"]==0
        and type(w.get("raw_wait_status")) is int and w["raw_wait_status"]==0
        for w in job["descendant_waits"]),"All actual adopted descendant waits0")
    c.require(not job.get("resource_abort") and not job.get("cancel_requested") and not job.get("owned_termination") and not job.get("error"),
        "No cancelled/resource-aborted/error job")
    c.require(all(type(job.get(k)) in (int,float) and math.isfinite(job[k]) and job[k]>0
        for k in ("started_unix","started_monotonic","finished_unix")) and job["finished_unix"]>=job["started_unix"],
        "Actual ordered finite terminal timestamps")
    return job

def _validate_fit_records_v1(cert,record):
    c.require(cert.get("schema")==CERT_SCHEMA and cert.get("root_authorizer")=="root_agent"
        and cert.get("status")=="actual_method_wait0_owned_drain"
        and cert.get("actual_execution") is True and cert.get("submit_acknowledgment_is_terminal") is False
        and cert.get("terminal_validator_ref")==c.ref(SOURCE),"Explicit actual TGB fit terminal certificate; never submit acknowledgment")
    cap=c.read(cert["capability_ref"]);registry=c.read(cert["registry_snapshot_ref"]);tool=c.read(cert["actual_tool_terminal_ref"])
    c.require(cap.get("schema")=="GPU0_declared_logical_pool_capability_v1" and cap.get("root_authorizer")=="root_agent"
        and cap.get("physical_gpu")==0 and cap.get("gpu_uuid")==c.UUID
        and cert["pool_source_ref"]==c.ref("research/reviews/GPU0_declared_experiments_pool_source_20261016_v1/gpu0_declared_pool_v1.py")
        and cert["pool_source_ref"] in cap["source_refs"].values(),"Genuine source-bound future GPU0 finite pool")
    for name,r in cap["source_refs"].items():
        c.require(name==r["path"] and c.ref(name)==r,"Actual complete controller source closure unchanged")
    c.require(registry.get("schema")=="GPU0_declared_logical_pool_registry_v1"
        and registry.get("capability_ref")==cert["capability_ref"] and registry.get("pool")==cap["pool"]
        and registry.get("physical_gpu")==0 and registry.get("pool_job")=="gpu0_shared_v1:"+cap["pool"]+":gpu0"
        and identity(registry.get("controller")) and registry.get("safety_error") is None and not registry.get("ambiguous_descendants_or_lease_holders"),
        "Exact unambiguous source-bound finite registry")
    name=cert["logical_job"];rows=[r for r in registry.get("jobs",[]) if r.get("logical_job")==name]
    c.require(len(rows)==1 and name in cap["jobs"],"One actual declared fit job")
    job=successful_job(rows[0]);outer=cap["jobs"][name]
    c.require(job.get("requested")==outer and outer["job_id"]==name,"Exact genuine requested outer job")
    envelope=c.read(outer["input_ref"]);request=c.read(envelope["request_ref"])
    c.require(envelope.get("schema")=="GPU0_declared_operational_envelope_v1"
        and envelope["operational_storage_ref"]==outer["storage_ref"]
        and request.get("schema")=="GPU0_declared_operational_request_v1","Actual outer envelope/request/source identity")
    method=request["method_job"];spec=c.read(method["input_ref"]);storage=c.read(method["storage_ref"])
    c.require(outer["module_ref"]==method["module_ref"] and outer["cuda_caps_ref"]==method["cuda_caps_ref"]
        and outer["cuda_cap_bytes"]==method["cuda_cap_bytes"] and outer["cpu_rss_cap_bytes"]==method["cpu_rss_cap_bytes"]
        and outer["operational_deadline_seconds"]==method["operational_deadline_seconds"]
        and outer["args"]==["--execute","--input",outer["input_ref"]["path"],"--expected-input-sha256",outer["input_ref"]["sha256"]],
        "Exact outer source/caps/literal envelope arguments derive from original method")
    c.require(method["job_id"]==name and spec["job_id"]==name
        and method["input_ref"]==cert["scientific_input_ref"] and spec["refs"]["storage"]==method["storage_ref"]
        and spec.get("phase")=="train" and spec.get("root_authorizer")=="root_agent" and spec.get("status")=="active"
        and spec.get("physical_gpu")==0 and spec.get("gpu_uuid")==c.UUID and "heldout_target_capability_ref" not in spec
        and spec.get("schema")=="TGB_H051_GPU0_root_input_v1"
        and spec.get("frozen_scientific_handoff_ref")==c.FROZEN_HANDOFF
        and method["module_ref"]==spec["scientific_entry_ref"]==c.ref(c.SCIENCE+"/driver_v1.py")
        and method["runtime_entry_ref"]==spec["runtime_entry_ref"]==c.ref(c.HERE+"/runtime_train_v1.py")
        and method["cuda_cap_bytes"]==spec["max_cuda_reserved_bytes"]==c.CUDA_CAP
        and method["cpu_rss_cap_bytes"]==spec["max_cpu_rss_bytes"]==c.RSS_CAP
        and method["operational_deadline_seconds"]==c.DEADLINE
        and method["args"]==["--execute","--input",method["input_ref"]["path"],"--expected-input-sha256",method["input_ref"]["sha256"]]
        and storage["job_id"]==name and storage["output_directory"]==spec["output_directory"]
        and storage["reserved_new_bytes"]==c.OUTPUT_CAP and storage["reservation"]["auxiliary_scopes"]==[],
        "Exact unchanged scientific fit input/entry/caps/storage/arguments resolved from actual outer job")
    for path,sha in spec["source_sha256"].items():
        c.require(c.ref(path)==dict(path=path,sha256=sha),"Original complete fit science/runtime source closure unchanged")
    c.require(c.read(spec["refs"]["config"])==c.protocol_v1(),"Exact original fit protocol")
    c.require(tool.get("schema")==TOOL_SCHEMA and tool.get("root_authorizer")=="root_agent"
        and tool.get("observation_source")=="actual_root_exec_or_write_stdin_terminal"
        and tool.get("command") in ("wait","direct_supervisor_wait")
        and type(tool.get("actual_exit_code")) is int and tool["actual_exit_code"]==0
        and tool.get("actual_terminal_consumed") is True and tool.get("capability_ref")==cert["capability_ref"]
        and tool.get("logical_job")==name and tool.get("terminal_job")==job
        and tool.get("controller_identity")==registry["controller"]
        and isinstance(tool.get("exec_session_id"),(str,int)) and bool(str(tool["exec_session_id"]))
        and isinstance(tool.get("terminal_chunk_id"),str) and tool["terminal_chunk_id"]
        and registry["updated_unix"]>=job["finished_unix"],
        "Genuine root-consumed METHOD wait0 identity; submitclient0 cannot establish terminal")
    folder=spec["output_directory"]
    c.require(c.path(cert["fit_completed_ref"]["path"])==c.path(folder+"/fit_completed.json")
        and c.path(cert["prediction_seal_ref"]["path"])==c.path(folder+"/prediction_seal.json")
        and c.path(cert["runtime_binding_ref"]["path"])==c.path(folder+"/runtime_binding.json"),"Exact original fit outputs")
    fit=c.read(cert["fit_completed_ref"]);seal=c.read(cert["prediction_seal_ref"]);binding=c.read(cert["runtime_binding_ref"])
    c.require(binding.get("schema")=="TGB_H051_GPU0_actual_runtime_binding_v1"
        and binding.get("input_ref")==method["input_ref"] and binding.get("storage_ref")==method["storage_ref"]
        and binding.get("runtime_entry_ref")==method["runtime_entry_ref"]
        and binding.get("scientific_entry_ref")==method["module_ref"]
        and binding.get("frozen_scientific_handoff_ref")==c.FROZEN_HANDOFF
        and binding.get("source_closure_ref")==spec["transitive_source_closure_ref"],"Actual writer binds original fit metadata to exact executed input")
    c.require(fit.get("schema")=="TGB_trade_H051_primary_fit_completed_v1"
        and fit.get("primary_full_budget_complete") is True and fit.get("total_models")==3
        and fit.get("total_optimizer_updates")==300 and fit.get("TRAIN_graph_forwards")==6900
        and fit.get("final_replay_graph_forwards")==90 and fit.get("VAL_or_TEST_metric_computed") is False
        and fit.get("confirmation_started") is False and c.same_ref_v1(fit.get("prediction_seal_ref"),cert["prediction_seal_ref"])
        and fit["executed_protocol_ref"]==seal["executed_protocol_ref"]
        and c.read(fit["executed_protocol_ref"])==c.protocol_v1(),"Authentic original3arm100epoch completion and frozen protocol")
    c.require(seal.get("schema")=="TGB_trade_H051_primary_all_country_predictions_sealed_v1"
        and seal.get("shape")==[1,3,7,255,255] and seal.get("axes")==["seed","arm","forecast_year","source_country","destination"]
        and seal.get("dtype")=="torch.float32" and seal.get("seeds")==[17]
        and seal.get("arms")==["tree_only","first_order","conditional_triple"]
        and seal.get("forecast_years")==list(range(2010,2017)) and seal.get("all_255_source_predictions") is True
        and seal.get("official_query_source_selection_performed") is False
        and seal.get("heldout_target_loader_invoked_by_trainer") is False
        and seal.get("fit_target_years")==list(range(1987,2010)) and seal.get("chosen_final_epoch")==100
        and len(seal.get("checkpoint_refs",[]))==3
        and c.path(seal["prediction_ref"]["path"])==c.path(folder+"/primary_all_heldout_predictions.npy"),
        "Every model/year/all255sources sealed before any held-out source/label selection")
    return dict(certificate=cert,capability=cap,registry=registry,job=job,method_job=method,
        scientific_input=spec,fit=fit,seal=seal,fit_terminal_certificate_ref=record)

def validate_fit_terminal_v1(record):
    return _validate_fit_records_v1(c.read(record),record)

def load_prediction_bundle_v1(proof):
    """Read retained5.46MB payload only; no model/checkpoint/replay/refit."""
    raw=c.checked(proof["seal"]["prediction_ref"],limit=5462100+65536)
    import numpy as np,torch
    values=np.load(io.BytesIO(raw),allow_pickle=False)
    c.require(values.shape==(1,3,7,255,255) and values.dtype==np.float32 and values.flags.c_contiguous
        and values.nbytes==5462100 and bool(np.isfinite(values).all()),"Exact full sealed FP32 retained payload")
    payload=hashlib.sha256(memoryview(values.reshape(-1)).cast("B")).hexdigest()
    c.require(payload==proof["seal"]["score_payload_sha256"],"Actual all255 prediction payload hash before label capability")
    from research.reviews.TGB_trade_H051_training_source_20261016_v1.trainer_v1 import SealedPrimaryPredictionsV1
    return SealedPrimaryPredictionsV1(torch.from_numpy(values.copy()),(17,),("tree_only","first_order","conditional_triple"),
        tuple(range(2010,2017)),proof["certificate"]["prediction_seal_ref"],proof["certificate"]["fit_completed_ref"],payload)

def bind_fit_terminal_v1(request_ref,folder):
    """Future root-only descriptive binding. Never polls/waits/signals or infers."""
    req=c.read(request_ref)
    c.require(req.get("schema")=="TGB_H051_GPU0_root_fit_terminal_binding_request_v1"
        and req.get("status")=="active" and req.get("root_authorizer")=="root_agent","Explicit root binding after genuine method wait0")
    cert=dict(schema=CERT_SCHEMA,status="actual_method_wait0_owned_drain",root_authorizer="root_agent",
        actual_execution=True,submit_acknowledgment_is_terminal=False,terminal_validator_ref=c.ref(SOURCE))
    for k in ("logical_job","capability_ref","registry_snapshot_ref","actual_tool_terminal_ref","pool_source_ref",
        "scientific_input_ref","fit_completed_ref","prediction_seal_ref","runtime_binding_ref"):cert[k]=req[k]
    target=c.path(folder);c.require(not target.exists() and target.parent.is_dir(),"Fresh metadata certificate directory")
    # Validate all evidence before committing the descriptive certificate.
    # The candidate is checked in memory; all evidence remains exact disk metadata.
    marker=dict(path=c.HERE+"/__in_memory_certificate_only__.json",sha256="0"*64)
    _validate_fit_records_v1(cert,marker)
    target.mkdir();p=target/"fit_terminal_certificate.json";p.write_text(json.dumps(cert,indent=2,sort_keys=True)+"\n")
    result=c.ref(str(p.relative_to(c.ROOT)));validate_fit_terminal_v1(result);return result
