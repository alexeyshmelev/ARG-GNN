"""Minimal source-only smoke checks. No data, model, guard or GPU execution."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
import ast,copy,json,sys
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import common_v1 as c
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import runtime_train_v1 as train
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import fit_terminal_v1 as terminal
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import heldout_targets_v1 as heldout

def run_checks_v1():
    cases=[]
    def check(name,ok):
        c.require(ok,name);cases.append(dict(case=name,passed=True))
    def reject(name,fn):
        try:fn()
        except (ValueError,KeyError,TypeError):cases.append(dict(case=name,passed=True));return
        raise ValueError("Unexpected acceptance:"+name)
    base=Path(c.HERE)
    for p in base.glob("*.py"):ast.parse(p.read_text());compile(p.read_text(),str(p),"exec")
    check("all_new_sources_parse_compile",True)
    check("exact_caps32MiB_2GiB_8GiB_2h", (c.OUTPUT_CAP,c.CUDA_CAP,c.RSS_CAP,c.DEADLINE)==(33554432,2147483648,8589934592,7200))
    reject("prepare_rejects_unbound_TRAIN_before_data",lambda:train.prepare_v1(c.protocol_v1()))
    tr=Path(c.HERE+"/runtime_train_v1.py").read_text()
    check("TRAIN_has_no_heldout_or_evaluator_import",not any(isinstance(n,(ast.Import,ast.ImportFrom)) and
        ("heldout_targets" in ast.unparse(n) or "evaluation_v1" in ast.unparse(n)) for n in ast.walk(ast.parse(tr))))
    original_reader=Path(c.DATA+"/observed_archive_v1.py").read_text()
    check("pinned_original_archive_reader_unchanged",c.ref(c.DATA+"/observed_archive_v1.py")["sha256"]=="b5a3c3587cb02ef688852e14d3e3ef2b60f687e935df7fbe7910e2bbe1836b5f")
    check("pinned_unchanged_scope_checker",c.ref(c.CHECKER)["sha256"]=="2621353de0dc56f328f7f308ba17a341425ef2fc02d54739b6ccfc7d1a6ce2cf")
    common_src=Path(c.SOURCE).read_text();tree=ast.parse(common_src)
    runtime=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="runtime_v1")
    callback=next(n for n in runtime.body if isinstance(n,ast.FunctionDef) and n.name=="check")
    names=ast.unparse(callback)
    check("epoch_year_callback_has_no_global_or_scope_disk_guard",not any(s in names for s in ("budget_check","checker.check","measure_scopes","inspect_v1")))
    writer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="writer_v1")
    text=ast.unparse(writer)
    check("writer_subclass_delegates_original_science_artifact_methods",all("super()."+name in text for name in ("_json","begin_run","save_initial","save_final","seal_predictions")))
    check("writer_adds_no_optimizer_or_model_math",not any(word in text for word in ("backward(","optimizer.step","forward_step","softmax(")))
    held_src=Path(c.HERE+"/heldout_targets_v1.py").read_text()
    check("heldout_requires_fit_then_payload_before_archive",held_src.index("terminal.validate_fit_terminal_v1")<held_src.index("terminal.load_prediction_bundle_v1")<held_src.index("archive_module.download_observations_v1"))
    check("heldout_filters_year_before_country_weight",held_src.index("if current not in values:continue")<held_src.index("u,v=self.archive.node_ids"))
    fit_src=Path(c.HERE+"/fit_terminal_v1.py").read_text()
    check("retained_payload_loader_has_no_checkpoint_replay_or_refit","torch.load(" not in fit_src and "run_primary_v1(" not in fit_src)
    check("terminal_accepts_wait_only_not_submit_ack",'("wait","direct_supervisor_wait")' in fit_src and 'submit_acknowledgment_is_terminal' in fit_src)
    fake=dict(path="synthetic_in_memory_metadata.json",sha256="0"*64)
    proof=dict(fit_terminal_certificate_ref=fake,certificate=dict(prediction_seal_ref=fake))
    cap=dict(schema="TGB_H051_explicit_heldout_target_capability_v1",root_authorizer="root_agent",status="active",split="VAL",
        fit_terminal_certificate_ref=fake,prediction_seal_ref=fake,heldout_reader_ref=c.ref(c.HERE+"/heldout_targets_v1.py"),
        allowed_target_years=list(range(2010,2014)),complete_all255_predictions_before_target_source_selection=True,
        VAL_release_authorized=True,expires_at_utc=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
    check("synthetic_in_memory_VAL_cap_control",heldout.validate_split_capability_v1(cap,"VAL",proof)==cap)
    for key,value in (("allowed_target_years",[2014]),("split","TEST"),("VAL_release_authorized",False),("complete_all255_predictions_before_target_source_selection",False)):
        bad=copy.deepcopy(cap);bad[key]=value
        reject("reject_synthetic_bad_VAL:"+key,lambda bad=bad:heldout.validate_split_capability_v1(bad,"VAL",proof))
    test=copy.deepcopy(cap);test.update(split="TEST",allowed_target_years=list(range(2014,2017)),TEST_release_authorized=True)
    reject("TEST_requires_separate_frozen_confirmation_decision",lambda:heldout.validate_split_capability_v1(test,"TEST",proof))
    job=dict(state="succeeded",exit_code=0,leader_wait_status_known=True,owned_drain_observed=True,pid=101,leader_start_ticks=201,
        process_identities=[dict(pid=101,uid=1000,start_ticks=201)],descendant_waits=[],
        started_unix=1.,started_monotonic=1.,finished_unix=2.)
    check("synthetic_in_memory_wait0_drain_control",terminal.successful_job(job)==job)
    for key,value in (("leader_wait_status_known",False),("owned_drain_observed",False),("exit_code",1),("cancel_requested",True)):
        bad=copy.deepcopy(job);bad[key]=value
        reject("reject_synthetic_bad_terminal:"+key,lambda bad=bad:terminal.successful_job(bad))
    check("no_numerical_or_canonical_guard_import",not any(x in sys.modules for x in ("torch","torch_geometric","arggnn.native_argformer_exec")))
    return dict(schema="TGB_H051_GPU0_source_only_smoke_v1",status="PASS",case_count=len(cases),cases=cases,
        source_only=True,synthetic_records_in_memory_only=True,no_data_labels_predictions_models_or_checkpoints_read=True,
        no_guard_GPU_admission_job_or_Git_calls=True,actual_scientific_or_device_qualification=False)
if __name__=="__main__":print(json.dumps(run_checks_v1(),indent=2,sort_keys=True))
