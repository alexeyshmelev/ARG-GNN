"""Explicit split evaluation from retained sealed predictions; no refit/replay."""
import json
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import common_v1 as c
SOURCE=c.HERE+"/runtime_evaluate_v1.py"

def invoke_job_v1(j):
    c.require(j.get("worker_kind",j.get("kind"))=="TGB" and j.get("runtime_entry_ref")==c.ref(SOURCE)
        and j.get("module_ref")==c.ref(c.SCIENCE+"/evaluation_v1.py"),"Exact finite original TGB evaluation entry")
    spec=c.read(j["input_ref"]);spec["input_ref"]=j["input_ref"]
    c.require(spec.get("phase")=="evaluate" and spec.get("split") in ("VAL","TEST")
        and spec.get("fit_authorized") is False and c.is_ref(spec.get("heldout_target_capability_ref"))
        and c.is_ref(spec.get("fit_terminal_certificate_ref"))
        and spec.get("runtime_entry_ref")==c.ref(SOURCE)
        and spec.get("scientific_entry_ref")==c.ref(c.SCIENCE+"/evaluation_v1.py")
        and spec["runtime_source_refs"].get("heldout_reader")==c.ref(c.HERE+"/heldout_targets_v1.py")
        and spec["runtime_source_refs"].get("fit_terminal")==c.ref(c.HERE+"/fit_terminal_v1.py"),
        "Separate root-active VAL/TEST input with explicit target capability and genuine fit terminal")
    operational=c.runtime_v1(spec,j)
    try:
        # Heldout module is reachable only through this separately bound entry.
        targets_module=c.load(c.HERE+"/heldout_targets_v1.py",
            "research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1.heldout_targets_v1")
        targets=targets_module.HeldoutTargetsV1(spec["heldout_target_capability_ref"],spec["split"],
            spec["fit_terminal_certificate_ref"],operational["runtime_check"])
        protocol=c.protocol_v1();writer=c.writer_v1(spec,operational);writer.begin_run(protocol)
        baseline_ref=protocol["source_refs"]["H052_results"]
        baseline=c.read(baseline_ref)
        evaluator=c.load(c.SCIENCE+"/evaluation_v1.py",
            "research.reviews.TGB_trade_H051_training_source_20261016_v1.evaluation_v1")
        result=evaluator.evaluate_sealed_split_v1(targets.bundle,split=spec["split"],
            load_target_year=targets.load_target_year_v1,baseline_results=baseline,baseline_result_ref=baseline_ref,
            writer=writer,runtime_check=operational["runtime_check"],protocol=protocol)
        completed=writer._json("evaluation_completed.json",dict(schema="TGB_H051_GPU0_explicit_split_completed_v1",
            input_ref=j["input_ref"],split=spec["split"],fit_terminal_certificate_ref=spec["fit_terminal_certificate_ref"],
            heldout_target_capability_ref=spec["heldout_target_capability_ref"],
            frozen_confirmation_decision_ref=targets.cap.get("frozen_confirmation_decision_ref"),
            original_evaluation_result_ref=result,prediction_seal_ref=targets.bundle.seal_ref,
            retained_prediction_payload_reconstructed=True,model_or_training_replay=False,
            optimization_performed=False,selection_on_TEST=False))
        operational["runtime_check"]("after_explicit_split_evaluation");operational["checker"].check(required=0)
        print(json.dumps(dict(status="TGB_explicit_split_evaluated",split=spec["split"],completed_ref=completed,
            actual_execution=True,model_or_training_replay=False)),flush=True)
        return 0
    finally:operational["checker"].memo.uninstall()
