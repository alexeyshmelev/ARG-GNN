"""Separate explicit VAL/TEST capability. TRAIN never imports this module."""
from datetime import datetime
import csv,io,time
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import common_v1 as c
from research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1 import fit_terminal_v1 as terminal
SOURCE=c.HERE+"/heldout_targets_v1.py"

def validate_split_capability_v1(cap,split,proof):
    c.require(split in ("VAL","TEST") and cap.get("schema")=="TGB_H051_explicit_heldout_target_capability_v1"
        and cap.get("root_authorizer")=="root_agent" and cap.get("status")=="active"
        and cap.get("split")==split and cap.get("fit_terminal_certificate_ref")==proof["fit_terminal_certificate_ref"]
        and c.same_ref_v1(cap.get("prediction_seal_ref"),proof["certificate"]["prediction_seal_ref"])
        and cap.get("heldout_reader_ref")==c.ref(SOURCE)
        and cap.get("allowed_target_years")==(list(range(2010,2014)) if split=="VAL" else list(range(2014,2017)))
        and cap.get("complete_all255_predictions_before_target_source_selection") is True,
        "Independent exact root split capability and genuine frozen fit/seal")
    end=datetime.fromisoformat(cap["expires_at_utc"])
    c.require(end.tzinfo is not None and time.time()<end.timestamp(),"Active held-out target capability")
    if split=="VAL":c.require(cap.get("VAL_release_authorized") is True,"Explicit VAL release")
    else:
        c.require(cap.get("TEST_release_authorized") is True and c.is_ref(cap.get("frozen_confirmation_decision_ref")),
            "Separate explicit TEST release and frozen confirmation decision")
        decision=c.read(cap["frozen_confirmation_decision_ref"])
        c.require(decision.get("schema")=="TGB_H051_confirmation_decision_frozen_v1"
            and decision.get("root_authorizer")=="root_agent" and decision.get("status")=="frozen"
            and decision.get("TEST_closed_when_frozen") is True
            and decision.get("fit_terminal_certificate_ref")==proof["fit_terminal_certificate_ref"]
            and isinstance(decision.get("decision"),str) and bool(decision["decision"])
            and decision.get("selection_on_TEST") is False,"Root decision frozen while TEST closed; no TEST selection")
    return cap

class HeldoutTargetsV1:
    def __init__(self,capability_ref,split,fit_terminal_certificate_ref,runtime_check):
        self.capability_ref=capability_ref;self.split=split;self.runtime_check=runtime_check
        self.proof=terminal.validate_fit_terminal_v1(fit_terminal_certificate_ref)
        self.cap=validate_split_capability_v1(c.read(capability_ref),split,self.proof)
        # This authenticates both NPY artifact SHA and raw full255 payload SHA,
        # shape/axes/all arms/years before any label member can be opened.
        self.bundle=terminal.load_prediction_bundle_v1(self.proof)
        runtime_check("after_sealed_full255_payload_before_heldout_archive")
        archive_module=c.load(c.DATA+"/observed_archive_v1.py","_TGB_original_observed_archive_for_explicit_split")
        self.archive=archive_module.download_observations_v1()
        c.require(self.archive.train_label_member_opened is False,"Original archive has opened no labels")
        self._targets=None;self.heldout_label_member_opened=False

    def load_target_year_v1(self,year):
        c.require(type(year) is int and year in self.cap["allowed_target_years"],"Reject other split BEFORE label member access")
        c.require(c.read(self.capability_ref)==self.cap,"Immutable explicit root split capability")
        validate_split_capability_v1(self.cap,self.split,self.proof)
        self.runtime_check("before_explicit_"+self.split+"_target_"+str(year))
        if self._targets is None:
            import numpy as np
            values={y:(np.zeros((255,255),dtype=np.float64),np.zeros(255,dtype=bool)) for y in self.cap["allowed_target_years"]}
            with self.archive._archive.open(self.archive._label_member) as raw:
                self.heldout_label_member_opened=True
                reader=csv.reader(io.TextIOWrapper(raw,encoding="utf-8",newline=""))
                c.require(next(reader)==["year","nation","trading nation","weight"],"Original exact target schema")
                for row in reader:
                    current=int(row[0])
                    # Filter year BEFORE decoding any other split's country,
                    # source presence or weight. Nothing outside this split stored.
                    if current not in values:continue
                    u,v=self.archive.node_ids[row[1]],self.archive.node_ids[row[2]];w=float(row[3])
                    matrix,present=values[current]
                    c.require(np.isfinite(w) and w>0 and matrix[u,v]==0,"Exact official split labels and no duplicate pair")
                    matrix[u,v]=w;present[u]=True
            self._targets=values
        import torch
        from research.reviews.TGB_trade_H051_training_source_20261016_v1.targets_and_metrics_v1 import TargetYearV1
        matrix,present=self._targets[year]
        return TargetYearV1(year,torch.from_numpy(matrix.copy()),torch.from_numpy(present.copy()))
