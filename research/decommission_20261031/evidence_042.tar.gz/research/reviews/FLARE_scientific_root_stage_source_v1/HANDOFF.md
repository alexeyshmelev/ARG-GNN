# FLARE root scientific stage source handoff

The completed target is american_c3_train_000, the full30Mb TRAIN inference canary/development cell. It is not a held-out comparison. The active templates bind the actual original observation, completed path-preparation focal registry, root counts and simulation map metadata. No genotype, focal, tree, JAR or query truth payload was opened by this source task.

The actual installed-JDK FLARE source build completed with real outer/direct wait0. Its completion is data/native_FLARE_build_existing_JDK_root_v1/completed.json, SHA 460201cfe83d9b0aa8b966682957e65012091c1c2e3a0a983e29c920950ca910. actual_completed_build_input.json binds the genuine build completion, binary provenance, Java qualification, build record and both outer/minimal direct-wait receipts. Native invocation uses this build by default, with no new build or agent qualification run.

Root uses root_stage_driver.py from the project cwd with CUDA_VISIBLE_DEVICES empty. CPU threads are4. Every root admission uses the original unmemoized completed-credit-v3 reserve path and binds the actual46d4 context, all21 actual source files, selected template, target/input completion/count metadata, active config/runtime/registration and actual predecessor/build metadata. The64-ref limit is enforced before reserve. Prospective binding counts from source/metadata checks were conversion43, native51, seal48.

Each --admit requires --packet, --output, --job-id and --expires-at-utc with fresh project-local paths and an explicit future UTC expiry. It returns an exact admission_ref. Admission creates a root registration and active stage config; no worker is launched until the separate --launch call. Fresh output and worker_aux scopes share the exact stage cap. There is no scheduler or automatic chaining.

Use the following argv shapes, replacing bracketed values with actual root-owned paths/keys/expiry and returned refs. All command environments set CUDA_VISIBLE_DEVICES='' and OMP_NUM_THREADS=MKL_NUM_THREADS=OPENBLAS_NUM_THREADS=NUMEXPR_NUM_THREADS=4.

1. Convert:
   .runtime/env/bin/python -B DRIVER --admit --stage convert --target TARGET --expected-target-sha256 TARGET_SHA --packet [fresh-convert-packet] --output [fresh-convert-output] --job-id [fresh-convert-key] --expires-at-utc [future-UTC]
2. Launch each admitted stage:
   .runtime/env/bin/python -B DRIVER --launch --admission [reported-admission-path] --expected-admission-sha256 [reported-admission-SHA]
3. After actual conversion success, native:
   .runtime/env/bin/python -B DRIVER --admit --stage native --target TARGET --expected-target-sha256 TARGET_SHA --conversion [actual-conversion-completed.json] --expected-conversion-sha256 [actual-SHA] --packet [fresh-native-packet] --output [fresh-native-output] --job-id [fresh-native-key] --expires-at-utc [future-UTC]
4. After actual native success and its real wait0/group ESRCH, seal:
   .runtime/env/bin/python -B DRIVER --admit --stage seal --target TARGET --expected-target-sha256 TARGET_SHA --native-run [actual-native-completed.json] --expected-native-run-sha256 [actual-SHA] --packet [fresh-seal-packet] --output [fresh-seal-output] --job-id [fresh-seal-key] --expires-at-utc [future-UTC]

DRIVER = research/reviews/FLARE_scientific_root_stage_source_v1/root_stage_driver.py
TARGET = research/reviews/FLARE_scientific_root_stage_source_v1/train000_target.json
TARGET_SHA = a944251c7e5b0d7cc311192b2e953aac4f2d193235f4e8834c5f7745406e954b

Storage caps remain conversion950000000B, native9000000000B and seal32000000B. Formula bounds use all226185 input sites: conversion876994450B, native8499254001B including VCF7373083377B and1GiB temporary space, seal21897216B. A524288B outer receipt/log allowance is also checked inside each cap. No compression or native marker-filter savings are assumed.

All scientific producer sources are unchanged. Conversion preserves all supported observed2-to4-allele SNPs and rejects unsupported sites without silent filtering. The official native options remain probs=true, em=true, update-p=false, array=false, min-maf=.005, min-mac=50, gen=10, panel-probs=false, nthreads=4, seed=-99999; native heap stays16GiB. The whole native .anc.vcf.gz, .model, .global.anc.gz and .log products are preserved. Sealing uses original AN1/AN2 calls, carries their one-hot transport to the original common scorer, and retains raw rounded ANP values/strings. Only the optional derived marker-tract TSV is disabled. Scoring remains pending and no truth reference is admitted.

Outer monitoring reuses the frozen build driver's owned-PID/group helpers. Conversion/seal use4GiB RSS and3600s, native24GiB RSS and14400s, with40s termination grace. Aggregate RSS includes the root monitor and observed descendants across separate native sessions. This is a polling soft bound, not a kernel quota. Between-poll processes/peaks and process/task exit races can be missed and are reported. The original native inference runner supervises its own native group; its Java version probe retains the original subprocess.run behavior. A real proc.wait returncode is exclusively fsynced to worker_aux/actual_wait_minimal.json before final group checks, guards or logs. Unresolved observed groups block final guard/log writes. No automatic completion credit is issued.

For held-out VAL/test, fill heldout_target.inactive_template.json only after actual independent completion. The actual observation completion must expose status completed_current_C3_inference and matching observation_ref. The actual focal completion must expose completed_* status, observation_ref, parent_id, focals_ref, query_focal_count=10000 and query_ancestry_truth_opened=false. Supply the actual root count and matching recorded simulation metadata. The driver requires observation split val/test and the registered_heldout_full30Mb_comparison role. It rejects TRAIN relabelling and mismatched observation/count/focal/predecessor refs. It derives the active three-stage configs from that actual target; oversized actual counts are rejected under the fixed stage caps. The VAL acceptance check here used synthetic metadata only; no actual held-out completion was asserted.

source_static_receipt.json records40 source compilation, bounded-metadata, pure formula and synthetic negative/heldout/predecessor checks. These checks do not execute admission, guards, Popen, Java/native, GPU or Git and do not validate end-to-end science execution. Root owns actual execution and scoring/reporting.
