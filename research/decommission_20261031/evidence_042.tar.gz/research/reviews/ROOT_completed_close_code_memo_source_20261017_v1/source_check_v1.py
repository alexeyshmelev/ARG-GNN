"""RAM tests of exact close critical AST + original code-only transaction cache.

All guard state, authorities, JSON, namespaces, PID observations, measurements,
mutex and append are synthetic RAM fixtures. No project guard is imported; no
real mutex, process, journal, payload, measurement or authority operation occurs.
"""
from pathlib import Path
from types import ModuleType,SimpleNamespace
from contextlib import contextmanager
from datetime import datetime,timezone
import ast,copy,hashlib,json,traceback
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/ROOT_completed_close_code_memo_source_20261017_v1"
SRC=HERE+"/root_completed_close_code_memo_v1.py"
BPATH="research/reviews/ROOT_mutation_transaction_memo_source_20261017_v1/root_mutation_memo_v1.py"
GPATH="research/reviews/Relate_failed64GiB_retention_successor_source_20261017_v1/relate_failed64_retention_v1.py"
VPATH="src/arggnn/project_budget_v4.py"
QPATH="scripts/project_budget_v9.py"
raws={p:(ROOT/p).read_bytes()for p in (SRC,BPATH,GPATH,VPATH,QPATH)}
def need(ok,message):
 if not ok:raise ValueError(message)
def defs(tree):return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
trees={p:ast.parse(raw)for p,raw in raws.items()}
gd,vd,qd=(defs(trees[p])for p in (GPATH,VPATH,QPATH))
# Only inert helper modules are evaluated. Their top-level code imports stdlib,
# defines constants/callables, and performs no project IO or guard operation.
base_ns={"__name__":"ram_original_code_memo","__file__":str(ROOT/BPATH)}
exec(compile(raws[BPATH],str(ROOT/BPATH),"exec",dont_inherit=True,optimize=0),base_ns)
ext={"__name__":"ram_completed_close_memo","__file__":str(ROOT/SRC)}
exec(compile(raws[SRC],str(ROOT/SRC),"exec",dont_inherit=True,optimize=0),ext)
BASE_REF=ext["BASE_REF"];BREV=ext["BASE_REVIEW_REF"];BSEAL=ext["BASE_REVIEW_MANIFEST_REF"]
for r in (BREV,BSEAL):raws[r["path"]]=(ROOT/r["path"]).read_bytes()
base_api=defs(trees[BPATH])["RootMutationMemo"]
allow_expr=next(n.args[0]for n in ast.walk(defs(base_api)["__init__"])if isinstance(n,ast.Call)and ast.unparse(n.func)=="need"and any(isinstance(x,ast.Name)and x.id=="record"for x in ast.walk(n.args[0])))
def allowed(record):
 return eval(compile(ast.Expression(allow_expr),"<original-code-allowlist>","eval"),{"__builtins__":{},"Path":Path,"isinstance":isinstance,"dict":dict,"set":set,"str":str,"len":len,"all":all},{"record":record})
class Fixture:
 def __init__(self,hook=None):
  self.hook=hook or (lambda fixture,event:None);self.mem=dict(raws);self.reads={};self.events=[]
  self.trace=[];self.locked=False;self.enters=0;self.exits=0;self.txs=[];self.namespace_change=False
  self.expired=False;self.force_bad_prefix=False;self.append_error=False;self.enter_error=False
  self.code_ref=self.put("research/RAM_close/code.py",b"def immutable_code(): return 1\n")
  self.json_ref=self.put("research/RAM_close/read_many.json",{"metadata":"must never cache"})
  self.a={"path":SRC,"sha256":hashlib.sha256(raws[SRC]).hexdigest()}
  comp=self.put(HERE+"/RAM_component_manifest.json",{"source_sha256":{SRC:self.a["sha256"],BPATH:BASE_REF["sha256"]}})
  self.review_ref=self.put(HERE+"/RAM_independent_review.json",{
   "independent":True,"source_only":True,"verdict":"SOURCE_PASS","source_ref":self.a,
   "base_memo_ref":BASE_REF,"source_manifest_ref":comp,"blockers":[]})
  pins={r["path"]:r["sha256"]for r in (self.a,BASE_REF,BREV,BSEAL,self.review_ref,comp,self.code_ref)}
  self.m=self.put(HERE+"/RAM_integration_manifest.json",{"source_sha256":pins})
  self.own=dict(key="RAM/completed",output=str(ROOT/"RAM_closed_scope"),auxiliary_scopes=[],
   reserved_bytes=33554432,consumer_bindings=[self.code_ref,self.json_ref])
  digest=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
  self.digest=digest
  storage=self.put("research/RAM_close/storage.json",{"reservation":self.own,"reserved_new_bytes":self.own["reserved_bytes"],"output_directory":"RAM_closed_scope"})
  launch=self.put("research/RAM_close/launch.json",{"pid":1234,"job":"RAM"})
  wait=self.put("research/RAM_close/wait.json",{"pid":1234,"returncode":0,"job":"RAM"})
  completed_identity={"status":"completed_RAM","parent_id":"RAM","stage":"fixture"}
  completed=self.put("RAM_closed_scope/completed.json",completed_identity)
  obs=dict(schema="concurrent_completed_scope_targeted_root_observation_v1",root_authorizer="root_agent",
   key=self.own["key"],reservation_sha256=digest(self.own),storage_ref=storage,launch_ref=launch,
   direct_wait_ref=wait,completed_ref=completed,launcher_pid=1234,
   all_root_owned_launcher_supervisor_worker_pids_listed=True,direct_wait_observed=True,
   completed_scope_all_old_original_resume_write_capabilities_revoked=True,preserve_all_files=True,
   external_NFS_writers_outside_observation=True,pids=[1234,1235],
   observations=[dict(pid=n,absent=True,method="targeted os.kill(pid,0) ESRCH",checked_utc="2001-01-01T00:00:00+00:00")for n in (1234,1235)])
  obs[ext["OBSERVATION_FIELD"]]=self.m
  self.obs_ref=self.put("research/RAM_close/observation.json",obs)
  self.request=dict(key=self.own["key"],reservation_sha256=digest(self.own),storage_ref=storage,
   storage_locator=[],launch_ref=launch,launch_pid_locator=["pid"],launch_identity={"pid":1234,"job":"RAM"},
   direct_wait_ref=wait,wait_pid_locator=["pid"],wait_exit_locator=["returncode"],
   wait_identity={"pid":1234,"returncode":0,"job":"RAM"},completed_ref=completed,
   completed_identity=completed_identity,observation_ref=self.obs_ref)
  self.view=dict(base_pins={"frozen":"RAM"},completed_overlay_prefix={"events":0,"tail_sha256":None},
   new_reserved_bytes=self.own["reserved_bytes"],completed_credit_bytes=0)
  self.authority_ref=self.put("research/RAM_close/authority.json",dict(request=self.request,
   expected_before={"base_pins":{"frozen":"RAM"},"completed_overlay_prefix":{"events":0,"tail_sha256":None}},
   expires_at_utc="2099-01-01T00:00:00+00:00"))
  self.state_ref=self.put("research/RAM_close/current_prefix.json",self.view)
  v4=ModuleType("RAM_v4");v4.__file__=str(ROOT/VPATH);vn=v4.__dict__
  def canonical(root,name):
   p=Path(name);p=p if p.is_absolute()else root/p
   need(root==ROOT and p!=root and root in p.parents and ".."not in p.parts,"RAM canonical")
   self.trace.append("canonical")
   if self.namespace_change and str(p)==self.own["output"]:return ROOT/"RAM_replaced_namespace"
   return p
  def file_bytes(root,name):
   p=canonical(root,name);key=str(p.relative_to(ROOT));self.reads[key]=self.reads.get(key,0)+1
   raw=self.mem[key];return raw,hashlib.sha256(raw).hexdigest()
  @contextmanager
  def mutex(root):
   need(root==ROOT and not self.locked,"RAM original nonnested mutex")
   self.enters+=1
   if self.enter_error:raise RuntimeError("RAM mutex enter")
   self.locked=True;self.hook(self,"lock_enter")
   try:yield
   finally:self.locked=False;self.exits+=1
  vn.update(ROOT=ROOT,Path=Path,json=json,hashlib=hashlib,canonical=canonical,file_bytes=file_bytes,
   LEGACY=".runtime/RAM_legacy.json",LOCK=".runtime/RAM_scheduler.lock",SOURCE=VPATH,CONFIG="configs/RAM.json")
  safe=["encoded","integer","parse","reference","bound","scope_spec","paths_overlap","accounting_paths"]
  exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(vd[n])for n in safe],type_ignores=[])),"<exact-v4-pure-RAM-functions>","exec"),vn)
  v4.mutex=mutex
  def measure_scopes(root,paths):
   need(self.locked,"RAM measurement under original mutex");self.trace.append("measure")
   self.hook(self,"measurement")
   return dict(conservative_scope_bytes=4096,entries=2,scope_paths=[str(p)for p in paths],stat_only=True)
  v4.measure_scopes=measure_scopes
  budget=ModuleType("RAM_budget");budget.__file__=str(ROOT/QPATH);budget.v4=v4;budget.digest=digest
  budget.JOURNAL_REL=".runtime/RAM_v9";exec(compile(ast.Module(body=[copy.deepcopy(qd["successor_paths"])],type_ignores=[]),"<exact-successor-pure-RAM>","exec"),budget.__dict__)
  g=ModuleType("RAM_guard");g.__file__=str(ROOT/GPATH);gn=g.__dict__
  gn.update(ROOT=ROOT,budget=budget,Path=Path,copy=copy,datetime=datetime,timezone=timezone,
   MAX_JSON=65536,MAX_COMPLETED_JSON=1048576,COMPLETED_SCHEMAS=frozenset(),
   BOOTSTRAP_CHARGE=2097152,META_CHARGE=524288,CEILING_BYTES=980000000000,HUMAN_LIMIT_BYTES=1000000000000,
   WARNING_BYTES=950000000000,MALFORMED_KEY="RAM/revoked",ORDINARY_EXCLUSIONS=frozenset(),require=need)
  pure=["_raw","_json","_completed_json","_expire","_pointer","_identity","_completed_identity","charge",
   "warning_fields","assert_open","_pins","_measurement","_proof","_utc","apply_close_completed_v1"]
  exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(gd[n])for n in pure],type_ignores=[])),
   str(ROOT/GPATH),"exec",dont_inherit=True,optimize=0),gn)
  def paths(own):return v4.scope_spec(ROOT,own)
  def policy():
   v4.bound(ROOT,self.json_ref,True)
   return dict(never_credit_keys=[],base_projected_bytes=500000000000)
  def state(source,launcher,*,fresh=False):
   need(self.locked and fresh,"RAM fresh state under original mutex");self.trace.append("state")
   for unused in range(3):
    v4.bound(ROOT,self.code_ref);v4.reference(ROOT,self.code_ref["path"]);paths(self.own);v4.bound(ROOT,self.json_ref,True)
   view=v4.bound(ROOT,self.state_ref,True)
   self.hook(self,"state")
   return {self.own["key"]:copy.deepcopy(self.own)},set(),copy.deepcopy(view),{"guard":self.code_ref},[],[],{}
  def authority(ref,operation,bindings,*,fresh):
   need(self.locked and fresh and operation=="close_completed","RAM fresh authority")
   value=g._json(ref);g._expire(value);need(not self.expired,"RAM authority expired at final check")
   if self.force_bad_prefix:value["expected_before"]={"bad":"prefix"}
   self.trace.append("authority");return value
  def absent(pid):
   need(self.locked,"RAM targeted absence under original mutex");self.trace.append("absent")
   return dict(pid=pid,absent=True,method="targeted os.kill(pid,0) ESRCH",checked_utc=datetime.now(timezone.utc).isoformat())
  def append(operation,record,value,state):
   need(self.locked and self.txs and self.txs[-1].enabled is False,"RAM append after disabled cache")
   before=self.reads.get(self.code_ref["path"],0);v4.bound(ROOT,self.code_ref)
   need(self.reads[self.code_ref["path"]]==before+1,"RAM postwrite source read uncached")
   self.trace.append("append");self.events.append((operation,record,copy.deepcopy(value)))
   if self.append_error:raise RuntimeError("RAM original append uncertainty")
   return "f"*64
  original_proof=g._proof
  def proof(request,own,*,observe=False):
   result=original_proof(request,own,observe=observe);self.hook(self,"proof");return result
  gn.update(_paths=paths,_policy=policy,_state_locked=state,_authority=authority,_absent=absent,_append=append,_proof=proof)
  self.g=g;self.v4=v4;self.budget=budget
  self.original_v4={n:getattr(v4,n)for n in ("bound","reference","scope_spec","canonical","file_bytes","mutex","measure_scopes")}
  self.original_successor=budget.successor_paths
  originals={id(mod):{n:getattr(mod,n)for n in (defs(trees[GPATH])if mod is g else ["measure_scopes"])if hasattr(mod,n)}for mod in (g,v4)}
  def source_bytes(record):
   raw=self.mem[record["path"]];need(hashlib.sha256(raw).hexdigest()==record["sha256"],"RAM stable source SHA")
   return raw
  def functions_from_source(module,record,names):
   source_bytes(record);result={}
   for name in names:
    need(getattr(module,name)is originals[id(module)][name],"RAM exact original helper identity")
    node=(gd if module is g else vd)[name]
    result[name]=(getattr(module,name),copy.deepcopy(node))
   return result
  fixture=self
  class Core:
   def __init__(self,guard,*,integration_manifest_ref,adapter_ref,cache_refs):
    need(adapter_ref==BASE_REF,"RAM exact base ref")
    self.allow={}
    for record in cache_refs:
     need(allowed(record),"RAM original immutable code allowlist")
     self.allow[record["path"]]=record["sha256"]
    self._check()
   def _check(self):
    need(not hasattr(g,"_outer_memo"),"RAM no consumer memo")
    for name,fn in fixture.original_v4.items():need(getattr(v4,name)is fn,"RAM original v4 before transaction")
    need(budget.successor_paths is fixture.original_successor,"RAM original budget helper")
    manifest=v4.bound(ROOT,fixture.m,True)
    need(manifest.get("source_sha256",{}).get(BPATH)==BASE_REF["sha256"],"RAM base constructor manifest")
  class Transaction(base_ns["_Transaction"]):
   def __init__(self,*args,**kwargs):
    super().__init__(*args,**kwargs);fixture.txs.append(self)
  self.base=SimpleNamespace(_ACTIVE=False,_Transaction=Transaction,RootMutationMemo=Core,
   source_bytes=source_bytes,functions_from_source=functions_from_source,PINS=base_ns["PINS"])
  ext["load_base"]=lambda:self.base
  self.memo=ext["RootCompletedCloseCodeMemo"](g,integration_manifest_ref=self.m,adapter_ref=self.a,
   independent_review_ref=self.review_ref,cache_refs=[self.code_ref])
 def put(self,path,value):
  raw=value if isinstance(value,bytes)else json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
  self.mem[path]=raw;return dict(path=path,sha256=hashlib.sha256(raw).hexdigest())
 def run(self):
  return self.memo.close_completed_v1(self.authority_ref,expected_source_sha256="RAM_source",expected_launcher_sha256="RAM_launcher")
 def restored(self):
  need(not self.locked and not ext["_ACTIVE"]and not self.base._ACTIVE,"RAM mutex/active flags restored")
  need(all(getattr(self.v4,n)is fn for n,fn in self.original_v4.items()),"RAM v4 original functions restored")
  need(self.budget.successor_paths is self.original_successor,"RAM original successor restored")
  need(all(not tx.sources and not tx.names and tx.bytes==0 and not tx.patches and not tx.enabled for tx in self.txs),"RAM transaction caches destroyed")
results=[]
def success(name):
 f=Fixture();r=f.run();f.restored()
 need(r["credit_bytes"]==33554432-4096 and r["retained_bytes"]==4096 and r["scope_measurements"]==1,"RAM genuine original receipt arithmetic")
 need(r["projected_bytes"]==500000000000+33554432-(33554432-4096)+2097152+524288,"RAM exact original charge")
 need(len(f.events)==1 and f.trace.count("measure")==1 and f.trace.count("absent")==4,"RAM unchanged single measurement/two targeted absence passes")
 need(f.memo.counts["source_hits"]>0 and f.memo.counts["namespace_hits"]>0,"RAM repeated code/name work memoized")
 need(f.reads[f.json_ref["path"]]>=6,"RAM mutable JSON never cached")
 first=dict(f.memo.counts);f.run();f.restored()
 need(len(f.txs)==2 and f.txs[1].counts["source_misses"]>0,"RAM no cross-operation cache")
 results.append({"name":name,"status":"PASS","source_hits":first["source_hits"],"namespace_hits":first["namespace_hits"]})
def failure(name,setup=None,hook=None,append_count=0):
 f=Fixture(hook=hook)
 if setup:setup(f)
 try:f.run()
 except (ValueError,RuntimeError,KeyError):pass
 else:raise AssertionError("RAM negative accepted: "+name)
 f.restored();need(len(f.events)==append_count,"RAM original append count "+name)
 results.append({"name":name,"status":"PASS","append_count":len(f.events)})
success("original close body/proof/measurement/receipt and isolated code cache")
failure("prefix mismatch before proof",setup=lambda f:setattr(f,"force_bad_prefix",True))
failure("expired final authority after measurement",hook=lambda f,e:setattr(f,"expired",True)if e=="measurement"else None)
failure("cached immutable code changed before final validation",hook=lambda f,e:f.mem.__setitem__(f.code_ref["path"],b"changed source")if e=="proof"else None)
failure("helper source changed before append",hook=lambda f,e:f.mem.__setitem__(SRC,b"changed helper")if e=="proof"else None)
failure("original guard source changed before append",hook=lambda f,e:f.mem.__setitem__(GPATH,b"changed guard")if e=="proof"else None)
failure("mutable JSON metadata changed during close",hook=lambda f,e:f.mem.__setitem__(f.json_ref["path"],b'{"metadata":"changed"}')if e=="proof"else None)
failure("integration manifest JSON changed during close",hook=lambda f,e:f.mem.__setitem__(f.m["path"],b'{"source_sha256":{}}')if e=="proof"else None)
failure("independent review JSON changed during close",hook=lambda f,e:f.mem.__setitem__(f.review_ref["path"],b'{"verdict":"FAIL"}')if e=="proof"else None)
failure("authority JSON changed after original proof",hook=lambda f,e:f.mem.__setitem__(f.authority_ref["path"],b'{"request":{}}')if e=="proof"else None)
failure("observation JSON changed after original proof",hook=lambda f,e:f.mem.__setitem__(f.obs_ref["path"],b'{"wrong":"join"}')if e=="proof"else None)
failure("scope namespace changed",hook=lambda f,e:setattr(f,"namespace_change",True)if e=="proof"else None)
def raise_on(event):
 def hook(f,e):
  if e==event:raise RuntimeError("RAM "+event+" exception")
 return hook
failure("proof exception restores original functions",hook=raise_on("proof"))
failure("measurement exception restores original functions",hook=raise_on("measurement"))
failure("original append exception preserves uncertainty/restores",setup=lambda f:setattr(f,"append_error",True),append_count=1)
failure("original mutex acquisition exception resets flags",setup=lambda f:setattr(f,"enter_error",True))
failure("replaced original helper identity rejected",hook=lambda f,e:setattr(f.g,"_measurement",lambda *a:0)if e=="measurement"else None)
# Fresh replay must reject changed authority/state JSON, never reuse snapshots.
failure("changed current prefix JSON",setup=lambda f:f.mem.__setitem__(f.state_ref["path"],b'{"prefix":"changed"}'))
# An observation without the exact new direct integration join is accepted by
# original proof's extra-field rule but must fail at the narrow wrapper boundary.
def wrong_join(f):
 obs=json.loads(f.mem[f.obs_ref["path"]]);obs[ext["OBSERVATION_FIELD"]]={"path":"research/wrong.json","sha256":"0"*64}
 newobs=f.put(f.obs_ref["path"],obs);f.request["observation_ref"]=newobs
 auth=json.loads(f.mem[f.authority_ref["path"]]);auth["request"]=f.request;f.authority_ref=f.put(f.authority_ref["path"],auth)
failure("missing/wrong direct integration join",setup=wrong_join)
# Unsupported role and nested memo failures cannot acquire a mutation lock.
f=Fixture();f.g._outer_memo=object()
try:f.run()
except ValueError:pass
else:raise AssertionError("RAM consumer memo allowed")
f.restored();need(f.enters==0,"RAM consumer memo rejected before lock");results.append({"name":"consumer memo prohibited","status":"PASS"})
f=Fixture();ext["_ACTIVE"]=True
try:f.run()
except ValueError:pass
else:raise AssertionError("RAM nested memo allowed")
ext["_ACTIVE"]=False;f.restored();need(f.enters==0,"RAM nesting rejected before lock");results.append({"name":"nested memo prohibited","status":"PASS"})
for path in ("research/authority.json",".runtime/journal.py","data/x.py","src/../x.py","/src/x.py"):
 need(not allowed({"path":path,"sha256":"a"*64}),"RAM base excludes "+path)
results.append({"name":"original code-only allowlist excludes mutable/outside refs","status":"PASS"})
# Capture the AST actually compiled by critical_close and prove no critical-body
# substitution occurs apart from removing its one original outer with.
captured=[];real_compile=compile
def spy(tree,*args,**kwargs):
 if isinstance(tree,ast.Module):captured.append(copy.deepcopy(tree))
 return real_compile(tree,*args,**kwargs)
ext["compile"]=spy
f=Fixture();f.run();f.restored();del ext["compile"]
derived=captured[-1].body[0]
need(ast.dump(ast.Module(body=derived.body,type_ignores=[]),include_attributes=False)==
 ast.dump(ast.Module(body=gd["apply_close_completed_v1"].body[0].body,type_ignores=[]),include_attributes=False),"RAM exact original close critical AST retained")
results.append({"name":"actual compiled critical AST equals original body","status":"PASS"})
# No unsupported mutation API exists in the component.
api=defs(defs(trees[SRC])["RootCompletedCloseCodeMemo"])
need(set(api)=={"__init__","_component","_guard_functions","_check","close_completed_v1"},"RAM close-only API")
results.append({"name":"only close_completed_v1 public operation","status":"PASS"})
result={"schema":"ROOT_completed_close_code_memo_source_RAM_checks_v1","status":"PASS_SOURCE_ONLY",
 "case_count":len(results),"cases":results,"guard_imported":False,"real_mutex_or_journal_operations":False,
 "process_or_runtime_probes":False,"payload_reads":False,"real_scope_measurements":False,"performance_measured":False,
 "method":"Exact selected original close critical AST, proof/measurement/charge helpers and original _Transaction run against RAM state/JSON/namespace/mutex/PID/measurement/append callbacks. Environmental/provenance predicates use a registered fixture identity model; production provenance checks inspected statically."}
target=ROOT/HERE/"source_check.result.v1.json"
with target.open("x")as f:json.dump(result,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps({"status":result["status"],"case_count":len(results),"result":str(target)}))
