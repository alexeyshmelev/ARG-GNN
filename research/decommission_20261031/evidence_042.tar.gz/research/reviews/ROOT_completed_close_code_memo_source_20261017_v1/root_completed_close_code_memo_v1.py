"""Inactive, close-only ROOT code memo; import performs no project IO.

Use requires an independently reviewed new integration. Original guard/source,
authorities, reservation roles, measurements, journals and receipt stay exact.
"""
from pathlib import Path
import ast,copy,importlib.util,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/ROOT_completed_close_code_memo_source_20261017_v1"
SOURCE=HERE+"/root_completed_close_code_memo_v1.py"
BASE_REF=dict(path="research/reviews/ROOT_mutation_transaction_memo_source_20261017_v1/root_mutation_memo_v1.py",
 sha256="2923df9f5a48e76da0b59e6394f31d0b8f901c214a76cc62d65969d010655d98")
BASE_REVIEW_REF=dict(path="research/reviews/admission_repairs_independent_20261017_v1/memo_review.v1.json",
 sha256="76ec107aa147d6d8f93a2aed424eba8ab07c28b8dc988b3097b3961e32c512c9")
BASE_REVIEW_MANIFEST_REF=dict(path="research/reviews/admission_repairs_independent_20261017_v1/memo_review_manifest.v1.json",
 sha256="6c4fcd3de3f9c58aecdb8f54fd3baae426438e0b30a5745bfaf5a25d4802b6d1")
OBSERVATION_FIELD="root_completed_close_code_memo_integration_ref"
_ACTIVE=False

def need(ok,message):
 if not ok:raise ValueError(message)

def load_base(record=BASE_REF):
 """Authenticate without a guard import; called only by explicit construction."""
 need(record==BASE_REF,"Exact independently reviewed ROOT code-only memo")
 p=ROOT/record["path"]
 # The original stable, no-follow source authenticator is derived from exact
 # bytes only after an initial original no-follow read with the same semantics.
 import hashlib,os,stat
 need(p.resolve()==p and ROOT in p.parents,"Canonical original memo source")
 before=p.lstat();need(stat.S_ISREG(before.st_mode)and before.st_nlink==1 and before.st_size<=2**20,"Bounded original memo source")
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,"rb")as f:
  opened=os.fstat(f.fileno());raw=f.read(2**20+1);after=os.fstat(f.fileno())
 named=p.lstat();identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 need(identity(before)==identity(opened)==identity(after)==identity(named)and len(raw)==before.st_size
  and hashlib.sha256(raw).hexdigest()==record["sha256"],"Exact stable original ROOT memo")
 name="_ROOT_completed_close_original_code_memo"
 spec=importlib.util.spec_from_file_location(name,p);module=importlib.util.module_from_spec(spec)
 # Execute exactly authenticated bytes, avoiding a second import-path read.
 exec(compile(raw,str(p),"exec",dont_inherit=True,optimize=0),module.__dict__)
 module.source_bytes(record)
 return module

def critical_close(node,scope,append):
 """Only remove the exact outer mutex; retain the original critical AST body."""
 need(isinstance(node,ast.FunctionDef)and node.name=="apply_close_completed_v1"
  and not node.decorator_list and len(node.body)==1 and isinstance(node.body[0],ast.With),
  "Exact single original close critical section")
 block=node.body[0]
 need(len(block.items)==1 and block.items[0].optional_vars is None
  and ast.unparse(block.items[0].context_expr)=="budget.v4.mutex(ROOT)","Original actual close mutex")
 derived=copy.deepcopy(node);derived.name="_memo_close_critical";derived.body=copy.deepcopy(block.body)
 derived.decorator_list=[];namespace=dict(scope,_append=append,__name__=__name__)
 exec(compile(ast.fix_missing_locations(ast.Module(body=[derived],type_ignores=[])),
  SOURCE+"#exact-close-critical-body","exec",dont_inherit=True,optimize=0),namespace)
 return namespace[derived.name]

class RootCompletedCloseCodeMemo:
 """Only unchanged ordinary completed close; no reserve/retirement/consumer API."""
 def __init__(self,guard,*,integration_manifest_ref,adapter_ref,independent_review_ref,cache_refs):
  self.base=load_base();self.guard=guard;self.budget=guard.budget;self.v4=self.budget.v4
  self.manifest_ref=copy.deepcopy(integration_manifest_ref);self.adapter_ref=copy.deepcopy(adapter_ref)
  self.review_ref=copy.deepcopy(independent_review_ref)
  need(self.adapter_ref.get("path")==SOURCE,"Exact close-only helper source path")
  self.base.source_bytes(self.adapter_ref)
  self.core=self.base.RootMutationMemo(guard,integration_manifest_ref=self.manifest_ref,
   adapter_ref=BASE_REF,cache_refs=cache_refs)
  self.counts={};self._check()

 def _component(self,bound):
  """All component/integration JSON is read by the original uncached reader."""
  self.base.source_bytes(BASE_REF);self.base.source_bytes(self.adapter_ref)
  manifest=bound(ROOT,self.manifest_ref,True);pins=manifest.get("source_sha256")
  need(isinstance(pins,dict),"New sealed integration source_sha256 mapping required")
  required=[BASE_REF,self.adapter_ref,BASE_REVIEW_REF,BASE_REVIEW_MANIFEST_REF,self.review_ref]
  need(all(isinstance(r,dict)and set(r)=={"path","sha256"}and pins.get(r["path"])==r["sha256"]for r in required),
   "Exact helper, reviewed base and independent close review in integration closure")
  need(all(pins.get(path)==sha for path,sha in self.core.allow.items()),"Every cached code ref is authenticated by this integration")
  base_review=bound(ROOT,BASE_REVIEW_REF,True);base_seal=bound(ROOT,BASE_REVIEW_MANIFEST_REF,True)
  need(base_review.get("independent")is True and base_review.get("verdict")=="SOURCE_PASS"
   and base_review.get("source_ref")==BASE_REF and base_review.get("blockers")==[]
   and base_seal.get("review_ref")==BASE_REVIEW_REF,"Exact independently reviewed original ROOT memo")
  review=bound(ROOT,self.review_ref,True);component_ref=review.get("source_manifest_ref")
  need(review.get("independent")is True and review.get("source_only")is True and review.get("verdict")=="SOURCE_PASS"
   and review.get("source_ref")==self.adapter_ref and review.get("base_memo_ref")==BASE_REF
   and review.get("blockers")==[],"Independent exact close helper SOURCE_PASS required")
  need(isinstance(component_ref,dict)and set(component_ref)=={"path","sha256"}
   and pins.get(component_ref["path"])==component_ref["sha256"],"Reviewed close component manifest in integration closure")
  component=bound(ROOT,component_ref,True);component_pins=component.get("source_sha256",{})
  need(component_pins.get(SOURCE)==self.adapter_ref["sha256"]
   and component_pins.get(BASE_REF["path"])==BASE_REF["sha256"],"Exact reviewed close component source closure")

 def _guard_functions(self):
  checked=self.base.functions_from_source(self.guard,self.base.PINS["guard"],
   ("apply_close_completed_v1","_state_locked","_authority","_proof","_paths","_measurement",
    "_absent","_policy","_pins","assert_open","charge","_append"))
  self.base.functions_from_source(self.v4,self.base.PINS["v4"],("measure_scopes",))
  return checked

 def _check(self):
  self.core._check()  # exact original guard/v4/budget; no consumer memo or threads
  self._component(self.v4.bound)
  self.close_functions=self._guard_functions()

 def close_completed_v1(self,authority_ref,*,expected_source_sha256,expected_launcher_sha256):
  global _ACTIVE
  need(not _ACTIVE and not self.base._ACTIVE,"No nested ROOT mutation memo")
  self._check();original_mutex=self.v4.mutex;original_append=self.guard._append
  _ACTIVE=True;self.base._ACTIVE=True;tx=None
  try:
   with original_mutex(ROOT):
    tx=self.base._Transaction(ROOT,self.v4,self.budget,self.core.allow)
    try:
     tx.install();calls=[0]
     def append(operation,record,value,state):
      need(calls[0]==0 and operation=="close_completed"and record==authority_ref,"One exact ordinary close append only")
      calls[0]+=1
      # Original source and namespace reads happen under the same original lock.
      # Once disabled, hits stay disabled through all final checks and append.
      tx.finish()
      self._component(tx.original["bound"]);self._guard_functions()
      need(self.guard._append is original_append and self.v4.mutex is original_mutex,"Original close append and mutex remain unchanged")
      authority=self.guard._authority(record,"close_completed",state[3],fresh=True)
      need(authority["expected_before"]==self.guard._pins(state[2])
       and authority["request"]==value["request"],"Final fresh exact authority/request/prefix")
      request=authority["request"]
      self.guard.assert_open(request["key"],state[0],state[1])
      observation=tx.original["bound"](ROOT,request["observation_ref"],True)
      need(observation.get(OBSERVATION_FIELD)==self.manifest_ref,"New direct ROOT observation binds this exact close integration")
      return original_append(operation,record,value,state)
     critical=critical_close(self.close_functions["apply_close_completed_v1"][1],self.guard.__dict__,append)
     receipt=critical(authority_ref,expected_source_sha256=expected_source_sha256,
      expected_launcher_sha256=expected_launcher_sha256)
     need(calls[0]==1,"Original completed close appends exactly once")
     return receipt
    finally:
     self.counts=dict(tx.counts);tx.close()
  finally:
   _ACTIVE=False;self.base._ACTIVE=False
