# Independent H020 legacy completion normalization review

Reject the proposal under the unchanged close semantics.

The original seven-control completion and original direct launcher wait0 are supported. All six proposed original evidence hashes match. The original producer source also matches its recorded SHA and writes receipt.json after completing all seven controls.

The unchanged980guard explicitly requires the actual producer's output/completed.json. H020 has no such producer file. Its authentic receipt.json is10,169,131bytes, above the unchanged1MiB producer-completion limit. A new small root-derived marker would document genuine history, but it would replace the required original producer artifact with a different administrative document. Clear labelling does not make that substitution satisfy the narrower proof requirement. Do not create the marker or obtain credit by compressing, copying, renaming or summarizing the receipt into the required path.

A metadata-only storage projection could truthfully explain old reservation fields. It does not cure the missing producer artifact or authorize this close. No new guard or exception is proposed.

A narrower compatible candidate already exists: H018/observed_baseline_GT_preparation_v2, originally50,000,000bytes. Its existing4288-byte producer completed.json, actual stored reservation/output/cap and original source-bound direct worker wait0/groupdrain all match. The review JSON pins those exact original records. Root still needs current-open validation, fresh targeted worker2717006/supervisor2716834 and known group absence, complete capability revocation, and the unchanged real close/stat measurement. No current absence, retained-byte total or credit is asserted here.

This review read source and JSON metadata only. It did not import a guard, open/hash any checkpoint or prediction payload file, mutate accounting or old scopes, execute processes, install software or use Git.
