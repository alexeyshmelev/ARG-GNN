# H049 TRAIN/EVAL cap proposals

Filled inactive configs, requests and named rationales are ready for root review. Existing sources/configs are unchanged. No arrays, checkpoints, truth, jobs, GPU, guards, admission or Git were used. Actual cut-preparation completion/wait refs remain null. The confirmed canonical launcher namespace issue requires the separately authorized additive GPU successor before execution.

| Proposed cap | TRAIN bytes | EVAL bytes |
|---|---:|---:|
| Complete phase CPU banks |6,979,321,856|1,811,939,328|
| Full phase grid+marker+cut cache |12,415,139,840|3,154,116,608|
| Separate marker cache |939,524,096|268,435,456|
| Named grid/cut preparation |5,235,539,968|5,333,057,536|
| Named marker preparation |796,917,760|800,063,488|
| One-parent FP64/FP32 target |659,554,304|659,554,304|
| GPU parent+mass residency |536,870,912|603,979,776|
| GPU persistent grid/cut |90,177,536|92,274,688|
| All144 prediction RAM gate |31,608,274,944|31,608,274,944|
| RSS fail-stop |39,728,447,488 (37GiB)|64,424,509,440 (60GiB)|
| CUDA reservation fail-stop |22,548,578,304 (21GiB)|22,548,578,304 (21GiB)|
| Output reservation |61,865,984|19,922,944|

All20 resource fields are in each config. Shared smaller caps: all40 coordinate bulk22,020,096 bytes, binding JSON327,680, archive6,291,456, checkpoint file2,097,152, raw log tail524,288, GPU qualification files4,194,304. Fixed metadata is6,291,456 for TRAIN and12,582,912 for EVAL. Named cut work is803,209,216/817,889,280.

The genuine raw144-grid matrix is31,607,126,208 bytes. TRAIN allocates no validation matrix; its positive RAM cap reserves the identical registered gate for the protocol. All144 immutable products must verify before any VAL truth. Dense predictions remain RAM-only.

## Capacity rationale and limits

CPU bank sizing uses the complete32/8-parent sum, not the one-parent preparation cap. Full-phase caches intentionally retain all prepared grids/markers across30 passes. Their exact one-parent minima are also reported in cap_rationale_v1.json. Separate marker accounting conservatively double-counts shared borrowed storage.

RSS components include the genuine banks/caches, named marker/grid preparation, target/transient banks, validation matrix and eight182-query mass caches, coordinate/binding bulk, a2GiB Python/Torch/JSON policy allowance and256MiB memo2 capacity. EVAL also has2GiB diagnostic-workspace policy. Add25% plus2GiB, then round to GiB. These are fail-stop policies and estimates, not measured or proved peaks.

CUDA components use full native node32 banks; native leaf96 state (the bidirectional32 GRU returns64 channels, concatenated with32 context); source chunk/pooling dimensions; query-block32 balanced-chain stages; rank8 memory/injection and full-grid workbanks; and all three models' learned/Adam state. Forward/autograd multiplicities are explicitly policy coefficients. Add25% plus1GiB then round to GiB. No GPU peak is claimed. The first scheduled update of each arm remains the only full-model qualification; no disposable update or short fit is introduced.

The frozen context applies the per-process Torch allocation fraction, and guards reject excessive peak CUDA reservation or RSS. These do not certify whole-device allocation or uninterrupted sub-limit peaks. Root must preserve actual step/failure evidence if qualification fails. No automatic escalation/replay is proposed.

The canonical authorization still uses its own unchanged50GB+4GB scheduler eligibility rule. These smaller runtime caps do not relax that authority or permit additional GPU sharing.

## Checkpoint and output budget

Source-derived tensor count is55: body38,H042 adapter4,H048 heads/scalars10,memory3. With model parameters, two Adam moments and scalar steps, a checkpoint has220 tensor storage records and389,572 raw tensor bytes. Record/ZIP and scientific/optimizer metadata policies give the2MiB file cap. This is an unmeasured serialization allowance, checked by the producer before writing.

TRAIN forecasts18*(2MiB+8192) checkpoint bytes,14,107,392 observation-recipe planning bytes,6MiB fixed metadata and3,227,648 JSON-escaped log/wait bytes:61,522,688 total, within61,865,984 reserved.

EVAL forecasts3,561,216 observation-recipe bytes,12MiB fixed metadata (GPU qualification,18x8 primary history cells,3x8x7 full cohort groups,144 packets and terminal/metric receipts) and3,227,648 log/wait bytes:19,371,776 total, within19,922,944 reserved. No checkpoint or probability archives are saved in EVAL.

GPU startup allowance covers own library-map/nvtop/runtime files, with an actual size check after canonical qualification. It is a finite policy cap, not an observation of their future size.

## Files and exact remaining root bindings

- config_train.proposed.inactive.json / config_evaluate.proposed.inactive.json
- admission_request.train.proposed.inactive.json / admission_request.evaluate.proposed.inactive.json
- plan_request.train.proposed.json / plan_request.evaluate.proposed.json
- cap_rationale_v1.json / readonly_checks_v1.json / receipt_v1.json

Both public metadata plan calls returned0. Scientific protocol is exact; TRAIN/EVAL configs differ only in declared resource fields. H049 remains3arms,30passes,960updates each,18checkpoints and144seals with both registered EACH-control criteria.

Root still must bind:
1. Actual successful original H049 compact preparation completion and real direct-wait/drain refs in both configs.
2. The additive canonical arggnn dispatcher/GPU execution source and manifest/config pins; the original research.* GPU module cannot pass the canonical launcher.
3. Explicit GPU4or5 assignment, reviewed active config/request copies and actual admission/launch authority.
4. For EVAL, actual completed full-budget TRAIN completion,launch and direct-wait/drain refs.

No future completion hash or GPU assignment has been invented.
