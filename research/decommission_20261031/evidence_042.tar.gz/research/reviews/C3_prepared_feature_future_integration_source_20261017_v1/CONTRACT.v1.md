# Inactive prepared-feature C3 prediction integration

This package is a proposed operational successor for only VAL001/002 prediction stages and the final metadata matrix. VAL000 keeps its exact running v5 input and source. Every existing input, prediction, source, charge, failure and clock remains immutable. Nothing in this package is an admission or activation.

The accepted preprocessing component is v3, independently reviewed as SOURCE_PASS in C3_CPU_prepared_features_independent_20261017_v3/review.v3.json. That pass covers the component only. The complete integration is pending a fresh independent review.

## Prediction path

The original saved600 family, all six checkpoint identities, original model constructor, original shared seal callable, full bidirectional recurrence, original focal scorer and original data plans remain unchanged. Only original pending epoch30 cells for VAL001/002 are eligible under the preserved election. Completed cells are reused. VAL000 cannot be launched by this successor.

The new Dataset is a subclass of the original whole-tree Dataset. It invokes the original __getitem__ code object with a private substitution for the CPU block encoder. The accepted v3 component performs bounded integer PyG propagation and compensated FP32 branch summaries. Its numerical adaptation is explicit in config, prediction seals and preparation receipts. Bitwise original-feature equivalence is not claimed.

Forward scans prepare each chronological CPU bank once. Reverse scans retrieve the same observed bank after checking active genotype, allele, coordinate, reference/query, focal and span signatures, cached bank bytes and cached focal/geometry bytes. The loaded tskit TreeSequence is immutable and retains its original identity. No learned embedding, recurrent state or posterior is cached. A fresh PyG wrapper is created for every retrieval because Data.to mutates wrapper fields. Both directions retain every original tree, site, sample and recurrent column. All1,600sample columns,1,000masked query columns,30Mb and10,000original focal records remain.

The per-parent cache holds at most64GiB of feature tensors without spill or eviction, with32MiB layout and8MiB focal/geometry caps. A64MiB named temporary allowance controls complete SNP tiles, selected adaptively up to32sites without dropping data. A2GiB Python allowance is recorded. The original128GiB process RSS failstop and8GiB CUDA cap remain. Metadata-derived feature upper bounds are56,406,290,944bytes (52.53GiB) for VAL001 and57,762,078,784bytes (53.80GiB) for VAL002. Auxiliary tensor bounds are1,157,436and1,177,812bytes. These source bounds do not establish allocator, interpreter, source-state or whole-process fit.

The original C3 block encoder requires every sampled node to be a leaf. V3 direct support helpers can handle some sampled ancestors, but the full C3 block path rejects them exactly as before. This integration does not add coverage of sampled internal nodes, does not prune those nodes and does not infer that the full original observations satisfy the restriction.

## Exact mixed-source provenance

The completion join accepts only the exact pinned v5 VAL000 input, manifest and execution source for its missing cell. VAL001/002 must bind this successor's manifest and execution source. Each successful stage still needs its actual matching worker OSwait0, complete bounded ownership/drain, independent exact source review, consumed ROOT outer0, original election and original pending-epoch set. The existing drain-policy body is unchanged apart from receiving the exact expected source explicitly.

The matrix combines27retained cells and the three actual missing epoch30cells. It validates all five exact original plans and every seal's plan, observation and focal registry join before calling the unchanged original30cell barrier. No truth or scoring capability is added. The provenance output records the separate v5/v6 producer identities. No all3same-manifest claim remains.

## Direct roles and preserved control path

Five real executed source refs are retained: initializer, contract, execution including the direct attachment role, worker including the cache adapter, and the real accepted v3 component file. The attachment role is embedded byte-for-byte after exact namespace substitution in the execution file. It uses a private module, and its source ref is the actual execution file. The accepted PyG component remains a real file for ordinary source inspection.

This is actual source consolidation, not role omission. Static replacement of the original five refs with these five retains64direct slots. Fresh admission must still request all returned current roles through the unchanged original union, which rejects over64. Current guard, selector, physical GPU0 lease, title, capacity envelopes, pidfd lifecycle, timers, writer boundaries,32MiB output/AUX reservation and old unknown failures remain enforced by the inherited route.

Author checks use ASTs, immutable metadata and RAM evidence only. They exercise exact v5/v6 joins, wrong-source rejection, retained-epoch rejection and all5plan/all30cell requirements. No operational modules, guards, original arrays, GPU, model, optimizer, state, resource probe or Git action were used. No speed, fit or ancestry accuracy is reported.
