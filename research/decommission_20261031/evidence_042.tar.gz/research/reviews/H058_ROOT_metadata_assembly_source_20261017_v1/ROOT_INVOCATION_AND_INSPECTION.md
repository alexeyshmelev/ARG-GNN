# H058 ROOT metadata assembly source

This is an inert source-only assembler for the exact independently reviewed H058
CPU TRAIN recipe. It is not a supervisor or qualification. It has not been run
or imported. Static compile/hash/AST checks passed. No actual ROOT instruction,
active declaration,preparation,charged packet/output,guard,admission,execution,
numerical work,probe or Git action was created/performed during authoring.
ROOT must review this helper before any actual staging.

The required recipe is
research/reviews/H058_full_parent_CPU_runtime_wrapper_independent_review_20261017_v2/ROOT_RECIPE.md
SHAc9fc7ac542a239bafc5b513192c6a796558cb846e3f869b3b110424fcf88c12f.
The combined wrapper/scientific review is review.v1.json in that same directory,
SHAb25978f877cb01ea4289e6d6f541f97226c0f558bbec6476659f78e5c38fb61f.
It is used unchanged for both source_review_ref and scientific_review_ref;
nested producer PASS stays intact. All old failed/unknown histories stay intact.

After reviewing source and making actual current observations, ROOT creates its
own immutable instruction outside the new preparation,copying
ROOT_instruction.INACTIVE.template.v1.json and filling its exact fields:

- root_authorizer=root_agent; staging_authorized,issue_full_TRAIN_declarations,
  current_CPU_capacity_confirmed,current_runtime_settings_confirmed=true only
  after ROOT actually accepts those facts/settings and the complete condition.
- cpu_ids exactly160through191 and runtime_flags exactly the reviewed expected
  CPU/32intraop/1interop/FP32/zeroCUDA/packageversions. These flags are ROOT's
  declaration; the helper does no package import/discovery or resource query.
- assembler_source_manifest_ref is this exact sealed source_manifest.v1.json
  path/SHA. Fill separate never-used preparation/packet/output names under the
  three template/recipe prefixes; all three paths must initially be absent.
- actual timezone-aware created_at_utc/expires_at_utc exactly25hours apart,with
  >87300seconds remaining at staging and later wrapper input validation.
- registration_decisions_source_ref and registration_ledger_source_ref bind the
  actual current research/experiment_decisions.json and research/experiment_ledger.md
  bytes by SHA. The helper copies genuine exact bytes into immutable snapshots,
  checks the unique existingH058decision/text and never relabels registration.

Exact staging invocation from /workspace-SR003.nfs2/ARG-GNN:

```sh
PYTHONPATH=.:src:scripts CUDA_VISIBLE_DEVICES= .runtime/env/bin/python -B -s -m research.reviews.H058_ROOT_metadata_assembly_source_20261017_v1.assemble_root_metadata_v1 --stage-root-instruction-ref '{"path":"<actual ROOT instruction path relative to repository>","sha256":"<actual instruction SHA256>"}'
```

This explicit ROOT command stages metadata only. No-argument invocation is inert
and performs no project reads/writes. The helper authenticates source/review pins,
keeps all validation before its first preparation mkdir,then uses exclusive
immutable writes. If staging fails,retain partial metadata and inspect the true
failure; no delete/retry/replay or automatic recovery exists.

Future staging creates only the fresh preparation and these metadata files:
registration_decisions.snapshot.json,registration_ledger.snapshot.md,
runtime.root_v1.json,runtime_equivalence.root_v1.json,
full_training_directive.root_v1.json,layout_resource_proof.root_v1.json,
training_context.root_v1.json,runtime_qualification.root_v1.json,
ROOT_directive.root_v1.json,ROOT_request.root_v1.json,assembly_receipt.root_v1.json.
It never precreates <packet>.scientific_config.json,<packet>.config.json,
<packet>.source_and_input_closure.json or <packet>.reserve_authority.json.
The reviewed wrapper alone owns those exclusive files and actual reservation.
The helper never creates packet/output/worker_aux/TMP and never calls a guard.

ROOT must inspect before using the staged request:

1. Actual CPU160-191capacity and existing package/runtime metadata support the
   source settings without disturbing other jobs. CPU32threads/interop1,
   zeroCUDA/FP32,128GiBwhole-ownedRSS,32GiBcache,original2DataLoaderworkers,
   all32TRAINparents/30passes/960EACH/1920total and12scheduled checkpoints remain
   exact. Source-count forecasts are not runtime/RAM/backward/serialization fit.
2. The three declarations match actual producer field predicates documented in
   producer_field_contract.v1.json. They intentionally add no schema-string
   gate. layout status admitted_first_scheduled_full_parent_step is prospective
   authority for the first scheduled step after genuine admission,not evidence
   that any step already ran. full_training_fit_measured remainsfalse.
3. scientific_config equals sealed defaults except precisely the three allowed
   operational refs. continuation_reuse_attestation_ref,
   continuation_replay_directive_ref and separate_continuation_directive_ref
   remainnull; no identity audit/control reuse/VAL or TESTrelease is asserted.
4. Runtime qualification is metadata/source acceptance using the exact original
   one-holdPASSsummary609b7d6101524bb1ff5d3127f1478b5113e9de483a13fd1e2bd387d45531aada
   and original direct/outer evidence. No rerun,extra proof/probe/update or
   full960fit claim is added. Actual admitted worker rechecks installed flags.
5. Exact original H050input/TRAINbindings,H045warmstart and completion,
   registration,protocol,producer,combined review,v2manifest/handoff and all
   immutable refs remain unchanged. Direct ledger Markdown is not added to
   consumer roles; the wrapper retains its exact transitive SHA proof.
6. Native7/H050 remains the legally current mutation route when ROOT acts. This
   helper pins its exact selector5bcee3d8b53222ee45119dc51e1a35850e7e04c20d84c702080d5685d77b5120
   and has no discovery,fallback or successor substitution. ROOT owns actual
   current guard/capacity/all-roleunion<=64 checks at admission. No role trimming.
7. Request parent is exactly the new preparation; charged output and whole
   packet remain absent,as do all four exclusive wrapper filenames. Absence
   does not certify a never-reserved key; the unchanged wrapper/guard does that.
   The finite25hour interval does not reset any old clock or change86700souter/
   86400sscience/30scleanup/150sevidence limits.
8. Staged request/directive/runtime/config/declaration SHA refs and authority
   fields represent ROOT's actual intent. The assembler receipt explicitly
   says resources were not observed by the assembler and no admission/execution
   occurred. It outputs an admission argv for review only and never runs it.

After inspection,ROOT may separately run only the returned reviewed v2 --admit-ref
command. Only genuine admission0 allows that driver's exact emitted one-shot
setsidexecution_argv. Preserve actual1920updates/fullhistories/12checkpoints/
scientificcompleted+ROOT_completed/wait0/drain/consumedouter0 requirements.
No automatic close,credit,replay,VAL/TESTaccess,targetscore or controlrefit follows.
