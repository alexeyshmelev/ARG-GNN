"""Inert H058 metadata assembler. Explicit ROOT staging only; never admit/execute.

Only standard-library source/JSON/text handling. Default invocation prints an
inactive status and reads/writes no project file. ROOT supplies fresh current
CPU/runtime assertions in its own SHA-bound instruction after reviewing source.
"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,copy,hashlib,json,os,stat,sys
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
HERE='research/reviews/H058_ROOT_metadata_assembly_source_20261017_v1'
WRAPPER='research/reviews/H058_full_parent_CPU_runtime_wrapper_source_20261017_v2'
SOURCE=HERE+'/assemble_root_metadata_v1.py'
CPUS=list(range(160,192))
SELECTOR_REF=dict(path='research/reviews/native7_H050_stopped_retention_ROOT_activation_20261016_v1/explicit_child_selector.root_active_v1.json',sha256='5bcee3d8b53222ee45119dc51e1a35850e7e04c20d84c702080d5685d77b5120')
FLAGS=dict(backend='cpu',intraop_threads=32,interop_threads=1,default_dtype='torch.float32',CUDA_initialized=False,
 torch_version='2.6.0+cu124',numpy_version='2.4.6',PyG_version='2.7.0')
DIRECTIVE_FIELDS=('preparation_directory','source_manifest_ref','source_review_ref','scientific_review_ref','registration_ref',
 'registration_decisions_ref','registration_ledger_ref','training_context_ref','runtime_ref','runtime_qualification_ref',
 'scientific_config','caps','cpu_ids','created_at_utc','expires_at_utc')
def require(ok,message):
 if not ok:raise ValueError(message)
def local(name):
 p=Path(name);p=p if p.is_absolute()else ROOT/p
 require(p!=ROOT and ROOT in p.parents and '..'not in p.parts and p.resolve()==p,'Canonical contained no-link metadata path')
 return p
def raw_path(name):
 p=local(name);s=p.lstat()
 require(stat.S_ISREG(s.st_mode)and s.st_nlink==1 and s.st_size<=32*2**20 and p.suffix in('.json','.py','.md','.patch'),'Bounded source/metadata only')
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb')as f:
  actual=os.fstat(f.fileno());data=f.read(32*2**20+1)
 after=p.lstat()
 fields=lambda v:(v.st_dev,v.st_ino,v.st_mode,v.st_nlink,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
 require(fields(s)==fields(actual)==fields(after)and len(data)==s.st_size,'Source/metadata changed during read')
 return data
def reference(name):
 p=local(name);return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(raw_path(p)).hexdigest())
def raw(record):
 require(isinstance(record,dict)and set(record)=={'path','sha256'},'Explicit exact metadata path/SHA')
 data=raw_path(record['path']);require(hashlib.sha256(data).hexdigest()==record['sha256'],'Exact metadata SHA')
 return data
def read(record):return json.loads(raw(record))
def template(name):return json.loads(raw_path(WRAPPER+'/'+name))
def put(path,value):
 data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()if not isinstance(value,bytes)else value
 require(len(data)<=(32*2**20 if isinstance(value,bytes)else 2**20),'Bounded snapshots/source metadata')
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o400)
 with os.fdopen(fd,'wb')as f:f.write(data);f.flush();os.fsync(f.fileno())
 return reference(path)
def source_packet(instruction):
 manifest=read(instruction['assembler_source_manifest_ref'])
 require(instruction['assembler_source_manifest_ref']==reference(HERE+'/source_manifest.v1.json'),'Exact ROOT-reviewed assembler manifest')
 for path,sha in manifest['files_sha256'].items():raw(dict(path=path,sha256=sha))
 deps=json.loads(raw_path(HERE+'/dependencies.v1.json'))
 for path,sha in deps['pins'].items():raw(dict(path=path,sha256=sha))
 review=read(deps['wrapper_review_ref']);b=template('scientific_binding.v1.json')
 require(review.get('independent')is True and review.get('verdict')=='SOURCE_PASS'and review.get('blockers')==[]
  and review['producer_review']['verdict']=='SOURCE_PASS'and review['producer_review']['blockers']==[]
  and review['producer_review']['producer_ref']==b['runner_source_ref'],'Genuine combined wrapper/scientific review preserved')
 return deps,review,b
def stage(instruction_ref):
 require(Path.cwd()==ROOT and sys.dont_write_bytecode and sys.flags.no_user_site,'ROOT repository -B -s interpreter')
 qin=read(instruction_ref)
 expected={'schema','root_authorizer','staging_authorized','issue_full_TRAIN_declarations','current_CPU_capacity_confirmed',
  'current_runtime_settings_confirmed','cpu_ids','runtime_flags','assembler_source_manifest_ref','preparation_directory',
  'packet_directory','output_directory','created_at_utc','expires_at_utc','registration_decisions_source_ref','registration_ledger_source_ref'}
 require(set(qin)==expected and qin.get('schema')=='H058_ROOT_metadata_assembly_instruction_v1'
  and qin.get('root_authorizer')=='root_agent'and all(qin.get(k)is True for k in('staging_authorized',
   'issue_full_TRAIN_declarations','current_CPU_capacity_confirmed','current_runtime_settings_confirmed'))
  and qin.get('cpu_ids')==CPUS and qin.get('runtime_flags')==FLAGS,'Explicit actual ROOT instruction and current CPU160-191/runtime declarations required')
 deps,review,b=source_packet(qin);cfg=copy.deepcopy(b['config_defaults']);caps=template('caps.inactive.v1.json')
 require(b['operational_ref_keys']==['runtime_equivalence_ref','full_training_directive_ref','layout_resource_proof_ref']
  and cfg['continuation_reuse_attestation_ref']is None and cfg['continuation_replay_directive_ref']is None
  and cfg['separate_continuation_directive_ref']is None,'Initial TRAIN permits only three operational refs; no continuation audit')
 protocol=cfg['scientific_protocol'];train=protocol['TRAIN_parent_ids']
 require(train==['ap_expanded_train_%03d'%i for i in range(32)]and protocol['passes']==30
  and protocol['updates_per_arm']==960 and protocol['updates_all_new_arms']==1920
  and cfg['CPU_training_threads']==32 and cfg['CPU_training_interop_threads']==1
  and cfg['max_cpu_rss_bytes']==caps['rss_bytes']==128*2**30
  and cfg['CPU_prepared_cache_cap_bytes']==caps['max_cached_parent_bytes']==32*2**30
  and caps['dataloader_workers']==2 and caps['reservation_bytes']==32*2**20,'Original full science and resource declarations unchanged')
 created=datetime.fromisoformat(qin['created_at_utc']);expires=datetime.fromisoformat(qin['expires_at_utc']);now=datetime.now(timezone.utc)
 require(created.tzinfo and expires.tzinfo and created<=now and expires-created==timedelta(hours=25)
  and(expires-now).total_seconds()>caps['wall_seconds']+600,'Fresh actual finite25hour ROOT interval with >87300s margin')
 prep=local(qin['preparation_directory']);packet=local(qin['packet_directory']);output=local(qin['output_directory'])
 require(prep.parent==ROOT/'research/reviews'and prep.name.startswith('H058_CPU_ROOT_preparation_')
  and packet.parent==ROOT/'research/reviews'and packet.name.startswith('H058_CPU_ROOT_')
  and output.parent==ROOT/'experiments/results'and output.name.startswith('H058_full_parent_CPU_')
  and prep!=packet and not any(p.exists()or p.is_symlink()for p in(prep,packet,output)),'Fresh exclusive prep/charged paths; no packet or output creation')
 require(qin['registration_decisions_source_ref']['path']=='research/experiment_decisions.json'
  and qin['registration_ledger_source_ref']['path']=='research/experiment_ledger.md','Snapshot genuine current repository decision/ledger sources')
 decisions_bytes=raw(qin['registration_decisions_source_ref']);ledger_bytes=raw(qin['registration_ledger_source_ref'])
 decisions=json.loads(decisions_bytes);require(len([d for d in decisions['decisions']if d.get('id')=='H058'])==1
  and 'H058'in ledger_bytes.decode('utf-8'),'Genuine H058 decision/ledger snapshots; never relabel registration')
 registration=read(b['registration_ref']);require(registration['id']=='H058'and registration['protocol']['passes']==30
  and registration['protocol']['aligned_and_null_new_updates_each']==960,'Exact original H058 registration')
 selected=read(SELECTOR_REF);wdeps=template('dependencies.v1.json')
 require(selected['active']is True and selected['root_authorizer']=='root_agent'and selected['selector_source_ref']==wdeps['SELECTOR']
  and selected['source_ref']==wdeps['GUARD_REF']and selected['policy_ref']==wdeps['POLICY_REF']
  and selected['accounting_mode']=='native7_H050_stopped_retention_v1','Exact explicit original native7/H050 selector; no fallback')
 raw(wdeps['BASE_RUNTIME']);summary=read(b['one_hold_summary_ref'])
 require(summary['status']=='PASS'and summary['optimizer_updates']==0 and summary['full_parent_fit_established']is False
  and summary['completed_ref']==cfg['one_hold_completion_ref']and summary['actual_wait_ref']==cfg['one_hold_direct_wait_ref']
  and summary['actual_outer_terminal_ref']==cfg['one_hold_outer_terminal_ref'],'Original one-hold source evidence only; no new qualification')
 for name in('one_hold_completion_ref','one_hold_direct_wait_ref','one_hold_outer_terminal_ref'):raw(cfg[name])
 # All validation above is metadata-only. No guard,resource query,model or process.
 # First write creates only fresh preparation. Preserve partial staging on failure.
 prep.mkdir(mode=0o700)
 dr=put(prep/'registration_decisions.snapshot.json',decisions_bytes);lr=put(prep/'registration_ledger.snapshot.md',ledger_bytes)
 runtime=template('runtime.INACTIVE.template.v1.json');runtime.update(actual_runtime_qualified=True,cpu_ids=CPUS)
 rr=put(prep/'runtime.root_v1.json',runtime)
 # These exact producer field contracts intentionally have no invented schema predicate.
 er=put(prep/'runtime_equivalence.root_v1.json',dict(root_authorizer='root_agent',flags=copy.deepcopy(qin['runtime_flags']),
  original_H050_runtime_ref=cfg['H050_CPU_runtime_ref'],CPU_entry_ref=b['runner_source_ref'],extra_qualification_or_probe_authorized=False))
 fr=put(prep/'full_training_directive.root_v1.json',dict(root_authorizer='root_agent',full30pass_training_authorized=True,
  scientific_protocol=protocol,device='cpu',physical_gpu=None,CPU_entry_ref=b['runner_source_ref'],extra_probe_updates_authorized=False))
 pr=put(prep/'layout_resource_proof.root_v1.json',dict(root_authorizer='root_agent',status='admitted_first_scheduled_full_parent_step',
  source_count_ref=cfg['source_count_ref'],physical_gpu=None,device='cpu',CPU_prepared_cache_cap_bytes=32*2**30,
  original_TRAIN_parent_ids=train,reduced_data=False,counted_in_960_updates=True,full_training_fit_measured=False))
 cfg.update(runtime_equivalence_ref=er,full_training_directive_ref=fr,layout_resource_proof_ref=pr)
 context=template('training_context.INACTIVE.template.v1.json');context['root_authorizer']='root_agent'
 cr=put(prep/'training_context.root_v1.json',context)
 qualification=template('runtime_qualification.INACTIVE.template.v1.json')
 qualification.update(root_authorizer='root_agent',status='qualified',runtime_ref=rr,source_manifest_ref=reference(WRAPPER+'/source_manifest.v1.json'),
  runner_source_ref=b['runner_source_ref'],unresolved_items=[],standalone_token_update_probe=False,full_training_fit_measured=False,scientific_probe_updates=0)
 qr=put(prep/'runtime_qualification.root_v1.json',qualification)
 request=template('ROOT_request.INACTIVE.template.v1.json')
 request.update(active=True,execution_authorized=True,root_authorizer='root_agent',cpu_ids=CPUS,
  preparation_directory=qin['preparation_directory'],packet_directory=qin['packet_directory'],output_directory=qin['output_directory'],
  created_at_utc=qin['created_at_utc'],expires_at_utc=qin['expires_at_utc'],source_manifest_ref=reference(WRAPPER+'/source_manifest.v1.json'),
  source_review_ref=deps['wrapper_review_ref'],scientific_review_ref=deps['wrapper_review_ref'],registration_decisions_ref=dr,
  registration_ledger_ref=lr,training_context_ref=cr,runtime_ref=rr,runtime_qualification_ref=qr,scientific_config=cfg,storage_policy_selector_ref=SELECTOR_REF)
 directive=template('ROOT_directive.INACTIVE.template.v1.json')
 directive.update({k:copy.deepcopy(request[k])for k in DIRECTIVE_FIELDS});directive.update(active=True,root_authorizer='root_agent')
 request['root_directive_ref']=put(prep/'ROOT_directive.root_v1.json',directive)
 require((expires-datetime.now(timezone.utc)).total_seconds()>caps['wall_seconds']+600,'ROOT staging must retain >87300s admission margin')
 request_ref=put(prep/'ROOT_request.root_v1.json',request)
 require(not packet.exists()and not output.exists(),'Charged paths remain absent after metadata staging')
 reserved=[prep/(packet.name+suffix)for suffix in('.scientific_config.json','.config.json','.source_and_input_closure.json','.reserve_authority.json')]
 require(not any(p.exists()for p in reserved),'Four exclusive wrapper staging filenames left absent')
 receipt=dict(schema='H058_ROOT_metadata_staging_receipt_v1',instruction_ref=instruction_ref,assembler_ref=reference(SOURCE),
  assembler_source_manifest_ref=qin['assembler_source_manifest_ref'],request_ref=request_ref,wrapper_review_ref=deps['wrapper_review_ref'],
  source_only_staging=True,guard_admission_or_execution_performed=False,current_resources_observed_by_assembler=False,
  full_training_fit_measured=False,continuation_reuse_attestation_ref=None,continuation_replay_directive_ref=None,
  next_admission_argv=[str(ROOT/'.runtime/env/bin/python'),'-B','-s','-m',WRAPPER.replace('/','.')+'.root_driver_v1','--admit-ref',json.dumps(request_ref)])
 receipt_ref=put(prep/'assembly_receipt.root_v1.json',receipt)
 return dict(request_ref=request_ref,receipt_ref=receipt_ref,admission_or_execution_performed=False,next_admission_argv=receipt['next_admission_argv'])
def main(argv=None):
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--stage-root-instruction-ref',help='Exact JSON path/SHA ref to ROOT-authored current instruction; stages metadata only')
 args=parser.parse_args(argv)
 if args.stage_root_instruction_ref is None:
  print(json.dumps(dict(status='INACTIVE_SOURCE_ONLY',project_reads_or_writes=False,guard_admission_execution=False)));return 0
 result=stage(json.loads(args.stage_root_instruction_ref));print(json.dumps(result,sort_keys=True));return 0
if __name__=='__main__':raise SystemExit(main())
