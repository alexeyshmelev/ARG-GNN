"""Static source/AST authentication only. Never runs or imports assembler/project."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN');HERE='research/reviews/H058_ROOT_metadata_assembly_source_20261017_v1'
def main():
 d=ROOT/HERE;source=(d/'assemble_root_metadata_v1.py').read_text();compile(source,str(d/'assemble_root_metadata_v1.py'),'exec');tree=ast.parse(source)
 deps=json.loads((d/'dependencies.v1.json').read_text())
 for p,v in deps['pins'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v,p
 imports={a.name for n in tree.body if isinstance(n,ast.Import)for a in n.names}|{n.module for n in tree.body if isinstance(n,ast.ImportFrom)}
 assert imports<={'pathlib','datetime','argparse','copy','hashlib','json','os','stat','sys'}
 funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
 calls=[ast.unparse(n.func)for n in ast.walk(tree)if isinstance(n,ast.Call)]
 for bad in('subprocess','importlib','torch','numpy','guard','budget','admit','execute','sched_getaffinity','statvfs','scandir','walk','kill','Popen','system','exec','eval'):
  assert not any(c==bad or bad in c.split('.')for c in calls),bad
 top=[n for n in tree.body if isinstance(n,ast.Expr)]
 assert all(isinstance(n.value,ast.Constant)for n in top),'No top-level I/O/calls'
 mainfn=funcs['main'];branch=next(n for n in mainfn.body if isinstance(n,ast.If))
 assert ast.unparse(branch.test)=='args.stage_root_instruction_ref is None'
 assert any(isinstance(n,ast.Return)and isinstance(n.value,ast.Constant)and n.value.value==0 for n in branch.body)
 assert not any(isinstance(n,ast.Call)and ast.unparse(n.func)in('stage','read','raw','raw_path','reference','put')for n in ast.walk(branch))
 stage=funcs['stage'];stepcalls=[ast.unparse(n.func)for n in ast.walk(stage)if isinstance(n,ast.Call)]
 assert stepcalls.index('source_packet')<stepcalls.index('prep.mkdir')<stepcalls.index('put')
 cfgupdates=[n for n in ast.walk(stage)if isinstance(n,ast.Call)and ast.unparse(n.func)=='cfg.update']
 assert len(cfgupdates)==1 and {k.arg for k in cfgupdates[0].keywords}=={'runtime_equivalence_ref','full_training_directive_ref','layout_resource_proof_ref'}
 assert 'continuation_reuse_attestation_ref' in source and 'continuation_replay_directive_ref' in source
 contracts=json.loads((d/'producer_field_contract.v1.json').read_text());producer=(ROOT/contracts['producer_ref']['path']).read_text();ptree=ast.parse(producer)
 pf={n.name:n for n in ptree.body if isinstance(n,ast.FunctionDef)}
 for n,v in contracts['source_function_segment_sha256'].items():assert hashlib.sha256(ast.get_source_segment(producer,pf[n]).encode()).hexdigest()==v
 producer_flags=next(n.value for n in pf['validate_runtime_flags_v1'].body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='expected'for t in n.targets))
 literal_flags={k.arg:ast.literal_eval(k.value)for k in producer_flags.keywords}
 own_flags=next(n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='FLAGS'for t in n.targets))
 assert {k.arg:ast.literal_eval(k.value)for k in own_flags.keywords}==literal_flags
 inactive=json.loads((d/'ROOT_instruction.INACTIVE.template.v1.json').read_text())
 assert inactive['root_authorizer']is None and all(inactive[k]is False for k in('staging_authorized','issue_full_TRAIN_declarations','current_CPU_capacity_confirmed','current_runtime_settings_confirmed'))
 assert inactive['assembler_source_manifest_ref']is None and inactive['cpu_ids']==list(range(160,192))
 assert all(p.name not in('ROOT_request.root_v1.json','ROOT_directive.root_v1.json','runtime.root_v1.json')for p in d.iterdir())
 return dict(schema='H058_metadata_assembler_static_source_check_v1',status='PASS_STATIC_SOURCE_ONLY',dependency_source_metadata_pins=len(deps['pins']),producer_runtime_flags_match_exact_AST=True,
  producer_predicate_function_source_hashes_match=True,only3operational_config_refs_changed=True,default_branch_no_project_IO=True,explicit_ROOT_stage_required=True,
  inactive_instruction_contains_no_authority=True,no_guard_admit_execute_resource_query_model_or_process_calls=True,
  assembler_imported_or_run=False,active_ROOT_metadata_written=False,preparation_packet_or_output_created=False,payloads_or_numerics_or_Git=False)
if __name__=='__main__':print(json.dumps(main(),sort_keys=True,indent=2))
