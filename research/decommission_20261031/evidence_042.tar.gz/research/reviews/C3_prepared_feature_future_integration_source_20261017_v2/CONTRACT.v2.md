# Inactive prepared feature integration v2

This version repairs two source interfaces found in the blocked v1 whole integration review. It is inactive. It adds no execution, storage admission, process or scientific authority.

The accepted compensated FP32 CPU feature component remains the exact v3 file. The request validator now consumes the genuine review's candidate_ref and candidate_manifest_ref, both with exact pinned identities. It retains the exact schema, independent SOURCE_PASS verdict and empty blockers. It also authenticates the pinned manifest and requires its component_ref to identify that same file. No legacy source_ref or component_ref alias is accepted in place of candidate_ref.

The original shared prediction wrapper passes explicit kind=json through its disclosed writer. GuardedWriter now accepts that value in its existing JSON branch alongside the existing default None. Serialization, finite JSON requirement, 8 MiB bound, exclusive no-follow creation, source and phase disclosures, accounting boundaries and NPZ handling are unchanged.

Five actual executed refs remain. The execution file contains the unchanged embedded direct attachment role. The real accepted preprocessing component remains its fifth actual ref. Static replacement preserves 64 direct slots. Actual admission still requires ROOT's complete current returned role union through the unchanged cap.

The scientific model, constructor, all six checkpoint states, full recurrence, scorer, complete observations and original focal identities are unchanged. The accepted v3 feature computation, Dataset adapter and CPU cache implementation are unchanged from v1. No cached model state or posterior is introduced. Original 1,600 haplotypes, 1,000 masked queries, 30 Mb and 10,000 focal records remain. CPU feature bound is 64 GiB, complete temporary tile allowance is 64 MiB, process RSS cap is 128 GiB and CUDA cap is 8 GiB. Metadata feature bounds remain 52.53 GiB for VAL001 and 53.80 GiB for VAL002. These are source bounds, not measured runtime fit or speed.

## Unresolved matrix release dependency

This narrow v2 still launches only pending epoch30 VAL001 and VAL002 stages. Its exact VAL000 provenance policy remains pinned to original v5 input, manifest and execution source. The exact original wrapper and predictor passed into the unchanged v5 writer fail deterministic explicit JSON dispatch after the NPZ call. Therefore this unchanged mixed source policy cannot establish all30 success merely by repairing the future two parents. V2 neither fabricates v5 success nor substitutes a new VAL000 producer.

A separately reviewed ROOT provenance resolution is required before any all30 release. It must preserve genuine terminal evidence, the 27 retained cells and the original all30 barrier. No live v5 edits, old output migration, automatic replay or fallback are authorized here. ROOT's independent handling of a stopped or failed old route is not assumed complete by this source package.

## Author checks and limits

The inherited 22 positive and 7 negative source/RAM checks remain. Additional exact interface checks execute AST definitions of the unchanged shared wrapper, unchanged seal_prediction_v1, actual v2 GuardedWriter and unchanged common JSON serializer against a RAM filesystem. A dummy architecture supplies attributes without a model forward. Tiny numerical NPZ fixtures test serialization only. Stream, scientific support and registry interfaces are RAM stubs. No scientific coverage, validity, fit, accuracy or speed conclusion follows from the fixture.

The same exact wrapper/predictor chain passed into immutable v1 and v5 writers is an expected negative control. Genuine component metadata and wrong schema, candidate, manifest, verdict, blockers and alias substitutions are checked. JSON exclusivity, finite values, flat names and size bounds, NPZ object rejection and exact descriptor flags are retained.

No guard modules are imported or called. No live state, process, resource, original scientific payload or truth is accessed. No model/GPU work, installation, Git operation or admission occurs. Component SOURCE_PASS and author interface PASS do not constitute whole route acceptance.
