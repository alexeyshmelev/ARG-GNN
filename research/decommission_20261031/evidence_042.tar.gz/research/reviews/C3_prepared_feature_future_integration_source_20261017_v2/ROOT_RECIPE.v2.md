# ROOT handoff recipe for inactive narrow v2

1. Review the exact source_manifest.v1.json and both author results with a fresh whole integration reviewer. Preserve sealed v1 and its BLOCKED review.
2. Treat the JSON and genuine component metadata fixes as future source changes only. Nothing in this package activates work or modifies a live producer.
3. Keep the current narrow scope explicit: only VAL001/002 pending epoch30 stages use this future source. Fresh reviewed ROOT registration/request namespaces, clocks and current admission unions remain mandatory. Preserve all original caps, physical GPU0 lease, process title, controller, H058 envelope, guards and own wait/drain requirements.
4. Do not treat successful future VAL001/002 seals as enough for all30 release. The unchanged exact-v5-success VAL000 dependency is unresolved. A separate reviewed provenance and terminal resolution is required. This version does not include a new VAL000 authority, alternate evidence or state/output migration.
5. Preserve all 27 retained cells and the unchanged original all30 before truth barrier. Do not score or select a checkpoint through this prediction package.
6. ROOT alone owns actual terminal consumption, route revocation, amendments, capacity, admission, launch, process control, publishing and Git.

No actual experiment, model forward, scientific data qualification or runtime performance measurement was performed by these interface checks.
