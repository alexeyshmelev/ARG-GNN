# C3 training performance audit

The live job is active, but its execution design makes one reported optimizer update very large and hides progress until update100. Exact update count and full600-update completion within the86400second lifetime remain unknown.

Each update processes one complete2Mb parent, all1600haplotypes,145–162physical blocks and10000querylabels. Across the20parents there are3089blocks,98516trees and254141098node occurrences per epoch. The current step performs4B encoder entries,6B complete-bank CPU hashes,4B full bank clones/transfers and4B directional GRU entries per update. The600-update condition schedules370680encoder block entries. These are source-derived costs, not measured timings.

The two workers already completed all caches. They build observations rather than execute GPU training, and their sampled states were waiting on Unix IPC. The identity-checked main process remained active at about1.10CPU cores over one3second sample, with roughly29.5GBRSS and little actual disk I/O. This does not reveal its current update or prove which operation dominates wall time.

Main avoidable costs are duplicated forward/reverse encoder computation, repeated immutable-bank hashes/clones/transfers, CPU boundary transfers between every recurrent block and repeated work on reference-only recurrent columns. The current fast callback does no storage scan, though it repeatedly validates policy/lease/title. Fullstorageguards occur around actual product writes. The blackout comes from source logging cadence rather than an established absence of training.

Use the existing separately reviewed shared-context chain-rule implementation as the successor basis. It reduces encoder entries from4B to2B and providergets from6B to2B while preserving one fullparent meanCE and clippedAdamWupdate. Its one tinyFP32 equivalence check already passed. Do not rerun that answered fixture or claim a measured fullrun speedup.

For a separate new source family, add a bounded single-parent GPU cache of immutable observation banks and keep active contexts/states onGPU under explicit caps. Then retain all1600-haplotype PyG tree computations but gather the1000querycolumns before the independent GRUs. The600reference GRU outputs never reach the query loss, so that axis optimization preserves the mathematical objective and reduces recurrence/context axes37.5percent. It still needs one meaningful ordinaryFP32 qualification with mapping/gradient/update checks.

Planning caps are2GiB activeGPU rawbank,40GiB all20CPU banks, inherited40GiB totalCUDA and128GiB rootRSS. Opaque autograd/runtime workspaces remain unqualified. No learned context may survive across optimizer updates. Extraction workers can drain after the complete main-owned private cache is sealed under a separately reviewed provider contract.

A future source should record every completed optimizer update with actual counter,parent,loss and elapsed timings. Keep those receipts compact and bounded, and retain the actual storage/device/lease guards. Source and counter identities must be explicit for any exact-state continuation. A current unknown optimizer state must not be guessed or reconstructed.

Available original30MbVAL plans are much larger:VAL000 has2392blocks/76527trees,VAL001 has2390blocks/76453trees, both1600haplotypes/10000focals. No plan count is inferred for the other threeVALparents.

The current job was preserved. This audit used only authenticated source, compact plan/status metadata and targeted read-only process metadata. It used no GPU, data/model/checkpoint payload, numerical import, profiler, signal, rerun, admission or Git operation.
