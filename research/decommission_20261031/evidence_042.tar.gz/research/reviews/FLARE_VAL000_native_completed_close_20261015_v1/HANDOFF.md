# Heldout FLARE VAL000 native: exact completed-scope close packet

Root genuinely consumed native exec session58619 terminal0. The namespace
successor completed data/FLARE_val000_native_namespace_980_root_v1. This packet
binds the actual9,000,000,000-byte reservation, native completion, seeded
launch, worker direct wait, outer monitor wait, native direct wait, source,
config/storage and root terminal review. It does not reopen native products,
predictions, truth, focal NPZ, models or binaries.

The native stage is heldout VAL000 registered_heldout_full30Mb_comparison,
with native options and common marker/focal identities unchanged. This is
pre-truth native completion, not ancestry accuracy or exact paper reproduction.
Root's current seal runs in its own scope and may keep reading these outputs.

## Exact original process evidence

Producer PIDs are3025526 (root stage monitor),3025716 (scientific worker) and
3026147 (native JVM observed by the terminal monitor). Owned worker/native
groups are3025716 and3026147. The supervisor group is not recorded and is
not invented. Root confirmed direct SSH last-command Python with fixed log
redirection, without another project/setsid/Popen wrapper. There is no extra
PID or group to invent.

Worker direct wait0, outer wait0/error:null/groupESRCH and native direct
wait0/operational_failure:null/groupESRCH are all independently bound. The
current-run monitor has a polling limitation: transient between-poll processes
can be missed. This packet makes no broader descendant or complete-history
claim beyond the exact source-owned terminal receipts.

Root execution freshly probes all3known producer PIDs and both owned groups.
Present, reused, zombie or inaccessible identities block close. Historical
groupESRCH in the receipts does not replace that fresh root observation.
No PID or group probe was performed by this worker.

## Original generic operation, preserved read-only reuse

operation_packet.inactive.json is the exact original generic request with
observation_ref:null. No absence certificate, active close authority, root
revocation, retained-byte count or credit was fabricated.

close_native_v1.py is a narrowly bound successor of the existing native
completed-scope helper. Its8metadata/absence/execute/main function ASTs,
including the whole generic execute path, are unchanged. The collector
binds the heldout namespace run and genuine root terminal review.

Only explicit root --execute imports/configures the unchanged actual980 guard,
rechecks source/policy/repair and original unmemoized mutation functions,
takes the existing cooperative admission lock, verifies the exact still-open
reservation, and creates the genuine fresh absence/revocation/observation
evidence. It then drafts and applies the existing original
apply_close_completed_v1 operation. No policy, guard, accounting journal,
framework or scientific code change is provided.

Revocation affects old native producer write/launch/resume/retry capabilities
for this exact reservation. read_only_reuse_preserved:true and
preserve_all_files:true remain explicit. Seal and future scientific scoring
retain read access; the separate seal allocation is neither closed nor revoked.

The original generic API measures retained bytes over the actual output and
owned auxiliary scopes. Credit is only the unused part of the9GB native
reservation. The full9GB is not claimed as credit; exact retained/credit/
projected totals remain unknown until the real API receipt exists.

## Root commands

Run from /workspace-SR003.nfs2/ARG-GNN. Default is metadata-only and has
already returned0 without guard calls or PID probes.

~~~bash
.runtime/env/bin/python -B research/reviews/FLARE_VAL000_native_completed_close_20261015_v1/close_native_v1.py
.runtime/env/bin/python -B research/reviews/FLARE_VAL000_native_completed_close_20261015_v1/close_native_v1.py --execute --scope FLARE_VAL000_native
~~~

The default fresh evidence folder is closed_FLARE_VAL000_native_v1 beneath
this packet. Root owns actual execution/wait and receipt review. An existing
partial folder or already-closed key is an audit condition, never permission
to overwrite, replay or manufacture a receipt. No close was executed here.

## Actual pins

- Native completion:e0455383237b6f0ce8f77b1e40b32c5a7d6881dd95a440b584fadbb46ed46419
- Outer wait:525f3ec6c68502c26318f1cb81465a816e7dc25afd0b2febc3681fabdc8e47ae
- Minimal direct wait:066c5d211afab94e08e5fe0222c9e002188d1401e988cfee14925b3fb0d74fa6
- Native wait:260c7502c31bde7b680bac079e9efe972bf6e63ed7fbb7248da9ef3367b960a6
- Full metadata/source pins:actual_refs.json; inactive exact request:operation_packet.inactive.json.
