"""Independent gate byte-pin, scope, and pool-dispatch tests. Virtual files/mocks only."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone,timedelta
import ast,copy,hashlib,io,json,types
ROOT_REAL=Path("/workspace-SR003.nfs2/ARG-GNN")
FOLDER="research/reviews/GPU45_C3cache_H050_migration_gate_successor_20261016_v2"
source=(ROOT_REAL/FOLDER/"migration_gate_successor_v2.py").read_text()
files={};reads=[];symlinks=set()
class MemoryPath(PurePosixPath):
    def resolve(self):return self
    def is_file(self):return str(self) in files
    def is_symlink(self):return str(self) in symlinks
    def read_bytes(self):reads.append(str(self));return files[str(self)]
    def open(self,mode):
        assert mode=="rb";reads.append(str(self));return io.BytesIO(files[str(self)])
ns=dict(Path=MemoryPath,datetime=datetime,timezone=timezone,ast=ast,hashlib=hashlib,json=json)
mod=ast.Module(body=[n for n in ast.parse(source).body if isinstance(n,(ast.Assign,ast.FunctionDef))],type_ignores=[])
ast.fix_missing_locations(mod);exec(compile(mod,"<isolated_gate>","exec"),ns)
def put(rel,raw):files[str(ns["ROOT"]/rel)]=raw
refs=[ns[k] for k in ["FLOW_REF","ROOT_CAPTURE_REF","CAPTURE_SOURCE_REF","ACTUAL_MINIMAL_REF","ACTUAL_TOOL_REF",
    "ACTUAL_DRAIN_REF","ACTUAL_REVOCATION_REF","DRIVER_REF"]]
input_ref=json.loads((ROOT_REAL/ns["ROOT_CAPTURE_REF"]["path"]).read_text())["exact_original_input_ref"]
refs.append(input_ref)
refs.append(dict(path=ns["SOURCE"],sha256=hashlib.sha256(source.encode()).hexdigest()))
for record in refs:
    raw=(ROOT_REAL/record["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==record["sha256"]
    put(record["path"],raw)
gate=json.loads((ROOT_REAL/FOLDER/"migration_gate.proposed.inactive.json").read_text())
gate.update(status="active",root_authorizer="root_agent",created_utc=datetime.now(timezone.utc).isoformat())
gate_path="independent_virtual/active_gate.json"
def gate_ref():
    put(gate_path,json.dumps(gate,sort_keys=True).encode())
    return dict(path=gate_path,sha256=hashlib.sha256(files[str(ns["ROOT"]/gate_path)]).hexdigest())
ref=gate_ref();results=[]
def passed(name,ok=True):
    assert ok,name;results.append(dict(case=name,passed=True))
def rejects(name,call):
    try:call()
    except (ValueError,KeyError,TypeError):passed(name)
    else:raise AssertionError(name)
before=copy.deepcopy(files);reads.clear()
value=ns["validate_gate_v2"](ref)
passed("real_bound_reads_validate_virtual_active_gate_with_exact_actual_immutable_evidence",value==gate)
passed("all_pinned_evidence_source_bytes_reread",all(str(ns["ROOT"]/r["path"]) in reads for r in refs))
passed("no_virtual_evidence_bytes_changed",files==before)
for record in refs+[ref]:
    key=str(ns["ROOT"]/record["path"]);saved=files[key];files[key]=saved+b"\n"
    rejects("changed_byte_pin_"+record["path"].rsplit("/",1)[-1],lambda:ns["validate_gate_v2"](ref))
    files[key]=saved
rejects("wrong_gate_digest",lambda:ns["read"](dict(ref,sha256="0"*64)))
rejects("extra_ref_key",lambda:ns["read"](dict(ref,extra=True)))
rejects("bounded_read",lambda:ns["read"](ref,1))
symlinks.add(str(ns["ROOT"]/gate_path))
rejects("symlink_evidence",lambda:ns["read"](ref));symlinks.clear()
rejects("uncontained_evidence",lambda:ns["read"](dict(path="/outside.json",sha256="a"*64)))
real_read=ns["read"]
data={r["path"]:json.loads(files[str(ns["ROOT"]/r["path"])]) for r in refs if r["path"].endswith(".json")}
data[gate_path]=copy.deepcopy(gate);baseline=copy.deepcopy(data)
ns["read"]=lambda record,maximum=None:copy.deepcopy(data[record["path"]])
def semantic(name,mutate):
    data.clear();data.update(copy.deepcopy(baseline));mutate()
    rejects(name,lambda:ns["validate_gate_v2"](ref))
semantic("unknown_optimizer_count_cannot_be_relabelled_zero",
    lambda:data[ns["ACTUAL_TOOL_REF"]["path"]].update(original_optimizer_updates=0))
semantic("historical_global_absence_rejected",
    lambda:data[ns["ACTUAL_DRAIN_REF"]["path"]].update(historical_global_absence_claimed=True))
semantic("unrelated_inventory_rejected",
    lambda:data[ns["ACTUAL_DRAIN_REF"]["path"]].update(unrelated_host_inventory_performed=True))
semantic("extra_unrelated_group_rejected",
    lambda:data[ns["ACTUAL_DRAIN_REF"]["path"]]["groups"].append(dict(PGID=5,ESRCH=True)))
semantic("duplicate_identity_observation_rejected",
    lambda:data[ns["ACTUAL_DRAIN_REF"]["path"]]["identities"].__setitem__(1,copy.deepcopy(data[ns["ACTUAL_DRAIN_REF"]["path"]]["identities"][0])))
semantic("changed_owned_UID_rejected",
    lambda:data[ns["ROOT_CAPTURE_REF"]["path"]]["identities"][-1].update(UID=9999))
semantic("missing_root_consumed_terminal_rejected",
    lambda:data[ns["ACTUAL_TOOL_REF"]["path"]].update(root_consumed_original_supervisor_terminal=False))
semantic("revocation_native_GPU5_preservation_required",
    lambda:data[ns["ACTUAL_REVOCATION_REF"]["path"]].update(native_GPU5_preserved=False))
semantic("old_files_preservation_required",
    lambda:data[ns["ACTUAL_REVOCATION_REF"]["path"]].update(old_files_preserved=False))
semantic("no_completion_credit_claim_required",
    lambda:data[ns["ACTUAL_REVOCATION_REF"]["path"]].update(no_old_allocation_completion_or_credit_claimed=False))
semantic("source_explanation_must_not_be_exact_exception_claim",
    lambda:data[gate_path].update(exact_final_exception_observed=True))
semantic("future_gate_timestamp_rejected",
    lambda:data[gate_path].update(created_utc=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()))
semantic("gate_cannot_precede_fresh_transition_observation",
    lambda:data[gate_path].update(created_utc=data[ns["ACTUAL_MINIMAL_REF"]["path"]]["finished_utc"]))
semantic("group_ESRCH_claim_must_cover_exact_known_groups",
    lambda:data[ns["ACTUAL_DRAIN_REF"]["path"]]["groups"].__setitem__(0,dict(PGID=9999,ESRCH=True)))
data.clear();data.update(copy.deepcopy(baseline));ns["read"]=real_read
pool_source=(ROOT_REAL/FOLDER/"gpu45_c3cache_h050_pool_v2.staged.py").read_text()
old_source=(ROOT_REAL/"research/reviews/GPU45_C3cache_H050_pool_successor_20261016_v1/gpu45_c3cache_h050_pool_v1.staged.py").read_text()
pnew=ast.parse(pool_source);pold=ast.parse(old_source)
def definition(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
passed("entire_controller_AST_unchanged",ast.dump(definition(pnew,"Shared45Controller"),include_attributes=False)==ast.dump(definition(pold,"Shared45Controller"),include_attributes=False))
new_gate=copy.deepcopy(definition(pnew,"validate_migration_gate"));old_gate=definition(pold,"validate_migration_gate")
new_gate.body=[n for n in new_gate.body if not isinstance(n,ast.If)]
passed("old_gate_branch_AST_unchanged",ast.dump(new_gate,include_attributes=False)==ast.dump(old_gate,include_attributes=False))
loader_calls=[];validate_calls=[]
class FakeModule:
    def validate_gate_v2(self,record,gpu):
        validate_calls.append((record,gpu));return ns["validate_gate_v2"](record,gpu)
class FakeLoader:
    def exec_module(self,module):loader_calls.append("mock_only")
def mock_spec(name,path):
    loader_calls.append((name,str(path)));return types.SimpleNamespace(loader=FakeLoader())
dispatch=dict(json=json,ROOT=ns["ROOT"],require=ns["require"],
    bound=lambda record:files[str(ns["ROOT"]/record["path"])],
    ref=lambda path:dict(path=path,sha256=hashlib.sha256(files[str(ns["ROOT"]/path)]).hexdigest()),
    importlib=types.SimpleNamespace(util=types.SimpleNamespace(spec_from_file_location=mock_spec,module_from_spec=lambda spec:FakeModule())))
for n in pnew.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ("MIGRATION_SUCCESSOR_REF","MIGRATION_FAILURE_FLOW_REF") for t in n.targets):
        dispatch[n.targets[0].id]=ast.literal_eval(n.value)
only=ast.Module(body=[definition(pnew,"validate_migration_gate")],type_ignores=[]);ast.fix_missing_locations(only)
exec(compile(only,"<isolated_pool_dispatch>","exec"),dispatch)
passed("pool_labelled_branch_routes_exact_record_gpu_once",
    dispatch["validate_migration_gate"](ref,4)==gate and validate_calls==[(ref,4)] and len(loader_calls)==2)
rejects("pool_cannot_route_labelled_gate_to_GPU5",lambda:dispatch["validate_migration_gate"](ref,5))
for record in [dispatch["MIGRATION_SUCCESSOR_REF"],dispatch["MIGRATION_FAILURE_FLOW_REF"]]:
    key=str(ns["ROOT"]/record["path"]);saved=files[key];files[key]=saved+b"\n";before_calls=len(loader_calls)
    rejects("pool_rejects_unpinned_dispatch_"+record["path"].rsplit("/",1)[-1],lambda:dispatch["validate_migration_gate"](ref,4))
    passed("no_mock_import_on_bad_pin_"+record["path"].rsplit("/",1)[-1],len(loader_calls)==before_calls)
    files[key]=saved
passed("immutable_old_evidence_still_unchanged",files==before)
print(json.dumps(dict(schema="C3_known_roster_gate_independent_pure_fixtures_v1",cases=results,cases_passed=len(results),
    actual_guard_hook_probe_signal_wait_admission_install_job_process_GPU_or_Git_actions=0),indent=2,sort_keys=True))
