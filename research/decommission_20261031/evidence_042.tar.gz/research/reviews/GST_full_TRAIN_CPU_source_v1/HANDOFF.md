# GST source checkpoint

Stopped immediately on latest human priority for genuine ARGformer/FLARE shared-data comparisons. This folder contains a source/metadata checkpoint only. No GST worker, root integration, instrumentation, sys.setprofile observer or new checks were implemented. No real GST data/model/checkpoint, admission, guard execution, training, GPU, installation or Git action occurred.

Inspected unchanged native source confirms full10439TRAIN,1495VALID, four native modes and seeds0–4 in model-major order, construction before train_one reseeding,20epochs/batch16/commonLR.001. Keep13060 actual optimizer calls per fit versus unchanged author cosineT_max13040. The existing TRAIN1000 prefix and every author source remain unchanged. CPU runtime is the existing Python3.14.3/Torch2.10+cpu/PyG2.7 prefix. Intended TEST withholding would pass fullVALID into both unchanged train_one evaluation slots.

No further GST work is authorized under current priority. Await root's exact existing FLARE source/readiness recipe. checkpoint.json pins the consulted source/metadata.
