"""Resume fixed CPU parent streams, preserving source/config and downstream split."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import importlib.util,json,os,subprocess,sys,time,traceback
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN");sys.path.insert(0,str(ROOT))
from scripts import project_budget_v9 as b
P=ROOT/"research/reviews/ancestralpaths_full_panel_discovery_v1_root"
CORE="483d78bf2ef3c917d65ecf1dde5a7809bfadc21194c9f9a90394ce5c532fdd5e"
BASE="a8049bc103afb1cbbbce6f8fc3707a21de9613b23034599641b688994fc5caa3"
SOURCE="src/arggnn/prepare_ancestralpaths_full_panel_discovery_v1.py"
CONFIG="configs/ancestralpaths_full_panel_discovery_v1.json"
ADAPTER="src/arggnn/project_storage_full_reservation_v1.py"
LAUNCHER="scripts/launch_reserved_gpu_full_storage_v1.py"
HELPER="research/reviews/full_reservation_admission_v1_root/admission.py"
def ref(p):return b.v4.reference(ROOT,p)
def read(p):return json.loads((ROOT/p).read_text())
def save(packet,name,obj):
 p=packet/name
 with p.open("x") as f:json.dump(obj,f,indent=2,sort_keys=True);f.write("\n")
 return ref(p)
def view():
 with b.v4.mutex(ROOT):
  c,bindings=b.reviewed(ROOT,CORE,BASE)
  return b.state(ROOT,c,bindings,verify_closed=False)[4],bindings
def run(parent):
 packet=P/(parent+"_remaining_v2");packet.mkdir(exist_ok=False)
 old=read("research/reviews/ancestralpaths_full_panel_discovery_v1_root/ap_full_train_000/runtime.json")
 now=datetime.now(timezone.utc);expiry=(now+timedelta(hours=23)).isoformat()
 output="data/ancestralpaths_full_panel_discovery_v1/"+parent
 assert not (ROOT/output).exists()
 runtime=dict(old,job_id="ancestralpaths-full-panel-v2-"+parent.replace("_","-"),
  output_directory=output,created_at_utc=now.isoformat(),expires_at_utc=expiry)
 rt=save(packet,"runtime.json",runtime)
 authority=read("research/reviews/ancestralpaths_full_panel_discovery_v1_root/ap_full_train_000/budget_admission.json")
 v,bindings=view();authority["expected_before"]=b.pins(v)
 authority["reservation"]=dict(key="H034/"+parent,output=str(ROOT/output),auxiliary_scopes=[],reserved_bytes=2000000000,
  consumer_bindings=[ref(SOURCE),ref(CONFIG),rt,ref(ADAPTER),ref(LAUNCHER),bindings["implementation"],bindings["launcher"],
   ref("src/arggnn/project_budget_v9_consumer.py")])
 ar=save(packet,"budget_admission.json",authority)
 loader=importlib.util.spec_from_file_location("reserve",ROOT/HELPER);helper=importlib.util.module_from_spec(loader);loader.loader.exec_module(helper)
 result=helper.apply(ROOT,ar,expected_source_sha256=CORE,expected_launcher_sha256=BASE)
 save(packet,"budget_receipt.json",result);v,_=view()
 storage=dict(kind="project_budget_v9_storage_record",active=True,consumer_uses_v9_guard=True,accounting_mode="full_reserved_no_closed_scope_credit",
  job_id=runtime["job_id"],output_directory=output,reserved_new_bytes=2000000000,expires_at_utc=expiry,reservation=result["value"],
  initial_ledger_pins=b.pins(v),budget_components=dict(implementation=bindings["implementation"],launcher=bindings["launcher"],consumer_adapter=ref(ADAPTER)))
 save(packet,"storage.json",storage)
 admission=dict(parent_id=parent,allowed_stages=["all"],job_id=runtime["job_id"],output_directory=output,
  source_ref=ref(SOURCE),config_ref=ref(CONFIG),runtime_ref=rt,storage=storage)
 adm=save(packet,"execution_admission.json",admission)
 cmd=[str(ROOT/".runtime/env/bin/python"),"-B","-m","arggnn.prepare_ancestralpaths_full_panel_discovery_v1",
  "--execute","--stage","all","--parent",parent,"--config",CONFIG,
  "--expected-config-sha256",ref(CONFIG)["sha256"],"--expected-source-sha256",ref(SOURCE)["sha256"],"--admission",adm["path"]]
 env=dict(os.environ);env.update(CUDA_VISIBLE_DEVICES="",PYTHONDONTWRITEBYTECODE="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1")
 with (packet/"launch.log").open("xb") as log:
  child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 save(packet,"launch.json",dict(parent_id=parent,pid=child.pid,command=cmd,observed_utc=now.isoformat(),
  physical_GPUs_used=0,downstream_role=("INTERNAL_VAL" if parent=="ap_full_train_002" else "OUTER_DISCOVERY"),output_directory=output,
  reserved_bytes=2000000000,prior_scientific_stream_and_configuration_unchanged=True))
 deadline=time.monotonic()+60
 while not (ROOT/output/"freeze.json").exists():
  if child.poll() is not None:raise ValueError("Producer terminated before startup validation: "+str(child.returncode))
  if time.monotonic()>deadline:raise TimeoutError("Observe same live producer before scheduling next reservation")
  time.sleep(.2)
 print(json.dumps(dict(parent_id=parent,pid=child.pid,validated_startup=True,full_reserved_bytes=result["full_reserved_bytes"])),flush=True)
if __name__=="__main__":
 try:
  for parent in ["ap_full_train_002","ap_full_discovery_holdout_000"]:run(parent)
 except Exception:traceback.print_exc(file=sys.stdout);raise SystemExit(1)
