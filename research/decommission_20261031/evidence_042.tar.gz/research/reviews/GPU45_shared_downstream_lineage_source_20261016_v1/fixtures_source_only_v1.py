"""Pure source fixtures: no guards, processes, probes, models or scientific payload reads."""
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
import ast,copy,hashlib,importlib.util,json,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE=Path("research/reviews/GPU45_shared_downstream_lineage_source_20261016_v1")
sys.dont_write_bytecode=True
def load(name):
    p=ROOT/HERE/name;sp=importlib.util.spec_from_file_location("_pure_"+name.replace(".","_"),p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
t=load("shared_terminal_v1.py");runtime=load("runtime_metadata_adapter_v1.py");driver=load("root_downstream_v1.py");scope=load("controller_metadata_scope_check_v1.py")
passed=[]
def check(name,fn):
    fn();passed.append(name)
def reject(name,fn):
    try:fn()
    except (ValueError,KeyError,TypeError,AssertionError):passed.append(name);return
    raise AssertionError("Accepted invalid fixture: "+name)
def R(p):return dict(path=p,sha256="1"*64)
def good():
    ir=R("packet/input.json");sr=R("packet/storage.json");cr=R("capability.json")
    j=dict(logical_job="test",requested=dict(job_id="test",input_ref=ir,storage_ref=sr,cuda_cap_bytes=28,cpu_rss_cap_bytes=64,
        args=["--execute","--input",ir["path"],"--expected-input-sha256",ir["sha256"]]),
        state="succeeded",pid=101,leader_start_ticks=500,process_identities=[dict(pid=101,uid=1000,start_ticks=500)],
        exit_code=0,leader_wait_status_known=True,owned_drain_observed=True,descendant_waits=[],
        started_unix=100.,started_monotonic=50.,finished_unix=101.)
    c=dict(schema=t.CERT_SCHEMA,status="completed_shared_job_wait0_owned_drain",root_authorizer="root_agent",actual_execution=True,
        exclusive_wait_relabelled=False,scientific_marker_unchanged=True,capability_ref=cr,registry_snapshot_ref=R("snapshot.json"),
        client_tool_terminal_ref=R("tool.json"),input_ref=ir,completed_ref=R("output/completed.json"),
        pool_source_ref=R("pool.py"),terminal_validator_ref=R("terminal.py"),logical_job="test",phase="train",output_directory="output")
    reg=dict(schema=t.REG_SCHEMA,capability_ref=cr,pool="p",physical_gpu=4,pool_job="gpu45_shared_v1:p:gpu4",
        controller=dict(pid=50,uid=1000,start_ticks=2),safety_error=None,ambiguous_descendants_or_lease_holders=[],jobs=[j],updated_unix=102.)
    cap=dict(schema="GPU45_shared_logical_pool_capability_v1",root_authorizer="root_agent",logical_job_sharing_authorized=True,
        source_refs={"pool.py":R("pool.py")},pool="p",physical_gpu=4,jobs={"test":j["requested"]})
    spec=dict(job_id="test",physical_gpu=4,refs=dict(storage=sr),max_cuda_reserved_bytes=28,max_cpu_rss_bytes=64,phase="train",output_directory="output")
    done=dict(input_ref=ir);tool=dict(schema=t.TOOL_SCHEMA,root_authorizer="root_agent",observation_source="actual_root_exec_or_write_stdin_terminal",
        actual_terminal_consumed=True,command="run",capability_ref=cr,logical_job="test",tool_exit_code=0,tool_session_id=12,terminal_chunk_id="abc",terminal_job=copy.deepcopy(j))
    return [c,reg,cap,spec,done,tool]
check("valid actual leader terminal",lambda:t.validate_records(*good()))
for name,index,path,value in [
("no relabel legacy exclusive",0,["exclusive_wait_relabelled"],True),
("reject inferred tool terminal",5,["actual_terminal_consumed"],False),
("reject tool nonzero",5,["tool_exit_code"],1),
("reject missing real session",5,["tool_session_id"],""),
("reject missing real chunk",5,["terminal_chunk_id"],""),
("reject wrong job",0,["logical_job"],"other"),
("reject wrong actual marker input",4,["input_ref"],R("other.json")),
("reject wrong runtime storage",3,["refs","storage"],R("other.json")),
("reject wrong config CUDAcap",3,["max_cuda_reserved_bytes"],29),
("reject wrong config CPUcap",3,["max_cpu_rss_bytes"],63),
("reject physical device mismatch",3,["physical_gpu"],5),
("reject output path mismatch",3,["output_directory"],"other"),
("reject controller ambiguity",1,["ambiguous_descendants_or_lease_holders"],[999]),
("reject safety error",1,["safety_error"],"x"),
("reject preterminal snapshot",1,["updated_unix"],99.),
("reject cancelled worker",1,["jobs",0,"cancel_requested"],True),
("reject resource abort",1,["jobs",0,"resource_abort"],{"why":"cap"}),
("reject missing actual leader wait",1,["jobs",0,"leader_wait_status_known"],False),
("reject absent owned drain",1,["jobs",0,"owned_drain_observed"],False),
("reject leader nonzero",1,["jobs",0,"exit_code"],1),
("reject unqualified success",1,["jobs",0,"state"],"draining"),
("reject leader identity drift",1,["jobs",0,"leader_start_ticks"],501),
("reject returned terminal JSON drift",5,["terminal_job","finished_unix"],102.),
("reject absent sharing authority",2,["logical_job_sharing_authorized"],False)]:
    a=good();v=a[index]
    for k in path[:-1]:v=v[k]
    v[path[-1]]=value
    reject(name,lambda a=a:t.validate_records(*a))
a=good();a[1]["jobs"][0]["process_identities"].append(dict(pid=102,uid=1000,start_ticks=501))
a[1]["jobs"][0]["descendant_waits"]=[dict(pid=102,start_ticks=501,raw_wait_status=0,returncode=0,wait_status_known=True)]
a[5]["terminal_job"]=copy.deepcopy(a[1]["jobs"][0])
check("valid actual adopted wait0",lambda:t.validate_records(*a))
for field,value in [("returncode",1),("raw_wait_status",256),("wait_status_known",False),("pid",103)]:
    b=copy.deepcopy(a);b[1]["jobs"][0]["descendant_waits"][0][field]=value
    reject("reject adopted "+field,lambda b=b:t.validate_records(*b))
# Original scientific functions are never copied or rewritten.
check("frozen H050 producer bytes",lambda:driver.require(runtime.ref(runtime.H050_PRODUCER_REF["path"])==runtime.H050_PRODUCER_REF,"producer SHA"))
check("frozen H050 context adapter bytes",lambda:driver.require(runtime.ref(runtime.H050_CONTEXT_FIX_REF["path"])==runtime.H050_CONTEXT_FIX_REF,"context SHA"))
check("frozen C3 worker bytes",lambda:driver.require(runtime.ref(runtime.C3_ENTRY_REF["path"])==runtime.C3_ENTRY_REF,"worker SHA"))
old=ast.parse((ROOT/"src/arggnn/gpu45_c3cache_h050_pool_v1.py").read_text());new=ast.parse((ROOT/HERE/"pool.staged.py").read_text())
oc=next(n for n in old.body if isinstance(n,ast.ClassDef) and n.name=="Shared45Controller")
nc=next(n for n in new.body if isinstance(n,ast.ClassDef) and n.name=="Shared45Controller")
om={n.name:n for n in oc.body if isinstance(n,ast.FunctionDef)};nm={n.name:n for n in nc.body if isinstance(n,ast.FunctionDef)}
for name in sorted(set(om)-{"_check","_launch_queue","start"}):
    check("unchanged owned controller "+name,lambda name=name:driver.require(ast.dump(om[name],include_attributes=False)==ast.dump(nm[name],include_attributes=False),name))
# The same reviewed lock-order correction is required in this fresh pool.
for w in ast.walk(nm["start"]):
    if isinstance(w,ast.With) and any("scheduler.lock" in ast.unparse(i.context_expr) for i in w.items):
        check("no metadata guard nested under downstream scheduler flock",lambda w=w:driver.require(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="_check" for n in ast.walk(w)),"no nested guard"))
check("downstream startup has prospective pre-lock allowance",lambda:driver.require(ast.unparse(nm["start"]).count("self._check(64 * 1024)")==2,"pre-lock64KiB"))
# Exact replacement lists are compiled without importing original modules/functions.
src=(ROOT/HERE/"root_downstream_v1.py").read_text();tree=ast.parse(src)
for fn,record,original_name in [("admit_h050",driver.H050_DRIVER_REF,"admit"),("admit_c3",driver.C3_DRIVER_REF,"admit")]:
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==fn)
    assignments=[n for n in node.body if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=="substitutions" for v in n.targets)]
    replacements=ast.literal_eval(assignments[0].value);s=driver.function_source(record,original_name)
    for before,after in replacements:s=driver.replace_once(s,before,after)
    check("compile frozen "+fn+" boundaries",lambda s=s:compile(s,"<pure-source-boundaries>","exec"))
# Compile H050 shared lineage with mocked private metadata common; never import science.
origsrc=(ROOT/runtime.H050_COMMON_REF["path"]).read_text();ot=ast.parse(origsrc)
ns=dict(__builtins__=__builtins__)
for node in ot.body:
    if isinstance(node,ast.FunctionDef) and node.name in ("validate_spec_v1","validate_train_lineage_v1","direct_required_refs_v1"):
        exec(compile(ast.Module(body=[node],type_ignores=[]),"<pure-original-functions>","exec"),ns)
c=SimpleNamespace(**ns);adapter=load("runtime_metadata_adapter_v1.py")
fix=SimpleNamespace(private_common_v1=lambda:c,source_metadata_refs_v1=lambda rows,cfg:rows)
saved=runtime.load_exact;runtime.load_exact=lambda record,label:fix
try:
    adapted=runtime.h050_common_v1()
    check("private H050 spec resolves shared lineage",lambda:driver.require(adapted.validate_spec_v1.__globals__["validate_train_lineage_v1"] is adapted.validate_train_lineage_v1,"private lineage"))
finally:runtime.load_exact=saved
# Compute actual direct closure from immutable admitted TRAIN metadata, no guard call.
trainfolder=ROOT/"research/reviews/H050_shared_admission_source_metadata_closure_fix_20261016_v1"
spec=json.loads((trainfolder/"admitted_H050_shared_train_v2/input.json").read_text())
cfg=json.loads((ROOT/spec["refs"]["config"]["path"]).read_text())
authority=json.loads((trainfolder/"admitted_H050_shared_train_v2/reserve_authority.json").read_text())
actual=authority["request"]["consumer_bindings"];by={r["path"]:r for r in actual}
def unique(rows):return list({r["path"]:r for r in rows}.values())
n=next(n for n in ot.body if isinstance(n,ast.FunctionDef) and n.name=="direct_required_refs_v1")
constants={
"GUARD_REF":"research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py",
"POLICY_REF":"research/reviews/prospective_980GB_capacity_source_v1/activation_policy.root_active_v1.json",
"LAUNCHER_REF":"scripts/launch_reserved_gpu_authorized_GPU45_980_v1.py",
"REPAIR_REF":"research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json",
"AUTH_REF":"research/reviews/H040_GPU45_migration_root_20261015_v1/GPU45_authorization.json",
"MEMO_REF":"research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py",
"V4_REF":"src/arggnn/project_budget_v4.py","H045_CONFIG_REF":"research/reviews/H045_GPU45_episode_root_source_v1/config.json"}
prep=("cut_preparation_completion_ref","cut_preparation_actual_wait_ref","cut_preparation_admission_ref","cut_preparation_input_ref","cut_preparation_config_ref","cut_preparation_runtime_ref","cut_preparation_launch_ref")
namespace=dict(unique=unique,ref=runtime.ref,TERMINAL_FIELDS=("preparation_completion_ref","preparation_actual_wait_ref")+prep,
    TRAIN_FIELDS=("train_completion_ref","train_launch_ref","train_actual_wait_ref"),
    framework=SimpleNamespace(declared_cut_preparation_source_refs_v2=lambda cfg:{
        "cut_preparation_producer_ref":cfg["preparation_producer_ref"],"cut_preparation_codec_ref":cfg["cut_preparation_codec_ref"],
        "cut_preparation_source_manifest_ref":cfg["cut_preparation_source_manifest_ref"]}),**{k:by[v] for k,v in constants.items()})
exec(compile(ast.Module(body=[n],type_ignores=[]),"<pure-original-direct-required>","exec"),namespace)
base=namespace["direct_required_refs_v1"](cfg,spec)
fixsource=ROOT/runtime.H050_CONTEXT_FIX_REF["path"];sp=importlib.util.spec_from_file_location("_pure_original_metadata_fix",fixsource);fixm=importlib.util.module_from_spec(sp);sp.loader.exec_module(fixm)
base=fixm.source_metadata_refs_v1(base,cfg);check("actual original base direct42",lambda:driver.require(len(base)==42,"base42"))
oldextras=[r for r in actual if r not in base]
budget_paths=["scripts/project_budget_v9.py","scripts/launch_reserved_gpu_v6.py","src/arggnn/project_storage_cpu_closed_scopes_v1.py","src/arggnn/project_storage_terminal_scopes_v1.py","src/arggnn/project_storage_terminal_success_scopes_v1.py","src/arggnn/project_storage_terminal_retired_scopes_v1.py","research/reviews/concurrent_completed_scope_credits_v3/completed_scope_credits_v3.py","research/reviews/completed_scope_credits_root_activation_20261015_v1/activation_policy.json"]
budget=[by[p] for p in budget_paths]
readonly=[cfg[k] for k in ("count_manifest_ref","cut_preparation_source_manifest_ref","metrics_source_config_ref")]
base=[r for r in base if r not in readonly]
ops=[runtime.ref(str(HERE/name)) for name in ("root_downstream_v1.py","runtime_metadata_adapter_v1.py","shared_terminal_v1.py","controller_metadata_scope_check_v1.py")]
ops += [dict(path=driver.POOL,sha256=runtime.ref(str(HERE/"pool.staged.py"))["sha256"]),dict(path=driver.LAUNCHER,sha256=runtime.ref(str(HERE/"launcher.staged.py"))["sha256"]),runtime.ref(driver.BASE)]
renew_paths=["research/reviews/GPU45_C3cache_H050_pool_successor_20261016_v1/c3_progress_observer_v1.py","research/reviews/GPU45_C3cache_H050_migration_gate_successor_20261016_v2/migration_gate_successor_v2.py","research/reviews/GPU45_C3cache_H050_migration_gate_successor_20261016_v2/failure_flow_source_authentication_v2.json","research/reviews/H039_marker_repair_renewal_source_20261016_v1/marker_repair_renewal_v1.py","research/reviews/H039_marker_repair_renewal_source_20261016_v1/bootstrap_renewal_v1.py","research/reviews/H039_marker_repair_renewal_source_20261016_v1/renewal_certificate.root_active_v1.json"]
closure=unique(base+ops+[by[x] for x in renew_paths]+budget+[by["src/arggnn/H050_direct_readout_cut_memory_exec_v1.py"],R("new_eval_request.json"),R("new_downstream_route.json"),R("new_lineage_bundle.json")])
check("actual-base downstream direct64",lambda:driver.require(len(closure)==64 and all(Path(r["path"]).suffix in (".py",".sh",".json") for r in closure),"direct64"))
# Scope hotpath: synthetic guard only, never invoke a real guard or filesystem measure.
@contextmanager
def mutex(_):yield
own=dict(key="controller",reserved_bytes=32*2**20,auxiliary_scopes=[],consumer_bindings=[R("source.py")])
policy=dict(base_pins={"x":1},implementation_ref=R("impl.py"),launcher_ref=R("launcher.py"),source_ref=R("guard.py"))
storage=dict(reservation=own,reserved_new_bytes=own["reserved_bytes"],expires_at_utc="future",completed_overlay_policy_ref=R("policy.json"),
    budget_components=dict(implementation=policy["implementation_ref"],launcher=policy["launcher_ref"],consumer_adapter=policy["source_ref"]),
    initial_ledger_pins=dict(base_pins=policy["base_pins"],completed_overlay_prefix=dict(events=1,tail_sha256="h1")))
own["root_admission"]=R("auth.json")
event=dict(operation="reserve",authority=own["root_admission"],value=copy.deepcopy(own))
auth=dict(request={k:v for k,v in own.items() if k!="root_admission"},expected_before=dict(base_pins=policy["base_pins"],completed_overlay_prefix=dict(events=0,tail_sha256=None)))
class FakeGuard:
    MODE="prospective_980gb_v1";_POLICY_REF=R("policy.json")
    def __init__(self):
        self.rows=[copy.deepcopy(event)];self.hashes=["h1"];self.used=1024;self.raw_count=0;self.closed=False
        self.budget=SimpleNamespace(v4=SimpleNamespace(mutex=mutex,integer=lambda n,label:driver.require(type(n) is int and n>=0,label),
            measure_scopes=lambda root,paths:dict(conservative_scope_bytes=self.used)))
    def _expire(self,s):driver.require(not self.closed,"expiry")
    def _policy(self):return policy
    def _raw(self,r):self.raw_count+=1
    def _events(self,b):return self.rows,self.hashes
    def check_prefix(self,p,hashes):driver.require(p["events"]<=len(hashes) and p["tail_sha256"]==hashes[p["events"]-1],"prefix")
    def _authority(self,r,op,b,fresh=False):
        if op=="reserve":return auth
        return dict(request=dict(key="controller"),expected_before=dict(base_pins=policy["base_pins"],completed_overlay_prefix=dict(events=1,tail_sha256="h1")))
    def _paths(self,o):return ["only-own-scope"]
def fake_scope():
    o=object.__new__(scope.ControllerMetadataScopeV1);o.guard=FakeGuard();o.storage=storage;o.initial_prefix=dict(events=1,tail_sha256="h1");o.bindings={};return o
o=fake_scope();receipt=o.check(10)
check("isolated scope original measure and direct auth",lambda:driver.require(receipt["remaining_scope_bytes"]==own["reserved_bytes"]-1024 and o.guard.raw_count==1 and receipt["global_projection_recomputed_this_check"] is False,"isolated"))
o=fake_scope();o.guard.used=own["reserved_bytes"];reject("scope prospective overflow",lambda:o.check(1))
o=fake_scope();o.guard.closed=True;reject("scope expiry",lambda:o.check())
o=fake_scope();o.guard.hashes=["changed"];reject("scope changed original prefix",lambda:o.check())
o=fake_scope();o.guard.rows.append(dict(operation="close_completed",authority=R("close.json"),value={}));o.guard.hashes.append("h2");reject("scope actual own close rejects writes",lambda:o.check())

# Exercise every retained H050 scientific lineage predicate with synthetic
# metadata only. Shared terminal proof itself is mocked; no files/models/truth.
f=adapted.validate_train_lineage_v1;fg=f.__globals__;arms=("a","b","c","d");parents=tuple("train_%02d"%i for i in range(32));passes=(5,10,15,20,25,30)
source="synthetic/producer.py";context="synthetic/context.py";rootdriver="synthetic/driver.py";output="synthetic/shared_TRAIN"
refs={name:R(name+".json") for name in ("completion","capability","terminal","input","config","runtime")}
refs["completion"]=R(output+"/completed.json")
cfg0=dict(producer_ref=R(source),registration_ref=R("registration.json"),warmstart_checkpoint_ref=R("warm.pt"),
    warmstart_completion_ref=R("warm.json"),cut_preparation_completion_ref=R("prep.json"),cut_preparation_actual_wait_ref=R("prep_wait.json"),science="fixed")
old0=dict(schema="H050_direct_readout_root_input_v1",hypothesis_id="H050",arm="joint_four_arm",phase="train",
    root_authorizer="root_agent",status="active",physical_gpu=4,device="cuda",output_directory=output,job_id="original_shared_train",
    refs=dict(config=refs["config"],runtime=refs["runtime"]),root_driver_ref=R(rootdriver),root_context_module_ref=R(context),
    producer_ref=R(source),canonical_dispatcher_ref=R(source),main_source_ref=R(source),worker_cli_ref=R(source),
    source_sha256={"source.py":"frozen"})
train0=dict(schema="H050_four_arm_train_completion_v1",hypothesis_id="H050",status="completed_fixed30pass_four_arm_TRAIN",
    arms=list(arms),steps={a:960 for a in arms},VAL_truth_read=False,outer_truth_read=False,common_initial_predictor_verified=True,
    scientific_protocol={"fixed":"protocol"},parameters_per_arm={a:3 for a in arms},
    input_ref=refs["input"],config_ref=refs["config"],producer_ref=R(source),
    history=[dict(pass_index=i,steps={a:32*i for a in arms},full_parent_updates_per_arm=32,parent_order=list(parents)) for i in range(1,31)],
    first_step_qualification={a:dict(finite_FP32=True,part_of_continuous_960_updates=True,parent_id=parents[0],
        full_model_qualification=dict(parameters=3,actual_optimizer_step=1,no_extra_updates=True,warmstart_checkpoint_ref=cfg0["warmstart_checkpoint_ref"],
            gradient_checks={"body.weight":dict(dtype="torch.float32",finite=True)},updated_parameters={"body.weight":True})) for a in arms},
    checkpoint_groups={str(at):{a:R(output+"/"+a+".pass_%02d.pt"%at) for a in arms} for at in passes})
for key in ("registration_ref","warmstart_checkpoint_ref","warmstart_completion_ref","cut_preparation_completion_ref","cut_preparation_actual_wait_ref"):train0[key]=cfg0[key]
spec0=dict(phase="evaluate",train_completion_ref=refs["completion"],train_launch_ref=refs["capability"],train_actual_wait_ref=refs["terminal"])
fg.update(require=driver.require,worker=SimpleNamespace(ARMS=arms,TRAIN=parents,PASSES=passes,RESOURCE_CAPS=frozenset(),
    SOURCE=source,hooks=SimpleNamespace(fixed_protocol_v1=lambda:{"fixed":"protocol"}),model=SimpleNamespace(PARAMETERS={a:3 for a in arms})),
    DRIVER=rootdriver,CONTEXT=context,ref=R,TERMINAL_FIELDS=(),validate_config_v1=lambda c,r:c,
    exact_sources_v1=lambda r,c:{"source.py":"frozen"},is_ref_v1=lambda r:isinstance(r,dict) and set(r)=={"path","sha256"},
    validate_h050_shared_terminal_v1=lambda reader,spec,cfg:dict(output_directory=output,input_ref=refs["input"],physical_gpu=4))
def lineage_fixture(mutator=None):
    tr=copy.deepcopy(train0);old=copy.deepcopy(old0);cfg=copy.deepcopy(cfg0);traincfg=copy.deepcopy(cfg0)
    if mutator:mutator(tr,old,cfg,traincfg)
    values={refs["completion"]["path"]:tr,refs["capability"]["path"]:dict(physical_gpu=4),refs["terminal"]["path"]:{},
        refs["input"]["path"]:old,refs["config"]["path"]:traincfg,
        refs["runtime"]["path"]:dict(job_id=old["job_id"],device="cuda",physical_gpu=4,output_directory=output)}
    reader=SimpleNamespace(decode_json=lambda r:values[r["path"]])
    return f(reader,spec0,cfg)
check("complete synthetic H050 scientific lineage accepted",lambda:driver.require(len(lineage_fixture()["train_checkpoint_groups"])==6,"six"))
for name,mutator in [
    ("reject H050 incomplete update total",lambda tr,old,cfg,tc:tr["steps"].update(a=959)),
    ("reject H050 missing pass",lambda tr,old,cfg,tc:tr["history"].pop()),
    ("reject H050 duplicated parent pass",lambda tr,old,cfg,tc:tr["history"][0]["parent_order"].__setitem__(0,parents[1])),
    ("reject H050 nonfinite first step",lambda tr,old,cfg,tc:tr["first_step_qualification"]["a"].update(finite_FP32=False)),
    ("reject H050 nonFP32 gradient",lambda tr,old,cfg,tc:tr["first_step_qualification"]["a"]["full_model_qualification"]["gradient_checks"]["body.weight"].update(dtype="torch.float16")),
    ("reject H050 extra optimizer updates",lambda tr,old,cfg,tc:tr["first_step_qualification"]["a"]["full_model_qualification"].update(no_extra_updates=False)),
    ("reject H050 no body parameter update",lambda tr,old,cfg,tc:tr["first_step_qualification"]["a"]["full_model_qualification"]["updated_parameters"].update({"body.weight":False})),
    ("reject H050 opened VAL truth",lambda tr,old,cfg,tc:tr.update(VAL_truth_read=True)),
    ("reject H050 opened outer truth",lambda tr,old,cfg,tc:tr.update(outer_truth_read=True)),
    ("reject H050 common predictor mismatch",lambda tr,old,cfg,tc:tr.update(common_initial_predictor_verified=False)),
    ("reject H050 checkpoint group missing",lambda tr,old,cfg,tc:tr["checkpoint_groups"].pop("30")),
    ("reject H050 wrong checkpoint output",lambda tr,old,cfg,tc:tr["checkpoint_groups"]["30"].update(a=R("other/a.pass_30.pt"))),
    ("reject H050 registration provenance drift",lambda tr,old,cfg,tc:tr.update(registration_ref=R("other_registration.json"))),
    ("reject H050 exact source closure drift",lambda tr,old,cfg,tc:old.update(source_sha256={"source.py":"drift"})),
    ("reject H050 scientific config drift",lambda tr,old,cfg,tc:tc.update(science="changed"))]:
    reject(name,lambda mutator=mutator:lineage_fixture(mutator))
# Compile original direct CPU supervisor with exact entry/schema substitutions.
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="launch_cpu")
cpu=driver.function_source(driver.C3_DRIVER_REF,"launch")
cpu=driver.replace_once(cpu,'packet,output=c.phase_paths(phase)','packet,output=downstream_phase_paths(phase)')
before=next(n for n in node.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="before" for t in n.targets))
after=next(n for n in node.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="after" for t in n.targets))
cpu=driver.replace_once(cpu,ast.literal_eval(before.value),ast.literal_eval(after.value))
cpu=driver.replace_once(cpu,'wait=dict(pid=proc.pid,returncode=rc,actual_direct_launcher_wait=True',
    'wait=dict(schema="GPU45_downstream_CPU_actual_direct_wait_v1",operational_root_entry_ref=DOWNSTREAM_ENTRY,operational_runtime_adapter_ref=DOWNSTREAM_RUNTIME,pid=proc.pid,returncode=rc,actual_direct_launcher_wait=True')
check("compile unchanged original CPU owned supervisor with explicit entry/schema",lambda:compile(cpu,"<pure-CPU-supervisor-boundaries>","exec"))
# Verify deterministic cache environment stays beneath own auxiliary metadata.
pooltext=(ROOT/HERE/"pool.staged.py").read_text();ptree=ast.parse(pooltext);envnode=next(n for n in ptree.body if isinstance(n,ast.FunctionDef) and n.name=="expected_worker_env")
envns=dict(ROOT=ROOT,Path=Path,require=driver.require);exec(compile(ast.Module(body=[envnode],type_ignores=[]),"<pure-env-paths>","exec"),envns)
env=envns["expected_worker_env"](dict(worker_auxiliary_scope="packet/worker_aux"))
check("downstream deterministic cache paths owned",lambda:driver.require(all(v.startswith(str(ROOT/"packet/worker_aux/downstream_runtime")) for k,v in env.items() if k.endswith("DIR") or k.endswith("HOME") or k in ("TMP","TEMP","CUDA_CACHE_PATH")),"owned env"))
reject("downstream absolute auxiliary rejected",lambda:envns["expected_worker_env"](dict(worker_auxiliary_scope="/elsewhere")))


# Only the response-send deadline changes in the original full server loop.
pooltext=(ROOT/HERE/"pool.staged.py").read_text();ptree=ast.parse(pooltext)
servernode=next(n for n in ptree.body if isinstance(n,ast.FunctionDef) and n.name=="response_deadline_run_source_v1")
serverns=dict(ast=ast,ref=runtime.ref,BASE=driver.BASE,BASE_SHA="ae1e0494ab672cfa3017759460eb06a4b4789eaef54928496c3c80314adcc0e1",ROOT=ROOT,require=driver.require)
exec(compile(ast.Module(body=[servernode],type_ignores=[]),"<pure-server-adapter>","exec"),serverns)
serversource=serverns["response_deadline_run_source_v1"]()
check("compile response deadline adaptation without socket",lambda:compile(serversource,"<pure-server-loop>","exec"))
newrun=ast.parse(serversource).body[0]
baseclass=next(n for n in ast.parse((ROOT/driver.BASE).read_text()).body if isinstance(n,ast.ClassDef) and n.name=="Controller")
oldrun=next(n for n in baseclass.body if isinstance(n,ast.FunctionDef) and n.name=="run")
class RemoveResponseDeadline(ast.NodeTransformer):
    count=0
    def visit_Assign(self,n):
        if any(isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=="state"
            and isinstance(t.slice,ast.Constant) and t.slice.value=="deadline" for t in n.targets):
            self.count+=1;return None
        return self.generic_visit(n)
remove=RemoveResponseDeadline();stripped=remove.visit(newrun)
check("server loop unchanged except one post-dispatch response deadline",lambda:driver.require(remove.count==1 and ast.dump(stripped,include_attributes=False)==ast.dump(oldrun,include_attributes=False),"only response deadline"))
clientnode=next(n for n in ptree.body if isinstance(n,ast.FunctionDef) and n.name=="controller_request")
check("client bounded300s actual response wait",lambda:driver.require(any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="settimeout" and len(n.args)==1 and isinstance(n.args[0],ast.Constant) and n.args[0].value==300 for n in ast.walk(clientnode)),"bounded timeout"))

summary=dict(schema="GPU45_downstream_source_pure_fixtures_v1",status="PASS_SOURCE_ONLY",cases=len(passed),passed=passed,
    actual_guards_called=False,actual_processes_or_probes=False,scientific_payloads_read=False,model_imports=False,
    actual_original_TRAIN_base_direct_bindings=42,prospective_H050_EVALUATE_direct_bindings_using_actual_base=64)
print(json.dumps(summary,sort_keys=True,indent=2))
