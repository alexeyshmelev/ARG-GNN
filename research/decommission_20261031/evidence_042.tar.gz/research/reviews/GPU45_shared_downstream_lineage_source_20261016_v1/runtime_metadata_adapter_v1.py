"""Private operational validators; original scientific functions remain unchanged."""
from pathlib import Path
import ast,hashlib,importlib.util,json,sys,types
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/GPU45_shared_downstream_lineage_source_20261016_v1"
SOURCE=HERE+"/runtime_metadata_adapter_v1.py"
TERMINAL=HERE+"/shared_terminal_v1.py"
H050_COMMON_REF=dict(path="research/reviews/H050_direct_readout_cut_memory_source_20261015_v1/producer_integration_v1/root_bridge_v1/bridge_common_v1.py",sha256="5ec43d65bde777d18c071be2cdf4ee5c14ef2784bfe54ac27582f187ee93552b")
H050_CONTEXT_FIX_REF=dict(path="research/reviews/H050_shared_admission_source_metadata_closure_fix_20261016_v1/context_metadata_fix_v1.py",sha256="6c704a0b47d5b6f136479879ad9c11036f6d80760a93933ae3d0f222db3ce67d")
H050_PRODUCER_REF=dict(path="research/reviews/H050_direct_readout_cut_memory_source_20261015_v1/producer_integration_v1/producer_v1.py",sha256="1efd84ea51ed05b20e713f6a39ef33dfc08ce3921730d8ce8aa39ef184506130")
C3_CONTRACT_REF=dict(path="research/reviews/C3_GNN_prefetch_ramcache_isolated980_root_20261015_v3/root_contract_v1.py",sha256="8143dcd241c23f9bcf3379644c275f66febc8cf8dea01727e542d88651d734a0")
C3_ENTRY_REF=dict(path="research/reviews/C3_GNN_prefetch_ramcache_isolated980_root_20261015_v3/worker_entry_v1.py",sha256="8901ac783449859db3f1a872932806a30768fe9c4e5e7f975e78bfd34e0f624d")

def require(ok,message):
    if not ok:raise ValueError(message)

def ref(name):
    p=ROOT/name;require(p.resolve()==p and p.is_file() and not p.is_symlink(),"Canonical existing metadata source")
    return dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def load_exact(r,label):
    require(ref(r["path"])==r,"Exact frozen original source")
    sp=importlib.util.spec_from_file_location(label,ROOT/r["path"]);m=importlib.util.module_from_spec(sp)
    sys.modules[label]=m;sp.loader.exec_module(m);return m

def terminal():
    return load_exact(ref(TERMINAL),"_GPU45_downstream_terminal_v1")

def declared_runtime_refs(spec):
    rows=spec.get("operational_downstream_source_refs")
    require(isinstance(rows,dict) and all(isinstance(k,str) and ref(k)==r for k,r in rows.items()),"Exact explicit downstream operational closure")
    require(all(ref(p) in rows.values() for p in (SOURCE,TERMINAL)),"Runtime/terminal source declared")
    return list(rows.values())

def validate_h050_shared_terminal_v1(reader,spec,cfg):
    require(spec["phase"]=="evaluate","H050 shared TRAIN lineage only for EVALUATE")
    proof=terminal().validate_certificate(spec["train_actual_wait_ref"],reader)
    cert,old,cap,train=proof["certificate"],proof["input"],proof["capability"],proof["completion"]
    require(cert["phase"]=="train" and spec["train_completion_ref"]==cert["completed_ref"]
        and spec["train_launch_ref"]==cert["capability_ref"]
        and old.get("schema")=="H050_direct_readout_root_input_v1" and old.get("hypothesis_id")=="H050"
        and old.get("arm")=="joint_four_arm" and old.get("phase")=="train"
        and old.get("root_context_module_ref")==H050_CONTEXT_FIX_REF
        and old.get("operational_pool_source_ref")==terminal().TRAIN_POOL_REF
        and old["refs"]["config"]==train["config_ref"]==spec["refs"]["config"],
        "Exact actual shared H050 TRAIN and identical admitted TRAIN/EVAL config bytes")
    bundle=reader.decode_json(spec["shared_train_lineage_ref"])
    expected=dict(schema="H050_shared_TRAIN_lineage_metadata_closure_v1",hypothesis_id="H050",
        train_completion_ref=spec["train_completion_ref"],train_launch_ref=spec["train_launch_ref"],
        train_actual_wait_ref=spec["train_actual_wait_ref"],train_input_ref=train["input_ref"],
        train_config_ref=train["config_ref"],train_runtime_ref=old["refs"]["runtime"],
        runtime_adapter_ref=ref(SOURCE),terminal_validator_ref=ref(TERMINAL),
        read_only_training_metadata_refs={k:cfg[k] for k in ("count_manifest_ref","cut_preparation_source_manifest_ref","metrics_source_config_ref")})
    require(bundle==expected,"Exact explicitly bound transitive TRAIN lineage metadata")
    declared_runtime_refs(spec)
    require(reader.decode_json(train["config_ref"])==cfg,"Unchanged exact TRAIN configuration")
    return dict(output_directory=old["output_directory"],input_ref=train["input_ref"],physical_gpu=cap["physical_gpu"])

def h050_common_v1():
    adapter=load_exact(H050_CONTEXT_FIX_REF,"_H050_shared_metadata_fix_for_downstream_v1")
    c=adapter.private_common_v1()
    src=(ROOT/H050_COMMON_REF["path"]).read_text();require(ref(H050_COMMON_REF["path"])==H050_COMMON_REF,"Frozen H050 common")
    node=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=="validate_train_lineage_v1")
    fn=ast.get_source_segment(src,node)
    legacy=next(n for n in node.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=="require" and "Genuine same-identity original supervisor" in ast.get_source_segment(src,n))
    paths=next(n for n in node.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=="require" and "Only fresh H050 bridge TRAIN admission" in ast.get_source_segment(src,n))
    for before,after in [
        (ast.get_source_segment(src,legacy),'shared=validate_h050_shared_terminal_v1(reader,spec,cfg)'),
        ('packet=HERE+"/admitted_train/"','packet=None  # Original exclusive namespace is not relabelled'),
        (ast.get_source_segment(src,paths),'require(train["input_ref"]==shared["input_ref"],"Actual shared TRAIN input proof")'),
        ('old["output_directory"]=="experiments/results/H050_GPU%d_direct_readout_cut_memory_train_seed101_v1"%launch["physical_gpu"]','old["output_directory"]==shared["output_directory"]')]:
        require(fn.count(before)==1,"Single exact H050 operational-only adaptation boundary");fn=fn.replace(before,after)
    ns=dict(c.__dict__);ns["validate_h050_shared_terminal_v1"]=validate_h050_shared_terminal_v1
    exec(compile(fn,"<H050_shared_terminal_operational_blocks_only>","exec"),ns)
    c.validate_train_lineage_v1=ns["validate_train_lineage_v1"]
    # Keep original validate_spec function globals private and scientifically unchanged.
    c.validate_spec_v1.__globals__["validate_train_lineage_v1"]=c.validate_train_lineage_v1
    original_node=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=="direct_required_refs_v1")
    plain=dict(c.__dict__);exec(compile(ast.Module(body=[original_node],type_ignores=[]),"<unchanged_H050_original_required_refs>","exec"),plain)
    original=plain["direct_required_refs_v1"]
    def required(cfg,spec):
        if spec["phase"]!="evaluate":return adapter.source_metadata_refs_v1(original(cfg,spec),cfg)
        # The complete old lineage remains authenticated through one declared JSON
        # closure. No scientific payload is added as a direct source binding.
        base=original(cfg,dict(spec,phase="train"))
        # Exactly three immutable read-only JSON records are authenticated through
        # the explicit bundle to retain all original direct source/guard refs.
        indirect={cfg[k]["path"]:cfg[k] for k in ("count_manifest_ref","cut_preparation_source_manifest_ref","metrics_source_config_ref")}
        require(all(Path(r["path"]).suffix==".json" and r in base for r in indirect.values()),"Only explicit original readonly JSON metadata")
        base=[r for r in base if r not in indirect.values()]
        rows=adapter.source_metadata_refs_v1(base,cfg)
        rows=c.unique(rows+[spec["shared_train_lineage_ref"]]+declared_runtime_refs(spec))
        require(len(rows)<=64,"Unchanged64 direct metadata binding ceiling")
        return rows
    c.direct_required_refs_v1=required
    c.validate_spec_v1.__globals__["direct_required_refs_v1"]=required
    return c

def c3_contract_v1():
    c=load_exact(C3_CONTRACT_REF,"_C3_private_shared_terminal_contract_v1")
    original=c.validate_terminal
    def validate(envelope_ref,wait_ref,stage):
        w=c.read(wait_ref)
        if w.get("schema")=="GPU45_downstream_CPU_actual_direct_wait_v1":
            require(stage in ("matrix","score"),"Explicit downstream CPU stages")
            v=c.read(envelope_ref);old=c.read(w["input_ref"])
            require(w.get("actual_direct_launcher_wait") is True and w.get("all_owned_processes_and_groups_drained") is True
                and type(w.get("returncode")) is int and w["returncode"]==0 and w.get("operational_failure") is None
                and w.get("completed_ref")==envelope_ref and w.get("phase")==stage
                and w.get("driver_ref")==c.ref(c.DRIVER) and w.get("operational_root_entry_ref")==ref(HERE+"/root_downstream_v1.py")
                and w.get("operational_runtime_adapter_ref")==ref(SOURCE)
                and all(type(row.get("status")) is int and row["status"]==0 for row in w.get("adopted_waits",[]))
                and v.get("input_ref")==w["input_ref"] and old.get("phase")==stage and old.get("physical_gpu") is None
                and envelope_ref["path"]==old["output_directory"]+"/completed.json"
                and v.get("status")==c.STATUSES[stage] and v.get("stage")==stage
                and v.get("root_driver_ref")==c.ref(c.DRIVER) and v.get("native_MLM_dependency") is False
                and v.get("TEST_deferred") is True,"Genuine new-labelled actual CPU directwait0/owned drain and unchanged scientific envelope")
            declared_runtime_refs(old);return v
        if w.get("schema")!=terminal().CERT_SCHEMA:return original(envelope_ref,wait_ref,stage)
        proof=terminal().validate_certificate(wait_ref)
        v=proof["completion"];spec=proof["input"]
        require(proof["certificate"]["completed_ref"]==envelope_ref
            and proof["certificate"]["phase"]==stage and spec.get("phase")==stage
            and spec.get("schema")=="C3_GNN_prefetch_isolated980_active_input_v1"
            and v.get("status")==c.STATUSES[stage] and v.get("stage")==stage
            and v.get("root_driver_ref")==c.ref(c.DRIVER)
            and v.get("native_MLM_dependency") is False and v.get("TEST_deferred") is True,
            "Original scientific C3 envelope with honest shared operational terminal proof")
        return v
    c.validate_terminal=validate
    return c

def run_h050_v1(argv):
    producer=load_exact(H050_PRODUCER_REF,"_H050_original_producer_for_shared_evaluate_v1")
    # Compile original main unchanged with a private metadata loader proxy.
    original_util=importlib.util
    class Loader:
        def __init__(self,wrapped):self.wrapped=wrapped
        def create_module(self,spec):return self.wrapped.create_module(spec) if hasattr(self.wrapped,"create_module") else None
        def exec_module(self,m):
            self.wrapped.exec_module(m)
            require(ref(H050_CONTEXT_FIX_REF["path"])==H050_CONTEXT_FIX_REF,"Exact unchanged admitted context")
            m.private_common_v1=h050_common_v1
    def context_spec(label,p,*args,**kwargs):
        sp=original_util.spec_from_file_location(label,p,*args,**kwargs)
        require(Path(p)==ROOT/H050_CONTEXT_FIX_REF["path"],"Only exact admitted H050 context loader is adapted")
        sp.loader=Loader(sp.loader);return sp
    proxy=types.SimpleNamespace(util=types.SimpleNamespace(spec_from_file_location=context_spec,module_from_spec=original_util.module_from_spec))
    ns=dict(producer.__dict__);ns["importlib"]=proxy
    src=(ROOT/H050_PRODUCER_REF["path"]).read_text()
    main=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=="main")
    exec(compile(ast.Module(body=[main],type_ignores=[]),"<unchanged_original_H050_main_private_metadata_loader>","exec"),ns)
    return ns["main"](argv)

def run_c3_v1(argv):
    c=c3_contract_v1()
    worker=load_exact(C3_ENTRY_REF,"_C3_original_worker_for_shared_downstream_v1")
    worker.c=c
    return worker.main(argv)

def invoke_job_v1(spec_ref,argv):
    t=terminal();spec=t.read(spec_ref);rows=declared_runtime_refs(spec)
    storage=t.read(spec["refs"]["storage"])
    require(all(r in storage["reservation"]["consumer_bindings"] for r in rows),"Actual direct-bound downstream operational source closure")
    require(spec.get("phase")!="train","Downstream runtime cannot start TRAIN")
    if spec.get("hypothesis_id")=="H050":require(spec["phase"]=="evaluate","Only original H050 EVALUATE");return run_h050_v1(argv)
    require(spec["phase"] in tuple("predict_val_%03d"%i for i in range(5))+("matrix","score"),"Only original C3 VAL/matrix/score downstream stages")
    return run_c3_v1(argv)

def main(argv=None):
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--execute",action="store_true");p.add_argument("--input");p.add_argument("--expected-input-sha256");a=p.parse_args(argv)
    if not a.execute:print(json.dumps(dict(status="source_only",actual_execution=False)));return 0
    require(a.input and a.expected_input_sha256,"Pinned downstream operational capability")
    r=dict(path=a.input,sha256=a.expected_input_sha256)
    return invoke_job_v1(r,["--execute","--input",a.input,"--expected-input-sha256",a.expected_input_sha256])
if __name__=="__main__":raise SystemExit(main())
