"""Root-only downstream metadata/admission entry; inert without explicit execute."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import argparse,ast,hashlib,importlib.util,json,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/GPU45_shared_downstream_lineage_source_20261016_v1"
SOURCE=HERE+"/root_downstream_v1.py"
RUNTIME=HERE+"/runtime_metadata_adapter_v1.py"
TERMINAL=HERE+"/shared_terminal_v1.py"
POOL="src/arggnn/gpu45_shared_downstream_pool_v1.py"
LAUNCHER="scripts/launch_reserved_gpu45_shared_downstream_pool_v1.py"
BASE="src/arggnn/gpu_pool_v1.py"
C3_MODULE="arggnn.american_c3_gnn_prefetch_ramcache_isolated980_exec_v3"
H050_MODULE="arggnn.H050_direct_readout_cut_memory_exec_v1"
H050_DRIVER_REF=dict(path="research/reviews/H050_direct_readout_cut_memory_source_20261015_v1/producer_integration_v1/root_bridge_v1/root_driver_v1.py",sha256="f8399361305ecb3b27172695d6e6e5c1827da330d4fa3d4565bda2df1ed6d6ac")
C3_DRIVER_REF=dict(path="research/reviews/C3_GNN_prefetch_ramcache_isolated980_root_20261015_v3/root_driver_v1.py",sha256="1b30a9e68f4c31e65492f26af28e1d22d45ec96211d301758e9ef5a9864a6536")

def require(ok,message):
    if not ok:raise ValueError(message)

def path(name):
    if isinstance(name,Path) and name.is_absolute():name=str(name.relative_to(ROOT))
    require(isinstance(name,str) and not Path(name).is_absolute() and ".." not in Path(name).parts,"Contained path")
    p=ROOT/name;require(p.resolve()==p and p.is_relative_to(ROOT) and not p.is_symlink(),"Canonical path");return p

def ref(name):
    p=path(name);return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def read(r):
    require(ref(r["path"])==r,"Exact metadata/source SHA");data=path(r["path"]).read_bytes();require(len(data)<=33554432,"Bounded metadata");return json.loads(data)

def save(folder,name,value):
    p=folder/name;require(not p.exists() and p.parent.resolve().is_relative_to(ROOT),"Fresh metadata only")
    p.write_text(json.dumps(value,sort_keys=True,indent=2)+"\n");return ref(p)

def load(r,label):
    require(ref(r["path"])==r,"Exact frozen source");sp=importlib.util.spec_from_file_location(label,ROOT/r["path"]);m=importlib.util.module_from_spec(sp);sys.modules[label]=m;sp.loader.exec_module(m);return m

def runtime():return load(ref(RUNTIME),"_GPU45_downstream_root_runtime_v1")

def pool():
    require(ref(POOL)["sha256"]==ref(HERE+"/pool.staged.py")["sha256"] and ref(LAUNCHER)["sha256"]==ref(HERE+"/launcher.staged.py")["sha256"],"Root must install exact fresh additive pool/launcher")
    return load(ref(POOL),"_GPU45_fresh_downstream_pool_v1")

def op_refs():
    return [ref(x) for x in (SOURCE,RUNTIME,TERMINAL,POOL,LAUNCHER,BASE,HERE+"/controller_metadata_scope_check_v1.py")]

def route(record):
    r=read(record);p=pool()
    require(r.get("schema")=="GPU45_shared_downstream_route_v1" and r.get("status")=="active" and r.get("root_authorizer")=="root_agent"
        and r.get("physical_gpu")==4 and r.get("maximum_concurrent_jobs")==2 and r.get("headroom_mib")==4096,
        "Explicit fresh GPU4 downstream route")
    require(r["pool_source_ref"]==ref(POOL) and r["launcher_ref"]==ref(LAUNCHER) and r["base_source_ref"]==ref(BASE),"Exact new additive pool path")
    require(type(r["expires_unix"]) in (int,float),"Bounded downstream expiry")
    certificate=p.install_marker_renewal(r["marker_repair_renewal_ref"])
    renewal_expiry=datetime.fromisoformat(certificate["renewed_expires_at_utc"].replace("Z","+00:00")).timestamp()
    now=datetime.now(timezone.utc).timestamp()
    require(now<r["expires_unix"]<=now+86400 and r["expires_unix"]+600<renewal_expiry,"Fresh bounded downstream execution/drain authority within genuine renewal")
    p.validate_train_pool_shutdown(r["train_pool_shutdown_ref"])
    return r,p

def renewal_refs(r,p):
    return [p.RENEWAL_SOURCE_REF,p.RENEWAL_BOOTSTRAP_REF,r["marker_repair_renewal_ref"],p.C3_PROGRESS_OBSERVER_REF,p.MIGRATION_SUCCESSOR_REF,p.MIGRATION_FAILURE_FLOW_REF]

def metadata(record):
    r,p=route(record)
    return dict(operational_launch_mode="GPU4_fresh_shared_H050_EVALUATE_C3_original5VAL_v1",
        operational_shared_route_ref=record,operational_pool_source_ref=ref(POOL),operational_launcher_ref=ref(LAUNCHER),
        operational_pool_base_ref=ref(BASE),operational_root_entry_ref=ref(SOURCE),
        marker_repair_renewal_ref=r["marker_repair_renewal_ref"],
        operational_downstream_source_refs={v["path"]:v for v in op_refs()})

def phase_paths(stage):
    require(stage in tuple("predict_val_%03d"%i for i in range(5))+("matrix","score"),"Exact downstream C3 stage")
    return ROOT/HERE/("admitted_C3_"+stage+"_v1"),"experiments/results/C3_GNN_shared_downstream_"+stage+"_v1"

def function_source(record,name):
    require(ref(record["path"])==record,"Frozen original metadata driver")
    text=path(record["path"]).read_text();n=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.get_source_segment(text,n)

def replace_once(text,before,after):
    require(text.count(before)==1,"Single exact frozen operational source adaptation: "+before[:80]);return text.replace(before,after)

def bind_h050(record):
    r=read(record);shared=r["shared_route_ref"];route(shared);t=runtime().terminal()
    proof=t.validate_certificate(r["train_actual_wait_ref"]);old=proof["input"];train=proof["completion"]
    require(r.get("schema")=="H050_downstream_evaluate_binding_request_v1" and r.get("status")=="active"
        and r.get("root_authorizer")=="root_agent" and r["train_completion_ref"]==proof["certificate"]["completed_ref"]
        and r["train_launch_ref"]==proof["certificate"]["capability_ref"],"Explicit genuine shared TRAIN/EVAL binding")
    directory=ROOT/HERE/"H050_evaluate_metadata_v1";require(not directory.exists(),"Fresh EVAL metadata namespace");directory.mkdir()
    bundle=dict(schema="H050_shared_TRAIN_lineage_metadata_closure_v1",hypothesis_id="H050",
        train_completion_ref=r["train_completion_ref"],train_launch_ref=r["train_launch_ref"],train_actual_wait_ref=r["train_actual_wait_ref"],
        train_input_ref=train["input_ref"],train_config_ref=train["config_ref"],train_runtime_ref=old["refs"]["runtime"],
        runtime_adapter_ref=ref(RUNTIME),terminal_validator_ref=ref(TERMINAL),
        read_only_training_metadata_refs={k:read(train["config_ref"])[k] for k in ("count_manifest_ref","cut_preparation_source_manifest_ref","metrics_source_config_ref")})
    bundle_ref=save(directory,"shared_train_lineage.json",bundle)
    req=dict(schema="H050_root_admission_request_v1",status="active",root_authorizer="root_agent",phase="evaluate",physical_gpu=4,
        config_ref=train["config_ref"],reserved_bytes=r["reserved_bytes"],shared_train_lineage_ref=bundle_ref,
        train_completion_ref=r["train_completion_ref"],train_launch_ref=r["train_launch_ref"],train_actual_wait_ref=r["train_actual_wait_ref"],
        shared_route_ref=shared)
    req_ref=save(directory,"admission_request.root_active.json",req)
    result=dict(request_ref=req_ref,config_reused_exactly=True,scientific_execution_started=False);print(json.dumps(result),flush=True);return result

def admit_h050(record):
    req=read(record);r,p=route(req["shared_route_ref"]);c=runtime().h050_common_v1()
    require(req["phase"]=="evaluate","Only H050 EVALUATE downstream admission")
    meta=dict(metadata(req["shared_route_ref"]),shared_train_lineage_ref=req["shared_train_lineage_ref"],
        operational_canonical_module_ref=ref("src/arggnn/H050_direct_readout_cut_memory_exec_v1.py"))
    text=function_source(H050_DRIVER_REF,"admit")
    substitutions=[
        ('dict(phase=phase,**terminal)','dict(phase=phase,refs=dict(config=r["config_ref"]),**terminal,**DOWNSTREAM_META)'),
        ('packet=ROOT/HERE/("admitted_"+phase)','packet=ROOT/DOWNSTREAM_HERE/"admitted_H050_evaluate_v1"'),
        ('output="experiments/results/H050_GPU%d_direct_readout_cut_memory_%s_seed101_v1"%(gpu,phase)','output="experiments/results/H050_shared_downstream_evaluate_seed101_v1"'),
        ('expiry=(now+timedelta(hours=24)).isoformat()','expiry=min(now+timedelta(hours=24),datetime.fromtimestamp(DOWNSTREAM_EXPIRES,timezone.utc)).isoformat()'),
        ('job="H050-direct-readout-%s-seed101-v1-GPU%d"%(phase,gpu)','job="H050-shared-downstream-EVALUATE-v1"'),
        ('validate_spec_v1(reader,spec,cfg)','spec.update(DOWNSTREAM_META)\n    validate_spec_v1(reader,spec,cfg)'),
        ('direct_required_refs_v1(cfg,spec)+list(budget_bindings.values())','direct_required_refs_v1(cfg,spec)+DOWNSTREAM_REQUIRED_REFS+list(budget_bindings.values())')]
    for a,b in substitutions:text=replace_once(text,a,b)
    ns=dict(c.__dict__);ns.update(datetime=datetime,timedelta=timedelta,timezone=timezone,json=json,
        DOWNSTREAM_HERE=HERE,DOWNSTREAM_EXPIRES=r["expires_unix"],DOWNSTREAM_META=meta,
        DOWNSTREAM_REQUIRED_REFS=op_refs()+renewal_refs(r,p)+[ref("src/arggnn/H050_direct_readout_cut_memory_exec_v1.py"),record,req["shared_route_ref"]])
    exec(compile(text,"<original_H050_admission_downstream_operational_only>","exec"),ns)
    admitted=ns["admit"](record)
    return dict(admitted_ref=ref(ROOT/HERE/"admitted_H050_evaluate_v1"/"admitted.json"),admitted=admitted)

def admit_c3(record):
    wrapper=read(record)
    require(wrapper.get("schema")=="GPU45_shared_C3_downstream_admission_wrapper_v1"
        and wrapper.get("status")=="active" and wrapper.get("root_authorizer")=="root_agent","Explicit fresh C3 downstream operational admission authority")
    shared=wrapper["shared_route_ref"];r,p=route(shared)
    c=runtime().c3_contract_v1();request_ref=wrapper["worker_request_ref"];req,caps,_=c.validate_request(request_ref);phase=req["phase"]
    require(phase in tuple("predict_val_%03d"%i for i in range(5))+("matrix","score"),"Original downstream C3 stage only")
    if phase.startswith("predict"):
        require(caps["max_cuda_reserved_bytes"]==40*2**30 and caps["max_cpu_rss_bytes"]==128*2**30 and caps["operational_deadline_seconds"]==86400,"Explicit reviewed outer downstream GPU limits")
        require(caps["phase_write_budget_bytes"]>=4*2**30,"Explicit six-product planning allowance; no TRAIN1GiB reuse")
    original=load(C3_DRIVER_REF,"_C3_original_root_driver_for_downstream_admission_v1")
    text=function_source(C3_DRIVER_REF,"admit")
    substitutions=[
        ('packet,output=c.phase_paths(phase)','packet,output=downstream_phase_paths(phase)'),
        ('sources={p:c.ref(p)["sha256"] for p in c.source_paths()}','sources={p:c.ref(p)["sha256"] for p in c.source_paths()}\n    sources.update({r["path"]:r["sha256"] for r in DOWNSTREAM_REFS if r["path"].endswith(".py")})'),
        ('consumers=unique([*bindings.values(),*mandatory])','consumers=unique([*bindings.values(),*mandatory,*DOWNSTREAM_REFS])\n    c.require(len(consumers)<=64,"Unchanged64 direct binding ceiling")'),
        ('expiry=now+timedelta(seconds=caps["operational_deadline_seconds"])','expiry=min(now+timedelta(seconds=caps["operational_deadline_seconds"]),datetime.fromtimestamp(DOWNSTREAM_EXPIRES,timezone.utc))'),
        ('job="American-C3-GNN-prefetch-isolated980-"+phase+"-v1"','job="C3-shared-downstream-"+phase+"-v1"'),
        ('actual_launcher_ref=c.LAUNCHER_REF if phase in c.GPU_PHASES else None','actual_launcher_ref=DOWNSTREAM_LAUNCHER_REF if phase in c.GPU_PHASES else None'),
        ('input_ref=c.save(packet,"input.json",spec)','spec.update(DOWNSTREAM_META)\n    input_ref=c.save(packet,"input.json",spec)')]
    for a,b in substitutions:text=replace_once(text,a,b)
    ns=dict(original.__dict__);ns.update(c=c,downstream_phase_paths=phase_paths,DOWNSTREAM_REFS=op_refs()+renewal_refs(r,p)+[record,shared],
        DOWNSTREAM_EXPIRES=r["expires_unix"],DOWNSTREAM_LAUNCHER_REF=ref(LAUNCHER),
        DOWNSTREAM_META=dict(metadata(shared),operational_canonical_module_ref=c.verify_shim() if phase in c.GPU_PHASES else c.ref(c.ENTRY)))
    exec(compile(text,"<original_C3_admission_downstream_operational_only>","exec"),ns)
    ns["admit"](request_ref)
    packet,_=phase_paths(phase);return dict(admitted_ref=ref(packet/"admitted.json"))

def assemble(record):
    req=read(record);r,p=route(req["shared_route_ref"])
    require(req.get("schema")=="GPU45_shared_downstream_controller_admission_v1" and req.get("status")=="active"
        and req.get("root_authorizer")=="root_agent" and len(req["worker_admitted_refs"])==6,"Explicit complete six-job downstream controller authority")
    jobs={};stages=[]
    for ar in req["worker_admitted_refs"]:
        admitted=read(ar);ir=admitted["input_ref"];spec=read(ir);name=spec["job_id"]
        module=H050_MODULE if spec.get("hypothesis_id")=="H050" else C3_MODULE
        stages.append((module,spec["phase"]))
        require(spec.get("operational_shared_route_ref")==req["shared_route_ref"] and spec["physical_gpu"]==4 and name not in jobs,"Exact new shared worker route")
        cr=spec["refs"]["config"] if module==H050_MODULE else spec["caps_ref"];caps=read(cr);pin=p.MODULE_PINS[module]
        storage=read(spec["refs"]["storage"])
        require(all(x in storage["reservation"]["consumer_bindings"] for x in op_refs()+renewal_refs(r,p)),"Actual downstream worker source/renewal closure reserved")
        require(spec["max_cuda_reserved_bytes"]==caps["max_cuda_reserved_bytes"]==pin["cuda_bytes"]
            and spec["max_cpu_rss_bytes"]==caps["max_cpu_rss_bytes"]==pin["cpu_bytes"],"Original scientific worker outer caps")
        jobs[name]=dict(job_id=name,module=module,module_ref=ref(pin["path"]),scientific_canonical_module_ref=ref(pin["path"]),operational_runtime_adapter_ref=ref(RUNTIME),dispatch_mode="private_metadata_adapted_original_main",input_ref=ir,cuda_caps_ref=cr,
            storage_ref=spec["refs"]["storage"],cuda_cap_bytes=pin["cuda_bytes"],cpu_rss_cap_bytes=pin["cpu_bytes"],
            operational_deadline_seconds=86400,margin_mib=2048,peak_mib=pin["cuda_bytes"]//2**20+2048,
            log_limit_bytes=2**20,env=p.expected_worker_env(spec),args=["--execute","--input",ir["path"],"--expected-input-sha256",ir["sha256"]])
    require(sorted(stage for module,stage in stages if module==C3_MODULE)==["predict_val_%03d"%i for i in range(5)]
        and [stage for module,stage in stages if module==H050_MODULE]==["evaluate"],"Exact complete downstream stage set before any controller reserve")
    packet=ROOT/HERE/"admitted_downstream_controller_v1";require(not packet.exists(),"Fresh downstream controller namespace")
    output=HERE+"/downstream_controller_output_v1";require(not path(output).exists(),"Fresh controller output")
    rb=req["reserved_bytes"];require(type(rb) is int and 32*2**20<=rb<=64*2**20,"Explicit complete controller cap");packet.mkdir()
    plan=dict(schema="GPU45_shared_logical_pool_plan_v1",pool=r["pool"],physical_gpu=4,gpu_uuid=r["gpu_uuid"],
        maximum_concurrent_jobs=2,headroom_mib=4096,termination_grace_seconds=30,jobs=jobs,
        shared_route_ref=req["shared_route_ref"],migration_gate_ref=r["migration_gate_ref"],
        marker_repair_renewal_ref=r["marker_repair_renewal_ref"],train_pool_shutdown_ref=r["train_pool_shutdown_ref"],
        at_most_one_C3_prediction_job_active=True,no_measured_fit_claim=True)
    pr=save(packet,"pool_plan.root_active.json",plan);guard=p.current_guard();c=runtime().h050_common_v1()
    with guard.budget.v4.mutex(ROOT):state=guard._state_locked(c.CORE,c.BASE,fresh=True)
    view,bindings=state[2],state[3]
    ops=op_refs()+renewal_refs(r,p)+[r["train_pool_shutdown_ref"],r["migration_gate_ref"]]
    consumers=c.unique(list(bindings.values())+ops+[pr,record,req["shared_route_ref"],dict(path=p.GUARD,sha256=p.GUARD_SHA),p.POLICY,p.REPAIR]+[ref(x["path"]) for x in p.MODULE_PINS.values()])
    require(len(consumers)<=64,"Original64 direct metadata limit")
    expiry=datetime.fromtimestamp(r["expires_unix"]+600,timezone.utc);job="GPU4-shared-downstream-controller-v1"
    reserve=dict(key="H041/"+job,output=str(ROOT/output),auxiliary_scopes=[],reserved_bytes=rb,consumer_bindings=consumers)
    authority=guard.operation_draft_v1("reserve",reserve,expected_before=guard._pins(view),bindings=bindings);authority.update(active=True,expires_at_utc=expiry.isoformat())
    receipt=guard.apply_reserve_v1(save(packet,"reserve_authority.json",authority),expected_source_sha256=c.CORE,expected_launcher_sha256=c.BASE)
    save(packet,"reserve_receipt.json",receipt)
    storage=dict(kind="project_budget_v9_storage_record",active=True,consumer_uses_v9_guard=True,accounting_mode=guard.MODE,
        job_id=job,output_directory=output,reserved_new_bytes=rb,reservation=receipt["value"],initial_ledger_pins=receipt["initial_ledger_pins"],
        expires_at_utc=expiry.isoformat(),completed_overlay_policy_ref=p.POLICY,
        budget_components=dict(implementation=ref(guard.budget.SOURCE_REL),launcher=ref(guard.budget.LAUNCHER_REL),consumer_adapter=dict(path=p.GUARD,sha256=p.GUARD_SHA)))
    sr=save(packet,"storage.json",storage);sources={x["path"]:x for x in ops+[ref(x["path"]) for x in p.MODULE_PINS.values()]}
    cap=dict(plan,schema="GPU45_shared_logical_pool_capability_v1",status="active",root_authorizer="root_agent",
        logical_job_sharing_authorized=True,external_job_sharing_authorized=True,legacy_exclusive_coexistence_allowed=False,
        maximum_distinct_project_GPUs=2,source_refs=sources,plan_ref=pr,controller_storage_ref=sr,controller_job_id=job,
        expires_unix=r["expires_unix"],drain_expires_unix=r["expires_unix"]+600,
        owned_drain_after_expiry_authorized=True,owned_termination_escalation_authorized=True)
    capref=save(packet,"pool_capability.root_active.json",cap);p.load_cap(capref)
    result=dict(capability_ref=capref,controller_storage_ref=sr,launched=False);save(packet,"admitted.json",result);print(json.dumps(result),flush=True);return result

def seal_terminal(record):
    request=read(record)
    require(request.get("schema")=="GPU45_shared_terminal_seal_request_v1" and request.get("status")=="active"
        and request.get("root_authorizer")=="root_agent","Explicit root actual terminal sealing request")
    t=runtime().terminal()
    # Freeze one authenticated read. The live controller may keep updating other
    # jobs; an extra re-read would introduce a needless mutable-registry race.
    raw=path(request["actual_registry_ref"]["path"]).read_bytes()
    require(len(raw)<=33554432 and hashlib.sha256(raw).hexdigest()==request["actual_registry_ref"]["sha256"],"Exact bounded actual registry bytes")
    reg=json.loads(raw);cap=read(request["capability_ref"]);name=request["logical_job"]
    require(isinstance(name,str) and 1<=len(name)<=128 and all(c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-" for c in name),"Safe exact logical-job metadata namespace")
    rows=[j for j in reg["jobs"] if j.get("logical_job")==name];require(len(rows)==1,"Exact actual job")
    job=rows[0];ir=job["requested"]["input_ref"];spec=read(ir);done=read(request["completed_ref"]);tool=read(request["client_tool_terminal_ref"])
    directory=ROOT/HERE/("terminal_"+name);require(not directory.exists(),"Fresh immutable terminal namespace")
    snap=directory/"registry.snapshot.json"
    snapshot_ref=dict(path=str(snap.relative_to(ROOT)),sha256=hashlib.sha256(raw).hexdigest())
    pool_source=request["pool_source_ref"]
    cert=dict(schema=t.CERT_SCHEMA,status="completed_shared_job_wait0_owned_drain",root_authorizer="root_agent",
        actual_execution=True,exclusive_wait_relabelled=False,scientific_marker_unchanged=True,
        capability_ref=request["capability_ref"],registry_snapshot_ref=snapshot_ref,
        client_tool_terminal_ref=request["client_tool_terminal_ref"],input_ref=ir,completed_ref=request["completed_ref"],
        pool_source_ref=pool_source,terminal_validator_ref=ref(TERMINAL),logical_job=name,phase=spec["phase"],output_directory=spec["output_directory"])
    t.validate_records(cert,reg,cap,spec,done,tool)
    directory.mkdir();snap.write_bytes(raw)
    cr=save(directory,"shared_terminal.json",cert);t.validate_certificate(cr)
    result=dict(shared_terminal_ref=cr,scientific_completion_ref=request["completed_ref"],exclusive_wait_relabelled=False)
    print(json.dumps(result),flush=True);return result

def launch_cpu(record):
    request=read(record);require(request.get("schema")=="GPU45_downstream_CPU_launch_request_v1"
        and request.get("root_authorizer")=="root_agent" and request.get("status")=="active" and request.get("phase") in ("matrix","score"),
        "Explicit root CPU downstream launch")
    shared=request["shared_route_ref"];r,p=route(shared);c=runtime().c3_contract_v1();original=load(C3_DRIVER_REF,"_C3_original_root_driver_for_downstream_CPU_v1")
    text=function_source(C3_DRIVER_REF,"launch")
    text=replace_once(text,'packet,output=c.phase_paths(phase)','packet,output=downstream_phase_paths(phase)')
    before='else:env["CUDA_VISIBLE_DEVICES"]="";command+=[str(ROOT/module)]'
    after='else:env["CUDA_VISIBLE_DEVICES"]="";command+=[str(ROOT/DOWNSTREAM_BOOTSTRAP["path"]),"--execute","--renewal-certificate",DOWNSTREAM_RENEWAL["path"],"--renewal-sha256",DOWNSTREAM_RENEWAL["sha256"],"--renewal-source-sha256",DOWNSTREAM_RENEWAL_SOURCE["sha256"],"--module","research.reviews.GPU45_shared_downstream_lineage_source_20261016_v1.runtime_metadata_adapter_v1","--"]'
    text=replace_once(text,before,after)
    text=replace_once(text,'wait=dict(pid=proc.pid,returncode=rc,actual_direct_launcher_wait=True',
        'wait=dict(schema="GPU45_downstream_CPU_actual_direct_wait_v1",operational_root_entry_ref=DOWNSTREAM_ENTRY,operational_runtime_adapter_ref=DOWNSTREAM_RUNTIME,pid=proc.pid,returncode=rc,actual_direct_launcher_wait=True')
    ns=dict(original.__dict__);ns.update(c=c,downstream_phase_paths=phase_paths,DOWNSTREAM_BOOTSTRAP=p.RENEWAL_BOOTSTRAP_REF,
        DOWNSTREAM_RENEWAL=r["marker_repair_renewal_ref"],DOWNSTREAM_RENEWAL_SOURCE=p.RENEWAL_SOURCE_REF,
        DOWNSTREAM_ENTRY=ref(SOURCE),DOWNSTREAM_RUNTIME=ref(RUNTIME))
    exec(compile(text,"<original_C3_CPU_supervisor_operational_entry_only>","exec"),ns)
    return ns["launch"](request["phase"])


def main(argv=None):
    pa=argparse.ArgumentParser(description=__doc__);pa.add_argument("action",nargs="?",default="describe",choices=("describe","seal-terminal","bind-h050","admit-h050","admit-c3","assemble","launch-cpu"));pa.add_argument("--execute",action="store_true");pa.add_argument("--record");pa.add_argument("--sha256");a=pa.parse_args(argv)
    if a.action=="describe":print(json.dumps(dict(status="source_only",actual_execution=False,TRAIN_sources_unchanged=True,phases=["H050_evaluate","C3_original5VAL"])));return 0
    require(a.execute and a.record and a.sha256,"Explicit root-only execution and pinned record")
    record=dict(path=a.record,sha256=a.sha256);result={"seal-terminal":seal_terminal,"launch-cpu":launch_cpu,"bind-h050":bind_h050,"admit-h050":admit_h050,"admit-c3":admit_c3,"assemble":assemble}[a.action](record)
    if a.action=="launch-cpu":return result
    if result is not None:print(json.dumps(result),flush=True)
    return 0
if __name__=="__main__":raise SystemExit(main())
