# Shared downstream source packet: H050 EVALUATE + original C3 VAL

Source only. Nothing here admitted, launched, probed, signalled, installed, credited,
or changed any active TRAIN/canonical/guard file. All proposals in templates/
remain inactive. Root performs every actual operation after source review.

## Exact scientific boundary

H050 uses the EXACT admitted TRAIN config ref. The original producer file,
load_checkpoints (all24 actual payload SHA/provenance/FP32 checks), run_evaluate
(all192 RAM prediction products sealed and verified BEFORE VAL truth), model,
training/protocol, truth gates and original context function body stay unchanged.
Only private operational receipt/path validation adapts to genuine shared TRAIN.
The original main function body is compiled unchanged with one private context
loader; the original admitted metadata-fix context bytes stay unchanged.

Original scientific completed.json is never relabelled or rewritten. A new
GPU45_shared_logical_job_terminal_certificate_v1 points to the original marker,
actual capability, frozen registry snapshot, exact input/storage/source identity,
and root's genuinely consumed wait-client terminal0 + exact returned terminal job.
Actual direct leader wait0, adopted wait0, owned drain and no cancellation/resource
abort/ambiguity are mandatory. Original exclusive launch/wait schemas are never
fabricated. All actual TRAIN controller override/checker sources are authenticated
transitively through the capability. Old failed/partial allocations stay charged.

H050 EVAL retains original direct source/guard bindings. One directly bound lineage
JSON authenticates exact TRAIN completion/capability/terminal/input/config/runtime
and exactly three immutable original read-only JSON records: count manifest,
cut-preparation source manifest, H045 metrics source config. Scientific readers
still authenticate every original ref. The warm .pt still uses the unchanged
TRAIN scientific-input proxy; payload bytes are never treated as source metadata.
Using the actual admitted TRAIN metadata, the complete prospective EVAL direct
list is64, including existing8 budget bindings and all actual new runtime sources.

C3 privately replaces validate_terminal dispatch for labelled shared terminals or
new-labelled actual CPU downstream direct waits. Original validate_bindings,
closed observation-plan gate, model/hooks/trainer, six predictions per original VAL,
all30 matrix seals BEFORE separate truth capability, score selection and TEST
deferral remain unchanged. C3 main/execute worker bodies stay original bytes.

## Fresh controller source

Root installs pool.staged.py byte-for-byte at
src/arggnn/gpu45_shared_downstream_pool_v1.py
and launcher.staged.py at
scripts/launch_reserved_gpu45_shared_downstream_pool_v1.py.
These are NEW separate paths. Do not overwrite old TRAIN pool/base/launcher.

The fresh pool declares exactly one H050 EVALUATE and all5 original C3 predict_val
jobs, maximum2 active with at most1 C3 prediction active. Original actual NVML
headroom/reservation checks and28/40GiB Torch +2GiB margins remain unchanged.
Observed external usage may force sequential execution. No simultaneous fit,
measurement or timing is promised. Per-worker owned RSS64/128GiB and24h deadlines,
original owned-process/PIDFD/subreaper/actual-wait/drain semantics remain unchanged.
Actual dispatch metadata explicitly declares the private operational runtime
adapter and original scientific canonical source separately.

Reviewed startup lock order: prospective64KiB check happens BEFORE scheduler flock;
the old nested check becomes a <=64KiB assertion. Controller metadata uses one full
original guard at startup, reviewed transaction-local memo2, then original mutex,
expiry/source/policy/direct bytes/journal authority/prefix/open-scope checks and
original conservative owned-scope measurement per write within32–64MiB charged cap.
No credit/rebase/cross-scope borrowing. Later receipts explicitly say they did NOT
recompute the unrelated global projection; all global mutations and scientific
worker guards still use original checks. No cross-transaction read cache.

The fresh server copies original base.run unchanged except resetting the30s reply
write deadline AFTER dispatch returns. The fresh client waits at most300s for the
actual bounded reply. Original request/reply byte limits stay intact. This avoids
one source-supported dropped-response path after slow dispatch; it is not a
recovered diagnosis of the current TRAIN clients' empty failures. Any failure
still requires inspecting the accepted-job registry before considering a retry.

All worker cache/TMP paths are deterministic beneath separately reserved own
auxiliary scopes; original C3 scientific TMP is also separately reserved. One
original full prospective worker boundary check precedes directory creation.

## Root sequence

Use PYTHONPATH=.:src:scripts and .runtime/env/bin/python -B.
Driver = this folder/root_downstream_v1.py. Every mutation requires --execute.
All actions take --record PATH --sha256 SHA. No action occurs by default.

1. Do not resubmit current TRAIN jobs. Root reported C3 running, H050 queued under
   actual83003MiB projection vs81920MiB, external5156MiB. Initial run clients55081
   and96608 returned1 empty; those results remain failures of unconfirmed cause.
   root_status_context_v1.json records message provenance without new probes.
   Current TRAIN capability is override folder/admitted_controller_v1/
   pool_capability.root_active.json SHA
   cc0f9ad0548a7cc81b7b90f0a75ad8db0c3182c6018ec2c09b370780396e93f0.

2. After EACH TRAIN job actually succeeds and scientific completed.json exists,
   consume a fresh original wait client terminal0 (command=wait is supported).
   Store actual root tool observation using the inactive client template: exact
   session/chunk, actual exit0 and the entire actual returned terminal_job JSON.
   Store actual registry ref, original scientific completion ref and capability
   in a fresh active seal request. Driver seal-terminal freezes ONE authenticated
   registry read, validates it, and returns shared_terminal_ref. It never relies
   on the mutable live registry hash as permanent lineage. No fake wait0 if a
   client times out or exits nonzero. Root may seal each completed job while the
   other continues; one immutable snapshot per certificate is preserved.

3. After BOTH TRAIN jobs really terminal/drained, root shuts down only that owned
   TRAIN controller and consumes its actual start-tool terminal0. Freeze its
   closed registry and create TRAIN_pool_shutdown record from template. It must
   identify the actual controller/capability, lifecycle=closed, no ambiguity or
   safety error, both jobs succeeded/actual waits/drains. This is prerequisite to
   new pool activation; exclusive same physical lease is also acquired afresh.

4. Root reviews and installs the exact NEW pool/launcher paths above. Activate a
   NEW shared_route from template with actual shutdown proof, UUID, original
   migration/renewal refs, future expiry <=24h, and expiry+600s before renewal end.
   Preserve every admitted TRAIN file/config/source byte.

5. H050: activate H050 binding request with original scientific TRAIN completion,
   train_launch_ref=ACTUAL shared pool capability (honest capability, not fake
   exclusive launch), train_actual_wait_ref=NEW shared terminal certificate,
   route ref and explicit original count-plan-compatible whole-scope reserve.
   Derive/validate reserve using original count_plan_v1/validate_plan_caps_v1;
   no measured-fit claim. Driver bind-h050 returns new admission request ref while
   reusing EXACT original config. Driver admit-h050 on returned request returns
   genuine admitted_ref in a fresh EVALUATE packet/output. Its scientific source
   closure remains exactly TRAIN's; additional actual operational source refs
   are explicit, direct-bound and checked before the original producer main.

6. C3: every predict_val_000..004 request MUST bind original same-parent native
   preparation/wait/observation plan and actual validate_closed_plan_stage
   evidence (real original completion, wait0, root consumption/revocation and
   close receipt). This gate was NOT relaxed. Existing reviewed original plan
   routes remain supported; create/close missing observation-only plans through
   their original root route first. No model or truth dependency is added.
   TRAIN binding completion_ref=original C3 completed.json;
   actual_wait_ref=NEW shared TRAIN certificate.
   Activate separate caps/requests/wrappers from templates. Proposed per-parent
   prediction caps are4GiB phase writes +2GiB TMP inside8GiB reservation,128GiB
   owned RSS/40GiB CUDA/24h. They are explicit fail-stop planning caps, not a fit
   measurement; the TRAIN1GiB write cap is not reused for six dense products.
   Driver admit-c3 on each active wrapper returns genuine admitted_ref.

7. Activate fresh controller request with ALL6 actual worker admitted refs, route
   and32MiB reservation. Driver assemble validates exact stage set before reserve,
   returns genuine capability. Use NEW installed launcher start/status/run/wait
   with returned ref. Job names:
   H050-shared-downstream-EVALUATE-v1
   C3-shared-downstream-predict_val_000-v1 through _004-v1.
   Admit/run at most original concurrency, actual headroom governs scheduling.
   Preserve all actual client failures and never retry accepted jobs blindly.

8. C3 after each VAL prediction: consume actual wait0 and seal honest shared
   certificate as in step2 (new pool source ref). Original envelopes and six
   scientific prediction seals remain unchanged. Matrix request binds all5
   original envelopes/new terminals + original TRAIN lineage. Driver admit-c3 on
   an active matrix wrapper creates CPU packet/output (separate512MiB proposed
   cap, no prefetch/cache). Launch CPU action must start in a dedicated setsid
   supervisor session:
   setsid .runtime/env/bin/python -B DRIVER launch-cpu --execute --record
   ACTIVE_CPU_LAUNCH_REQUEST --sha256 SHA.
   It uses the original C3 owned supervisor body, changing only actual operational
   entry/renewal bootstrap, packet path and explicit new CPU wait schema. It
   keeps genuine Popen wait, exact owned ancestry/groups/drain and original
   guards. Scientific completion retains original root-driver provenance and
   actual operational entry is separately declared.

9. Only after actual matrix completion/directwait0/drain, activate separate score
   request with matrix lineage and original5VAL truth handles. TEST remains
   deferred. Same admit-c3 + launch-cpu path. Original worker/hook seals30cells
   before truth resolver becomes reachable; all H050192 products seal before its
   own VAL truth gate. No score, selection or completion is asserted here.

84 pure fixtures pass without actual guards/probes/jobs/models/scientific payload
reads. They check terminal failures, retained H050 scientific lineage predicates,
exact source adaptations, original owned controller methods and memory logic,
lock ordering, response deadline-only loop delta, scope overflow/expiry/revocation,
owned cache paths and direct64 closure using actual admitted TRAIN metadata.
This is source qualification only; no reserve, resource fit or runtime success
has been claimed.
