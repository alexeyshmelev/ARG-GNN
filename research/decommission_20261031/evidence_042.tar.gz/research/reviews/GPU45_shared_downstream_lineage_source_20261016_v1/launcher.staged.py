#!/usr/bin/env python3
"""Root-installed additive exact shared pool entry. Default inert."""
from arggnn.gpu45_shared_downstream_pool_v1 import main
if __name__=="__main__":raise SystemExit(main())
