# Exact clade-flag execution source: prospective fixed control

Worker: src/arggnn/train_anonymous_clade_flag_control_v1.py. This is a complete source-only TRAIN driver with a separately admitted future VAL phase. It has not loaded a real bank/checkpoint, trained, evaluated, built a CUDA context, obtained admission, changed a journal or used Git. Frozen H040 mechanism/worker/context/guard files remain unchanged.

The human-authorized control was requested before H040 VAL and is not conditional on a favorable H040 result. prospective_protocol.json timestamps the fixed design without inspecting project model outcomes. Root must assign the actual hypothesis_id, register it, bind a new root context and admit/schedule it. The proposed config intentionally rejects its ROOT_ASSIGN_BEFORE_ADMISSION placeholder for execution.

## Fixed scientific protocol

The distinct control_id is H040_exact_clade_flag_control_v1 and arm is exact_clade_flags. Output/checkpoint/input/config schemas are specific to this control. It never uses tensor/event_mlp identity.

TRAIN uses the original selected H038 aligned/seed101 pass30 checkpoint, the same original complete Relate observation banks, all 952 haplotypes, 686 query columns and shared 32 TRAIN parents. It uses FP32/PyG, seed101 CPU initialization, fresh AdamW (lr=.001, decay=.0001, betas=.9/.999, eps=1e-8), clip norm1 and exactly 30 full passes: 960 complete-parent updates. Parent order is random.Random(101+pass), exactly as H040. Checkpoints occur at passes5/10/15/20/25/30. There is no early stopping, VAL-dependent optimization or shortening of the schedule.

The model remains exactly29,764 body weights +1,024 local flag-adapter weights =30,788. Its selected warm-start reference and four initial projection maps use the same schema/order as H040. The previous handmade model fixture verified matching initial state keys/values with synthetic backbone weights. This driver did not reopen the real checkpoint or rerun that fixture.

Original h038.native_hold_train_mass_v1 and biological_gst_control_v1.exact_span_loss supply unchanged external native-hold TRAIN mass and loss. Targets stay outside model inputs. All32 observed banks, stable-key joins and exact flag recipes are constructed and sealed before PhaseReader opens the TRAIN target gate.

Each node receives two uint8 observed proper-clade flags (gained_from_left, lost_to_right). Bitsets are ephemeral within two adjacent trees, collapsed through unary equivalences; no dense bitsets, flag arrays or correspondence matrices are written to disk. Rebuilding an evicted payload must exactly match its pre-target recipe/content hash. Cached payloads are content-checked before reuse.

## Bounded RAM and outputs

The proposed CPU bank cap is32GiB, TRAIN mass cap4GiB, flag cache512MiB, preparation planning cap8GiB, GPU observation/mass residency8GiB, one GPU flag payload128MiB and future RAM predictions8GiB. These are proposals; the root context supplies authoritative RSS, allocator, lease and storage guards.

Retained flag tensors use exactly2N bytes per parent. Preparation uses two int32 native child-link arrays (8N bytes), output flags (2N), and temporary Python tree masks/worklists/containers. flag_preparation_plan uses a deliberately conservative all-N planning allowance2058N+128H; it is explicitly not an RSS proof. Actual Python/allocator use remains guarded by root. No observed data was read to estimate production timings or sparsity.

The driver keeps only one transient GPU flag payload at a time. It uses the original FullParentResidencyV1 LRU for complete native banks/mass. Progress and pass/checkpoint receipts are compact. Proposed durable reservations are32MB for TRAIN and32MB for later evaluation; root can choose adequate scopes under the existing guard. Partial checkpoints are preserved on failure and no automatic replay is attempted.

## Frozen future validation

The separate evaluate context accepts one train_completion_ref for this arm only. It requires all six actual checkpoints with960-update provenance, original warm-start and matching scientific references. Before any VAL truth, it predicts and seals all6passes x8sharedVALparents =48 native-hold arrays in immutable CPU RAM, using original query/readout geometry and checkpoint/content hashes. Exact probability bytes are6*10976*sum(T_VAL). Dense probabilities are not written to disk.

Only after the complete48-cell seal barrier does the reader permit the eight VAL targets. The original FullPanelPrimaryValidationV1, h038.selection_key_v1 and unchanged metric config select equal-parent Present182 exact-span accuracy, lower NLL tie-break, then earlier pass. Full original cohort/calibration/boundary diagnostics run only for the selected checkpoint. There is no probability floor, posthoc renormalization, purity filter or outer access. VAL is reused development data; this control does not change that limitation.

## Root integration contract

Use a new, separately pinned root-owned context factory. The frozen H040 factory is not a drop-in handler for this schema and must not be edited. Its existing lease/title/current-adapter/writer workflow can be reused in a new module bound to this worker.

Context fields are root_authorizer=root_agent, admitted=true, phase=train|evaluate, arm=exact_clade_flags, cfg, config_ref, reader, output, guard, device, registry, entry_refs, observation_cache_ref, observation_source_refs and phase-only bindings. Evaluate additionally supplies singular train_completion_ref. entry_refs must contain the original32TRAIN+8VAL only. bindings must contain exactly the32TRAIN or8VAL IDs for that phase and the original same-parent truth paths. No outer binding is accepted.

The active root input schema is anonymous_clade_flag_root_execution_input_v1. It binds control_id, arm, hypothesis_id, phase, root_authorizer, status=active and root_context_module_ref. The root factory must verify the actual input, config, complete source closure, runtime/logical job, current guard/marker authority, storage scope and qualified leased device as before. A new hypothesis_id can be filled into the config/input without editing scientific source.

Keep base_fit_config from configs/census_tsinfer_fit_v1.json when configuring runtime; it contains the original gpu_runtime/nvtop_helper fields. Do not substitute the H038 top-level training config. proposed_config.json carries the same original observation-cache source references and original metric/warm-start contract, plus distinct flag caps/schema.

Default source description, with no model/data runtime:

    source scripts/project_env.sh
    .runtime/env/bin/python -B -m arggnn.train_anonymous_clade_flag_control_v1

Future root-launcher execution uses --execute --input <canonical-project-input> --expected-input-sha256 <digest>. It is rejected without a separately pinned active root capability. This task created no active input, factory, reservation or launcher.

## Source checks and interpretation

source_API_check.json confirms that the module imports and default description run, the fixed config validates after an in-memory source-check ID substitution, a pending hypothesis ID is rejected, unbound --execute is rejected, and scientific source hashes match. PyTorch was not even imported by these checks. No additional model fixture or training/evaluation was run.

The exact flags test complete observed topological change, not ancestral homology or branch-age changes. A separate source deduction also matters: tensor and eventMLP both send zero message whenever their old/new projected LCA states coincide, even with nonempty fully covered triplet incidence. Exact flags can preserve an explicit change indicator in that case, though the local adapter can still vanish for zero/nullspace states. This representation bottleneck differs from K4 missing the incidence itself. Heterogeneous SNP/age/reference features may separate states in practice, which requires independent empirical assessment.

This prospective control tests useful tree-change feature engineering against H040's learned endpoint interaction. Its implementation and any future outcome do not establish a new general ML expressivity result or publication priority.
