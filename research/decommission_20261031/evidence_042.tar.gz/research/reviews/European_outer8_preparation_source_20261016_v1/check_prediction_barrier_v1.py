"""Read-only fixed European outer8 prediction-before-truth readiness check."""
from pathlib import Path
import argparse, hashlib, json, os, stat
from research.reviews.European_outer8_preparation_source_20261016_v1.prepare_outer000_v1 import (
    ROOT, REGISTRY, METHODS, sources, ref, raw, read, freeze, need, local)
def declared_checkpoint(r,parent):
    need(isinstance(r,dict) and set(r)=={"path","sha256"} and isinstance(r["sha256"],str)
         and len(r["sha256"])==64 and all(c in "0123456789abcdef" for c in r["sha256"]),"Actual checkpoint identity declaration")
    p=local(r["path"])
    need(str(p.relative_to(ROOT)).startswith("experiments/results/European_outer8_predictions_")
         and parent in p.parts,"Corresponding admitted parent checkpoint namespace; weights remain unopened")
def opaque_prediction(r):
    p=local(r["path"])
    need(str(p.relative_to(ROOT)).startswith("experiments/results/European_outer8_predictions_"),"Admitted outer prediction namespace")
    fields=lambda x:(x.st_dev,x.st_ino,x.st_mode,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,"rb") as f:
        st=os.fstat(f.fileno())
        need(stat.S_ISREG(st.st_mode) and st.st_nlink==1 and 0<st.st_size<=2**30,"Regular prediction product")
        need(fields(p.lstat())==fields(st),"Opened exact no-follow prediction")
        h=hashlib.sha256()
        while True:
            block=f.read(8*2**20)
            if not block:break
            h.update(block)
        need(fields(os.fstat(f.fileno()))==fields(st) and fields(p.lstat())==fields(st)
             and h.hexdigest()==r["sha256"],"Opaque sealed probability bytes unchanged")
def check(bundle_ref):
    sources();bundle=read(bundle_ref);f=freeze(bundle["method_freeze_ref"]);inventory=read(ref(METHODS))
    parents=[r["parent_id"] for r in read(ref(REGISTRY))["outer_rows"]]
    methods=inventory["primary_method_ids"]
    need(bundle["schema"]=="European_outer8_all_prediction_seals_v1"
         and bundle["all_predictions_before_any_outer_truth"] is True
         and bundle["method_ids"]==methods and bundle["parent_ids"]==parents,"All fixed methods and eight parents")
    cells=bundle["cells"];need(len(cells)==len(parents)*len(methods),"Complete prediction matrix; failed/missing cells block")
    keys=set()
    for cell in cells:
        key=(cell["method_id"],cell["parent_id"])
        need(key not in keys and key[0] in methods and key[1] in parents,"One exact method-parent cell")
        keys.add(key);seal=read(cell["seal_ref"])
        need(seal["schema"]=="European_outer8_observed_only_prediction_seal_v1"
             and seal["method_id"]==key[0] and seal["parent_id"]==key[1]
             and seal["method_freeze_ref"]==bundle["method_freeze_ref"]
             and seal["outer_truth_opened"] is False and seal["full_686_queries"] is True
             and seal["class_order"]==["Ana","CHG","WHG","EHG"]
             and seal["prediction_coordinates_source"]=="original_observed_fixed100bp_centers"
             and seal["truth_breakpoints_used"] is False,"Strict observed-only full-query prediction identity")
        expected_path="data/expanded_full_panel_v1/"+key[1]+"/full_panel_observed_entry.json"
        need(seal["observation_entry_ref"]["path"]==expected_path,"Original corresponding observed entry")
        entry=read(seal["observation_entry_ref"])
        need(entry["schema"]=="mutation_routed_full_panel_observed_entry_v1"
             and entry["parent_id"]==key[1] and entry["split"]=="outer" and entry["observations_only"] is True
             and entry["truth_or_oracle_read"] is False and entry["samples"]==952 and entry["query_haplotypes"]==686 and entry["pure_reference_haplotypes"]==266
             and seal["source_roster_ref"]==entry["refs"]["source_roster"]
             and seal["scoring_coordinates_ref"]==entry["refs"]["scoring_coordinates"],"Original observed identity and coordinates")
        raw(seal["actual_inference_adapter_ref"]);review=read(seal["actual_adapter_review_ref"])
        need(review.get("verdict") in ("PASS","SOURCE_PASS") and review.get("source_ref")==seal["actual_inference_adapter_ref"],"Actual independently reviewed outer I/O adapter")
        expected=inventory["methods"][key[0]]
        need(seal["frozen_identity"]==expected,"No post-TEST model/checkpoint/protocol change")
        if expected["fit_regime"]=="within_parent_observed_only":
            need(set(seal["actual_checkpoint_refs"])=={"mlm","contrastive"} and seal["query_ancestry_supervision"] is False,
                 "Actual parent-specific native checkpoints fixed before truth")
            for checkpoint in seal["actual_checkpoint_refs"].values():declared_checkpoint(checkpoint,key[1])
            fit=read(seal["within_parent_fit_seal_ref"])
            need(fit["schema"]=="European_outer8_native_within_parent_fit_seal_v1"
                 and fit["parent_id"]==key[1] and fit["method_freeze_ref"]==bundle["method_freeze_ref"]
                 and fit["frozen_identity"]==expected and fit["checkpoint_refs"]==seal["actual_checkpoint_refs"]
                 and fit["source_roster_ref"]==seal["source_roster_ref"]
                 and fit["outer_truth_opened"] is False and fit["query_ancestry_supervision"] is False
                 and fit["actual_wait0_and_owned_drain"] is True,"Actual observed-only within-parent fit/checkpoint metadata")
        else:need(seal["actual_checkpoint_refs"]==dict(selected=expected["checkpoint_ref"]),"Exact preselected saved checkpoint")
        need(seal["complete_prediction_status"]=="sealed" and seal["actual_wait0_and_owned_drain"] is True,"Completed actual prediction, no failure masking")
        opaque_prediction(seal["predictions_ref"])
    need(keys=={(m,p) for m in methods for p in parents},"No missing test cell")
    return dict(schema="European_outer8_prediction_barrier_ready_v1",bundle_ref=bundle_ref,
        method_freeze_ref=bundle["method_freeze_ref"],parents=8,cells=len(cells),all_predictions_sealed=True,
        truth_payload_opened=False,scoring_still_requires_separate_ROOT_admission=True,
        H058_automatically_added=False,model_tuning_authorized=False)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--bundle-ref");a=p.parse_args()
    if a.bundle_ref:print(json.dumps(check(json.loads(a.bundle_ref)),sort_keys=True))
    else:print(json.dumps(dict(status="SOURCE_ONLY",truth_payload_opened=False)))
if __name__=="__main__":main()
