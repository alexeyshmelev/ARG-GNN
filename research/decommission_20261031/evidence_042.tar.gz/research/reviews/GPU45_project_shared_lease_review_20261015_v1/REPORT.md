# Independent GPU45 shared-pool source review

**Do not activate this staged pool unchanged.** The lease/title/external-process design is mostly reusable, but a persistent supervision exception can bypass owned cancellation and shutdown. Exact host visibility and fresh operational lineage also remain unqualified. The existing exclusive GPU4 route can run one full C3 or H049 job now while native GPU5 stays unchanged.

## Memory feasibility

| Case on nominal80GiB A100 | Torch caps | Per-job margins | Device headroom | Total | Result |
|---|---:|---:|---:|---:|---|
| C3+H049 both40GiB |80GiB|4GiB|4GiB|88GiB|Does not fit, even with no external allocation|
| C3 40GiB + H049 21GiB proposal |61GiB|4GiB|4GiB|69GiB|Arithmetic fit only; at most11GiB external/driver usage|

The21GiB H049 and40GiB C3 caps are existing inactive resource proposals, not measured peaks or active-admission evidence. Training scope and budgets must remain complete; a lower operational cap must fail if exceeded, never crop the science. No GPU probe was performed, so actual total/free memory, UUID and external usage remain unknown. Both40GiB caps cannot be described as sharing one80GiB A100.

Pure AST-isolated fixtures confirmed refusal at88GiB, admission arithmetic at69GiB, retention of pending CUDA peaks, external11GiB boundary accounting and refusal at12GiB. These are synthetic source fixtures, not device measurements.

## Focused findings

**P1 F1: A persistent supervision exception prevents owned cancellation and shutdown.** tick calls _process_scan before cancellation and _signal_own. On an exception it only stores safety_error and persists. cancel_declared/shutdown call tick, so repeated opacity/scan errors skip owned signalling indefinitely. Already-running workers can continue without successful supervision. A pure AST-isolated fixture with one active leader reproduces this without any real process or signal. Fix: On supervision failure block admissions and keep all reservations/leases. Independently attempt PIDFD signalling of only previously verified owned UID/start identities outside the failing scan path. Keep ambiguous identities unresolved, never signal external/unknown processes, and do not claim drain until fresh evidence is complete. Source lines: 297, 324, 326, 319, 320, 335.

**P1 F2: Opaque unrelated PID/FD handling remains an admission blocker on the known host.** The successor deliberately fails whenever the inherited process reader reports inaccessible unrelated metadata. That preserves fail-closed ownership but no reviewed live qualification establishes that this host can satisfy it. With such opacity, submission tick sets safety_error before launching any worker. Fix: Do not remove the fail-closed check by a blanket skip. Either qualify current ownership visibility under existing authority, or make a narrow reviewed ownership-reader repair using the existing exact descendant/PIDFD design. Keep external process records charged and never adopted from title alone. Source lines: 181, 183, 227, 240.

**P1 F3: The proposed thin command is not a drop-in replacement for current admissions.** Fresh controller and worker storage bindings, real active capability/UUID/caps and honest actual-launcher lineage are required. Existing C3 input says actual_launcher_ref is the old exclusive launcher; H049 input says storage_launcher_ref is that exclusive launcher and canonical dispatcher fixes its root-driver path. Blindly changing only argv makes the recorded actual launcher misleading. Fix: Add one optional shared operational launch branch to the existing canonical C3/H049 root-driver/contract interfaces when no active consumer pins those bytes, then create fresh admissions binding actual pool/launcher/base. Reuse frozen scientific workers and validators. If an active consumer pins a driver, preserve it; use a minimal separate operational successor only where necessary and explicitly extend the canonical dispatcher binding. Source lines: 66, 86.

**P2 F4: Cancellation has no bounded owned escalation before drain authority expires.** Per-job cancellation and inherited _signal_own send SIGTERM once per verified identity. A noncooperative owned child may remain indefinitely; _check then refuses writes after drain expiry. The implementation correctly retains lease/reservation and does not falsely report drain, but the planned lifecycle has no complete bounded recovery. Fix: Use a declared grace period and PIDFD-verified owned escalation under the same bounded drain authority, or explicitly retain a root manual-drain requirement. Never release logical memory or the physical lease because a timer elapsed. Source lines: 337, 350, 130, 133.

**note N1: Thin script requires the existing project Python import environment.** The thin script imports arggnn without setting sys.path; use the root drivers’ existing PYTHONPATH or an explicit PYTHONPATH=src module invocation. Do not assume an arbitrary direct shell can import the project package. Fix: Use the existing root environment/entry-point convention; no new framework is needed. Source lines: 3.

## What can be retained

The successor restricts physical selection to4/5, takes the same exclusive lock inode as legacy launchers, and reuses the original inherited-descriptor/UUID/held-lock validator. It applies the exact required process title before scientific imports, separates pool identity from original logical job ID, and keeps original Torch caps. External compute entries stay charged and are never signalled by title. PIDFD signalling revalidates UID/start identity. Reservations survive pending CUDA initialization and leader exit until owned descendants and historical owned compute PIDs drain. The abstract Unix socket avoids a filesystem special-node exception. Current980 accounting and original worker writers remain unchanged.

The pool cannot join the current nativeGPU5 lease: the same exclusive kernel lock prevents that. No source, input, lease metadata, PID or job of the active v12 native run should be modified. Inventory may report external usage, but admission and cancellation affect only future proven-owned pool jobs.

## Minimal executable integration route

1. Immediate: keep nativeGPU5 unchanged; use original exclusiveGPU4 launcher for one complete C3 or H049 job at a time. Original worker science/budgets and lease/title checks already apply.
2. For same-device concurrency: fix only focused staged lifecycle issues and qualify exact visibility; do not clone the scientific workers or lease validator.
3. Use original canonical operational driver hook for shared run/capability, pin all new operational sources in fresh controller/worker reservations and honest actual launcher references. Preserve active pinned drivers until their consumers finish.
4. Install only the exact reviewed additive pool and thin launcher after source fixes; inactive templates remain inert.
5. Admit separate bounded controller scope, bind actual GPU4 UUID/total, active40GiB C3 and21GiB H049 resource caps and original private TMP/cache scopes. No science truncation or fitted-results claim follows from these caps.
6. Start one pool only after it acquires the original GPU4 physical lock. Submit both original jobs; actual state must show both running with two valid titles/UUIDs and full reservations, not merely two queued registrations.
7. If actual external/driver usage or free memory does not fit the69GiB requirement, let second job remain blocked/queued and use serial route. If both caps are40GiB, refuse same-device concurrency.
8. Root retains real outer client wait, per-worker/descendant waits, owned drain evidence and original completed-scope storage close. Logical memory release does not credit disk.

Do not add another scheduler/framework or duplicate worker science. The smallest immediate execution route is the original exclusive launcher on freeGPU4. True concurrent sameGPU4 execution is conditional on the focused lifecycle fix, usable ownership visibility, honest new operational bindings and actual memory admission. The root performs all installation/activation/GPU checks and real waits.

## Scope and evidence

No source was changed or installed. No guard, admission, GPU/process/socket/PIDFD probe, job, signal or Git action was run. Only source/metadata hashes, syntax and pure in-memory method fixtures were used. [Full source pins, findings and fixture outputs](review.json).

Staged pool SHA256 b6d16ba2011987c0185ab313c69edbc260b0e91096e49adaf8e09370fc58de69. Frozen base SHA256 ae1e0494ab672cfa3017759460eb06a4b4789eaef54928496c3c80314adcc0e1.
