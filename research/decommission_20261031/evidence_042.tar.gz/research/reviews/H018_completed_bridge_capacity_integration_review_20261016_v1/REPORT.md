# H018 completed bridge capacity integration

The existing H018/observed_baseline_GT_preparation_v2 candidate is compatible with the unchanged close proof shape. This is a metadata/source assessment, not a current-open, writer-absence or credit claim.

It has the original4288B output/completed.json and stored50,000,000B reservation covering data/H018_R16_observed_bridge_v2 plus its exact worker_aux_v2. The genuine controller terminal binds worker2717006 to direct OS wait0, original completion, no control/postprocessing error and owned group drain. Supervisor2716834 and worker2717006 are the source-known writer roster. The source launches only that preparation worker and authorizes no native/model execution.

The exact refs, identity locators and all14 unchanged request fields appear in review.v1.json. The original stored v3 mode and expired execution authority do not require normalization because current _proof checks original reservation/output/cap directly. Root must still validate current-open state with the active guard. The original completed status branch requires no manufactured marker or rewritten timestamp.

actual_wait.json is the controller terminal and genuine worker wait evidence. No distinct persisted external SSH/tool terminal ref was found in the original packet. That missing outer observation is not converted into a claimed wait0. The unchanged proof contract requires the original directworkerwait, which exists.

Root must establish fresh complete known-writer absence and cooperative future capability revocation, then invoke unchanged current close logic. Its own proof repeats PID checks and performs the single actual output-plus-auxiliary stat inventory. Until that commits, retained bytes and credit remain unknown. All scientific payloads stayed unopened, and no guard import, recursive scan, observation, mutation, close, credit or Git operation was performed by this review.
