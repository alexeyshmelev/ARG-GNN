# H058 current mutex holder: source supplement

The15:33:08UTC kernel snapshot identifies H058 worker46648 as the current holder. It does not identify the holder during the earlier timeout or the current Python subcall.

H058v9 already installs the accepted consumer namespace memo before storage validation. This is not an omitted-install bug. Within each guard lock, Census and seven overlay state layers still reconstruct policy/prerequisite checks, copy reservations, validate journals and replay authorities/proofs/charge predicates. Raw-byte hits do not remove repeated JSON parsing. Boundary checks additionally perform original complete own-scope stat measurements.

A concrete namespace reuse gap is visible: eight exact _paths bodies recursively preserve ancestor scope rules but their ten direct fixed policy/selector canonical sites are outside the installed four-caller allowlist. Each canonical executes Path.resolve on NFS. The exact binding file records all eight source/code identities. Census/Relate64 have two sites each, the other six have one each.

The narrow future candidate admits only those eight authenticated code objects to the existing bounded transaction namespace cache. Preserve every guard boundary, predicate, journal/fingerprint/inventory exclusion, scope measurement, original final uncached namespace/source-identity validation, cache limit and per-operation clearing. Preserve all old history, charges, scopes and deadlines.

No live installation or H058 edit is proposed. A future component and consumer integration require exact independent review before the first guard operation. Throughput gain and the share of the current hold remain unmeasured. ROOT owns any bounded actual profiling. Repeating the same accounting attempt under unchanged contention is not recommended.

No guard/probe/runtime/accounting/GPU/Git action was performed. Earlier sealed diagnosis files remain unchanged.
