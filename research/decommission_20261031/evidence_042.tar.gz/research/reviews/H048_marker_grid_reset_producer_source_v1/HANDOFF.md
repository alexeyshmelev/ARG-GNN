# H048 scientific producer handoff

src/arggnn/train_marker_grid_reset_chain_v1.py is the executable scientific TRAIN/EVAL bridge around the unchanged marker-grid model. The complete current root IO handoff and actual root commands are in research/reviews/H048_GPU45_grid_root_source_v1/HANDOFF.md.

The producer preserves the registered31,933-parameter paired arms and original H042 pass30 warmstart,32TRAIN/8VAL,30passes/960complete-parentFP32updates per arm, six paired checkpoints and all96 sealed original-grid VAL products before external truth. H046's actual optimizer step, H044's exact span target/loss and original full-panel selection/scoring are reused without changing their frozen sources or monkeypatching live modules.

The complete model's first actual scheduled update qualifies and counts asstep1/960. It records finite gradients for every learned tensor, actual backbone weight change, independent AdamW step1 and full-parent GPU peaks/time. No separate qualification update is added. Real checkpoint authentication and full-model qualification remain root-pending.

source_mock_check_receipt_v1.json passed fake schedule/checkpoint/failure accounting and synthetic NumPy all96-seal immutability/same-parent/truth-gate checks. No Torch import, real model, optimizer update, checkpoint/truth/observation payload, GPU or guard execution occurred. The unchanged prototype's earlier tinyFP32 arithmetic checks remain the only actual numerical model evidence.

The generic config.inactive.json/root_input.inactive.json/context_contract_v1.json are source API templates. The coherent root IO packet supplies the operationally complete inactive config and current980/memo2/lease integration. Root superseded72GB with the existing50GB CUDA authority plus4GBfree;512GB processRSS/160GiB cache/100MBdisk are the chosen source caps.

Registered utility and paired8-parent sampleSD reporting are implemented exactly. A matched-arm win is not a global-top1 or independent-confirmation claim. The original prototype remains SHA341cbf32f10dfa3b0c941c9a70244758d3cc45d6362f33c6e74da5fd8d26acb4.
