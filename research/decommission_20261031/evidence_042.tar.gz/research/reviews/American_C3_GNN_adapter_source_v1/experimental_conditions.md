# American C3 experimental conditions

This protocol supersedes the earlier inactive 100 kb discovery-training proposal. The 100 kb parents are qualification data. Frozen adapter modules and the author baseline remain unchanged. No condition below has been trained or capacity-qualified by this document.

## Discovery training and held-out evaluation

Use independent 1–2 Mb TRAIN parents with the same 1600 haplotypes as evaluation: AFR/EUR/EAS 200 each and ADMIX 1000, explicitly haploid. Propose 20 independent 1 Mb parents, plus 20 independent 2 Mb parents if whole-parent memory permits. The characteristic recombination scale at 12 generations and r=1e-8 is approximately 8.3 Mb, so these parents still undersample long-range tract context. Multiple independent parents provide ancestry diversity; 30 Mb evaluation tests length transfer. Do not call 100 kb qualification adequate discovery training.

Train with complete-parent BPTT. The inactive proposal enlarges the single-training-block limits to 16384 trees, 16000000 active nodes and 200000 sites. These are rejection bounds, not a GPU-memory claim or reservation. Root must inspect actual observed counts and qualify peak memory before admission. If a 2 Mb parent cannot fit, retain a separately named 1 Mb condition or revise resources/protocol before results. Never replace complete BPTT with detached history, tree pruning or hidden block resets.

Reserve disjoint 30 Mb VAL and TEST parents before sampling. Use VAL for registered model selection; seal TEST predictions before external query-truth scoring. The first actual full 30 Mb simulation is TRAIN and remains TRAIN. It may support TRAIN/resource work, but cannot become TEST by renaming its files or changing its split. Any use of 30 Mb TRAIN labels creates a separately registered training-length condition.

## What the primary comparison establishes

Our proposed condition learns from simulated query-ancestry labels on independent TRAIN parents, then transfers a frozen model to held-out inferred ARGs. Native ARGformer performs its unchanged per-ARG MLM and reference-supervised contrastive protocol using observed reference labels and unlabelled query paths. It can adapt to the observed held-out ARG without seeing its query ancestry truth. These information and training regimes differ.

The primary endpoint may compare complete pipelines on exactly the same held-out tsinfer/tsdate observation, reference roster, query identities and frozen focal records. Report per-parent macro-F1, class precision/recall and paired pipeline differences, with uncertainty resampling independent parents. The 10000 correlated focal paths are not 10000 independent replicates. Record training exposure, target-ARG adaptation and compute. A pipeline difference does not isolate architecture or establish native-paper equivalence.

Architecture claims require same-supervision controls: the same whole-tree backbone with a local head versus ordered genomic context, and aligned versus zeroed concordance summaries while retaining support-count/empty channels. Keep TRAIN targets, parent splits, observations, readouts, class masks and selection budget identical; report parameter counts and compute. These controls require separate implemented, pinned conditions before results support such claims.

## Optional matched observed-label transductive condition

A separate GNN condition could adapt per ARG using only its known reference labels, with no simulation-query supervision. Matching the available label source still does not match ARGformer's objective or optimization. It is feasibility-dependent and is not implemented by the frozen adapter.

Split reference individuals, keeping both haplotypes together, into fitting and validation groups, stratified by source class. Reference-validation labels must be absent from both inputs and fitting losses throughout selection. Within fitting references, form group-held-out loss folds. Before each forward pass, set every held-out individual's input reference class to unknown, then recompute donor allele frequencies, class/cohort call masks, smoothing denominators, leaf class indicators and every other class-dependent feature from the remaining labelled references. Exclude both haplotypes from every class-labelled donor pool. Zeroing a cached feature after encoding is insufficient.

Use explicit loss_target_columns and loss-row coordinates, separate from original query columns. For each fold, minimize cross-entropy of the masked reference predictions against their externally held labels. A masked reference retains its original reference role and never becomes an ADMIX query or a primary evaluation example. Its unlabelled genotype may remain in class-independent panel frequencies, tree topology and concordance features. Sample IDs, cohort names and held labels cannot supply input class information.

Select hyperparameters using the permanently withheld reference-validation groups under the same masking rule. After selection, a prespecified final refit may use group-held-out fitting folds over all known references; final query inference may restore their genuinely observed labels. Query ancestry truth remains external until predictions are sealed.

This objective needs a new explicit reference-loss interface and feature reconstruction. Current frozen training accepts complete short parents and query focal targets; it does not implement this transductive objective or guarantee full-30-Mb gradient memory. Any alternative context/training approximation must be a separately named condition. Keep the native author baseline unchanged and make no equivalence claim before implementation and qualification.
