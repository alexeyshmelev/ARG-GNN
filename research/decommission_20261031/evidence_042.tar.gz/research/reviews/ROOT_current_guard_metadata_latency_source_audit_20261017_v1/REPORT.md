# Current guard metadata latency source audit

The existing reviewed ROOT memo supplies exact fresh-state and reserve calls. It has no close API. A future ordinary-close acceleration requires a separately reviewed, narrow ROOT code-only close-specific successor; current jobs and existing files retain their original paths.

This audit read source and compact metadata only on anogena. No guard import/call, mutex/journal operation, process/runtime probe, profiling, payload read or latency measurement occurred. Parent-supplied H059 approximately ten-minute admission and later C3 completion are context only. Source repetition does not apportion elapsed time between replay, hashing, namespace I/O, scope measurement and lock wait; no speed or deadlock conclusion follows.

## Exact repeated work

Selected Relate64 b8b696a… _state_locked (331–397) calls frozen native7, then rebuilds its own policy/bindings, occupied scopes and entire journal. The chain continues native7 → native14v3 → Census fit2 → H020v3 → prospective980 → concurrent-completed-v3 → configured H039 capacity-v2 namespace → capacity-v1 → retired → success → terminal → frozen CPU → budget-v9 state → v4 current.

The seven upper overlays each rebuild inherited occupied scopes and replay their own event stream. Their _paths delegates through ancestor rules to CPU _paths and budget.successor_paths / v4 scope_spec (171–214). scope_spec canonicalizes output/AUX and authenticates every consumer binding. bound (80–88) invokes original file_bytes (51–63), which resolves, lstat/open/fstat/reads, SHA256-hashes and validates the named leaf. The same pinned code bindings therefore repeat across inherited reservation passes, replay and outer preflight. Protected policy/selector paths repeat canonicalization too.

Relate64 _bindings (213–221) authenticates manifest and selector, then consumer_bindings_v1; that helper hashes each supplied ref before deduplication. _policy, _manifest and _selected_record overlap on source/manifest/review/parent refs. Reserve adds an all-reservation _paths pass (428) after complete fresh state. Initial admission capture/reserve and C3 capture/close each independently replay state. These are source repetition sites, not measured dynamic counts.

Preserve exact journal bytes/hash chains, authority/prefix/policy/lineage joins, recorded proof/measurement certificates and every-prefix charge checks. Historical completed replay uses recorded PID observations, rather than measuring each historical scope anew. Frozen CPU explicitly calls budget-v9 state with verify_closed=False. Lower fingerprints retain original namespace/stat work. Replaying fresh state is not replaceable by cached capacity, reservations or prefixes.

## Existing callable and blockers

ROOT_mutation_transaction_memo_source_20261017_v1/root_mutation_memo_v1.py SHA256 2923df9f5a48e76da0b59e6394f31d0b8f901c214a76cc62d65969d010655d98 has independent component SOURCE_PASS 76ec107a…. Only read_state_v1 and reserve_v1 exist; _run rejects close/retirement.

Each owns the original mutex in a fresh single-thread ROOT -B -s optimize0 interpreter before consumer memo. Only explicit pinned .py/.sh code under src/scripts/research is cached, at most2048 entries/64MiB. Cloned bound/reference/scope_spec/successor_paths share transaction-local hits. Direct file_bytes, fingerprints, inventories and JSON remain original. Original uncached source/name validation precedes state return or first reserve append. Hits are disabled through original append/fsync/postread; no cache survives unlock.

Future separately sealed integration: authenticate the exact helper/review in an already-direct manifest M with source_sha256 mapping; construct RootMutationMemo(g,integration_manifest_ref=M,adapter_ref=A,cache_refs=C) after exact guard configuration. Replace initial held-lock state capture by memo.read_state_v1(expected_source_sha256=implementation_sha,expected_launcher_sha256=launcher_sha). Keep original role union/scope preflight and genuine authority construction. For reserve call memo.reserve_v1(authority_ref,expected_source_sha256=implementation_sha,expected_launcher_sha256=launcher_sha), with no outer mutex. The original actual-prefix race rejection still decides admission. Independently review the final integration.

H059 driver 876f026a… uses original mutex/state and apply_reserve; saved execution argv names that module. Its fed146aa… manifest has330 refs, no source_sha256 mapping and no ROOT memo pin. Existing constructor cannot consume it blindly. Reviewed H060 root_driver_v1.py:137–169 demonstrates new manifest/wrapper integration, but its AST transformer assumes guard(False)/implementation; H059 uses guard(selector_ref,False)/impl. Do not apply it unchanged or patch the current job.

C3 saved recipe 1122b2e8… names exact unchanged selected capture/close APIs. Parent confirms the actual invocation was inline Python, with no saved invocation source file; this audit invents none and does not infer status from receipt-file presence. Existing memo could reduce only a future initial capture after separate integration review; unchanged apply_close_completed_v1 still performs full fresh replay.

A close-specific successor must retain the exact original close critical body: fresh state/authority/prefix/open checks; exact metadata/direct wait0/proof joins; fresh targeted absence; one full original no-follow owned-scope measurement; postmeasurement absence; charge; original append/fsync/postread. All JSON, journals, authority, capacity/prefix/state, proof and measurement remain uncached. Disable code/name hits and revalidate them uncached before append, then freshly authenticate authority/expiry and its integration join.

Old reservations cannot gain a new direct manifest role. A safe future binding route is a new direct integration_manifest_ref in the genuine ROOT observation JSON: original _proof permits extra observation metadata, while its exact14-field request, original authority and event already bind that observation by SHA. A narrow successor may require that join without changing old reservations or original guards. This route is source-only until independent review.

Consumer namespace memo17a13773… explicitly permits only read_only_consumer and prohibits ROOT reserve/close. Its memo2 canonical exclusions concern direct fingerprint/journal-listing/inventory callers; memo2 raw file_bytes itself has no suffix allowlist. Do not interpret receipt wording as the ROOT code-only contract, or install it into a mutation interpreter.

Exact source hashes/function spans/call sites are sealed in source_evidence.v1.json. The AST/RAM result checks pure memo mode/allowlist predicates and close source ordering; it is not dynamic guard validation.
