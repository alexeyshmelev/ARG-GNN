"""CPU VAL/TEST route over the unchanged original ordinary monitor, inert import."""
from pathlib import Path
import argparse,ast,hashlib,json,os,sys,types
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1"
SOURCE=HERE+"/ordinary_evaluate_cpu_v1.py"
STATIC={'path': 'research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1/contract.source_only.v1.json', 'sha256': '64a1b35dd16d3bab37198651c6da7d44725712b2c78de52edeb90168af58def4'}
MONITOR={'path': 'research/reviews/H050_one_FP32_CPU_forward_qualification_source_20261016_v1/ordinary_root_cpu_v1.py', 'sha256': 'bd1ffa9b3a93a219958a62a3ffa1ef04e2aeacf1f997587b3268bdf7f5c74ae8'}
META={'path': 'research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1/fit_metadata_v1.py', 'sha256': 'b670ebeeb85af88c362adde7162a5d92f8188295638603f4f011cbc72b08b89b'}
_BASE=None
_METADATA=None
_REQUEST_REF=None

def need(ok,message):
    if not ok:raise ValueError(message)

def load(record,label):
    p=ROOT/record["path"]
    need(p.resolve()==p and p.is_file() and not p.is_symlink() and p.stat().st_size<=2**20
        and hashlib.sha256(p.read_bytes()).hexdigest()==record["sha256"],"Exact pinned small source")
    m=types.ModuleType(label);m.__file__=str(p);sys.modules[label]=m
    exec(compile(p.read_bytes(),str(p),"exec"),m.__dict__);return m

def contract():
    need(_REQUEST_REF is not None and Path.cwd().resolve()==ROOT and Path(__file__).resolve()==ROOT/SOURCE,"Exact explicit CPU evaluation")
    c=_BASE.read(STATIC);r=_BASE.read(_REQUEST_REF)
    need(c["schema"]=="TGB_H051_CPU_evaluation_static_contract_v1" and c["execution_authorized"] is False
        and c["original_ordinary_monitor_ref"]==MONITOR and c["metadata_ref"]==META,
        "Fixed inactive CPU evaluation source contract")
    need(r["schema"]=="TGB_H051_CPU_evaluation_root_request_v1" and r["root_authorizer"]=="root_agent"
        and r["status"]=="active" and r["execution_authorized"] is True and r["GPU_authorized"] is False
        and r["static_contract_ref"]==STATIC and r["actual_runtime_source_ref"]==_BASE.ref(__file__)
        and r["actual_evaluation_result_claimed"] is False and r["split"] in ("VAL","TEST"),"Actual separate root split request")
    split=r["split"];cap=_METADATA.read(r["heldout_capability_ref"])
    need(cap["split"]==split and cap["fit_terminal_certificate_ref"]==r["fit_terminal_certificate_ref"],"Exact root split/fit capability")
    rows=[*c["source_binding_basis_refs"],STATIC,r["fit_terminal_certificate_ref"],r["heldout_capability_ref"]]
    if split=="TEST":rows.append(cap["frozen_confirmation_decision_ref"])
    basis=_BASE.unique(rows)
    need(len(basis)+5<=64,"Complete exact direct binding union fits64 before admission metadata")
    return dict(c,source_binding_basis_refs=basis,root_request=r,
        output_directory=c["output_directories"][split],auxiliary_directory=c["auxiliary_directories"][split],
        job_id="TGB-H051-CPU-"+split+"-evaluation-v1",reservation_key="TGB-H051/CPU-"+split+"-evaluation-v1")

def generated_functions(original):
    tree=ast.parse(original)
    parts={n.name:ast.get_source_segment(original,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ("worker","execute")}
    worker=parts["worker"]
    replacements=[
        ('result=module.run_single_CPU_qualification_v1(resource_check=resource_check)',
         'result=module.run_evaluate_v1(c["root_request"],resource_check=resource_check,guard=m,storage=storage)'),
        ('fixture_passed=result["fixture_result"]["passed"]','completed_explicit_split=result["completed_explicit_split"]'),
        ('need(cfg==spec["fixed_config"] and cfg["output_cap_bytes"]==CAP and cfg["wrapper_ref"]==c["wrapper_ref"],"Exact fixture/caps/config")',
         'need(cfg==spec["fixed_config"] and cfg["output_cap_bytes"]==CAP and cfg["wrapper_ref"]==c["wrapper_ref"],"Exact fixture/caps/config")\n    need(cfg["root_evaluation_request_ref"]==CONTRACT_REF,"Exact active split request")')]
    for before,after in replacements:
        need(worker.count(before)==1,"One CPU evaluation callback/identity replacement");worker=worker.replace(before,after,1)
    execute=parts["execute"]
    changes=[
        ('c["minimal_handoff_ref"],',''),
        ('contract_ref=CONTRACT_REF)\n    config_ref=meta','contract_ref=CONTRACT_REF,root_evaluation_request_ref=CONTRACT_REF)\n    config_ref=meta'),
        ('need(result["fixture_result"]["passed"] is True and result["fixture_result"]["precision"]=="fp32"\n         and result["fixture_result"]["optimizer_steps"]==0\n         and result["fixture_result"]["all_four_arms"] is True\n         and result["fixture_result"]["no_truth_read"] is True\n         and result["fixture_result"]["no_optimization"] is True,"Genuine one FP32 fixture result")',
         'need(result["schema"]=="TGB_H051_CPU_explicit_split_returned_v1" and result["completed_explicit_split"] is True\n         and result["split"]==c["root_request"]["split"] and result["optimizer_updates"]==0\n         and result["original_scorer_and_target_CSV_reader_unchanged"] is True\n         and result["all255_predictions_sealed_before_target_source_selection"] is True\n         and result["TEST_used_for_selection"] is False,"Genuine original full-cohort explicit split evaluation")'),
        ('status="completed_single_FP32_CPU_fixture"','status="completed_explicit_TGB_CPU_split_pending_external_terminal"'),
        ('actual_fixture_passed=True','actual_split_evaluation_completed=True')]
    for before,after in changes:
        need(execute.count(before)==1,"One original monitor evaluation adaptation");execute=execute.replace(before,after,1)
    return worker.replace("H050_one","TGB_H051_CPU_eval"),execute.replace("H050_one","TGB_H051_CPU_eval")

def setup(request_ref):
    global _BASE,_METADATA,_REQUEST_REF
    need(_BASE is None,"One fresh ordinary CPU interpreter")
    _REQUEST_REF=request_ref;_METADATA=load(META,"_TGB_CPU_eval_exact_metadata")
    request=_METADATA.read(request_ref);need(request["split"] in ("VAL","TEST"),"Frozen explicit split")
    _BASE=load(MONITOR,"_TGB_CPU_eval_private_original_monitor")
    _BASE.__file__=str(ROOT/SOURCE);_BASE.CONTRACT_REF=request_ref;_BASE.HERE=ROOT/HERE
    _BASE.ADMIN=ROOT/HERE/("actual_"+request["split"]+"_admission_v1")
    _BASE.CAP=4*2**20;_BASE.RESULT_CAP=65536;_BASE.RSS=8*2**30;_BASE.WALL=7200;_BASE.contract=contract
    worker,execute=generated_functions((ROOT/MONITOR["path"]).read_text())
    exec(compile(worker+"\n\n"+execute,"<original_CPU_monitor_explicit_TGB_split_only>","exec"),_BASE.__dict__)
    return _BASE

def main(argv=None):
    os.chdir(ROOT);sys.path[:0]=[str(ROOT),str(ROOT/"src")]
    p=argparse.ArgumentParser(description=__doc__);mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--execute",action="store_true");mode.add_argument("--worker",action="store_true")
    p.add_argument("--request");p.add_argument("--expected-request-sha256")
    p.add_argument("--input");p.add_argument("--expected-sha256");p.add_argument("--monitor-parent-pid",type=int);p.add_argument("--monitor-read-fd",type=int)
    args=p.parse_args(argv)
    if args.worker:
        meta=load(META,"_TGB_CPU_eval_request_locator")
        spec=meta.read(dict(path=args.input,sha256=args.expected_sha256))
        return setup(spec["contract_ref"]).worker(args)
    need(args.request and args.expected_request_sha256,"Explicit exact root request")
    return setup(dict(path=args.request,sha256=args.expected_request_sha256)).execute()

if __name__=="__main__":
    try:raise SystemExit(main())
    except BaseException as exc:
        if isinstance(exc,SystemExit):raise
        print(json.dumps(dict(error=type(exc).__name__,message=str(exc)[:2048],evaluation_pass_not_asserted=True)),flush=True)
        raise SystemExit(1)
