"""CPU full-fit proof and deferred evaluation request metadata. Inert stdlib import."""
from pathlib import Path
from datetime import datetime
import hashlib,json,re,time
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1"
FIXED={"original_common": {"path": "research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1/common_v1.py", "sha256": "fa21a0dc6db6c85e736e0233701a9c2ad9ff9edaf554e637e45a58d535cde291"}, "original_fit_terminal": {"path": "research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1/fit_terminal_v1.py", "sha256": "02976177dce462dd8e05e3bc84f72777603a9deb9a379364862344d275f63c57"}, "original_heldout_reader": {"path": "research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1/heldout_targets_v1.py", "sha256": "90ffd59026388d917562d8be0e4c7424b7fa3a6722b980a6284db4dc08e77231"}, "original_monitor": {"path": "research/reviews/H050_one_FP32_CPU_forward_qualification_source_20261016_v1/ordinary_root_cpu_v1.py", "sha256": "bd1ffa9b3a93a219958a62a3ffa1ef04e2aeacf1f997587b3268bdf7f5c74ae8"}, "original_protocol": {"path": "research/reviews/TGB_trade_H051_training_source_20261016_v1/protocol.source_frozen.inactive.v1.json", "sha256": "a2253a9aec4d8405a14262d9dc69f9ee2bcff14ea36e0fbef466ba94424acb6e"}, "train_contract": {"path": "research/reviews/TGB_trade_H051_CPU_runtime_source_20261016_v1/contract.source_only.v1.json", "sha256": "dd4d95cb5528dffc2810fff9336a708027cfba5e0c77b973305142de4959eda6"}, "train_handoff": {"path": "research/reviews/TGB_trade_H051_CPU_runtime_source_20261016_v1/source_handoff.v1.json", "sha256": "cb5c5baa7e66ee5fc0498b7fe2a023249fa5a66f240b5a22e524bbd345aa6bde"}, "train_runtime": {"path": "research/reviews/TGB_trade_H051_CPU_runtime_source_20261016_v1/ordinary_root_cpu_v1.py", "sha256": "557b5cbf57a1d32826361964889e5d166600ec09b2c59fb4783fb0f6c89dd758"}}
ARMS=("tree_only","first_order","conditional_triple")

def need(ok,message):
    if not ok:raise ValueError(message)

def path(name):
    p=Path(name);p=p if p.is_absolute() else ROOT/p
    need(p!=ROOT and p.resolve()==p and ROOT in p.parents and not p.is_symlink(),"Canonical contained project path")
    return p

def ref(name):
    p=path(name);return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def checked(record,limit=2**20):
    need(isinstance(record,dict) and set(record) in ({"path","sha256"},{"path","sha256","bytes"}),"Exact pinned artifact")
    p=path(record["path"]);need(p.is_file() and p.stat().st_size<=limit,"Bounded source/metadata/artifact")
    raw=p.read_bytes()
    need(hashlib.sha256(raw).hexdigest()==record["sha256"] and ("bytes" not in record or len(raw)==record["bytes"]),"Actual original artifact SHA/size")
    return raw

def read(record):return json.loads(checked(record))

def same_ref(a,b):
    return path(a["path"])==path(b["path"]) and a["sha256"]==b["sha256"]

def at(record,expected):
    need(path(record["path"])==path(expected),"Exact original artifact pathname")
    return read(record)

def normalized_ref(record):
    checked(record,6*2**20)
    return ref(record["path"])

def actual_session(value):
    need(type(value) is int and value>0 or type(value) is str and re.fullmatch(r"[1-9][0-9]*",value) is not None,
        "Actual positive root tool session")
    return int(value)

def inspect_cpu_fit_v1(request,*,resource_check):
    """Root-only actual consumed fit evidence. No model/optimizer/label decode."""
    need(callable(resource_check),"Actual root CPU resource callback")
    resource_check("before_actual_CPU_fit_evidence")
    need(request.get("schema")=="TGB_H051_CPU_root_fit_certificate_request_v1"
        and request.get("root_authorizer")=="root_agent" and request.get("status")=="active"
        and request.get("all_future_fit_write_relaunch_capabilities_permanently_revoked") is True,
        "Separate actual root consumed fit and permanent future-write revocation")
    c=read(FIXED["train_contract"]);out=ROOT/c["output_directory"];aux=ROOT/c["auxiliary_directory"]
    inp=read(request["scientific_input_ref"])
    need(inp["schema"]=="TGB_H051_CPU_full_campaign_actual_input_v1" and inp["root_authorizer"]=="root_agent"
        and inp["source_ref"]==FIXED["train_runtime"] and inp["contract_ref"]==FIXED["train_contract"] and inp["execution_authorized"] is True
        and inp["GPU_authorized"] is False and inp["job_id"]==c["job_id"],
        "Exact original fully admitted CPU TRAIN input")
    completed=at(request["completed_ref"],out/"completed.json")
    result=at(completed["result_ref"],out/"result.json")
    wait=at(completed["actual_direct_wait_ref"],aux/"actual_wait_minimal.json")
    outer=at(completed["actual_outer_wait_ref"],aux/"outer_wait.json")
    launch=at(request["launch_ref"],aux/"actual_launch.json")
    need(completed["schema"]=="TGB_H051_CPU_full_campaign_root_completed_v1"
        and completed["input_ref"]==request["scientific_input_ref"]
        and completed["actual_full_campaign_completed"] is True
        and completed["root_tool_terminal_consumption_still_required"] is True
        and result["schema"]=="TGB_H051_CPU_full_campaign_returned_v1"
        and result["full_campaign_complete"] is True and result["total_models"]==3
        and result["total_optimizer_updates"]==300 and result["TRAIN_graph_forwards"]==6900
        and result["final_replay_graph_forwards"]==90 and result["VAL_metric_computed"] is False
        and result["TEST_metric_computed"] is False and result["scientific_file_count"]==13
        and result["scientific_protocol_ref"]==FIXED["original_protocol"],"Genuine entire frozen fit, no score/partial-run substitution")
    worker=launch["worker_identity"];monitor=launch["root_monitor_identity"]
    need(launch["input_ref"]==request["scientific_input_ref"] and launch["handshake_not_yet_released"] is True
        and launch["worker_pid"]==worker["pid"] and worker["pgid"]==worker["session"]==worker["pid"]
        and wait["actual_direct_wait"] is True and type(wait["returncode"]) is int and wait["returncode"]==0
        and wait["pid"]==wait["worker_pgid"]==worker["pid"] and wait["input_ref"]==request["scientific_input_ref"]
        and outer["actual_direct_wait"] is True and type(outer["returncode"]) is int and outer["returncode"]==0
        and outer["error"] is None and outer["worker_pid"]==worker["pid"]
        and outer["input_ref"]==request["scientific_input_ref"] and outer["owned_groups_ESRCH"] is True
        and outer["owned_process_identities"].get(str(worker["pid"]))==worker["start_ticks"]
        and (outer["root_monitor_identity"]["pid"],outer["root_monitor_identity"]["start_ticks"])==(monitor["pid"],monitor["start_ticks"]),
        "Original seeded actual owned worker wait0 and complete drain, same monitor identity")
    tool=read(request["actual_root_tool_terminal_ref"])
    need(tool.get("schema")=="TGB_H051_CPU_actual_root_tool_terminal_v1" and tool.get("root_authorizer")=="root_agent"
        and tool.get("actual_terminal_consumed") is True and type(tool.get("actual_exit_code")) is int and tool["actual_exit_code"]==0
        and actual_session(tool.get("exec_session_id"))>0 and type(tool.get("terminal_chunk_id")) is str and bool(tool["terminal_chunk_id"])
        and tool.get("actual_root_exec_or_write_stdin_terminal") is True
        and tool.get("scientific_input_ref")==request["scientific_input_ref"] and tool.get("completed_ref")==request["completed_ref"]
        and tool.get("actual_outer_wait_ref")==completed["actual_outer_wait_ref"]
        and tool.get("root_monitor_identity")==outer["root_monitor_identity"],
        "Genuinely consumed external full-fit outer0, never infer from worker or launch acknowledgments")
    fit=at(result["fit_receipt_ref"],out/"fit_completed.json")
    seal=at(result["prediction_seal_ref"],out/"prediction_seal.json")
    protocol=read(FIXED["original_protocol"]);executed=at(fit["executed_protocol_ref"],out/"protocol.executed.json")
    need(executed==protocol and fit["primary_full_budget_complete"] is True and fit["total_models"]==3
        and fit["total_optimizer_updates"]==300 and fit["TRAIN_graph_forwards"]==6900
        and fit["final_replay_graph_forwards"]==90 and fit["VAL_or_TEST_metric_computed"] is False
        and fit["prediction_seal_ref"]==result["prediction_seal_ref"],"Original complete scientific receipt/protocol")
    need(seal["schema"]=="TGB_trade_H051_primary_all_country_predictions_sealed_v1"
        and seal["shape"]==[1,3,7,255,255] and seal["dtype"]=="torch.float32"
        and seal["axes"]==["seed","arm","forecast_year","source_country","destination"]
        and seal["seeds"]==[17] and seal["arms"]==list(ARMS) and seal["forecast_years"]==list(range(2010,2017))
        and seal["all_255_source_predictions"] is True and seal["official_query_source_selection_performed"] is False
        and seal["heldout_target_loader_invoked_by_trainer"] is False and seal["chosen_final_epoch"]==100
        and seal["executed_protocol_ref"]==fit["executed_protocol_ref"],"Exact all7year/all3arm/all255 prediction seal before any target source selection")
    checked(seal["prediction_ref"],5462100+8192)
    initial=at(request["initial_metadata_ref"],out/"seed17.common_initial.json")
    checked(initial["state_ref"],640*2**10)
    need(path(initial["state_ref"]["path"])==out/"seed17.common_initial.pt" and initial["seed"]==17,"Original common initialization artifact")
    states=[initial["state_ref"]]
    need(len(seal["checkpoint_refs"])==3,"All3 unchanged final checkpoint metadata refs")
    for arm,record in zip(ARMS,seal["checkpoint_refs"]):
        resource_check("before_actual_original_final_state_hash")
        row=at(record,out/("seed17.%s.training.json"%arm))
        need(row["arm"]==arm and row["seed"]==17 and row["final_epoch"]==100 and row["optimizer_updates"]==100
            and same_ref(row["common_initial_ref"],request["initial_metadata_ref"]) and row["no_VAL_TEST_selection"] is True
            and row["training_years"]==list(range(1987,2010)) and len(row["history"])==100
            and [r["epoch"] for r in row["history"]]==list(range(1,101))
            and [r["optimizer_update"] for r in row["history"]]==list(range(1,101)),
            "Exact original final100epoch states and history, no epoch hunt or partial budget")
        need(path(row["state_ref"]["path"])==out/("seed17.%s.final_epoch100.pt"%arm),"Exact final state path")
        checked(row["state_ref"],640*2**10);states.append(row["state_ref"])
    resource_check("after_actual_CPU_fit_evidence")
    return dict(certificate_request=request,certificate_request_refs=request,completed=completed,result=result,fit=fit,seal=seal,
        states=states,tool=tool,worker=worker,monitor=monitor)

def certificate_from_proof_v1(root_request_ref,request,proof):
    """Pure formatting of already authenticated actual fit evidence."""
    return dict(schema="TGB_H051_CPU_full_fit_terminal_certificate_v1",root_authorizer="root_agent",status="actual_full_fit_consumed",
        root_request_ref=root_request_ref,source_ref=ref(HERE+"/fit_metadata_v1.py"),TRAIN_runtime_ref=FIXED["train_runtime"],
        actual_full_fit_external_tool_terminal_consumed=True,actual_external_exit_code=0,
        scientific_input_ref=request["scientific_input_ref"],completed_ref=request["completed_ref"],
        actual_direct_wait_ref=proof["completed"]["actual_direct_wait_ref"],actual_outer_wait_ref=proof["completed"]["actual_outer_wait_ref"],
        actual_root_tool_terminal_ref=request["actual_root_tool_terminal_ref"],
        fit_completed_ref=proof["result"]["fit_receipt_ref"],prediction_seal_ref=proof["result"]["prediction_seal_ref"],
        original_protocol_ref=FIXED["original_protocol"],all_original_state_refs=proof["states"],
        same_original_complete_initialization_and_final_states_hashes_verified=True,full300_updates_and90_replays=True,
        all7year_all3arm_all255_prediction_seals=True,heldout_targets_not_released=True,
        all_future_fit_write_relaunch_capabilities_permanently_revoked=True)

def build_fit_certificate_v1(root_request_ref,*,resource_check):
    """Root persists returned metadata exclusively under an existing charge."""
    request=read(root_request_ref);proof=inspect_cpu_fit_v1(request,resource_check=resource_check)
    return certificate_from_proof_v1(root_request_ref,request,proof)

def validate_fit_certificate_v1(record,*,resource_check):
    certificate=read(record)
    need(certificate["schema"]=="TGB_H051_CPU_full_fit_terminal_certificate_v1"
        and certificate["status"]=="actual_full_fit_consumed" and certificate["root_authorizer"]=="root_agent"
        and certificate["source_ref"]==ref(HERE+"/fit_metadata_v1.py"),"Exact CPU fit certificate, never GPU binder substitution")
    request=read(certificate["root_request_ref"])
    proof=inspect_cpu_fit_v1(request,resource_check=resource_check)
    rebuilt=certificate_from_proof_v1(certificate["root_request_ref"],request,proof)
    need(certificate==rebuilt,"Revalidated genuine actual fit evidence and unchanged states/seals")
    proof.update(certificate=certificate,fit_terminal_certificate_ref=record)
    return proof

def make_eval_request_v1(static_contract_ref,fit_certificate_ref,heldout_capability_ref,*,root_execute_authorized):
    need(root_execute_authorized is True,"Explicit separate root evaluation authority")
    c=read(static_contract_ref);cap=read(heldout_capability_ref)
    need(c["execution_authorized"] is False and cap.get("split") in ("VAL","TEST"),"Source-only static contract and exact split capability")
    return dict(schema="TGB_H051_CPU_evaluation_root_request_v1",root_authorizer="root_agent",status="active",execution_authorized=True,
        GPU_authorized=False,static_contract_ref=static_contract_ref,fit_terminal_certificate_ref=fit_certificate_ref,
        heldout_capability_ref=heldout_capability_ref,split=cap["split"],
        actual_runtime_source_ref=ref(HERE+"/ordinary_evaluate_cpu_v1.py"),
        source_only_contract_is_not_execution_authority=True,actual_evaluation_result_claimed=False)
