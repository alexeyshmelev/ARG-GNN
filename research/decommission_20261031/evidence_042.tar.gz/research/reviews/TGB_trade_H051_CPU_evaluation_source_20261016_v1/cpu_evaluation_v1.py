"""Explicit split CPU evaluation. Import is inert and stdlib only."""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
import ast,csv,hashlib,importlib,importlib.util,io,json,os,sys,time
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1"
SOURCE=HERE+"/cpu_evaluation_v1.py"
FIXED={"metadata_source": {"path": "research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1/fit_metadata_v1.py", "sha256": "b670ebeeb85af88c362adde7162a5d92f8188295638603f4f011cbc72b08b89b"}, "original_common": {"path": "research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1/common_v1.py", "sha256": "fa21a0dc6db6c85e736e0233701a9c2ad9ff9edaf554e637e45a58d535cde291"}, "original_fit_terminal": {"path": "research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1/fit_terminal_v1.py", "sha256": "02976177dce462dd8e05e3bc84f72777603a9deb9a379364862344d275f63c57"}, "original_heldout_reader": {"path": "research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1/heldout_targets_v1.py", "sha256": "90ffd59026388d917562d8be0e4c7424b7fa3a6722b980a6284db4dc08e77231"}, "original_monitor": {"path": "research/reviews/H050_one_FP32_CPU_forward_qualification_source_20261016_v1/ordinary_root_cpu_v1.py", "sha256": "bd1ffa9b3a93a219958a62a3ffa1ef04e2aeacf1f997587b3268bdf7f5c74ae8"}, "original_protocol": {"path": "research/reviews/TGB_trade_H051_training_source_20261016_v1/protocol.source_frozen.inactive.v1.json", "sha256": "a2253a9aec4d8405a14262d9dc69f9ee2bcff14ea36e0fbef466ba94424acb6e"}, "train_contract": {"path": "research/reviews/TGB_trade_H051_CPU_runtime_source_20261016_v1/contract.source_only.v1.json", "sha256": "dd4d95cb5528dffc2810fff9336a708027cfba5e0c77b973305142de4959eda6"}, "train_handoff": {"path": "research/reviews/TGB_trade_H051_CPU_runtime_source_20261016_v1/source_handoff.v1.json", "sha256": "cb5c5baa7e66ee5fc0498b7fe2a023249fa5a66f240b5a22e524bbd345aa6bde"}, "train_runtime": {"path": "research/reviews/TGB_trade_H051_CPU_runtime_source_20261016_v1/ordinary_root_cpu_v1.py", "sha256": "557b5cbf57a1d32826361964889e5d166600ec09b2c59fb4783fb0f6c89dd758"}}
_RAN=False

def need(ok,message):
    if not ok:raise ValueError(message)

def exact_module(record,label):
    p=ROOT/record["path"]
    need(p.resolve()==p and p.is_file() and not p.is_symlink()
        and hashlib.sha256(p.read_bytes()).hexdigest()==record["sha256"],"Exact pinned source")
    spec=importlib.util.spec_from_file_location(label,p);m=importlib.util.module_from_spec(spec)
    sys.modules[label]=m;spec.loader.exec_module(m);return m

def original_definition(record,name,namespace):
    p=ROOT/record["path"]
    need(p.resolve()==p and hashlib.sha256(p.read_bytes()).hexdigest()==record["sha256"],"Exact original definition source")
    source=p.read_text();nodes=[n for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name]
    need(len(nodes)==1,"One exact original definition")
    exec(compile(ast.Module(body=nodes,type_ignores=[]),record["path"],"exec"),namespace)
    return namespace[name]

def run_evaluate_v1(request,*,resource_check,guard,storage):
    global _RAN
    need(not _RAN and callable(resource_check),"One root explicit split invocation")
    _RAN=True
    need(Path.cwd().resolve()==ROOT and os.environ.get("CUDA_VISIBLE_DEVICES")==""
        and storage["reserved_new_bytes"]==4*2**20,"Exact CPU-only4MiB evaluation scope")
    meta=exact_module(FIXED["metadata_source"],"_TGB_CPU_exact_fit_metadata")
    need(request["schema"]=="TGB_H051_CPU_evaluation_root_request_v1" and request["status"]=="active"
        and request["root_authorizer"]=="root_agent" and request["execution_authorized"] is True
        and request["GPU_authorized"] is False and request["split"] in ("VAL","TEST"),
        "Separate active actual root evaluation request")
    resource_check("before_revalidating_consumed_full_fit")
    original_common=exact_module(FIXED["original_common"],"_TGB_CPU_private_original_common")
    # The unchanged common source is used only for pinned source/artifact readers.
    # Its GPU runtime/lease/checker APIs are never invoked.
    original_bundle_loader=original_definition(FIXED["original_fit_terminal"],"load_prediction_bundle_v1",
        dict(c=original_common,io=io,hashlib=hashlib))
    terminal=SimpleNamespace(validate_fit_terminal_v1=lambda record:meta.validate_fit_certificate_v1(record,resource_check=resource_check),
        load_prediction_bundle_v1=original_bundle_loader)
    namespace=dict(c=original_common,terminal=terminal,SOURCE=SOURCE,datetime=datetime,csv=csv,io=io,time=time)
    original_definition(FIXED["original_heldout_reader"],"validate_split_capability_v1",namespace)
    Targets=original_definition(FIXED["original_heldout_reader"],"HeldoutTargetsV1",namespace)
    # Original class first verifies complete all255 sealed predictions, and only
    # then constructs the archive. Its original CSV year filter remains exact.
    targets=Targets(request["heldout_capability_ref"],request["split"],
        request["fit_terminal_certificate_ref"],resource_check)
    evaluator=importlib.import_module("research.reviews.TGB_trade_H051_training_source_20261016_v1.evaluation_v1")
    original_writer=importlib.import_module("research.reviews.TGB_trade_H051_training_source_20261016_v1.artifact_writer_v1")
    protocol=meta.read(FIXED["original_protocol"])
    baseline_ref=protocol["source_refs"]["H052_results"];baselines=meta.read(baseline_ref)
    directory=ROOT/storage["output_directory"];expected="evaluation_"+request["split"]+".json"
    class Writer(original_writer.DirectoryArtifactWriterV1):
        def _json(self,name,value):
            need(name==expected,"Only original requested split evaluation output")
            data=(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
            need(len(data)<=2**20,"Count-derived1MiB original evaluation artifact cap")
            resource_check("before_original_split_result_write")
            guard.budget_check_v9(storage,boundary=True,required_write_bytes=len(data)+65536)
            result=super()._json(name,value)
            guard.budget_check_v9(storage,boundary=True,required_write_bytes=0)
            return result
    writer=Writer(directory)
    result_ref=evaluator.evaluate_sealed_split_v1(targets.bundle,split=request["split"],
        load_target_year=targets.load_target_year_v1,baseline_results=baselines,
        baseline_result_ref=baseline_ref,writer=writer,runtime_check=resource_check,protocol=protocol)
    result=meta.read(result_ref)
    need(result["schema"]=="TGB_trade_H051_sealed_split_results_v1" and result["split"]==request["split"]
        and result["model_selection_performed"] is False and result["seed_count"]==1,
        "Original full3arm requested split metrics, no model selection")
    resource_check("after_original_split_evaluation")
    return dict(schema="TGB_H051_CPU_explicit_split_returned_v1",completed_explicit_split=True,split=request["split"],
        result_ref=result_ref,fit_terminal_certificate_ref=request["fit_terminal_certificate_ref"],
        heldout_capability_ref=request["heldout_capability_ref"],full_frozen_campaign_required=True,
        original_scorer_and_target_CSV_reader_unchanged=True,model_or_checkpoint_reloaded=False,optimizer_updates=0,
        all255_predictions_sealed_before_target_source_selection=True,TEST_used_for_selection=False,
        actual_external_evaluation_tool_terminal_consumed=False)
