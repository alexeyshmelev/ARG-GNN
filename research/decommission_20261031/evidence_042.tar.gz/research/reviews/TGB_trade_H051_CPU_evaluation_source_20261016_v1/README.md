# CPU full-fit certificate and explicit heldout evaluation

Source only and inactive. No scientific payload, model/checkpoint/probability array, numerical package, guard, admission, process/GPU probe, job or Git action was used during authoring.

This packet supports the exact complete CPU campaign from TGB_trade_H051_CPU_runtime_source_20261016_v1. It cannot accept the GPU-specific fit binder. All original training/evaluation sources and scientific protocol remain unchanged.

## Genuine full-fit certificate

fit_metadata_v1.build_fit_certificate_v1 returns JSON and writes nothing. Root must invoke it only after genuinely consuming the complete CPU TRAIN outer tool0, with its real resource callback. Root persists the result exclusively through its existing charged bounded metadata writer. No checkpoint is decoded, rewritten or copied by certification.

The root request has the shape in fit_certificate_request.inactive.template.v1.json. Activate a fresh copy only with these actual refs: original active scientific input, ordinary completed.json, auxiliary actual_launch.json, original seed17.common_initial.json and a genuine actual_root_tool_terminal_ref. Set permanent future-fit-write/relaunch revocation true only when actually established.

The actual external terminal record uses root_tool_terminal.inactive.template.v1.json, filled from genuine exec/write_stdin terminal provenance. It requires actual_terminal_consumed=true, exact integer exit0, actual positive session ID, terminal chunk, original scientific input/completed/outer-wait refs and the actual same root-monitor identity. It must not be inferred from a launcher, worker wait or completed.json alone.

The binder follows original input/source/contract identity, seeded worker and monitor PID/start identities, inherited launch handshake, actual worker wait0 and owned drain, original monitor completed/result, entire300update/6900TRAIN/90replay budget and unmodified executed protocol. It authenticates the original initialization and every final state through their original metadata/hash/size, each100epoch history and no heldout selection. It authenticates all7years,3arms and255by255predictions and their original NPY artifact hash. The original raw payload hash and shape are independently checked by the unchanged original bundle loader before any label access.

Example root API after actual fit0, inside root's original monitored/charged metadata preparation:

    metadata = load_exact_source(fit_metadata_v1.py, its_sealed_SHA)
    certificate = metadata.build_fit_certificate_v1(ACTUAL_ROOT_REQUEST_REF, resource_check=ACTUAL_ROOT_RESOURCE_CALLBACK)
    # Persist certificate through root's existing exclusive charged metadata writer.
    # Record that actual path/SHA. This source creates no alternate writer/admission.

All templates remain inactive with null evidence and cannot authorize work. The original TRAIN artifacts and pending-external-terminal completed receipt remain untouched.

## Exact original heldout semantics

The CPU callback reuses three exact original AST definitions: validate_split_capability_v1, HeldoutTargetsV1 and load_prediction_bundle_v1. Only the certificate provider is a CPU validator and the reader source identity is this CPU callback. The unchanged CSV reader first filters year, then decodes only the released split's country/source/weight. It accepts no other target years. The full original prediction payload is verified before the target archive is opened.

Original evaluate_sealed_split_v1 and score_year_v1 are imported unchanged. All3arms and original official eligible country-years use sklearn1.9.1NDCG@10, equal-country/equal-year aggregation, the frozen native persistence/EMA baselines and paired architecture differences. No model/checkpoint reload, prediction replay, optimization, posthoc normalization, altered cohort, seed or checkpoint selection occurs.

VAL requires a separate active capability matching heldout_capability.VAL.inactive.template.v1.json with allowed2010–2013, actual CPU certificate, original prediction seal and exact cpu_evaluation_v1.py ref. TEST requires allowed2014–2016 plus the original explicit TEST release and a root TGB_H051_confirmation_decision_frozen_v1 JSON. That decision must be frozen while current-model TEST remains closed, bind the same CPU certificate, contain an explicit decision and selection_on_TEST=false. The original validator enforces this before labels. No automatic TEST release occurs.

## Ordinary CPU execution

After root creates the actual CPU certificate and independent split capability, fit_metadata_v1.make_eval_request_v1 returns a separate active request and writes nothing:

    request = metadata.make_eval_request_v1(
        ACTUAL_STATIC_CONTRACT_REF, ACTUAL_CPU_FIT_CERTIFICATE_REF,
        ACTUAL_SPLIT_CAPABILITY_REF, root_execute_authorized=True)
    # Root persists through its ordinary exclusive charged metadata writer.

Root then invokes, once per split from the project root:

    CUDA_VISIBLE_DEVICES='' .runtime/env/bin/python -B research/reviews/TGB_trade_H051_CPU_evaluation_source_20261016_v1/ordinary_evaluate_cpu_v1.py --execute --request ACTUAL_REQUEST_PATH --expected-request-sha256 ACTUAL_REQUEST_SHA256

The private runtime reuses the exact original ordinary CPU monitor/admission/guard, handshake, seeded owned identities, actual waits, drain, failure preservation,4threads and256KiB TMP/cache. Separate fixed fresh VAL/TEST admin/output/aux scopes prevent replay. Operational caps are4MiB complete output+aux,8GiB aggregate RSS,7200seconds including admission. One original evaluation JSON is capped at1MiB, a root result at64KiB, with a conservative3MiB complete control/artifact bound below4MiB. No score or array is copied into this new scope.

There are54static roles,62prospective VAL and63TEST direct roles. Original guard checks the actual complete union at most64. The CPU certificate is an immutable transitive grant for original fit evidence and original state/prediction payloads, all reauthenticated at evaluation start. It is not hidden new code authority. Root still owns actual admission, exact source/capability binding, original renewal/expiry, terminal consumption and score reporting.

Normal returned output identifies the original evaluation artifact. The ordinary completed receipt proves actual worker wait/drain only. Root separately consumes its true external evaluation tool0 before claiming completion. No fit certificate, evaluation, runtime/output fit, metric or superiority result is established by this source packet.
