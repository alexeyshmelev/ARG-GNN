"""Independent fake-only saved600 ROOT preparation integration and boundary checks."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import ast,copy,hashlib,importlib,importlib.util,json,os,sys,types,contextlib,io
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
sys.path.insert(0,str(ROOT))
REVIEW="research/reviews/C3_saved600_validator_ROOT_preparation_independent_review_20261016_v1"
PREP="research/reviews/C3_saved600_validator_ROOT_preparation_source_20261016_v1"
MAIN="research/reviews/C3_saved600_artifact_acceptance_source_20261016_v1"
MAIN_REVIEW=dict(path="research/reviews/C3_saved600_artifact_acceptance_independent_review_20261016_v1/review.v1.json",sha256="b89ce51b5fc08420bb7b275a21817146a54791438c4d8fa74ccdf810b4f1fe51")
prep=importlib.import_module(PREP.replace("/",".")+".prepare_root_v1")
c=importlib.import_module(MAIN.replace("/",".")+".acceptance_contract_v1")
manifest=json.loads((ROOT/MAIN/"source_manifest.v1.json").read_text())
checks=[]
def check(name,detail=None):
    checks.append(dict(name=name,status="PASS_SOFTWARE_ONLY",**({"detail":detail} if detail is not None else {})))
def reject(fn):
    try:fn()
    except (ValueError,KeyError,TypeError,AssertionError):return
    raise AssertionError("Expected rejection")
def extracted(path,name,ns):
    tree=ast.parse((ROOT/path).read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[fn],type_ignores=[]),"<exact-source:"+path+":"+name+">","exec"),ns)
    return ns[name]
guard_source=c.GUARD_REF["path"]
pure=dict(copy=copy,require=prep.require,_raw=lambda r:prep.require(isinstance(r,dict) and set(r)=={"path","sha256"},"fake exact ref"))
binding=extracted(guard_source,"consumer_bindings_v1",pure)
storage_ns=dict(require=prep.require,_raw=lambda r:None,budget_check_v9=lambda storage,**kw:(copy.deepcopy(storage),kw))
validate_storage=extracted(guard_source,"validate_storage_v9",storage_ns)
operation_ns=dict(require=prep.require,copy=copy,MODE="native14_stopped_retention_v3",RETIRE_OPERATION="SYNTHETIC_UNUSED_RETIRE",datetime=datetime,timezone=timezone)
native_draft=extracted(guard_source,"operation_draft_v1",operation_ns)
native_pins=extracted(guard_source,"_pins",operation_ns)
extracted(guard_source,"_expire",operation_ns)
native_authority=extracted(guard_source,"_authority",operation_ns)
def synthetic(i):
    return dict(path=REVIEW+"/SYNTHETIC_"+str(i)+".json",sha256=hashlib.sha256(str(i).encode()).hexdigest())
plain=types.SimpleNamespace(required_direct_refs_v1=lambda s,r:[])
g=types.SimpleNamespace(consumer_bindings_v1=binding)
rows=[synthetic(i) for i in range(65)]
assert len(prep.role_union_v1(plain,g,dict(bindings={str(i):r for i,r in enumerate(rows[:64])}),{},{},[]))==64
reject(lambda:prep.role_union_v1(plain,g,dict(bindings={str(i):r for i,r in enumerate(rows)}),{},{},[]))
check("exact_actual_binding_body_64accepted_65rejected")
reject(lambda:prep.role_union_v1(plain,g,dict(bindings=dict(a=rows[0])),{},{},[dict(rows[0],sha256="f"*64)]))
check("same_path_hash_conflict_rejected")
dropping=types.SimpleNamespace(consumer_bindings_v1=lambda returned,required,extra:required)
reject(lambda:prep.role_union_v1(types.SimpleNamespace(required_direct_refs_v1=lambda s,r:[rows[1]]),dropping,dict(bindings=dict(a=rows[0])),{},{},[]))
check("silently_dropped_returned_role_detected")
c.review_values_v1(c.read(MAIN_REVIEW),c.ref(c.SOURCE),prep.MANIFEST_REF)
check("actual_main_SOURCE_PASS_exact_source_manifest_and_independent_gate")
for mutation in (dict(verdict="INACTIVE"),dict(independent=False),dict(source_ref=rows[0]),dict(source_manifest_ref=rows[1])):
    value=c.read(MAIN_REVIEW);value.update(mutation)
    reject(lambda value=value:c.review_values_v1(value,c.ref(c.SOURCE),prep.MANIFEST_REF))
check("four_main_review_gate_negatives")

class FakeFlow:
    def __init__(self,mode="normal"):
        self.mode=mode;self.mem={};self.events=[];self.dirs=set();self.apply_count=0;self.storage_calls=[]
        self.raw_saves=[];self.pre_reserve_charge=None;self.final_charge=None
        outer=self
        class VirtualPath(type(Path())):
            def exists(self):
                key=str(self.relative_to(ROOT))
                if key.startswith("research/reviews/C3_full30Mb_eval_ROOT_saved600_validator_") or key.startswith("experiments/results/C3_full30Mb_eval_saved600_validator_"):
                    return str(self) in outer.dirs or key in outer.mem
                return Path(self).exists()
            def is_symlink(self):
                return False
            def mkdir(self,*a,**kw):
                key=str(self.relative_to(ROOT))
                assert key.startswith("research/reviews/C3_full30Mb_eval_ROOT_saved600_validator_")
                assert str(self) not in outer.dirs
                outer.dirs.add(str(self));outer.events.append("fake_packet_mkdir")
        self.VP=VirtualPath
        ns=dict(c.__dict__)
        def local(path):
            p=Path(str(path));p=p if p.is_absolute() else ROOT/p
            assert p.is_relative_to(ROOT) and ".." not in p.parts
            return VirtualPath(p)
        def ref(path):
            p=local(path);key=str(p.relative_to(ROOT))
            if key in self.mem:return dict(path=key,sha256=self.mem[key][1])
            return c.ref(key)
        def read(record,cap=33554432):
            if record["path"] in self.mem:
                value,sha=self.mem[record["path"]];assert sha==record["sha256"]
                return copy.deepcopy(value)
            return c.read(record,cap=cap)
        def save(directory,name,value):
            assert Path(name).name==name and name.endswith(".json")
            key=str((local(directory)/name).relative_to(ROOT));assert key not in self.mem
            raw=(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
            assert len(raw)<=65536
            charge=sum(size+8192 for path,size in self.raw_saves if str(Path(path).parent)==str(Path(key).parent))+len(raw)+8192
            assert charge<=524288
            self.mem[key]=(copy.deepcopy(value),hashlib.sha256(raw).hexdigest())
            self.raw_saves.append((key,len(raw)));self.final_charge=charge
            self.events.append("save:"+name)
            return ref(key)
        def acceptance(req):
            c.history_values_v1(req["original_history"])
            assert req["training_completion_ref"]==json.loads((ROOT/MAIN/"ROOT_validation_request.INACTIVE.template.v1.json").read_text())["training_completion_ref"]
            self.events.append("fake_acceptance_metadata_endpoint")
            return {"SYNTHETIC_ACCEPTANCE_ENDPOINT_ONLY":True},{}
        ns.update(local=local,ref=ref,read=read,save=save,manifest_v1=lambda:copy.deepcopy(manifest),acceptance_inputs_v1=acceptance)
        for name in ("require","active","caps_v1","review_values_v1","root_validation_request_v1","validate_request","validate_input_v1","required_direct_refs_v1","make_config"):
            ns[name]=types.FunctionType(getattr(c,name).__code__,ns,name, getattr(c,name).__defaults__)
        self.ns=ns
        guard=types.SimpleNamespace(MODE="native14_stopped_retention_v3")
        v4=types.SimpleNamespace(__name__="_fake_original_v4")
        def original():raise AssertionError("Uncalled original-mutation probe")
        original.__module__=v4.__name__
        v4.canonical=v4.file_bytes=v4.mutex=original
        if mode=="wrapped":
            v4.canonical=lambda:None
        guard.budget=types.SimpleNamespace(v4=v4,SOURCE_REL="scripts/project_budget_v9.py",LAUNCHER_REL="scripts/launch_reserved_gpu_v6.py")
        def inspect(**kw):
            assert kw==dict(expected_source_sha256=c.CORE,expected_launcher_sha256=c.BASE)
            self.events.append("fake_fresh_inspect")
            bindings=copy.deepcopy(manifest["current_guard_roles"])
            bindings["SYNTHETIC_UNEXPECTED_CURRENT_ROLE"]=synthetic(100)
            if mode=="overflow":
                for i in range(101,115):bindings["SYNTHETIC_EXTRA_"+str(i)]=synthetic(i)
            return dict(bindings=bindings,base_pins=dict(SYNTHETIC_BASE=1),completed_overlay_prefix=dict(events=321,tail_sha256="e"*64))
        def pins(view):return native_pins(view)
        def draft(op,request,**kw):
            assert op=="reserve" and kw["expected_before"]==dict(base_pins=dict(SYNTHETIC_BASE=1),completed_overlay_prefix=dict(events=321,tail_sha256="e"*64))
            assert kw["bindings"]["SYNTHETIC_UNEXPECTED_CURRENT_ROLE"]==synthetic(100)
            assert request["reserved_bytes"]==33554432 and len(request["auxiliary_scopes"])==2
            self.events.append("fake_draft");self.reserve_request=copy.deepcopy(request)
            return native_draft(op,request,**kw)
        def apply(record,**kw):
            self.apply_count+=1;self.events.append("fake_apply_once")
            self.pre_reserve_charge=self.final_charge
            operation_ns.update(_json=read,budget=guard.budget)
            authority=native_authority(record,"reserve",read(record)["bindings"],fresh=True)
            assert authority["schema"]=="native14_exact_root_operation_v1"
            assert authority["active"] is True and authority["expires_at_utc"]==self.expiry
            assert kw==dict(expected_source_sha256=c.CORE,expected_launcher_sha256=c.BASE)
            if mode=="race":raise ValueError("SYNTHETIC prefix changed")
            return dict(kind="concurrent_completed_scope_reserve_receipt_v1",value=dict(copy.deepcopy(authority["request"]),root_admission=record),
                initial_ledger_pins=dict(base_pins=dict(SYNTHETIC=1),completed_overlay_prefix=dict(events=322,tail_sha256="d"*64)))
        def storage(spec,cfg,value,**kw):
            self.events.append("fake_strict_storage_boundary")
            result=validate_storage(spec,cfg,value,**kw)
            assert result[1]==dict(first=True,boundary=True)
            self.storage_calls.append(copy.deepcopy(value))
            return result
        guard.inspect_v1=inspect;guard._pins=pins;guard.operation_draft_v1=draft;guard.apply_reserve_v1=apply
        guard.consumer_bindings_v1=binding if mode!="drop" else lambda returned,required,extra:required+extra
        guard.validate_storage_v9=storage
        self.guard=guard;ns["original_guard"]=lambda:guard
        self.fakec=types.SimpleNamespace(**ns)
        # Actual cloned schema functions resolve their shared fake namespace, never the real guard.
        loader=types.SimpleNamespace(exec_module=lambda module:self.events.append("fake_contract_loader"))
        fake_util=types.SimpleNamespace(spec_from_file_location=lambda name,path:types.SimpleNamespace(loader=loader),module_from_spec=lambda spec:self.fakec)
        pn=dict(prep.__dict__,importlib=types.SimpleNamespace(util=fake_util))
        if mode=="late":
            expiry=datetime.now(timezone.utc)+timedelta(hours=1)
            class Clock:
                @classmethod
                def fromisoformat(cls,value):return datetime.fromisoformat(value)
                count=0
                @classmethod
                def now(cls,tz):
                    cls.count+=1
                    return expiry-timedelta(seconds=1199) if cls.count>=5 else expiry-timedelta(hours=1)
            pn["datetime"]=Clock
            self.expiry=expiry.isoformat()
        else:self.expiry=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
        self.prepare=types.FunctionType(prep.prepare_root_v1.__code__,pn)
        self.args=types.SimpleNamespace(root_directive=prep.DIRECTIVE,instance="INDEPENDENT_SYNTHETIC_"+mode,
            review_path=MAIN_REVIEW["path"],review_sha256=MAIN_REVIEW["sha256"],expires_at_utc=self.expiry)
    def run(self):return self.prepare(self.args)
    def value(self,name):
        found=[v[0] for k,v in self.mem.items() if k.endswith("/"+name)]
        assert len(found)==1
        return copy.deepcopy(found[0])
    def put(self,value):
        path=REVIEW+"/SYNTHETIC_mutant.json"
        raw=(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n").encode()
        sha=hashlib.sha256(raw).hexdigest();self.mem[path]=(copy.deepcopy(value),sha)
        return dict(path=path,sha256=sha)
flow=FakeFlow();result=flow.run()
request=flow.value("request.root_active_v1.json");spec=flow.value("input.json")
admitted=flow.value("admitted.json");storage=flow.value("storage.json");config=flow.value("config.json")
assert result["status"]=="ADMITTED_SAVED600_CPU_VALIDATOR_NOT_EXECUTED"
assert flow.apply_count==1 and result["consumer_binding_count"]==52
assert synthetic(100) in storage["reservation"]["consumer_bindings"]
assert storage["reservation"]==flow.value("reserve_receipt.json")["value"]
assert storage["initial_ledger_pins"]==flow.value("reserve_receipt.json")["initial_ledger_pins"]
assert config["output_cap_bytes"]==storage["reserved_new_bytes"]==33554432
assert storage["reservation"]["auxiliary_scopes"]==[
    str(ROOT/request["packet_directory"]/"worker_aux"),str(ROOT/request["packet_directory"]/"worker_tmp")]
assert flow.pre_reserve_charge<=524288 and flow.final_charge<=524288
assert len(flow.raw_saves)==10 and not any((ROOT/k).exists() for k in flow.mem)
for obj in (request,spec,storage,flow.value("ROOT_validator_directive.json"),flow.value("reserve_authority.json")):
    assert obj["expires_at_utc"]==flow.expiry
assert admitted["input_ref"]==result["input_ref"] and admitted["driver_ref"]==c.ref(c.DRIVER)
assert admitted["execution_started"] is False
for value in (request,admitted,result,flow.value("ROOT_validator_directive.json"),flow.value("ROOT_original_producer_write_revocation.json")):
    assert value["original_history"]==c.ORIGINAL_HISTORY
assert flow.value("ROOT_validator_directive.json")["acceptance_prediction_scoring_retraining_or_close_authorized"] is False
assert flow.value("ROOT_original_producer_write_revocation.json")["complete_historical_writer_absence_claimed"] is False
assert flow.events.index("fake_fresh_inspect")>flow.events.index("save:config.json")
assert flow.events.index("fake_apply_once")<flow.events.index("fake_strict_storage_boundary")<flow.events.index("save:input.json")
check("exact_preparation_function_full_fake_flow_actual_request_input_guard_storage_schema_bodies",
    dict(binding_count=52,unexpected_current_role_retained=True,pre_reserve_metadata_charge=flow.pre_reserve_charge,total_packet_metadata_charge=flow.final_charge,all_saves_in_memory=True))
check("exact_32MiB_output_two_AUX_receipt_prefix_history_no_acceptance_expiry_joins")

argv=result["exact_one_ROOT_validator_execution_argv"]
assert argv[:5]==["setsid",str(ROOT/".runtime/env/bin/python"),"-B",str(ROOT/c.DRIVER),"--launch"]
assert argv[5:]==["--input",result["input_ref"]["path"],"--expected-input-sha256",result["input_ref"]["sha256"]]
driver_ns=dict(argparse=importlib.import_module("argparse"),json=json,c=flow.fakec,SOURCE=c.DRIVER,__doc__="fake-driver-schema-only")
driver_ns["bind_reviewed_supervisor_v1"]=lambda:lambda phase:flow.events.append("fake_supervisor:"+phase) or 0
flow.fakec.set_active_spec_v1=lambda record:flow.ns["validate_input_v1"](record)
driver_main=extracted(MAIN+"/root_driver_v1.py","main",driver_ns)
assert driver_main(argv[4:])==0 and flow.events[-1]=="fake_supervisor:validate_saved600"
check("emitted_sets id_argv_roundtrips_actual_driver_argument_and_admitted_gate_without_launch".replace("sets id","setsid"))
badcfg=dict(config,output_cap_bytes=33554431)
reject(lambda:validate_storage(spec,badcfg,storage,source_ref=c.ref(c.ENTRY),config_ref=spec["refs"]["config"],runtime_ref=c.RUNTIME_REF))
check("actual_native14_storage_body_rejects_config_below_32MiB")
for patch in (dict(schema="wrong"),dict(purpose="accept"),dict(VAL_truth_capability={}),dict(ROOT_accepts_original_producer1_and_outerUNKNOWN_for_artifact_validation_only=False)):
    value=copy.deepcopy(request);value.update(patch)
    reject(lambda value=value:flow.ns["validate_request"](flow.put(value)))
check("actual_request_schema_purpose_truth_and_failure_acknowledgment_negatives")
for patch in (dict(schema="wrong"),dict(GPU_authorized=True),dict(physical_gpu=0),dict(source_sha256={})):
    value=copy.deepcopy(spec);value.update(patch)
    reject(lambda value=value:flow.ns["validate_input_v1"](flow.put(value)))
check("actual_input_schema_GPU_and_source_map_negatives")
mutant=copy.deepcopy(storage);mutant["reservation"]["auxiliary_scopes"].append(str(ROOT/REVIEW/"SYNTHETIC_third_aux"))
value=copy.deepcopy(spec);value["refs"]["storage"]=flow.put(mutant)
reject(lambda:flow.ns["validate_input_v1"](flow.put(value)))
check("actual_input_rejects_third_AUX_scope")

for mode in ("race","wrapped","drop","overflow","late"):
    negative=FakeFlow(mode)
    reject(negative.run)
    if mode=="race":
        assert negative.apply_count==1 and not any(k.endswith(("/storage.json","/input.json","/admitted.json")) for k in negative.mem)
    elif mode=="late":
        assert negative.apply_count==1 and any(k.endswith("/admitted.json") for k in negative.mem)
        assert all(v[0].get("expires_at_utc",negative.expiry)==negative.expiry for v in negative.mem.values())
    else:
        assert negative.apply_count==0
    check("full_fake_flow_rejects_"+mode+"_without_retry_or_execution")
for attr,value in (("root_directive","wrong"),("instance","bad/instance"),("expires_at_utc","2026-10-16T00:00:00"),("expires_at_utc",(datetime.now(timezone.utc)+timedelta(seconds=1499)).isoformat())):
    negative=FakeFlow();setattr(negative.args,attr,value);reject(negative.run)
    assert not negative.mem and not negative.dirs and negative.apply_count==0
    check("early_reject_"+attr+"_"+("naive" if value=="2026-10-16T00:00:00" else "invalid_or_short"))

# Exercise the exact real metadata save function only on tiny owned review fixtures.
boundary=ROOT/REVIEW/"tiny_metadata_boundary_v3";boundary.mkdir()
accepted=[]
for i in range(64):
    try:accepted.append(c.save(boundary,"tiny_"+str(i)+".json",{}))
    except ValueError:
        assert i==63
        break
assert len(accepted)==63 and not (boundary/"tiny_63.json").exists()
reject(lambda:c.save(boundary,"too_large.json",{"x":"x"*65536}))
assert not (boundary/"too_large.json").exists()
exclusive=ROOT/REVIEW/"tiny_exclusive_v2";exclusive.mkdir()
c.save(exclusive,"tiny.json",{})
try:c.save(exclusive,"tiny.json",{})
except FileExistsError:pass
else:raise AssertionError("Existing metadata file overwritten")
check("actual_save_512KiB_conservative_charge_and_64KiB_prewrite_rejection_O_EXCL",
    dict(tiny_files_written=63,actual_payload_bytes=sum((boundary/("tiny_"+str(i)+".json")).stat().st_size for i in range(63)),conservative_charge=63*(8192+3)))

assert not any(name in sys.modules for name in ("torch","numpy","torch_geometric"))
output=dict(schema="C3_saved600_ROOT_preparation_independent_fake_checks_v1",status="PASS_SOFTWARE_ONLY",checks=checks,
    check_count=len(checks),source_ref=c.ref(PREP+"/prepare_root_v1.py"),
    main_review_ref=MAIN_REVIEW,full_flow_actual_function_code=True,
    fake_only_endpoints=["contract_loader","guard_inspect","reserve_authority","reserve_apply","strict_budget_boundary","acceptance_input_metadata","in_memory_packet_saves","supervisor"],
    actual_guard_resource_process_probe_accounting_authority_admission_or_execution=False,
    actual_source_schema_helpers=["prepare_root_v1","role_union_v1","storage_v1","validate_request","root_validation_request_v1","validate_input_v1","required_direct_refs_v1","consumer_bindings_v1","validate_storage_v9","operation_draft_v1","_pins","_authority","_expire","driver_main","save"],
    virtual_packet_created_on_filesystem=False,original_sources_modified=False)
print(json.dumps(output,sort_keys=True,indent=2))
