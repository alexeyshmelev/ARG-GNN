"""Final explicit prefix11 concrete join. No actual staging access, clocks, guard imports or operations."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
from types import SimpleNamespace
import ast,copy,hashlib,json,stat,traceback
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN');OUT=ROOT/'research/reviews/Census_final_whole_join_independent_20261017_v1';V32='research/reviews/research_execution_ROOT_20261017_v32/';S='research/reviews/Census_inspect_inline_ROOT_orchestration_source_20261017_v1/';P='research/reviews/Census_concrete_metadata_proposal_20261017_v1/';FUTURE='research/reviews/Census_retention_inline_ROOT_actual_inspect_root01_oct17'
checks=[];negatives=[];verified={}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def check(name,value=True):need(value,name);checks.append(name)
def pack(value):return (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def bounded(path,expected=None):
 need(not(path==FUTURE or path.startswith(FUTURE+'/')),'No actual staging pathname access')
 p=ROOT/path;s=p.lstat();need(p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_nlink==1 and s.st_size<=2**21,'Bounded exact regular source/metadata')
 raw=p.read_bytes();a=p.lstat();identity=lambda x:(x.st_dev,x.st_ino,x.st_mode,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
 need(identity(s)==identity(a)and len(raw)==s.st_size,'Stable immutable selected bytes');digest=sha(raw);need(expected is None or expected==digest,'Exact pin '+path);verified[path]=digest;return raw
def doc(path,expected=None):return json.loads(bounded(path,expected))
def readref(ref):return doc(ref['path'],ref['sha256'])
def compile_nodes(nodes,env,label):exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),label,'exec',dont_inherit=True,optimize=0),env)
def functions(raw,names):return[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)and n.name in names]
class RAMPath(PurePosixPath):
 def is_dir(self):return True
class FixtureDate(datetime):
 @classmethod
 def now(cls,tz=None):return cls(2001,1,1,12,0,0,tzinfo=timezone.utc)
def main():
 proposed_ref=dict(path=V32+'Census_final_whole_join_PROPOSED_INACTIVE.root_v1.json',sha256='bbcf3094751fc69f82a360caebe200af289b80c85d222b110dae7488e7e3fb4a');proposed=readref(proposed_ref)
 provenance_ref=dict(path=V32+'Census_final_concrete_rebind_provenance.root_v1.json',sha256='911ac960114b5c07f8dae115687f73c0c1689780e690293a0e026a665280df33');provenance=readref(provenance_ref);latest=readref(provenance['actual_prefix_and47roles_ref']);acceptance=readref(provenance['latest_actual_close_outer0_ref']);receipt=readref(latest['prefix_source_receipt_ref']);authority=readref(latest['authority_ref'])
 check('ROOT_explicit_proposal_provenance_latest_refs_join',provenance['proposed_review_ref']==proposed_ref and latest['journal_acceptance_ref']==provenance['latest_actual_close_outer0_ref']and acceptance['receipt_ref']==latest['prefix_source_receipt_ref']and acceptance['authority_ref']==latest['authority_ref'])
 check('genuine_close_outer0_and_original_journal_acceptance',acceptance['root_authorizer']=='root_agent'and acceptance['actual_terminal_consumed']is True and acceptance['actual_exit_code']==0 and acceptance['journal_exact_value_authority_prefix_match']is True and receipt['key']==authority['request']['key']and receipt['value']['request']==authority['request'])
 expected=latest['expected_before'];roles=latest['expected_guard_roles']
 check('prefix11_complete_ancestors_from_authority_and_actual_receipt',expected==dict(base_pins=authority['expected_before']['base_pins'],completed_overlay_prefix=receipt['completed_overlay_prefix'])and expected['completed_overlay_prefix']==dict(events=11,tail_sha256='75d1d9795463ef0454e1a818ac355eb19fc9df9bb56350734c4efb71dc2d5a99')and acceptance['original_journal_event_ref']['sha256']==expected['completed_overlay_prefix']['tail_sha256'])
 check('ROOT_holds_all_future_mutations_no_Census_credit',provenance['root_authorizer']=='root_agent'and provenance['no_intervening_ROOT_accounting_mutation']is True and provenance['future_ROOT_mutations_held_until_final_review_and_operation_resolved']is True and provenance['Census_credit']==latest['Census_retirement_credit_bytes']==acceptance['Census_retirement_credit_bytes']==0)
 oldreview=readref(provenance['original_proposal_review_ref']);check('prior_exact_concrete_source_pass_preserved',provenance['original_proposal_review_ref']['sha256']=='0c08a01de29faec3050a090e8d435b4afe017153d38e75290ceaae81558ab57b'and oldreview['verdict']=='SOURCE_PASS'and oldreview['independent']is True and oldreview['actual_whole_join_capability_reviewed']is False)
 ip=doc(P+'ROOT_instruction.PROPOSED_INACTIVE.v1.json','b4a5b933a900e21fb30d775fd929f16841064f7b3128c19d442bceacc02f4baa');tp=doc(P+'ROOT_actual_operation_intent.PROPOSED_INACTIVE.v1.json','ed03bb97f7a254019063384f4d54cea6c19bc8c50b376e1b8a9a41fb3544d6bb');historical=doc(P+'whole_join_review.PROPOSED_INACTIVE.v1.json','e1cfc7f8112d598b5fec37e88289f8776685114cef859ac5e36ab41ff358cd50')
 check('exact_all47_actual_close_roles_equal_historical_maps',len(roles)==47 and roles==authority['bindings']==ip['expected_guard_roles']==tp['expected_guard_roles']==historical['expected_guard_roles']==proposed['expected_guard_roles'])
 for ref in roles.values():bounded(ref['path'],ref['sha256'])
 check('all47_role_bytes_authenticated40unique_paths',len({r['path']for r in roles.values()})==40)
 check('complete_ancestor_base_unchanged_from_historical_prefix6',expected['base_pins']==ip['expected_before']['base_pins']and ip['expected_before']['completed_overlay_prefix']['events']==6 and proposed['expected_before']==expected)
 orch_raw=bounded(S+'orchestrate_v1.py','f1f1d0a748f3dbd9b7117721df13220072bd3f356edd0c5afce3dd6f300ada49');callback_raw=bounded(S+'ROOT_authorize_inline_retirement_v1.py','ef29065dbbcfe4d6aa83555b08ad347578d287cca65e361b2d1d9ef94dad2b15');helper_raw=bounded(ip['helper_ref']['path'],ip['helper_ref']['sha256']);integration_raw=bounded(S+'integration_manifest.INACTIVE.template.v1.json','3f98e6a2f7da5d6e3ddcd4dbf0ab90074f19e0d48d344609a5fc70a654682986');integration=json.loads(integration_raw)
 recipe=doc(S+'ROOT_RECIPE.v1.json','1b19b8bf0348f58818e1744e6483be5a9baf9cd911a8ec3aa716d98d9ed09e7e');layout=doc(S+'staging_layout.v1.json','dc9e101a57454fb38996b886876b18f2c48356e7d83452e5dff53f4452e89cfa')
 sourcepass=doc('research/reviews/Census_inspect_inline_ROOT_orchestration_independent_20261017_v1/review.v1.json','26669c29d426423c0083be64847616c76b70783b5f0d4b48285d2759410f4758');genericpass=doc('research/reviews/Census_retention_inline_independent_20261017_v1/review.v1.json','ab7ec25225876da84f1e061252601cb4a85df3f6f25a784d1385e70ec4b4f142')
 check('unchanged_accepted_complete_callback_orchestration_helper_passes',all(v['verdict']=='SOURCE_PASS'and v['independent']is True and v['blockers']==[]for v in(sourcepass,genericpass))and sourcepass['actual_callback_complete_source_review']is True and sourcepass['orchestration_complete_source_review']is True)
 check('source_integration217_and_fixed_aliases_unchanged',len(integration['source_sha256'])==217 and all(r['from']['sha256']==r['to']['sha256']for r in layout['byte_identical_copies'])and ip['source_manifest_ref']['sha256']==sha(integration_raw))
 deps=doc(P+'exact_dependencies.v1.json','70ff1dbd5bdb7dd5e1cc3b35c3dabff024414e791f396744be2518c28a5ca3f8')
 sources={}
 for name in ('helper_ref','memo_ref','memo_manifest_ref','memo_review_ref','bridge_ref','guard_ref','selector_ref','policy_ref','permanent_revocation_ref'):
  r=ip[name];sources[r['path']]=bounded(r['path'],r['sha256'])
 sources[ip['callback_source_ref']['path']]=callback_raw;sources[tp['orchestration_source_ref']['path']]=orch_raw;sources[ip['source_manifest_ref']['path']]=integration_raw
 orch=dict(Path=RAMPath,datetime=FixtureDate,timezone=timezone,need=need)
 compile_nodes([n for n in ast.parse(orch_raw).body if isinstance(n,ast.Assign)]+functions(orch_raw,('stamp','controls')),orch,'exact_orchestration_controls_RAM')
 helper=dict(Path=RAMPath,datetime=FixtureDate,timezone=timezone,need=need,copy=copy)
 tree=ast.parse(helper_raw);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));compile_nodes([n for n in tree.body if isinstance(n,ast.Assign)]+[n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='_authenticate'],helper,'exact_helper_authenticate_RAM')
 final=dict(schema='Census_inline_ROOT_retirement_whole_join_review_v1',independent=True,verdict='SOURCE_PASS',blockers=[],source_ref=ip['helper_ref'],source_manifest_ref=ip['source_manifest_ref'],callback_source_ref=ip['callback_source_ref'],callback_name=ip['callback_name'],fresh_metadata_paths=orch['FRESH'],permanent_revocation_ref=ip['permanent_revocation_ref'],guard_ref=ip['guard_ref'],memo_ref=ip['memo_ref'],selector_ref=ip['selector_ref'],policy_ref=ip['policy_ref'],bridge_ref=ip['bridge_ref'],actual_callback_complete_source_review=True,key=orch['KEY'],expected_before=expected,expected_guard_roles=roles,orchestration_complete_source_review=True,orchestration_source_ref=tp['orchestration_source_ref'],outcome_metadata_paths=orch['NAMES'],actual_intent_path=orch['INTENT'],admission_or_retirement_authorized=False)
 check('independently_assembled_final_review_exact_original_keyset',set(final)==set(proposed)==set(historical))
 common_keys=set(final)-{'independent','verdict','blockers','actual_callback_complete_source_review','orchestration_complete_source_review'}
 check('ROOT_proposal_all_concrete_join_fields_exact',all(final[k]==proposed[k]for k in common_keys)and proposed['independent']is False and proposed['verdict']=='UNREVIEWED_INACTIVE')
 review_bytes=pack(final);review_ref=dict(path=orch['REVIEW'],sha256=sha(review_bytes))
 def fixture(mutate=None):
  i=copy.deepcopy(ip);t=copy.deepcopy(tp)
  for v in (i,t):v.update(expected_before=copy.deepcopy(expected),expected_guard_roles=copy.deepcopy(roles),active=True,root_authorizer='root_agent',created_at_utc='2001-01-01T11:00:00+00:00',expires_at_utc='2001-01-01T13:00:00+00:00',whole_join_review_ref=review_ref)
  t['ROOT_authorizes_one_actual_original_Census_retirement']=True
  if mutate:mutate(i,t)
  tr=dict(path=orch['INTENT'],sha256=sha(pack(t)));i['uncached_current_refs'][0]=tr;ir=dict(path=orch['INSTRUCTION'],sha256=sha(pack(i)))
  ram={**sources,orch['REVIEW']:review_bytes,orch['INTENT']:pack(t),orch['INSTRUCTION']:pack(i)}
  def raw(ref):need(type(ref)is dict and set(ref)=={'path','sha256'}and sha(ram[ref['path']])==ref['sha256'],'Exact RAM authenticated bytes');return ram[ref['path']]
  def bound(root,ref,fresh):need(fresh is True,'Uncached original metadata');return json.loads(raw(ref))
  def expire(v):need(FixtureDate.fromisoformat(v['expires_at_utc'])>FixtureDate.now(timezone.utc),'Original finite instruction expiry')
  m=SimpleNamespace(helper_ref=i['helper_ref'],manifest_ref=i['source_manifest_ref'],review_ref=review_ref,memo_review_ref=i['memo_review_ref'],callback_ref=i['callback_source_ref'],callback_name=i['callback_name'],paths=i['fresh_metadata_paths'],revocation_ref=i['permanent_revocation_ref'],instruction_ref=ir,key=i['key'],metadata_directory=i['metadata_directory'],cache_refs=i['cache_refs'],current_refs=i['uncached_current_refs'],v4=SimpleNamespace(canonical=lambda root,path:root/path),guard=SimpleNamespace(_expire=expire),memo=SimpleNamespace(source_bytes=raw))
  orch['raw']=raw;orch['document']=lambda ref:json.loads(raw(ref));orch['controls'](ir,tr);helper['_authenticate'](m,bound);return i,t,m
 i,t,m=fixture();check('exact_finite_RAM_review_intent_instruction_DAG_accepts_prefix11_all47roles',i['expected_before']==expected and t['expected_guard_roles']==roles and t['instruction_path']==orch['INSTRUCTION']and 'instruction_ref'not in t and m.current_refs[0]['path']==orch['INTENT']and m.current_refs[1]==tp['orchestration_source_ref'])
 def reject(name,mutation):
  try:fixture(mutation)
  except(ValueError,KeyError,TypeError):negatives.append(name);return
  raise AssertionError('Accepted invalid '+name)
 reject('stale_prefix6_rejects_final_review',lambda i,t:(i.update(expected_before=copy.deepcopy(ip['expected_before'])),t.update(expected_before=copy.deepcopy(ip['expected_before']))))
 reject('omit_a_role',lambda i,t:i['expected_guard_roles'].pop(next(iter(roles))))
 reject('role_digest_drift',lambda i,t:t['expected_guard_roles'][next(iter(roles))].update(sha256='f'*64))
 reject('intent_prefix_drift',lambda i,t:t['expected_before']['completed_overlay_prefix'].update(events=12))
 reject('instruction_unknown_field',lambda i,t:i.update(unknown=True))
 reject('intent_unknown_field',lambda i,t:t.update(unknown=True))
 reject('inactive_controls',lambda i,t:i.update(active=False))
 reject('mismatched_finite_clocks',lambda i,t:t.update(expires_at_utc='2001-01-01T14:00:00+00:00'))
 reject('expired_instruction',lambda i,t:i.update(expires_at_utc='2001-01-01T11:00:00+00:00'))
 reject('altered_callback_digest',lambda i,t:i['callback_source_ref'].update(sha256='f'*64))
 reject('altered_fresh_paths',lambda i,t:i['fresh_metadata_paths'].update(observation=FUTURE+'/other.json'))
 reject('extended_original300s',lambda i,t:i.update(operation_wall_seconds=301))
 reject('extended_original120s',lambda i,t:i.update(fresh_target_seconds=121))
 entries=[*roles.values(),m.instruction_ref,m.manifest_ref,m.review_ref,m.memo_review_ref,m.helper_ref,helper['MEMO_REF'],helper['BRIDGE_REF'],helper['SELECTOR_REF'],helper['POLICY_REF'],m.callback_ref,m.revocation_ref];union={}
 for r in entries:need(r['path']not in union or union[r['path']]==r['sha256'],'No path/SHA conflict');union[r['path']]=r['sha256']
 check('complete_consumer_union50plus3equals53within_original64',len(union)==50 and len(set(orch['FRESH'].values()))==3 and not(set(union)&set(orch['FRESH'].values()))and len(union)+3==53<=64)
 text=helper_raw.decode();check('uncached_control_JSON_closure_and_final_restore_unchanged','[p for p in manifest["source_sha256"]if Path(p).suffix==".json"]'in text and 'tx.finish()'in text and text.index('tx.close();self.core._check()')<text.index('fresh_auth=self.guard._authority')and 'len(set(exclusions))<=2048'in text)
 check('original300prelock120proof_and_callback_expiry_unchanged',recipe['caps']['original_operation_seconds']==300 and recipe['caps']['original_target_fresh_seconds']==120 and "authority.update(active=True,expires_at_utc=instruction['expires_at_utc'])"in callback_raw.decode())
 check('no_staging_probe_or_control_activation_or_credit',provenance['fixed_staging_not_created']is True and ip['active']is tp['active']is False and ip['created_at_utc']is tp['created_at_utc']is None and final['admission_or_retirement_authorized']is False)
 # Only the independently authored review is saved. Active controls and fixture clocks remain RAM-only.
 with(OUT/'whole_join_review.v1.json').open('xb')as f:f.write(review_bytes)
 return dict(schema='Census_final_concrete_independent_checks_v1',status='PASS',positive_count=len(checks),negative_count=len(negatives),checks=checks,negative_cases=negatives,verified_selected_refs=verified,final_review_sha256=sha(review_bytes),final_expected_child_prefix=expected['completed_overlay_prefix'],all47roles_40paths_authenticated=True,all217source_payloads_rehashed=False,actual_staging_paths_accessed=False,actual_guard_helper_module_imports=False,actual_state_mutex_process_measurement_accounting_clock_or_Git_operations=False,active_controls_saved=False,actual_operations_or_credit_authorized=False,fixture_clock='2001-01-01T12:00:00+00:00',ROOT_no_intervening_mutation_assertion_inherited_not_probed=True)
try:result=main()
except BaseException:
 diagnostic=traceback.format_exc();(OUT/'first_diagnostic.v1.txt').write_text(diagnostic);print(diagnostic,flush=True);raise
with(OUT/'checks.result.v1.json').open('xb')as f:f.write(pack(result))
print(json.dumps({k:result[k]for k in ('status','positive_count','negative_count','final_review_sha256','final_expected_child_prefix','actual_staging_paths_accessed')},sort_keys=True))
