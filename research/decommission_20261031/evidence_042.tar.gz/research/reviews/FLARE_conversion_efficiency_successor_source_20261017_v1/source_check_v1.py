"""Stdlib-only source/recorded-metadata checks; no runtime/guard/probe execution."""
from pathlib import Path
import ast,hashlib,json,statistics

ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE=ROOT/"research/reviews/FLARE_conversion_efficiency_successor_source_20261017_v1"
OLD="research/reviews/FLARE_original_remaining_CPU_execution_source_20261017_v3"
checks=[]
def need(ok,label):
    if not ok:raise AssertionError(label)
def load(path):return json.loads((ROOT/path).read_text())
def sha(path):return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
def exact(record):
    p=ROOT/record["path"]
    need(p.resolve()==p and p.is_relative_to(ROOT)and p.is_file()and p.stat().st_size<=32*2**20,"Contained compact source/metadata")
    need(sha(record["path"])==record["sha256"],"Exact source/metadata "+record["path"])
def parsed(path):return ast.parse((ROOT/path).read_text())
def function(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name)
def methods(tree,name):
    c=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name==name)
    return {n.name:n for n in c.body if isinstance(n,ast.FunctionDef)}
def has_call(node,text):
    return any(isinstance(n,ast.Call)and ast.unparse(n.func)==text for n in ast.walk(node))
def record(label):checks.append(label)

d=load(str((HERE/"diagnosis.v1.json").relative_to(ROOT)))
decision=load(str((HERE/"efficiency_decision.v1.json").relative_to(ROOT)))
source_map=load(str((HERE/"source_map.v1.json").relative_to(ROOT)))
rootdiag=load(d["ROOT_failure_diagnosis_ref"]["path"])
s=load(d["failed_admitted_input_ref"]["path"]);q=load(s["root_stage_request_ref"]["path"])
for rr in (d["failed_admitted_input_ref"],s["root_stage_request_ref"],s["root_driver_ref"],s["main_source_ref"],q["source_manifest_ref"]):exact(rr)
need(s["root_driver_ref"]["path"]==OLD+"/root_driver_v1.py"and s["main_source_ref"]["path"]==OLD+"/worker_entry_v1.py","Actual setupv3 binding")
record("actual_failed_setupv3_input_request_driver_worker_binding")

wait=load(d["actual_direct_wait_ref"]["path"]);outer=load(d["actual_outer_wait_ref"]["path"]);log=load(d["actual_worker_log_ref"]["path"])
for key in ("ROOT_failure_diagnosis_ref","actual_direct_wait_ref","actual_outer_wait_ref","actual_worker_log_ref"):exact(d[key])
need(outer["tool_session_id"]==97739 and outer["actual_outer_returncode"]==1 and outer["consumed_by_ROOT"]is True,"Genuine ROOT97739outer1")
need(wait["returncode"]==1 and wait["all_owned_processes_and_groups_drained"]is True and wait["completed_ref"]is None and wait["automatic_close_or_credit"]is False,"Actual worker1/drain/no completion")
need("WORKER_SCIENTIFIC_CUTOFF"in log["tail"]and "fcntl.flock(stream, fcntl.LOCK_EX)"in log["tail"],"Actual interrupted original flock")
record("genuine97739outer1_worker1_drain_cutoff_flock_no_completion")

events=[]
for line in log["tail"].splitlines():
    try:v=json.loads(line)
    except json.JSONDecodeError:continue
    if isinstance(v,dict)and isinstance(v.get("FLARE_worker_progress"),dict):events.append(v["FLARE_worker_progress"])
pairs=[];pending=None
for e in events:
    if e["event"]=="original_guard_boundary_begin":
        need(pending is None,"No overlapping recorded boundary");pending=e
    elif e["event"]=="original_guard_boundary_end":
        need(pending is not None,"No unpaired recorded end")
        pairs.append(e["monotonic"]-pending["monotonic"]);pending=None
need(len(pairs)==37 and pending is not None,"37completed pairs plus excluded final")
need(abs(sum(pairs)-3370.956221259199)<1e-6 and abs(statistics.median(pairs)-36.91420828551054)<1e-6 and abs(max(pairs)-716.2427174439654)<1e-6,"Recorded boundary timing reproduced")
need(d["own_validation_seconds"]is None and d["mutex_wait_seconds_for_completed_boundaries"]is None,"No fabricated attribution")
record("37_recorded_boundary_pairs_recomputed_unmatched_excluded_attribution_unknown")

ctx=load(q["context_ref"]["path"]);row=ctx["targets"]["american_c3_val_001"];count=load(row["count_manifest_ref"]["path"])
exact(q["context_ref"]);exact(row["count_manifest_ref"])
need(row["input_sites"]==count["num_sites"]==227316 and row["haplotypes"]==count["num_samples"]==1600,"Original full sites/samples")
need(count["sequence_length"]==30000000 and count["truth_opened"]is False,"Original30Mb no truth")
need(d["caps_unchanged"]==q["caps"]and d["phase_budget_unchanged"]==q["phase_budget"],"Original caps exactly")
need(q["caps"]["scientific_seconds"]==3600 and q["caps"]["wall_seconds"]==4200 and q["caps"]["cpu_threads"]==4 and q["caps"]["rss_bytes"]==4294967296 and q["caps"]["reservation_bytes"]==889641408,"No cap changes")
record("full227316sites1600samples30Mb_original_caps_clocks_charge")

conv=parsed("src/arggnn/american_c3_flare_convert_v1.py")
execute=function(conv,"execute")
periodic=[n for n in ast.walk(execute)if isinstance(n,ast.If)and ast.unparse(n.test)=="site % 4096 == 0"]
need(len(periodic)==1 and ast.unparse(periodic[0].body[0])=="w.adapter.budget_check_v9(w.storage, boundary=True)","Exact original4096site boundary")
worker=parsed(OLD+"/worker_entry_v1.py")
need(has_call(worker,"g.budget_check_v9")and has_call(worker,"c.guard")and has_call(worker,"d.initial_storage_transaction"),"Unchanged real worker calls")
guard=parsed("research/reviews/Relate_failed64GiB_retention_successor_source_20261017_v1/relate_failed64_retention_v1.py")
budget=function(guard,"budget_check_v9")
expected=ast.parse("def budget_check_v9(storage, *, first=False, boundary=False, required_write_bytes=0):\n with budget.v4.mutex(ROOT):\n  return check_storage_locked_v1(storage,first=first,boundary=boundary,required_write_bytes=required_write_bytes)")
need(ast.dump(budget,include_attributes=False)==ast.dump(expected.body[0],include_attributes=False),"Exact one original mutex/full locked check")
record("unchanged_author_converter_all_required_boundaries_original_guard_body")

helper=parsed("research/reviews/European_outer8_current_policy_successor_source_20261016_v1/prepare_outer000_v1.py")
gh=function(helper,"guard")
need(has_call(gh,"selector.load_selected_guard_v1")and has_call(gh,"ns.install_consumer_v1"),"Guard configured then memo installed")
loadline=min(n.lineno for n in ast.walk(gh)if isinstance(n,ast.Call)and ast.unparse(n.func)=="selector.load_selected_guard_v1")
installline=min(n.lineno for n in ast.walk(gh)if isinstance(n,ast.Call)and ast.unparse(n.func)=="ns.install_consumer_v1")
need(loadline<installline,"Configure before memo")
namespace=parsed("research/reviews/current_mutex_contention_20261015_v1/consumer_namespace_memo_v1.py")
need(has_call(function(namespace,"install_consumer_v1"),"base.TransactionMemoAdapter"),"Existing original memo2 implementation")
record("actual_consumer_namespace_memo2_already_installed_before_release")

memo=parsed("research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py")
mm=methods(memo,"TransactionMemoAdapter")
need(has_call(mm["_make_mutex"],"original")and has_call(mm["_make_mutex"],"self._validate_snapshot"),"Original mutex/final uncached validation")
need(has_call(mm["_validate_snapshot"],"self.original['canonical']")and has_call(mm["_make_file_bytes"],"original"),"Original readers remain")
need(any(isinstance(n,ast.keyword)and n.arg=="cross_operation_cache"and isinstance(n.value,ast.Constant)and n.value.value is False for n in ast.walk(mm["__init__"])),"No crossoperation cache")
need("state['raw'].clear()"in ast.unparse(mm["_make_mutex"])and "state['canonical'].clear()"in ast.unparse(mm["_make_mutex"]),"Cold transaction cleanup")
record("existing_raw_JSON_byte_memo_final_validation_cold_each_transaction")

for version in ("v1","v2"):
    p="research/reviews/ROOT_mutation_transaction_memo_source_20261017_"+version+"/root_mutation_memo_v1.py"
    rm=methods(parsed(p),"RootMutationMemo")
    public={k for k in rm if not k.startswith("_")}
    need(public=={"read_state_v1","reserve_v1"},"No supported consumer API")
    need("not hasattr(self.guard, '_outer_memo')"in ast.unparse(rm["_check"]),"No stacked consumer memo")
review=load("research/reviews/ROOT_mutation_transaction_memo_independent_20261017_v2/review.v1.json")
need(review["status"]=="SOURCE_PASS"and review["blockers"]==[]and any("caller-held-mutex"in x for x in review["accepted_scope"]),"Actual bounded component review")
record("reviewed_ROOT_mutation_memos_no_public_consumer_check_interface")

baseline=load(OLD+"/source_manifest.v1.json")
need(len(baseline["source_sha256"])==176 and len(baseline["metadata_refs"])==154,"Complete original closure")
for path,digest in baseline["source_sha256"].items():exact(dict(path=path,sha256=digest))
for rr in baseline["metadata_refs"]:exact(rr)
for rr in source_map["inspected_refs"]:exact(rr)
record("all176_inherited_source_pins154_metadata_refs_and_inspected_refs_authenticate")

need(decision["efficiency_candidate_implemented"]is False and decision["launchable_driver_or_worker_supplied"]is False,"Honest no-candidate decision")
need(not(HERE/"root_driver_v1.py").exists()and not(HERE/"worker_entry_v1.py").exists(),"No runnable source supplied")
own=parsed(str((HERE/"source_check_v1.py").relative_to(ROOT)))
imports={n.module for n in ast.walk(own)if isinstance(n,ast.ImportFrom)}
imports.update(a.name for n in ast.walk(own)if isinstance(n,ast.Import)for a in n.names)
need(imports<={"pathlib","ast","hashlib","json","statistics"}and not has_call(own,"exec")and not has_call(own,"eval"),"Stdlib source/compact metadata only")
record("source_diagnosis_only_no_runnable_successor_or_project_guard_execution")

result=dict(schema="FLARE_conversion_efficiency_source_checks_v1",status="STATIC_DIAGNOSIS_PASS_NO_EFFICIENCY_CANDIDATE",checks=checks,checks_count=len(checks),actual_boundary_pairs_reproduced=len(pairs),actual_boundary_seconds_reproduced=sum(pairs),runnable_efficiency_candidate=False,scientific_numerical_probe_payload_conversion_execution=False,actual_guard_mutex_resource_process_or_Git_operations=False)
(HERE/"source_check.result.v1.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
print(json.dumps(result,sort_keys=True))
