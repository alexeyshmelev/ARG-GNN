"""CPU-only explicit scoring of sealed TGB predictions; original science frozen."""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
import argparse,copy,hashlib,importlib.util,json,math,os,re,resource,sys,time
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/TGB_H051_CPU_sealed_evaluation_source_20261016_v1"
SOURCE=HERE+"/cpu_evaluate_v1.py"
BINDING=HERE+"/binding_v1.py"
PIN_REF={"path":HERE+"/frozen_source_refs.v1.json","sha256":"48eba8fb580342a517feace359ffab394e363775eb186cc3a946f396e8e861ef"}
BRIDGE="research/reviews/TGB_trade_H051_GPU0_runtime_source_20261016_v1"
SCIENCE="research/reviews/TGB_trade_H051_training_source_20261016_v1"
PROTOCOL=SCIENCE+"/protocol.source_frozen.inactive.v1.json"
HANDOFF={"path":SCIENCE+"/source_handoff.v1.json","sha256":"193d58c1fc29b9dbb28e8aa9c5056fb31ab769b770cdcd5aec5f2318a061f8db"}
GUARD="research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py"
POLICY="research/reviews/prospective_980GB_capacity_source_v1/activation_policy.root_active_v1.json"
REPAIR="research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json"
CHECKER="research/reviews/GPU45_TRAIN_controller_execution_override_20261016_v1/controller_metadata_scope_check_v1.py"
RENEWAL="research/reviews/H039_marker_repair_renewal_source_20261016_v1/marker_repair_renewal_v1.py"
RSS_CAP=8*2**30
OUTPUT_CAP=32*2**20
DEADLINE=7200
NAME=re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z")
sys.path[:0]=[str(ROOT),str(ROOT/"src")]

def require(ok,message):
    if not ok:raise ValueError(message)

def path(name):
    require(isinstance(name,str) and ".." not in Path(name).parts,"Contained canonical path")
    p=Path(name) if Path(name).is_absolute() else ROOT/name
    require(p.resolve()==p and p.is_relative_to(ROOT) and not p.is_symlink(),"Canonical non-symlink project path")
    return p

def is_ref(r):
    return isinstance(r,dict) and set(r) in ({"path","sha256"},{"path","sha256","bytes"}) and isinstance(r["path"],str) and isinstance(r["sha256"],str) and len(r["sha256"])==64 and all(x in "0123456789abcdef" for x in r["sha256"])

def ref(name):
    p=path(name);require(p.is_file() and p.stat().st_size<=32*2**20,"Bounded source/metadata")
    return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def read(r):
    require(is_ref(r),"Exact metadata reference")
    p=path(r["path"]);require(p.is_file() and p.stat().st_size<=32*2**20,"Bounded metadata")
    data=p.read_bytes();require(hashlib.sha256(data).hexdigest()==r["sha256"] and ("bytes" not in r or r["bytes"]==len(data)),"Exact metadata bytes")
    return json.loads(data)

def unique(rows):
    result=[]
    for r in rows:
        v=dict(path=r["path"],sha256=r["sha256"])
        if v not in result:result.append(v)
    return result

def fixed_sources_v1():
    return read(PIN_REF)["source_sha256"]

def load_exact_v1(name,label):
    pins=fixed_sources_v1()
    require(name in pins and ref(name)==dict(path=name,sha256=pins[name]),"Exact unchanged executed source before import")
    s=importlib.util.spec_from_file_location(label,path(name));m=importlib.util.module_from_spec(s)
    sys.modules[label]=m;s.loader.exec_module(m);return m

def expiry_v1(spec):
    start=datetime.fromisoformat(spec["created_at_utc"]);end=datetime.fromisoformat(spec["expires_at_utc"])
    require(start.tzinfo is not None and end.tzinfo is not None and 0<(end-start).total_seconds()<=DEADLINE
        and start.timestamp()<=time.time()<end.timestamp(),"Root absolute CPU authority at most7200s")
    return end.timestamp()

def required_bindings_v1(spec):
    rows=[dict(path=a,sha256=b) for a,b in spec["source_sha256"].items()]
    rows += [PIN_REF,spec["root_binding_request_ref"],spec["source_closure_ref"],
        spec["refs"]["config"],spec["refs"]["runtime"],spec["refs"]["cpu_caps"],
        spec["marker_repair_renewal_ref"],spec["fit_terminal_certificate_ref"],spec["heldout_target_capability_ref"]]
    rows=unique(rows)
    require(len(rows)<=64 and all(path(r["path"]).suffix in (".json",".py",".sh") for r in rows),
        "Unchanged64 direct source/metadata bindings; no payload binding substituted")
    return rows

def validate_spec_v1(spec):
    require(spec.get("schema")=="TGB_H051_CPU_sealed_evaluation_input_v1" and spec.get("status")=="active"
        and spec.get("root_authorizer")=="root_agent" and spec.get("phase")=="evaluate"
        and spec.get("split") in ("VAL","TEST") and isinstance(spec.get("job_id"),str) and NAME.fullmatch(spec["job_id"])
        and spec.get("device")=="cpu" and spec.get("physical_gpu") is None and spec.get("cuda_visible_devices")==""
        and spec.get("max_cuda_reserved_bytes")==0 and spec.get("max_cpu_rss_bytes")==RSS_CAP
        and spec.get("output_cap_bytes")==OUTPUT_CAP and spec.get("operational_deadline_seconds")==DEADLINE
        and spec.get("fit_authorized") is False and spec.get("model_execution_authorized") is False
        and spec.get("checkpoint_reads_authorized") is False and spec.get("replay_authorized") is False
        and spec.get("scope_checker_reuse_for_complete_evaluation_scope_root_authorized") is True
        and spec.get("frozen_scientific_handoff_ref")==HANDOFF
        and spec.get("runtime_entry_ref")==ref(SOURCE)
        and spec.get("scientific_entry_ref")==ref(SCIENCE+"/evaluation_v1.py"),
        "Separate strict root CPU-only sealed evaluation authority")
    request=read(spec["root_binding_request_ref"])
    require(request.get("schema")=="TGB_H051_CPU_evaluation_binding_request_v1"
        and request.get("status")=="active" and request.get("root_authorizer")=="root_agent"
        and all(request[k]==spec[k] for k in ("job_id","split","device","created_at_utc","expires_at_utc",
            "output_directory","max_cuda_reserved_bytes","max_cpu_rss_bytes","output_cap_bytes",
            "operational_deadline_seconds","scope_checker_reuse_for_complete_evaluation_scope_root_authorized",
            "fit_terminal_certificate_ref","heldout_target_capability_ref","marker_repair_renewal_ref")),
        "Exact root authorizing request and generated CPU input")
    expiry_v1(spec)
    require(is_ref(spec.get("fit_terminal_certificate_ref")) and is_ref(spec.get("heldout_target_capability_ref"))
        and is_ref(spec.get("marker_repair_renewal_ref")),"Independent genuine fit, heldout split and authentic guard-renewal refs")
    require(spec["source_sha256"]==dict(fixed_sources_v1(),**{
        SOURCE:ref(SOURCE)["sha256"],BINDING:ref(BINDING)["sha256"],
        PIN_REF["path"]:PIN_REF["sha256"],spec["root_binding_request_ref"]["path"]:spec["root_binding_request_ref"]["sha256"]}),
        "Only exact original science/guard/readers plus actual CPU runtime metadata sources")
    closure=read(spec["source_closure_ref"])
    require(closure.get("schema")=="TGB_H051_CPU_exact_source_closure_v1"
        and closure["source_sha256"]==spec["source_sha256"] and closure["frozen_scientific_handoff_ref"]==HANDOFF,
        "Exact truthful CPU/original source closure")
    for name,sha in spec["source_sha256"].items():require(ref(name)==dict(path=name,sha256=sha),"Every declared source/metadata exact")
    require(read(spec["refs"]["config"])==read(dict(path=PROTOCOL,sha256=fixed_sources_v1()[PROTOCOL])),
        "Original frozen scientific protocol unchanged")
    caps=read(spec["refs"]["cpu_caps"])
    require(caps==dict(device="cpu",max_cuda_reserved_bytes=0,max_cpu_rss_bytes=RSS_CAP,
        operational_deadline_seconds=DEADLINE,output_cap_bytes=OUTPUT_CAP),"Exact explicit CPU caps")
    runtime=read(spec["refs"]["runtime"])
    require(runtime=={k:spec[k] for k in ("job_id","split","output_directory","device","physical_gpu",
        "cuda_visible_devices","created_at_utc","expires_at_utc","operational_deadline_seconds")},
        "Exact CPU runtime metadata and absolute expiry")
    storage=read(spec["refs"]["storage"]);bindings=storage["reservation"]["consumer_bindings"]
    require(storage.get("kind")=="project_budget_v9_storage_record" and storage.get("active") is True
        and storage.get("consumer_uses_v9_guard") is True and storage.get("accounting_mode")=="prospective_980gb_v1"
        and storage["job_id"]==spec["job_id"] and storage["output_directory"]==spec["output_directory"]
        and storage["reserved_new_bytes"]==storage["reservation"]["reserved_bytes"]==OUTPUT_CAP
        and storage["reservation"]["auxiliary_scopes"]==[] and storage["reservation"]["output"]==str(path(spec["output_directory"]))
        and storage["expires_at_utc"]==spec["expires_at_utc"] and len(bindings)<=64
        and all(r in bindings for r in required_bindings_v1(spec)),"Exact fully charged separate32MiB/noaux CPU evaluation scope")
    require(path(spec["output_directory"]).parent.is_dir(),"Existing output parent; no uncharged ancestor creation")
    return storage

def operational_v1(spec):
    storage=validate_spec_v1(spec)
    require(not path(spec["output_directory"]).exists(),"Fresh independent CPU output, no overwrite/resume")
    require("torch" not in sys.modules and "torch_geometric" not in sys.modules,"Fresh interpreter before numerical imports")
    os.environ["CUDA_VISIBLE_DEVICES"]=""
    # Install only the authentic existing guard renewal, never issue an authority.
    renewal=load_exact_v1(RENEWAL,"_TGB_CPU_original_marker_renewal")
    renewal.install_renewal_v1(spec["marker_repair_renewal_ref"])
    certificate,_=renewal.validate_certificate_v1(spec["marker_repair_renewal_ref"])
    require(expiry_v1(spec)<datetime.fromisoformat(certificate["renewed_expires_at_utc"].replace("Z","+00:00")).timestamp(),
        "CPU expiry fits authentic existing guard renewal")
    guard=load_exact_v1(GUARD,"_TGB_CPU_original_980_guard")
    guard.configure_v2(dict(path=REPAIR,sha256=fixed_sources_v1()[REPAIR]),
        policy_ref=dict(path=POLICY,sha256=fixed_sources_v1()[POLICY]))
    checker_module=load_exact_v1(CHECKER,"_TGB_CPU_unchanged_ownscope_checker")
    checker=checker_module.ControllerMetadataScopeV1(guard,storage)
    # Unchanged checker constructor performs the one full original startup guard.
    started=time.monotonic();end=expiry_v1(spec);torch_module=None
    def check(stage):
        require(isinstance(stage,str) and stage,"Explicit CPU evaluation boundary")
        require(os.environ.get("CUDA_VISIBLE_DEVICES")=="","CPU visibility remains empty")
        require(time.monotonic()-started<DEADLINE and time.time()<end,"Original finite CPU deadline and absolute expiry")
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=RSS_CAP,"Current/peak self RSS within8GiB")
        if torch_module is not None:require(torch_module.cuda.is_initialized() is False,"No CUDA context initialized")
    check("before_numerical_imports")
    import torch
    require(torch.__version__=="2.6.0+cu124" and torch.cuda.is_initialized() is False,"Pinned Torch CPU operations with no CUDA initialization")
    torch_module=torch;check("after_CPU_only_import")
    return dict(checker=checker,runtime_check=check,storage=storage)

def writer_v1(spec,operational):
    original=load_exact_v1(SCIENCE+"/artifact_writer_v1.py","_TGB_CPU_original_JSON_writer")
    checker=operational["checker"];check=operational["runtime_check"]
    def prewrite(size):
        check("before_actual_CPU_result_write")
        require(type(size) is int and 0<=size<=OUTPUT_CAP-65536,"Bounded exact JSON plus block/directory allowance")
        checker.check(required=size+65536)
    class CPUWriterV1(original.DirectoryArtifactWriterV1):
        def _json(self,name,value):
            raw=json.dumps(value,indent=2,sort_keys=True)+"\n";prewrite(len(raw.encode()))
            result=super()._json(name,value);checker.check(required=0);return result
        def begin_run(self,protocol):
            prewrite(0);result=super().begin_run(protocol)
            self._json("runtime_binding.json",dict(schema="TGB_H051_CPU_actual_evaluation_runtime_binding_v1",
                input_ref=spec["input_ref"],storage_ref=spec["refs"]["storage"],runtime_entry_ref=ref(SOURCE),
                scientific_entry_ref=spec["scientific_entry_ref"],frozen_scientific_handoff_ref=HANDOFF,
                source_closure_ref=spec["source_closure_ref"],split=spec["split"],device="cpu",physical_gpu=None,
                CUDA_VISIBLE_DEVICES="",CUDA_context_initialized=False,GPU_lease_or_title_required=False,
                original_fit_terminal_ref=ref(BRIDGE+"/fit_terminal_v1.py"),
                original_heldout_reader_ref=ref(BRIDGE+"/heldout_targets_v1.py"),
                original_scope_checker_ref=ref(CHECKER),
                scope_checker_reuse_for_complete_evaluation_scope_root_authorized=True))
            return result
        def save_initial(self,*a,**k):raise ValueError("CPU evaluation cannot write model state")
        def save_final(self,*a,**k):raise ValueError("CPU evaluation cannot write model state")
        def seal_predictions(self,*a,**k):raise ValueError("CPU evaluation reads an existing prediction seal")
        def write_fit_receipt(self,*a,**k):raise ValueError("CPU evaluation cannot claim a fit")
    return CPUWriterV1(path(spec["output_directory"]))

def run_v1(input_ref):
    spec=read(input_ref);spec["input_ref"]=input_ref
    op=operational_v1(spec)
    try:
        # Exact original gates/loader are reused. Class definitions may import
        # trainer/model modules; no model construction, checkpoint, fit or replay.
        targets_module=load_exact_v1(BRIDGE+"/heldout_targets_v1.py",
            "research.reviews.TGB_trade_H051_GPU0_runtime_source_20261016_v1.heldout_targets_v1")
        targets=targets_module.HeldoutTargetsV1(spec["heldout_target_capability_ref"],spec["split"],
            spec["fit_terminal_certificate_ref"],op["runtime_check"])
        protocol=read(spec["refs"]["config"]);writer=writer_v1(spec,op);writer.begin_run(protocol)
        baseline_ref=protocol["source_refs"]["H052_results"];baseline=read(baseline_ref)
        evaluator=load_exact_v1(SCIENCE+"/evaluation_v1.py",
            "research.reviews.TGB_trade_H051_training_source_20261016_v1.evaluation_v1")
        result=evaluator.evaluate_sealed_split_v1(targets.bundle,split=spec["split"],
            load_target_year=targets.load_target_year_v1,baseline_results=baseline,baseline_result_ref=baseline_ref,
            writer=writer,runtime_check=op["runtime_check"],protocol=protocol)
        completed=writer._json("evaluation_completed.json",dict(schema="TGB_H051_CPU_explicit_split_completed_v1",
            input_ref=input_ref,split=spec["split"],device="cpu",fit_terminal_certificate_ref=spec["fit_terminal_certificate_ref"],
            heldout_target_capability_ref=spec["heldout_target_capability_ref"],
            frozen_confirmation_decision_ref=targets.cap.get("frozen_confirmation_decision_ref"),
            original_evaluation_result_ref=result,prediction_seal_ref=targets.bundle.seal_ref,
            retained_prediction_payload_reconstructed=True,model_or_training_replay=False,optimization_performed=False,
            selection_on_TEST=False,CUDA_context_initialized=False))
        op["runtime_check"]("CPU_evaluation_completed");op["checker"].check(required=0)
        print(json.dumps(dict(status="TGB_CPU_sealed_split_evaluated",split=spec["split"],completed_ref=completed,
            actual_execution=True,device="cpu",model_or_training_replay=False)),flush=True)
        return 0
    finally:op["checker"].memo.uninstall()

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--execute",action="store_true")
    p.add_argument("--input");p.add_argument("--expected-input-sha256");a=p.parse_args(argv)
    if not a.execute:
        print(json.dumps(dict(status="source_only_not_activated",device="cpu")));return 0
    require(a.input and a.expected_input_sha256,"Explicit root input and exact SHA")
    return run_v1(dict(path=a.input,sha256=a.expected_input_sha256))
if __name__=="__main__":raise SystemExit(main())
