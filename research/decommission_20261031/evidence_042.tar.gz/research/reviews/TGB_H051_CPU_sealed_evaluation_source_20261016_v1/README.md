# CPU-only evaluation of sealed TGB H051 predictions

Source only. Root owns admissions, execution, supervision and genuine terminal
evidence. This is an operational hardware change to evaluation of the same
sealed predictions and frozen protocol. No fit, checkpoint load, forward pass,
replay, optimizer, metric change or new experiment is introduced.

The exact sealed sibling fit_terminal_v1 validator, HeldoutTargetsV1, its
prediction bundle loader and label reader are reused unchanged. The original
evaluate_sealed_split_v1, TargetYearV1 and sklearn1.9.1 NDCG/support aggregation
remain unchanged. The original loader may import trainer/model modules to
obtain existing class definitions and its CPU prediction data container.
Imports are distinct from executing a model: this adapter never instantiates a
model, reads checkpoints, calls forward, trains, replays or refits.

A genuine TGB METHOD wait0 and owned drain certificate is sufficient. The
original validator authenticates the immutable exact fit row, controller/input
mapping, full prediction seal and payload. Other logical jobs may still be
running in that same pool; this CPU entry adds no whole-pool shutdown or
controller-terminal requirement. The snapshot must satisfy the original
unambiguous healthy-registry gate. A submission client0 never proves completion.

VAL and TEST require separate active original heldout capabilities. TEST keeps
the exact original frozen confirmation decision gate. Full255 predictions,
artifact SHA and full score-payload SHA are authenticated before any heldout
label member opens. No selection on TEST is introduced.

## CPU execution and charged output

The strict root input uses device cpu, physical_gpu null, zero CUDA bytes,
empty CUDA visibility,8GiB RSS and at most7200s absolute/monotonic authority.
Execution requires a fresh interpreter, sets CUDA_VISIBLE_DEVICES empty before
numerical imports, and checks torch.cuda.is_initialized() is false at every
runtime boundary. It neither requires nor calls a GPU lease, title, device
selection, CUDA allocation or GPU process check. Existing GPU class-definition
imports do not grant device execution.

Every split uses a separate fully charged32MiB reservation with no auxiliary
scopes. The unchanged ControllerMetadataScopeV1 constructor performs the
original full startup storage guard once. Its original ownscope check guards
each exact JSON write, under the original mutex, source/expiry/journal and
scope-cap rules. Root explicitly authorizes reuse for the complete charged
evaluation output. There are no auxiliary credits or global-projection claims.

The writer subclasses the original DirectoryArtifactWriterV1. Its original
exclusive JSON/fsync and write_evaluation methods emit results; only bounded
prewrite/afterwrite checks and a truthful CPU runtime_binding.json are added.
Model/checkpoint/prediction-seal/fit writing methods are disabled. The original
memo wrapper is uninstalled in finally after evaluation. Runtime callbacks
check time, peak self RSS and no CUDA initialization; root owns actual process
supervision and the outer timeout.

## Root metadata and execution order

Create new root files outside this sealed packet. The inactive request template
is deliberately unusable until root fills actual identities, capabilities,
absolute times and authorization.

1. Consume the genuine fit METHOD wait0/owned-drain evidence and bind its
existing exact fit_terminal_v1 certificate. The pool may continue other jobs.
2. Create the original independent VAL or TEST heldout capability; TEST requires
the original confirmation decision frozen while TEST remained closed.
3. Write the active CPU binding request using the exact32MiB/8GiB/7200s limits
and an authentic existing marker-repair renewal ref. No certificate is issued
or renewed by this adapter.
4. Call binding_v1.prepare_input_metadata_v1(request_ref,fresh_metadata_folder).
It writes source/runtime/caps metadata only and returns56 direct bindings.
No guard, admission, numerical import or data loader is called.
5. Root admits the returned32MiB/noaux scope, preserving the64 direct limit.
Call binding_v1.finalize_input_v1(draft_ref,storage_ref,metadata_folder) to
authenticate metadata/source bindings and write input.json.
6. In a fresh root-owned process, run the exact cpu_evaluate_v1.py with
--execute --input PATH --expected-input-sha256 SHA. Root records its real
terminal exit and retains evaluation_completed.json plus original result ref.

Finalization hashes declared immutable source/metadata, including the frozen
H052 reference artifacts, but does not parse prediction/checkpoint/label
payloads. Execution alone reads the sealed predictions and original archive,
under the unchanged gates. Scientific result values and payloads were not
opened during this source task. The source receipt verifies Python/source pins;
other expected frozen metadata refs are left to root binding/execution.

CPU metadata authority is independent of native MLM duration. It cannot extend
or modify the completed fit, its storage, original training input, or another
job's resource/expiry authority. Guard renewal is authenticated existing
storage authority and must outlast this independent at-most2h CPU input.

## Verification

Only bounded syntax, AST and source-pin checks were run. No adapter was imported
or invoked; no fixture, guard, admission, data/model/GPU/process probe, download,
job or Git operation occurred. Numerical/runtime execution remains unverified.
All existing sealed files remain unchanged.
