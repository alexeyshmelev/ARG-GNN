"""Future root CPU metadata only; no guard, numerical/data/model or job calls."""
from pathlib import Path
import copy,json
from research.reviews.TGB_H051_CPU_sealed_evaluation_source_20261016_v1 import cpu_evaluate_v1 as c
SOURCE=c.HERE+"/binding_v1.py"

def prepare_input_metadata_v1(request_ref,folder):
    req=c.read(request_ref)
    c.require(req.get("schema")=="TGB_H051_CPU_evaluation_binding_request_v1"
        and req.get("root_authorizer")=="root_agent" and req.get("status")=="active"
        and req.get("split") in ("VAL","TEST") and req.get("device")=="cpu"
        and req.get("output_cap_bytes")==c.OUTPUT_CAP and req.get("max_cpu_rss_bytes")==c.RSS_CAP
        and req.get("operational_deadline_seconds")==c.DEADLINE
        and req.get("max_cuda_reserved_bytes")==0
        and req.get("scope_checker_reuse_for_complete_evaluation_scope_root_authorized") is True,
        "Explicit root CPU-only32MiB/8GiB/7200s evaluation and ownscope checker reuse")
    for key in ("fit_terminal_certificate_ref","heldout_target_capability_ref","marker_repair_renewal_ref"):
        c.require(c.is_ref(req.get(key)),"Exact genuine prerequisite/capability ref: "+key)
    target=c.path(folder);out=c.path(req["output_directory"])
    c.require(not target.exists() and target.parent.is_dir() and not out.exists() and out.parent.is_dir()
        and req["output_directory"].startswith("experiments/results/") and "TGB" in out.name,"Fresh CPU metadata/output and existing parents")
    sources=dict(c.fixed_sources_v1())
    for r in (c.ref(c.SOURCE),c.ref(SOURCE),c.PIN_REF,request_ref):sources[r["path"]]=r["sha256"]
    spec=dict(schema="TGB_H051_CPU_sealed_evaluation_input_v1",status="active",root_authorizer="root_agent",
        phase="evaluate",split=req["split"],job_id=req["job_id"],created_at_utc=req["created_at_utc"],
        expires_at_utc=req["expires_at_utc"],output_directory=req["output_directory"],
        device="cpu",physical_gpu=None,cuda_visible_devices="",max_cuda_reserved_bytes=0,
        max_cpu_rss_bytes=c.RSS_CAP,output_cap_bytes=c.OUTPUT_CAP,operational_deadline_seconds=c.DEADLINE,
        fit_authorized=False,model_execution_authorized=False,checkpoint_reads_authorized=False,replay_authorized=False,
        scope_checker_reuse_for_complete_evaluation_scope_root_authorized=True,
        frozen_scientific_handoff_ref=c.HANDOFF,scientific_entry_ref=c.ref(c.SCIENCE+"/evaluation_v1.py"),
        runtime_entry_ref=c.ref(c.SOURCE),source_sha256=sources,root_binding_request_ref=request_ref)
    for key in ("fit_terminal_certificate_ref","heldout_target_capability_ref","marker_repair_renewal_ref"):spec[key]=req[key]
    c.expiry_v1(spec)
    target.mkdir()
    def save(name,value):
        p=target/name;c.require(not p.exists(),"Fresh immutable metadata")
        p.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n");return c.ref(str(p.relative_to(c.ROOT)))
    runtime={k:spec[k] for k in ("job_id","split","output_directory","device","physical_gpu","cuda_visible_devices",
        "created_at_utc","expires_at_utc","operational_deadline_seconds")}
    caps=dict(device="cpu",max_cuda_reserved_bytes=0,max_cpu_rss_bytes=c.RSS_CAP,
        operational_deadline_seconds=c.DEADLINE,output_cap_bytes=c.OUTPUT_CAP)
    spec["refs"]=dict(config=c.ref(c.PROTOCOL),runtime=save("runtime.json",runtime),cpu_caps=save("cpu_caps.json",caps))
    spec["source_closure_ref"]=save("source_closure.json",dict(schema="TGB_H051_CPU_exact_source_closure_v1",
        frozen_scientific_handoff_ref=c.HANDOFF,source_sha256=sources))
    bindings=c.required_bindings_v1(spec)
    return dict(schema="TGB_H051_CPU_metadata_ready_not_admitted_v1",
        input_draft_ref=save("input_draft_without_storage.json",spec),consumer_bindings=bindings,
        reserved_new_bytes=c.OUTPUT_CAP,auxiliary_scopes=[],no_guard_admission_or_execution=True)

def finalize_input_v1(draft_ref,storage_ref,folder):
    spec=copy.deepcopy(c.read(draft_ref));c.require("storage" not in spec["refs"],"Fresh CPU draft only")
    spec["refs"]["storage"]=storage_ref;c.validate_spec_v1(spec)
    p=c.path(folder)/"input.json";c.require(not p.exists(),"Fresh final CPU input")
    p.write_text(json.dumps(spec,indent=2,sort_keys=True)+"\n");return c.ref(str(p.relative_to(c.ROOT)))
