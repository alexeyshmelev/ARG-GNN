"""Extract exact pinned writer/caller ASTs; all payloads and writes are RAM stubs."""
from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,copy
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
OUT=ROOT/'research/reviews/C3_prepared_feature_future_integration_independent_20261017_v1'
V5='research/reviews/C3_remaining_cells_GPU0_source_20261017_v5/worker_v1.py'
V6='research/reviews/C3_prepared_feature_future_integration_source_20261017_v1/worker_v1.py'
SHARED='src/arggnn/american_c3_gnn_shared30mb_isolated_v2.py'
PREDICT='src/arggnn/american_c3_gnn_predict_isolated_v2.py'
def ref(name):
 p=ROOT/name
 return dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def require(ok,label):
 if not ok:raise ValueError(label)
def get(tree,name):return next(n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name==name)
def compile_nodes(nodes,env):exec(compile(ast.Module(body=copy.deepcopy(nodes),type_ignores=[]),'<independent_RAM_exact_AST>','exec'),env)
class RAMPath:
 def __truediv__(self,name):return self
 def exists(self):return False
parent='american_c3_val_000';training_ref=dict(path='RAM/training.json',sha256='a'*64)
training=dict(trained_parent_ids=['RAM/train'],protocol_sha256='a'*64)
checkpoint=dict(path='RAM/checkpoint',sha256='b'*64)
plan=dict(parent_id=parent,focal_registry_ref=dict(path='RAM/focals',sha256='c'*64))
loaders=[SimpleNamespace(dataset=SimpleNamespace(plan_ref=dict(path='RAM/plan',sha256='d'*64),plan=plan,direction=d))for d in ('forward','reverse')]
predict_node=get(ast.parse((ROOT/PREDICT).read_text()),'seal_prediction_v1')
shared_node=get(ast.parse((ROOT/SHARED).read_text()),'seal_shared_val_prediction_v1')
wrapper_node=get(shared_node,'DisclosedWriter')
results=[]
for name in [V5,V6]:
 calls=[];boundaries=[]
 c=SimpleNamespace(require=require,local=lambda _:RAMPath())
 env=dict(Path=Path,c=c,json=json,require=require,training=training,DEVELOPMENT_BRANCH='RAM/original_disclosure',LENGTH=30000000,
  VAL=(parent,),TEST=(),CLASSES=('EUR','EAS','AFR'),require_baseline_v1=lambda m:None,
  eligible_checkpoint_v1=lambda *args:(training,dict(epoch=30,global_step=600)),
  validate_plan_v1=lambda *a,**kw:None,streamed_focal_predictions=lambda *a,**kw:({'RAM_probability_payload':True},{}),
  registry=lambda r:{'RAM_original_registry':True},verify_prediction=lambda *a: calls.append(dict(event='original_prediction_identity_check')),
  identity_sha=lambda r:'e'*64,shutdown_dataloader=lambda l:dict(drained=True))
 compile_nodes([get(ast.parse((ROOT/name).read_text()),'GuardedWriter'),predict_node],env)
 actual=env['GuardedWriter'](dict(output_directory='RAM'),{},None,None)
 actual.boundary=lambda *a,**kw:boundaries.append(dict(args=a,kwargs=kw))
 class RAMScientificWriter:
  def save(self,filename,value,kind=None):
   calls.append(dict(event='shared_wrapper_delegate',name=filename,kind=kind))
   if kind=='npz':return dict(path='RAM/predictions.npz',sha256='f'*64)
   return actual.save(filename,value,kind=kind)
 env['writer']=RAMScientificWriter();compile_nodes([wrapper_node],env)
 try:
  env['seal_prediction_v1'](object(),*loaders,split='val',parent_id=parent,checkpoint_ref=checkpoint,
   training_completion_ref=training_ref,writer=env['DisclosedWriter'](),device='RAM',runtime_guard=lambda e:None)
 except ValueError as exc:
  error=str(exc)
 else:raise AssertionError('Exact sealed writer unexpectedly accepted original JSON caller')
 require(error.startswith('Only actual small JSON/NPZ writes'),'Expected exact original writer dispatch failure')
 require(calls[-1]['kind']=='json'and calls[-1]['name'].endswith('_prediction_seal.json'),'Exact unchanged shared JSON wrapper')
 require(calls[-2]['kind']=='npz','NPZ caller precedes JSON caller')
 require(boundaries==[],'JSON rejected before any storage/write boundary')
 results.append(dict(worker_ref=ref(name),outcome='BLOCKED_JSON_KIND_DISPATCH',exception_type='ValueError',message=error,
  exact_original_predictor_and_nested_shared_writer_AST_executed=True,calls=calls,actual_scientific_payloads_read=0,
  actual_NPZ_serialization_or_filesystem_write=False,JSON_write_boundary_calls=0))
result=dict(schema='C3_current_v5_and_candidate_v6_independent_RAM_seal_dispatch_v1',results=results,
 source_refs=[ref(n)for n in [V5,V6,SHARED,PREDICT]],no_operational_module_imports=True,no_model_or_array_execution=True,
 runtime_process_guard_state_mutex_probes=0,GPU_operations=0,Git_actions=0,actual_observation_truth_checkpoint_reads=0,
 interpretation='If original inference and NPZ serialization succeed, both pinned writers fail at JSON sealing. A possible real raw NPZ is unsealed and is not stage completion, all30 release or scientific success.')
with (OUT/'seal_dispatch_RAM.result.v1.json').open('x')as f:f.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status='CONFIRMED_BLOCKER',cases=len(results),result_ref=ref(str((OUT/'seal_dispatch_RAM.result.v1.json').relative_to(ROOT))))))
