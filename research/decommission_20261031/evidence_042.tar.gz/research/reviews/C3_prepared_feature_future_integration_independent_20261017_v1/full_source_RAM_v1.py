"""Independent full inactive-route source/metadata and extracted-AST RAM checks only."""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone
import ast,copy,hashlib,json,collections
R=Path('/workspace-SR003.nfs2/ARG-GNN');D=R/'research/reviews/C3_prepared_feature_future_integration_source_20261017_v1';O=R/'research/reviews/C3_prepared_feature_future_integration_independent_20261017_v1';OLD=R/'research/reviews/C3_remaining_cells_GPU0_source_20261017_v5'
checks=[];negative=[];findings=[]
def require(ok,label):
 if not ok:raise ValueError(label)
def check(ok,label):
 require(ok,label);checks.append(label)
def reject(fn,label):
 try:fn()
 except (ValueError,KeyError,TypeError,AssertionError)as e:negative.append(dict(case=label,message=str(e)));return
 raise AssertionError('Unexpected acceptance: '+label)
def ref(path):
 p=Path(path);p=p if p.is_absolute()else R/p
 return dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read_metadata(row):
 check(ref(row['path'])==row,'hash '+row['path'])
 return json.loads((R/row['path']).read_text())
def get(t,name):return next(n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name==name)
def extract(t,names,env):
 for n in names:exec(compile(ast.Module(body=[copy.deepcopy(get(t,n))],type_ignores=[]),'<independent_RAM_'+n+'>','exec'),env)
m=json.loads((D/'source_manifest.v1.json').read_text());pins=json.loads((D/'pins.v1.json').read_text());trees={n:ast.parse((D/n).read_text())for n in ('contract_v1.py','worker_v1.py','execution_v1.py')}
refs=m['executed_source_refs']+m['source_authentication_refs'];check(len(refs)==479 and len({r['path']for r in refs})==479,'479 distinct sealed source/metadata refs')
for row in refs:
 require(Path(row['path']).suffix in ('.py','.json','.md','.patch'),'No scientific payload in source closure')
 require(ref(row['path'])==row,'All sealed hashes exact: '+row['path'])
check(True,'All479 exact source closure hashes, no operational imports')
for p in D.glob('*.py'):ast.parse(p.read_text())
check(len(m['executed_source_refs'])==5,'Five actually executed refs')
component=read_metadata(pins['feature_review'])
check(component['independent']is True and component['verdict']=='SOURCE_PASS'and component['blockers']==[],'Genuine component-only SOURCE_PASS')
check(component.get('candidate_ref')==pins['feature_component']and component.get('source_ref',component.get('component_ref'))is None,'Actual component review candidate_ref incompatible with v1 validator')
# Execute the actual failing component-consumption require, with only immutable review metadata.
validation=get(trees['contract_v1.py'],'validate_request_v1')
component_require=next(n for n in validation.body if isinstance(n,ast.Expr)and isinstance(n.value,ast.Call)and any(isinstance(x,ast.Constant)and x.value=='Exact accepted v3 component, separate from whole integration review'for x in ast.walk(n)))
env=dict(require=require,component=component,pins_v1=lambda:copy.deepcopy(pins))
reject(lambda:exec(compile(ast.Module(body=[copy.deepcopy(component_require)],type_ignores=[]),'<exact_component_review_consumer>','exec'),env),'B1 exact review schema rejects before prepare namespace creation/reserve')
# Verify current v5 and candidate direct-role/body preservation against source, never imports.
oldtrees={n:ast.parse((OLD/n).read_text())for n in ('contract_v1.py','worker_v1.py','execution_v1.py')}
unchanged_exec=[]
for node in trees['execution_v1.py'].body:
 if isinstance(node,(ast.FunctionDef,ast.ClassDef))and node.name not in ('_same_source_direct_v6','worker_v1','execute_v1'):
  check(ast.dump(node,include_attributes=False)==ast.dump(get(oldtrees['execution_v1.py'],node.name),include_attributes=False),'Unchanged original caller/lifecycle AST '+node.name);unchanged_exec.append(node.name)
embedded=ast.literal_eval(next(n.value for n in trees['execution_v1.py'].body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='_DIRECT_SOURCE_V6'))
check(embedded==(OLD/'direct_gpu0_v1.py').read_text().replace(str(OLD.relative_to(R)),str(D.relative_to(R))).replace(str(OLD.relative_to(R)).replace('/','.'),str(D.relative_to(R)).replace('/','.')),'Byte-exact embedded direct attachment after namespace substitution')
embedded_hash=ast.literal_eval(next(n.value for n in trees['execution_v1.py'].body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='_DIRECT_SOURCE_V6_SHA'))
check(hashlib.sha256(embedded.encode()).hexdigest()==embedded_hash,'Embedded direct source digest enforced')
# Static source consolidation preserves every previously admitted role other than exact5 replacement.
v5input=read_metadata(pins['preserved_v5_VAL000_input']);v5storage=read_metadata(v5input['refs']['storage']);oldm=read_metadata(pins['preserved_v5_manifest'])
bindings=v5storage['reservation']['consumer_bindings'];oldexecuted=oldm['executed_source_refs'];replaced=[r for r in bindings if r not in oldexecuted]+m['executed_source_refs']
check(all(r in bindings for r in oldexecuted),'Old storage really bound all5 original executed sources')
check(len({(r['path'],r['sha256'])for r in bindings})==len({(r['path'],r['sha256'])for r in replaced})==64,'Actual static5to5consolidation keeps64direct refs')
check(all(r in replaced for r in bindings if r not in oldexecuted),'Every other old direct role retained')
source=(D/'contract_v1.py').read_text();check('list(state[3].values()),direct_refs_v1(q,request_ref,config_ref)'in source,'ROOT preparation unions every returned current role')
guard=ast.parse((R/pins['pins']['CENSUS_GUARD']['path']).read_text());gsource=ast.unparse(get(guard,'consumer_bindings_v1'))
check('len(result) <= 64'in gsource and '_raw(record)'in gsource,'Actual Census consumer union hashes refs and rejects over64')
selector=read_metadata(pins['pins']['CENSUS_SELECTOR']);check(selector['source_ref']==pins['pins']['CENSUS_GUARD']and selector['accounting_mode']=='Census_observation_two_scope_retention_v1','Exact current explicit Census route, no fallback')
verification=read_metadata(pins['pins']['CENSUS_VERIFICATION']);check(verification['actual_direct_guard_roles']==47 and verification['all_parent_pins_and_46roles_preserved']is True,'Existing published47guard-role receipt, not a fresh state observation')
# Original immutable election/cardinality and metadata-derived cache bounds.
q=read_metadata(v5input['root_stage_request_ref']);election=read_metadata(q['cell_election_ref'])
check(sum(len(v['retained_prediction_seal_refs'])for v in election['parents'].values())==27,'Actual original27retained cells')
check({p:v['pending_epochs']for p,v in election['parents'].items()}=={f'american_c3_val_{i:03d}':([30]if i<3 else [])for i in range(5)},'Exact original only3epoch30pending cells')
retained_seals=[]
for parent,v in election['parents'].items():
 for row in v['retained_prediction_seal_refs']:
  s=read_metadata(row);require(s['parent_id']==parent and s['records']==10000 and s['private_truth_opened']is False,'Retained full pretruth metadata');retained_seals.append(row)
check(len(retained_seals)==27,'All27original seal metadata verified without NPZ payloads')
V=tuple('american_c3_val_%03d'%i for i in range(5));E=(5,10,15,20,25,30);OWN=dict(pending=1024,discoveries=2**28,groups=65536,adopted_waits=2**28,history_rows=16)
ram={};key=lambda row:json.dumps(row,sort_keys=True)
def put(name,value):
 row=dict(path='RAM/'+name+'.json',sha256=hashlib.sha256(name.encode()).hexdigest());ram[key(row)]=copy.deepcopy(value);return row
training=put('training',{});env=dict(require=require,VAL=V,EPOCHS=E,OWNED_LIMITS_V8=OWN,PARENT='American_C3_short20_TRAIN_original5VAL',CLASSES=('EUR','EAS','AFR'),MANIFEST=str((D/'source_manifest.v1.json').relative_to(R)),DRIVER=str((D/'execution_v1.py').relative_to(R)),ref=ref,pins_v1=lambda:copy.deepcopy(pins),tref_v1=lambda:training,read=lambda row:copy.deepcopy(ram[key(row)]))
extract(trees['contract_v1.py'],['owned_drain_values_v2','new_stage_values_v1','_complete_plan_metadata_v6','validate_all_original_plan_joins_v6','per_parent_source_policy_v6'],env)
bounds_env=dict(c=SimpleNamespace(require=require));extract(trees['worker_v1.py'],['feature_cache_bounds_v6'],bounds_env)
plans={};cache_bounds={}
for parent,row in pins['original_plan_refs'].items():
 plan=read_metadata(row);env['_complete_plan_metadata_v6'](plan,parent_id=parent,length_bp=30000000);ram[key(row)]=plan;plans[parent]=plan
 if parent in V[1:3]:cache_bounds[parent]=bounds_env['feature_cache_bounds_v6'](plan)
check(cache_bounds[V[1]]['cache_tensor_upper_bound_bytes']==56406290944 and cache_bounds[V[2]]['cache_tensor_upper_bound_bytes']==57762078784,'Independent52.53/53.80GiBsource equations below fixed64GiB')
check(all(v['cache_tensor_cap_bytes']==64*2**30 and v['layout_tensor_cap_bytes']==32*2**20 and v['auxiliary_tensor_cap_bytes']==8*2**20 and v['feature_temporary_allowance_bytes']==64*2**20 and v['Python_allowance_bytes']==2*2**30 and v['original_CPU_RSS_cap_bytes']==128*2**30 and v['full_RSS_fit_measured']is False for v in cache_bounds.values()),'All fixed cache/layout/focal/temporary/Python/RSS allowances disclosed')
# Full original wait/drain function runs in RAM, unlike author source stub.
def history(count,rows=None):return dict(count=count,first=list(rows or []),last=list(rows or []),ordered_chain_sha256='a'*64,full_historical_roster_serialized=False)
def good_wait(driver):
 row=dict(pgid=100,absent=True)
 return dict(schema='C3_remaining_cells_actual_wait_v2',owned_roster_policy_ref=driver,owned_roster_policy=OWN,
  ownership=dict(complete_owned_roster_known=True,owned_roster_truncated=False,current_owned_identities=[],limits=OWN,
   retired_exact_identities_confirmed_absent_or_replaced=True,discovered_identity_history=history(1),retired_identity_history=history(1),
   reused_numeric_PID_history=history(0),group_count=1,retirement_reasons=dict(absent=1,replaced=0)),
  group_absence_summary=dict(all_owned_groups_observed_absent=True,scan_finished_within_deadline=True,errors=[],expected_group_count=1,observed_group_count=1,absent_group_count=1,history=history(1,[row])),
  adopted_waits=dict(history(0),nonzero_returncodes=0),owned_identity_absence=True,group_observations_summarized=True,group_observations=[row,row],
  returncode=0,actual_direct_worker_wait=True,actual_OS_wait_status=0,all_owned_processes_and_groups_drained=True,
  complete_owned_roster_known=True,operational_failure=None)
cases=[]
for idx,parent in enumerate(V[:3]):
 mf=pins['preserved_v5_manifest']if idx==0 else ref(env['MANIFEST']);driver=pins['preserved_v5_execution']if idx==0 else ref(env['DRIVER'])
 inp=pins['preserved_v5_VAL000_input']if idx==0 else dict(path='RAM/input'+str(idx),sha256=str(idx)*64);out='RAM/out'+str(idx)
 seal=put('out'+str(idx)+'/seal',dict(epoch=30,parent_id=parent,training_completion_ref=training,private_truth_opened=False,prediction_ref=dict(path=out+'/predictions.npz',sha256='f'*64)))
 result=put('result'+str(idx),dict(status='sealed_C3_original_remaining_cells',parent_id=parent,epochs=[30],training_completion_ref=training,cell_election_ref=q['cell_election_ref'],private_truth_opened=False,prediction_seal_refs=[seal]))
 review=put('review'+str(idx),dict(independent=True,verdict='SOURCE_PASS',blockers=[],candidate_manifest_ref=mf))
 req=put('request'+str(idx),dict(source_manifest_ref=mf,phase='predict_val_'+parent[-3:],cell_election_ref=q['cell_election_ref'],parent_id=parent,pending_epochs=[30],source_review_ref=review))
 ram[key(inp)]=dict(root_stage_request_ref=req,source_manifest_ref=mf,phase='predict_val_'+parent[-3:],output_directory=out)
 done=put('done'+str(idx),dict(status='completed_C3_remaining_cells',parent_id=env['PARENT'],original_VAL_parent_id=parent,child_input_ref=inp,actual_execution_source_manifest_ref=mf,cell_election_ref=q['cell_election_ref'],epochs=[30],training_completion_ref=training,query_ancestry_truth_opened=False,result_ref=result))
 wait=put('wait'+str(idx),dict(good_wait(driver),completed_ref=done,input_ref=inp,adapter_manifest_ref=mf))
 outer=put('outer'+str(idx),dict(root_authorizer='root_agent',actual_exit_code=0,actual_terminal_consumed=True,actual_wait_ref=wait,actual_direct_worker_returncode=0,actual_tool_session_id=idx+1))
 ev=dict(input_ref=inp,completion_ref=done,wait_ref=wait,outer_ref=outer)
 check(env['new_stage_values_v1'](ev,parent,q['cell_election_ref'],[30])=={30:seal},'Exactv5/v6producer source/full-drain RAM join '+parent)
 cases.append(dict(parent=parent,evidence=ev,review=review))
for case in cases:
 ev=case['evidence'];parent=case['parent']
 mutations=[('wrong_manifest',ev['input_ref'],lambda v:v.update(source_manifest_ref=pins['preserved_v5_manifest']if parent!=V[0]else ref(env['MANIFEST']))),
  ('wrong_review_source',case['review'],lambda v:v.update(candidate_manifest_ref=dict(path='RAM/wrong',sha256='0'*64))),
  ('worker_nonzero',ev['wait_ref'],lambda v:v.update(returncode=1,actual_OS_wait_status=256)),
  ('no_consumed_outer',ev['outer_ref'],lambda v:v.update(actual_terminal_consumed=False)),
  ('wrong_owned_source',ev['wait_ref'],lambda v:v.update(owned_roster_policy_ref=dict(path='RAM/wrong',sha256='0'*64))),
  ('incomplete_roster',ev['wait_ref'],lambda v:v['ownership'].update(owned_roster_truncated=True)),
  ('nonzero_adopted_wait',ev['wait_ref'],lambda v:v['adopted_waits'].update(nonzero_returncodes=1)),
  ('missing_group_proof',ev['wait_ref'],lambda v:v['group_absence_summary'].update(observed_group_count=0))]
 for label,row,mutate in mutations:
  before=copy.deepcopy(ram[key(row)]);mutate(ram[key(row)])
  reject(lambda:env['new_stage_values_v1'](ev,parent,q['cell_election_ref'],[30]),label+' '+parent);ram[key(row)]=before
wrong=copy.deepcopy(cases[0]['evidence']);wrong['input_ref']=put('not_exact_v5_input',ram[key(wrong['input_ref'])]);reject(lambda:env['new_stage_values_v1'](wrong,V[0],q['cell_election_ref'],[30]),'Differentv5inputrejected')
reject(lambda:env['new_stage_values_v1'](cases[1]['evidence'],V[1],q['cell_election_ref'],[5,30]),'Retainedepoch5cannotbereplayed')
chosen={}
for parent in V:
 chosen[parent]={}
 for epoch in E:
  plan=plans[parent];chosen[parent][epoch]=put(parent+'/'+str(epoch),dict(parent_id=parent,epoch=epoch,block_index_ref=pins['original_plan_refs'][parent],observation_ref=plan['observation_ref'],focal_registry_ref=plan['focal_registry_ref'],records=10000,private_truth_opened=False))
check(env['validate_all_original_plan_joins_v6'](chosen)==pins['original_plan_refs'],'All5plansand30cellswith6statesRAMpositive')
bad=copy.deepcopy(chosen);del bad[V[4]][30];reject(lambda:env['validate_all_original_plan_joins_v6'](bad),'29cellsmatrixrejected')
row=chosen[V[2]][30];before=copy.deepcopy(ram[key(row)]);ram[key(row)]['block_index_ref']=pins['original_plan_refs'][V[1]];reject(lambda:env['validate_all_original_plan_joins_v6'](chosen),'Crossparentplanrejected');ram[key(row)]=before
for field in ('observation_ref','focal_registry_ref'):
 before=copy.deepcopy(ram[key(row)]);ram[key(row)][field]=plans[V[1]][field];reject(lambda:env['validate_all_original_plan_joins_v6'](chosen),field+'driftrejected');ram[key(row)]=before
# Source-only chain: original model/seal/barrier calls and recurrence/scorer sources stay exact.
calls=lambda t,name:[ast.dump(n,include_attributes=False)for n in ast.walk(t)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id==name]
for name in ('AmericanC3WholeTreeGNNV1','seal_shared_val_prediction_v1','seal_validation_matrix_v1'):
 check(calls(trees['worker_v1.py'],name)==calls(oldtrees['worker_v1.py'],name),'Original scientific callAST '+name)
check('for i in (1,2)'in source,'NewpredictphasesexcludeVAL000')
check(component['independent_evidence']['atol']==component['independent_evidence']['rtol']==2e-6 and component['independent_evidence']['tolerance_widened']is False,'Original2e-6componentdrift criterion retained')
check(component['component_only']is True and component['whole_future_route_admissible']is False,'Componentpassneverpromotedtowholeroutepass')
result=dict(schema='C3_prepared_feature_full_integration_independent_source_RAM_checks_v1',status='BLOCKED',positive=len(checks),negative=len(negative),checks=checks,negative_cases=negative,cache_bounds=cache_bounds,
 sealed_source_ref_count=len(refs),immutable_source_metadata_bytes=sum((R/r['path']).stat().st_size for r in refs),
 current_selector_ref=pins['pins']['CENSUS_SELECTOR'],static_direct_refs=64,published_current_guard_roles=47,fresh_guard_union_not_probed=True,
 exact_original_election_ref=q['cell_election_ref'],actual_arrays_observations_truth_checkpoint_reads=0,
 operational_module_imports=0,process_guard_state_mutex_resource_probes=0,admissions=0,GPU_operations=0,Git_actions=0,live_source_edits=0,
 source_bounds_are_not_measured_RSS_speed_or_accuracy=True)
with (O/'full_source_RAM.result.v1.json').open('x')as f:f.write(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status='BLOCKED',positive=len(checks),negative=len(negative),result_ref=ref(O/'full_source_RAM.result.v1.json'))))
