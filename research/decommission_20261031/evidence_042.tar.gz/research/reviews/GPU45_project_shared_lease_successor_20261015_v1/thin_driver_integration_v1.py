"""Pure command construction for an additive future root driver. Never executes."""
from pathlib import Path
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
LAUNCHER="scripts/launch_reserved_gpu45_shared_v1.py"
def shared_command_v1(capability_ref,job_id):
    return [str(ROOT/".runtime/env/bin/python"),"-B",str(ROOT/LAUNCHER),
        "run","--execute","--capability",capability_ref["path"],
        "--sha256",capability_ref["sha256"],"--job",job_id]
def cancellation_command_v1(capability_ref,job_id):
    return [str(ROOT/".runtime/env/bin/python"),"-B",str(ROOT/LAUNCHER),
        "cancel","--execute","--capability",capability_ref["path"],
        "--sha256",capability_ref["sha256"],"--job",job_id]
