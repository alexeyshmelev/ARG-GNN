#!/usr/bin/env python3
"""Thin additive launcher for reviewed logical GPU4/5 sharing; default inert."""
from arggnn.gpu45_shared_pool_v1 import main
if __name__=="__main__":raise SystemExit(main())
