"""Conditional patch checks using AST and RAM stubs only."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
import ast,copy,hashlib,json,errno
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
D="research/reviews/H058_GPU0_late_live_absence_source_20261017_v1"
B="research/reviews/H058_GPU0_full_training_successor_source_20261017_v3"
OUT=ROOT/D
rows=[]
def check(name,ok):
 if not ok:raise AssertionError(name)
 rows.append(dict(name=name,status="PASS"))
def text(p):return (ROOT/p).read_text()
def jread(p):return json.loads(text(p))
def ref(p):return dict(path=p,sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest())
def fn(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
common=ast.parse(text(D+"/common_v1.proposed.py"));direct=ast.parse(text(D+"/direct_gpu0_v1.proposed.py"))
basecommon=ast.parse(text(B+"/common_v1.py"));basedirect=ast.parse(text(B+"/direct_gpu0_v1.py"))
check("base_manifest_sealed",ref(B+"/source_manifest.v1.json")["sha256"]=="1c8e0efc286d98cf9fffeceaac640709091f9aef98a60114a512ff4c305b9354")
for candidate,base,names in ((common,basecommon,{"validate_request_v1","validate_input_v1"}),(direct,basedirect,{"controller_v1","capacity_v1","install_before_torch_v1"})):
 left=copy.deepcopy(candidate);right=copy.deepcopy(base)
 left.body=[x for x in left.body if not(isinstance(x,ast.FunctionDef) and x.name in names)]
 right.body=[x for x in right.body if not(isinstance(x,ast.FunctionDef) and x.name in names)]
 check("other_functions_unchanged_"+str(sorted(names)),ast.dump(left,include_attributes=False)==ast.dump(right,include_attributes=False))
# Restore only the six intended AST edits, then compare complete source ASTs.
x=copy.deepcopy(common)
r=fn(x,"validate_request_v1");r.args.kwonlyargs=[];r.args.kw_defaults=[];r.body.pop(0)
gate=next(n for n in r.body if isinstance(n,ast.If) and any(isinstance(z,ast.Call) and isinstance(z.func,ast.Name) and z.func.id=="validate_native_resource_disposition_v1" for z in ast.walk(n)))
next(z for z in ast.walk(gate) if isinstance(z,ast.keyword) and z.arg=="fresh").value=ast.Constant(value=True)
inp=fn(x,"validate_input_v1")
for z in ast.walk(inp):
 if isinstance(z,ast.Call) and isinstance(z.func,ast.Name) and z.func.id=="validate_request_v1":z.keywords=[]
check("common_only_intended_mode_and_forwarding_change",ast.dump(x,include_attributes=False)==ast.dump(basecommon,include_attributes=False))
x=copy.deepcopy(direct)
controller=fn(x,"controller_v1")
controller.body=[n for n in controller.body if not(isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=="group")]
capacity=fn(x,"capacity_v1")
t=capacity.body[1] if isinstance(capacity.body[1],ast.Try) else next(n for n in capacity.body if isinstance(n,ast.Try))
t.body=[n for n in t.body if not(isinstance(n,ast.Assign) and any(isinstance(z,ast.Name) and z.id in ("native","native_pids") for z in n.targets)) and not(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and len(n.value.args)>1 and isinstance(n.value.args[1],ast.Constant) and str(n.value.args[1].value).startswith("Prior native roster GPU0 PID contexts"))]
installer=fn(x,"install_before_torch_v1")
wrapped=next(n for n in installer.body if isinstance(n,ast.FunctionDef) and n.name=="validate_lease")
wrapped.body=[n for n in wrapped.body if not(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=="capacity_v1")]
check("direct_only_group_context_and_existing_capacity_boundary_change",ast.dump(x,include_attributes=False)==ast.dump(basedirect,include_attributes=False))
# Isolated actual admission native branch plus unchanged actual resource validator.
now=datetime.now(timezone.utc)
class FixedDateTime(datetime):
 @classmethod
 def now(cls,tz=None):return now if tz else now.replace(tzinfo=None)
ns=dict(Path=Path,datetime=FixedDateTime,timezone=timezone,os=SimpleNamespace(getuid=lambda:1000))
for n in common.body:
 if isinstance(n,ast.Assign):exec(compile(ast.Module(body=[n],type_ignores=[]),"<constant>","exec"),ns)
for name in ("require","active","validate_native_resource_disposition_v1"):
 exec(compile(ast.Module(body=[fn(common,name)],type_ignores=[]),"<isolated_source>","exec"),ns)
vr=dict(path="RAM/resource.json",sha256="a"*64);ar=dict(path="RAM/absence.json",sha256="b"*64)
v=jread(B+"/native_resource_disposition.INACTIVE.template.v1.json");absence=jread(B+"/native_targeted_absence.INACTIVE.template.v1.json")
oldstamp=(now-timedelta(seconds=443.077285)).isoformat()
v.update(created_at_utc=(now-timedelta(minutes=10)).isoformat(),expires_at_utc=(now+timedelta(hours=26)).isoformat(),status="resources_released",H058_job_id="H058-GPU0-v3-fulltrain-root01_oct17",observed_at_utc=oldstamp,fresh_targeted_native_absence_ref=ar,no_native_GPU0_attachment_alive=True,all_old_native_launch_resume_write_routes_permanently_revoked=True)
absence.update(observed_at_utc=oldstamp,native_known_roots_and_contexts_absent=True,no_native_GPU0_attachment_alive=True,all_exact_native_identities_and_groups_absent=True,all_old_native_launch_resume_write_routes_permanently_revoked=True)
records={vr["path"]:v,ar["path"]:absence}
for key in ("NATIVE_ROOT_DISPOSITION_REF","NATIVE_RESOURCE_WAIT_REF","NATIVE_RESOURCE_OUTER_REF","NATIVE_RESOURCE_AMENDMENT_REF"):records[ns[key]["path"]]=jread(ns[key]["path"])
ns["read"]=lambda r:records[r["path"]];ns["ref"]=ref
request=copy.deepcopy(fn(common,"validate_request_v1"))
nativebranch=next(n for n in request.body if isinstance(n,ast.If) and any(isinstance(z,ast.Call) and isinstance(z.func,ast.Name) and z.func.id=="validate_native_resource_disposition_v1" for z in ast.walk(n)))
request.body=[request.body[0],ast.Assign(targets=[ast.Name(id="q",ctx=ast.Store())],value=ast.Name(id="record",ctx=ast.Load())),nativebranch,ast.Return(value=ast.Constant(value=True))]
ast.fix_missing_locations(request);exec(compile(ast.Module(body=[request],type_ignores=[]),"<exact_admission_native_branch>","exec"),ns)
q=dict(phase="train",job_id=v["H058_job_id"],native_resource_disposition_ref=vr)
try:ns["validate_request_v1"](q)
except ValueError:check("fresh_admission_still_rejects_443second_static_proof",True)
else:raise AssertionError("fresh admission")
check("admitted_input_accepts_aged_original_static_proof",ns["validate_request_v1"](q,admitted_input=True))
try:ns["validate_request_v1"](q,admitted_input=None)
except ValueError:check("nonboolean_mode_rejected",True)
else:raise AssertionError("mode")
v["all_old_native_launch_resume_write_routes_permanently_revoked"]=False
try:ns["validate_request_v1"](q,admitted_input=True)
except ValueError:check("admitted_input_keeps_permanent_revocation_requirement",True)
else:raise AssertionError("revocation")
v["all_old_native_launch_resume_write_routes_permanently_revoked"]=True;v["expires_at_utc"]=now.isoformat()
try:ns["validate_request_v1"](q,admitted_input=True)
except ValueError:check("admitted_input_keeps_finite_native_authority",True)
else:raise AssertionError("expiry")
v["expires_at_utc"]=(now+timedelta(hours=26)).isoformat()
# Exact input call must select admitted mode; actual admission call stays default.
inputcall=next(n for n in ast.walk(fn(common,"validate_input_v1")) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="validate_request_v1")
check("input_forwards_explicit_admitted_mode",len(inputcall.keywords)==1 and inputcall.keywords[0].arg=="admitted_input" and inputcall.keywords[0].value.value is True)
driver=ast.parse(text(B+"/root_driver_v1.py"));admitcall=next(n for n in ast.walk(fn(driver,"admit_v1")) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="validate_request_v1")
check("actual_admission_keeps_default_fresh_mode",admitcall.keywords==[])
# Exact new group loop exercised with RAM OS stub only.
group_loop=next(n for n in fn(direct,"controller_v1").body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=="group")
groupfn=ast.FunctionDef(name="group_boundary",args=ast.arguments(posonlyargs=[],args=[ast.arg(arg="native")],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[copy.deepcopy(group_loop),ast.Return(value=ast.Constant(value=True))],decorator_list=[])
ast.fix_missing_locations(groupfn);groupns={}
exec(compile(ast.Module(body=[groupfn],type_ignores=[]),"<exact_targeted_group_loop>","exec"),groupns)
calls=[]
def absent(group,signal):
 calls.append((group,signal));raise ProcessLookupError(errno.ESRCH,"absent")
groupns["os"]=SimpleNamespace(killpg=absent)
check("exact_known_native_group_ESRCH_accepted",groupns["group_boundary"](v))
check("only_exact_group_zero_observation_requested",calls==[(3752065,0)])
groupns["os"].killpg=lambda group,signal:None
try:groupns["group_boundary"](v)
except ValueError:check("live_exact_native_group_rejected",True)
else:raise AssertionError("live group")
def denied(group,signal):raise PermissionError(errno.EACCES,"denied")
groupns["os"].killpg=denied
try:groupns["group_boundary"](v)
except PermissionError:check("unknown_group_permission_error_blocks",True)
else:raise AssertionError("unknown group")
# Exact new context branch reuses the already obtained full GPU inventory.
body=next(n for n in fn(direct,"capacity_v1").body if isinstance(n,ast.Try)).body
start=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and any(isinstance(z,ast.Name) and z.id=="native" for z in n.targets))
contextfn=ast.FunctionDef(name="context_boundary",args=ast.arguments(posonlyargs=[],args=[ast.arg(arg="gpu"),ast.arg(arg="q")],kwonlyargs=[],kw_defaults=[],defaults=[]),body=copy.deepcopy(body[start:start+3])+[ast.Return(value=ast.Constant(value=True))],decorator_list=[])
ast.fix_missing_locations(contextfn)
contextns=dict(require=ns["require"],validate_native_resource_disposition_v1=lambda q,fresh:v)
exec(compile(ast.Module(body=[contextfn],type_ignores=[]),"<exact_existing_inventory_native_context_branch>","exec"),contextns)
check("empty_current_GPU0_contexts_accepted",contextns["context_boundary"](dict(compute=[]),q))
check("unrelated_GPU0_context_preserved_as_external",contextns["context_boundary"](dict(compute=[dict(pid=999999)]),q))
try:contextns["context_boundary"](dict(compute=[dict(pid=v["native_process_identities"][0]["pid"])]),q)
except ValueError:check("any_prior_native_roster_GPU_context_blocks",True)
else:raise AssertionError("native context")
# Call order and no equality-changing dynamic lease result.
inner=next(n for n in fn(direct,"install_before_torch_v1").body if isinstance(n,ast.FunctionDef) and n.name=="validate_lease")
capcall=next(n for n in inner.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=="capacity_v1")
ret=next(n for n in inner.body if isinstance(n,ast.Return))
baseinner=next(n for n in fn(basedirect,"install_before_torch_v1").body if isinstance(n,ast.FunctionDef) and n.name=="validate_lease")
baseret=next(n for n in baseinner.body if isinstance(n,ast.Return))
check("live_capacity_precedes_wrapped_lease_return",capcall.lineno<ret.lineno)
check("lease_return_dict_unchanged_for_configure_fit_equality",ast.dump(ret,include_attributes=False)==ast.dump(baseret,include_attributes=False))
check("current_worker_pid_classifies_own_H058_context",any(k.arg=="worker_pid" and ast.unparse(k.value)=="os.getpid()" for k in capcall.value.keywords))
configure=fn(ast.parse(text("src/arggnn/biological_candidate.py")),"configure_fit")
leasecall=next(n for n in ast.walk(configure) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="validate_lease")
cuda_calls=[n for n in ast.walk(configure) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and ast.unparse(n.func).startswith("torch.cuda.")]
check("pinned_configure_fit_lease_boundary_precedes_firstCUDA",leasecall.lineno<min(n.lineno for n in cuda_calls))
attach=fn(direct,"attach_v1")
check("attach_uses_existing_capacity_function",any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="capacity_v1" for n in ast.walk(attach)))
check("capacity_calls_controller_without_recursive_validate_lease",not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="validate_lease" for n in ast.walk(fn(direct,"capacity_v1"))))
# Every unchanged source/resource/science/timing predicate is retained by AST restoration above.
check("actual_v3_source_manifest_still_unchanged",ref(B+"/source_manifest.v1.json")["sha256"]=="1c8e0efc286d98cf9fffeceaac640709091f9aef98a60114a512ff4c305b9354")
result=dict(schema="H058_late_live_absence_conditional_patch_AST_RAM_tests_v1",status="PASS",count=len(rows),checks=rows,
 conditional_on_actual_terminal=True,actual_terminal_observed=False,production_imports=False,live_process_or_GPU_observations=False,
 actual_guard_mutex_or_resource_calls=False,source_only=True,candidate_ref=ref(D+"/CONDITIONAL_CANDIDATE.v1.json"))
with (OUT/"checks.result.v1.json").open("x") as f:json.dump(result,f,sort_keys=True,indent=2);f.write("\n")
print(json.dumps(dict(status="PASS",count=len(rows),result_ref=ref(D+"/checks.result.v1.json")),sort_keys=True))
