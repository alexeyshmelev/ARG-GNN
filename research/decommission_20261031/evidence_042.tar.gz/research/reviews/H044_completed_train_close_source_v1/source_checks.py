"""Static source/immutable compact metadata only. Never import/execute adapter/guard."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
REL="research/reviews/H044_completed_train_close_source_v1"
OUT=ROOT/REL
SOURCE=REL+"/close_completed_train_root.py"
def sha(path):return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
def ref(path):return dict(path=path,sha256=sha(path))
def read(record):
    assert ref(record["path"])==record
    raw=(ROOT/record["path"]).read_bytes();assert len(raw)<=1048576
    return json.loads(raw)
def resolve(node,values):
    if isinstance(node,ast.Constant):return node.value
    if isinstance(node,ast.Name):return values[node.id]
    if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return resolve(node.left,values)+resolve(node.right,values)
    if isinstance(node,(ast.List,ast.Tuple,ast.Set)):
        cls={ast.List:list,ast.Tuple:tuple,ast.Set:set}[type(node)];return cls(resolve(n,values) for n in node.elts)
    if isinstance(node,ast.Dict):return {resolve(k,values):resolve(v,values) for k,v in zip(node.keys,node.values)}
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=="dict" and not node.args:
        return {k.arg:resolve(k.value,values) for k in node.keywords}
    raise ValueError(type(node).__name__)
text=(ROOT/SOURCE).read_text();tree=ast.parse(text);values={}
for node in tree.body:
    if isinstance(node,ast.Assign):
        try:value=resolve(node.value,values)
        except (ValueError,KeyError):continue
        for target in node.targets:
            if isinstance(target,ast.Name):values[target.id]=value
funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
refs={k:v for k,v in values.items() if k.endswith("_REF")}
actual_refs={k:ref(v["path"]) for k,v in refs.items()}
checks={"all_frozen_sources_and_immutable_metadata_refs_match":refs==actual_refs}
cfg,spec,storage,launch,admitted,status=(read(values[k]) for k in ("CONFIG_REF","INPUT_REF","STORAGE_REF","LAUNCH_REF","ADMITTED_REF","ROSTER_REF"))
own=storage["reservation"]
reservation_sha=hashlib.sha256(json.dumps(own,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()
checks["real_original_storage_ref_and100MB_scope"]=spec["refs"]["storage"]==values["STORAGE_REF"] and own["key"]==values["KEY"] and own["reserved_bytes"]==storage["reserved_new_bytes"]==values["CAP"]==100000000 and own["output"]==str(ROOT/values["OUTPUT"]) and own["auxiliary_scopes"]==[str(ROOT/values["AUX"])]
checks["original_input_admitted_launch_identity"]=admitted["input_ref"]==launch["input_ref"]==values["INPUT_REF"] and admitted["driver_ref"]==spec["root_driver_ref"]==values["DRIVER_REF"] and launch["launcher_pid"]==values["LAUNCHER_PID"]==2613472 and launch["launcher_start"]==values["LAUNCHER_START"]==471253709 and launch["phase"]=="train" and launch["physical_gpu"]==4
snapshot={r["role"]:r for r in status["live_original_writer_roster"]}
checks["root_and_initial_descendants_bound_from_real_snapshot"]=snapshot["root_H044_supervisor"]["pid"]==values["ROOT_PID"]==2613394 and snapshot["root_H044_supervisor"]["start"]==values["ROOT_START"]==471251695 and snapshot["scientific_H044_worker"]["pid"]==values["WORKER_PID"]==2613542 and snapshot["scientific_H044_worker"]["start"]==values["WORKER_START"]==471255666 and snapshot["approved_GPU_launcher"]["pid"]==values["LAUNCHER_PID"] and status["original_launch_ref"]==values["LAUNCH_REF"] and status["original_input_ref"]==values["INPUT_REF"]
checks["snapshot_is_not_completion_and_initial_state_matches"]=status["completed_training_claim"] is False and all(r["pass_index"]==25 and r["additional_optimizer_steps"]==800 and r["initial_state_sha256"]==values["INITIAL_STATE_SHA256"] for r in status["arms"])
worker_tree=ast.parse((ROOT/values["WORKER_REF"]["path"]).read_text())
train_fn=next(n for n in worker_tree.body if isinstance(n,ast.FunctionDef) and n.name=="run_train_v1")
result_assign=next(n for n in ast.walk(train_fn) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="result" for t in n.targets))
complete_fields={k.arg for k in result_assign.value.keywords}
checks["completion_identity_fields_come_from_actual_frozen_trainer"]=set(values["COMPLETED_IDENTITY_FIELDS"])<=complete_fields
root_tree=ast.parse((ROOT/values["DRIVER_REF"]["path"]).read_text());launch_fn=next(n for n in root_tree.body if isinstance(n,ast.FunctionDef) and n.name=="launch")
wait_assign=next(n for n in ast.walk(launch_fn) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="waited" for t in n.targets))
wait_fields={k.arg for k in wait_assign.value.keywords}
checks["actual_wait_field_names_match_original_v4"]=set(("schema","launcher_pid","launcher_start","launch_ref","returncode","actual_direct_launcher_wait","owned_group_drained","owned_process_identities","historical_owned_groups","completed_ref","phase","physical_gpu","log_ref","peak_owned_RSS_bytes","error","waited_utc"))<=wait_fields
proof_tree=ast.parse((ROOT/values["GUARD_REF"]["path"]).read_text());proof=next(n for n in proof_tree.body if isinstance(n,ast.FunctionDef) and n.name=="_proof")
field_node=next(n for n in proof.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="fields" for t in n.targets));primitive_fields=ast.literal_eval(field_node.value)
request_assign=next(n for n in ast.walk(funcs["run"]) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="request" for t in n.targets));request_args={k.arg:k.value for k in request_assign.value.keywords}
checks["exact14_field_unchanged_primitive_request_schema"]=set(request_args)==primitive_fields and len(primitive_fields)==14
checks["real_storage_empty_locator_and_actual_launcher_wait_locators"]=all(ast.literal_eval(request_args[k])==v for k,v in dict(storage_locator=[],launch_pid_locator=["launcher_pid"],wait_pid_locator=["launcher_pid"],wait_exit_locator=["returncode"]).items())
terminal=ast.get_source_segment(text,funcs["terminal_evidence"])
checks["complete30pass960update_all12_checkpoint_and_budget_gate_present"]=all(s in terminal for s in ("completed_fixed30pass_paired_TRAIN","{a:960 for a in ARMS}","len(history)==30","row[\"full_parent_updates_per_arm\"]==32","for at in PASSES:","for arm in ARMS:","marker_cache_peak_bytes","flag_cache_peak_bytes","completed[\"initial_state_sha256\"]==INITIAL_STATE_SHA256"))
checks["wait0_noerror_drained_and_all_descendants_plus_root_required"]=all(s in terminal for s in ("wait[\"returncode\"]==0","wait[\"actual_direct_launcher_wait\"] is True","wait[\"owned_group_drained\"] is True","wait[\"error\"] is None","owned_process_identities","historical_owned_groups","pids=sorted([ROOT_PID]+[r[\"pid\"] for r in owned])"))
run_text=ast.get_source_segment(text,funcs["run"])
checks["terminal_checks_and_fresh_absence_precede_guard_state_and_close"]=run_text.index("terminal_evidence(")<run_text.index("first_pids=[absence(")<run_text.index("same_scope_write_resume_revocation.json")<run_text.index("m=load_guard()")<run_text.index("m._state_locked(")<run_text.index("m.operation_draft_v1(\"close_completed\"")<run_text.index("m.apply_close_completed_v1(")
checks["all_absence_signals_are_zero_only"]=all(len(n.args)==2 and isinstance(n.args[1],ast.Constant) and n.args[1].value==0 for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ("kill","killpg"))
checks["no_Torch_science_or_accounting_import_at_module_scope"]=all(not isinstance(n,ast.ImportFrom) or n.module in ("pathlib","datetime") for n in tree.body)
checks["default_mode_returns_before_any_execution_or_terminal_read"]=ast.get_source_segment(text,funcs["main"]).index("if not args.execute:")<ast.get_source_segment(text,funcs["main"]).index("return run(")
checks["same_scope_only_revocation_and_no_outer_exit_or_H018_credit"]=all(s in run_text for s in ("revocation_applies_only_to_original_key_output_and_auxiliary_scope=True","same_config_sources_and_checkpoints_read_only_reuse_preserved=True","new_distinct_evaluation_capability_unaffected=True","outer_SSH_exit_claimed=False")) and values["KEY"].startswith("H044/") and "H018_credit_authorized=False" in text
checks["no_deletion_checkpoint_read_or_new_measurement_helper"]=not any(s in text for s in ("torch.load","unlink(","rmtree(","chmod(","measure_scopes(","apply_reserve_v1("))
checks["unchanged_credit_policy_repair_and_original_mutex_source_paths"]=values["CORE"]==storage["budget_components"]["implementation"]["sha256"] and values["BASE"]==storage["budget_components"]["launcher"]["sha256"] and values["GUARD_REF"]==storage["budget_components"]["consumer_adapter"] and values["POLICY_REF"]==storage["completed_overlay_policy_ref"] and "with m.budget.v4.mutex(ROOT):" in run_text and "m.budget.digest(own)==digest(own)" in run_text
compile(text,SOURCE,"exec");compile(Path(__file__).read_text(),__file__,"exec")
checks["source_compiles_as_text_without_execution"]=True
assert all(checks.values()),[k for k,v in checks.items() if not v]
preview=dict(schema="H044_original_completed_TRAIN_close_preview_v1",active=False,not_a_guard_operation_authority=True,
    source_only=True,execution_performed=False,expected_before=None,original_scope_cap_bytes=values["CAP"],
    known_initial_writer_snapshot_ref=values["ROSTER_REF"],known_root_supervisor=dict(pid=values["ROOT_PID"],start=values["ROOT_START"]),
    request=dict(key=values["KEY"],reservation_sha256=reservation_sha,storage_ref=values["STORAGE_REF"],storage_locator=[],
        launch_ref=values["LAUNCH_REF"],launch_pid_locator=["launcher_pid"],launch_identity=launch,
        direct_wait_ref=None,wait_pid_locator=["launcher_pid"],wait_exit_locator=["returncode"],
        wait_identity=dict(schema="H044_marker_original_direct_wait_v1",launcher_pid=values["LAUNCHER_PID"],launcher_start=values["LAUNCHER_START"],
            launch_ref=values["LAUNCH_REF"],returncode=0,actual_direct_launcher_wait=True,owned_group_drained=True,error=None,phase="train",physical_gpu=4,
            completed_ref=None,owned_process_identities=None,historical_owned_groups=None),
        completed_ref=None,completed_identity=dict(schema="H044_marker_paired_train_completion_v1",hypothesis_id="H044",status="completed_fixed30pass_paired_TRAIN",
            input_ref=values["INPUT_REF"],config_ref=values["CONFIG_REF"],core_ref=values["MODEL_REF"],arms=list(values["ARMS"]),steps={a:960 for a in values["ARMS"]},
            history=None,checkpoint_groups=None,marker_cache_peak_bytes=None,flag_cache_peak_bytes=None,VAL_truth_read=False,outer_truth_read=False),observation_ref=None),
    missing_terminal_refs_are_not_issued=True,future_root_must_rebuild_request_from_actual_terminal_records=True,credit_bytes=None,retained_bytes=None,H018_scope_credit_authorized=False)
manifest=dict(schema="H044_completed_train_close_frozen_source_metadata_v1",source_only=True,adapter_ref=ref(SOURCE),source_checker_ref=ref(REL+"/source_checks.py"),
    frozen_refs=refs,original_reservation_sha256=reservation_sha,original_scope_key=values["KEY"],original_cap_bytes=values["CAP"],
    successful_C3_pattern_ref=ref("research/reviews/American_C3_root_wave_wait_012_013_20261015_v1/close_completed_stages_root.py"))
for filename,value in (("close_request.inactive.json",preview),("source_manifest.json",manifest)):
    with (OUT/filename).open("x") as f:json.dump(value,f,indent=2,sort_keys=True);f.write("\n")
receipt=dict(schema="H044_completed_train_close_static_source_checks_v1",checks=checks,all_passed=True,adapter_ref=ref(SOURCE),source_manifest_ref=ref(REL+"/source_manifest.json"),inactive_preview_ref=ref(REL+"/close_request.inactive.json"),
    terminal_files_opened=False,project_guard_or_science_imports=False,process_GPU_or_accounting_operations=False,source_text_compilation_only=True)
with (OUT/"source_checks_receipt.json").open("x") as f:json.dump(receipt,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps(dict(checks=len(checks),all_passed=True,adapter_ref=ref(SOURCE),receipt_ref=ref(REL+"/source_checks_receipt.json"))))
