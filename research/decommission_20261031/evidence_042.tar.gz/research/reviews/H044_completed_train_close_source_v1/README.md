# Inactive source-only original H044 TRAIN close adapter

This fresh package can close exactly H044/H044-GPU4-paired-marker-train-seed101-v3 through the unchanged completed-credit-v3 primitive, after genuine completion and writer absence. It grants no execution, admission or credit now. No terminal refs were invented or read during preparation. No guard, accounting or process operation was performed.

The motivation is a possible future release of genuinely unused bytes from the original 100,000,000-byte TRAIN reservation. The current native preparation and pending evaluation do not change the evidence requirements. There is no forecast or promised credit amount. The primitive must measure the original complete retained output and auxiliary scopes once, preserve every file and derive any actual credit itself. H018 unknown-OS-exit 5MB scope is explicitly not creditable by this package; there is no H018 selection or close route.

## Exact original inputs

- Storage: research/reviews/H044_marker_resolution_root_v1/admitted_train_v3/storage.json, SHA 2dd37f960807be92c71bd0204d9800f93d5b31ab6faa059db1b171acf58438ba. The primitive storage_locator is the empty list because this file is already the storage record.
- Launch: the same packet launch.json, SHA 9b07f706ac4c3bbcd396c2643e2ab44e6ebb92fc7a164c6d4e52c4e8d81637b1. Its real PID field is launcher_pid=2613472, start=471253709. Both primitive launch_pid_locator and wait_pid_locator are [launcher_pid], and wait_exit_locator is [returncode]. No worker-PID alias is substituted.
- Original input: d34005aca334f6313494fa0f67061dcd7b405ddb544a25ee008635017fb04bdb. Original admitted record: 9a5a7fd9d6a428a7a159eb783b9046ed1bc3aa6a93c0fdfc62d814f0409e9284.
- The pinned original live identity snapshot is train_execution_status_root_20261015_v3.json, SHA fbd9306b3d160d5058c6e3289fda2fa04c3c333132f46131d67e095b4d082c1d. It records root supervisor 2613394/start471251695 -> launcher2613472/start471253709 -> scientific worker2613542/start471255666, with exact commands and parent links. Its pass25/800-step status is identity evidence only and is never treated as completion.
- Original driver v4, context v2, worker, model, scientific config, guard, policy and repair authority remain exact SHA-bound. Source_manifest.json contains their full refs and the real original reservation digest.

close_request.inactive.json has the primitive exact14-field request shape, real storage/launch/digest/locators and prospective identity predicates. Its terminal refs, actual descendant roster, observation, measured bytes, credit and expected ledger prefix remain null. It is not an original guard operation authority. These nulls must never be copied into active authority. Future execution rebuilds the request from actual SHA-bound terminal evidence.

## Future terminal gate

The only accepted wait path is the original admitted_train_v3/actual_wait.json. The only accepted completion is experiments/results/H044_GPU4_marker_train_seed101_v3/completed.json. Root must provide the actual SHA256 of each. Merely finding files, source compiling, a progress receipt, process disappearance or an SSH command ending does not satisfy completion.

Before loading a guard or creating certificates, the adapter requires the original direct launcher wait0, no error, actual_direct_launcher_wait=True, owned_group_drained=True, matching launcher PID/start/launch/input/GPU4, exact completion ref, original owned RSS cap and actual nonfuture wait time. It requires the original completion schema/status/config/input/core/preparation/warmstart refs, both arms at960updates, all30 histories with32whole-parent updates per arm, all six two-arm checkpoint groups, original initial-state identity and no VAL/outer truth. Original cache peak/count and target-policy budget evidence is bound. Checkpoint refs must have the original twelve filenames and valid SHA forms. No checkpoint payload is opened or regenerated.

The completed identity fields were checked against the actual frozen trainer result construction. Actual wait field names and semantics were checked against original root_driver_v4.py. The adapter binds the entire actual original wait identity and the complete relevant original completion metadata, including every history and checkpoint ref.

## Complete writer absence without an outer SSH claim

The complete PID roster is the pinned original root supervisor plus every launcher, worker and adopted descendant in the original actual_wait.owned_process_identities. The original launch/worker identities from the snapshot must be present with matching starts/groups. All historical_owned_groups from the original wait are retained and cover every owned identity group. At most256 PIDs are accepted, preserving the original primitive bound.

Future explicit root execution must obtain fresh targeted os.kill(pid,0) ESRCH for every such PID, including root supervisor2613394. It must also obtain targeted os.killpg(group,0) ESRCH for every original historical worker group. A present, reused or zombie PID/group, a permission error, an incomplete terminal roster or a root writer still alive stops the close. The same targeted checks are repeated under the original budget mutex before drafting authority. The unchanged primitive independently rechecks all PIDs under its original mutex before/after its one scope measurement.

The original root supervisor belongs to an outer shell/session group2613393 in the snapshot. That outer parent is not declared to be an original scientific scope writer by the original driver. This adapter neither claims nor requires its OS exit. It requires the actual root writer PID itself to be absent, as well as all genuine original worker/launcher/descendant groups. No fresh absence observation or supervisor/SSH exit result was fabricated here.

## Revocation and unchanged credit path

After genuine terminal validation and fresh absence, future root execution creates an exclusive root_close_execution_v1 packet here. A scope-specific root certificate revokes only old original TRAIN write/resume/retry capabilities for this key, output and auxiliary scope. It preserves all original input/config/source/launch/checkpoint files, allows their read-only reuse and leaves a separately admitted evaluation capability unaffected. No source/config is globally revoked and no file is deleted, truncated, moved or chmodded.

The adapter loads the exact unchanged credit-v3 source and configures the same policy and repair authority. It verifies that root canonical/file_bytes/mutex functions are original and unmemoized. Under that original mutex it obtains fresh state, asserts this exact key is open and its original full reservation unchanged, makes the actual root observation and exact primitive request, then drafts close_completed against the fresh exact prefix/bindings. apply_close_completed_v1 performs the real revalidation, single owned-scope stat measurement and append. No manual credit, retained-byte estimate, journal mutation or rebase is introduced.

Only original output and worker_aux are measured by the unchanged primitive. All checkpoint/log products stay intact. The returned actual close receipt must report one measurement, zero artifacts deleted, no old-journal mutation and future_writes_and_relaunch_revoked=True. Any credit is taken only from that receipt. The complete old storage record and its initial pins are preserved.

If the close fails after the scope-specific revocation/packet was written, root must inspect and resolve that failed attempt. The exclusive packet blocks automatic replay. Do not resume the revoked original TRAIN scope. The source task did not create such an execution packet or perform any revocation.

## Verification and root command shapes

source_checks.py was executed as standard-library source/metadata analysis only. Its19 checks passed: immutable refs and actual original100MB reservation, original roster identities, frozen trainer/wait fields, exact14-field primitive schema and correct locators, full terminal predicates, gate ordering, zero-only targeted signal source, exact guard/policy/mutex path, scope-only revocation, no payload/deletion/new measurement helper and compile-as-text. It did not import/execute the adapter or guard, inspect terminal/process/GPU/state or open a checkpoint. The existing source checker writes exclusive evidence; its output artifacts should remain immutable.

A repeatable read-only pin/compile check, with no project imports:

    /usr/bin/python3 -B - <<PY
    from pathlib import Path
    import hashlib,json
    root=Path(/workspace-SR003.nfs2/ARG-GNN)
    folder=root/research/reviews/H044_completed_train_close_source_v1
    manifest=json.loads((folder/source_manifest.json).read_text())
    for record in [manifest[adapter_ref],manifest[source_checker_ref],*manifest[frozen_refs].values(),manifest[successful_C3_pattern_ref]]:
        raw=(root/record[path]).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==record[sha256]
    for name in (close_completed_train_root.py,source_checks.py):
        compile((folder/name).read_text(),name,exec)
    print(exact source/immutable metadata pins and text compilation passed)
    PY

Inert status inspection, if root wishes:

    /usr/bin/python3 -B research/reviews/H044_completed_train_close_source_v1/close_completed_train_root.py

Only after genuine original terminal completion and separate root authorization, root can replace both terminal placeholders with real hashes and invoke:

    /usr/bin/python3 -B research/reviews/H044_completed_train_close_source_v1/close_completed_train_root.py --execute --expected-adapter-sha256 f8a0c1510bbb434d12158ae3bcfdaf780a15445c12c05fb625279feec421b195 --expected-wait-sha256 ACTUAL_ORIGINAL_TRAIN_WAIT_SHA256 --expected-completed-sha256 ACTUAL_ORIGINAL_TRAIN_COMPLETED_SHA256

This is a command shape, not an admitted/executed command. The placeholders fail the64-hex validation. After a successful actual close, root must use the unchanged current guard to assess any fresh evaluation reservation. No new admission is authorized here.

All work was remote in the repository and only this fresh folder was written. No scientific data, target/label/roster/tree/model/checkpoint payload was read. No project/guard/scientific module import, process/GPU/accounting operation, original terminal read, admission, close, package action, Git operation or deletion occurred. The successful C3 close adapter was read only as a pattern; its outer-supervisor wait requirement is not falsely copied into this original H044 process topology.
