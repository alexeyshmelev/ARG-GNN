"""Inactive source-only adapter for one original completed H044 TRAIN scope.

Only an explicit future root --execute may inspect targeted process absence or
load the unchanged credit-v3 guard. No science/checkpoint payload is opened.
"""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import argparse,hashlib,importlib.util,json,os,re,shlex
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
REL="research/reviews/H044_completed_train_close_source_v1"
SOURCE=REL+"/close_completed_train_root.py"
HERE=ROOT/REL
EXECUTION=HERE/"root_close_execution_v1"
PACKET="research/reviews/H044_marker_resolution_root_v1/admitted_train_v3"
KEY="H044/H044-GPU4-paired-marker-train-seed101-v3"
OUTPUT="experiments/results/H044_GPU4_marker_train_seed101_v3"
AUX=PACKET+"/worker_aux"
WAIT_PATH=PACKET+"/actual_wait.json"
COMPLETED_PATH=OUTPUT+"/completed.json"
CAP=100000000
CORE="483d78bf2ef3c917d65ecf1dde5a7809bfadc21194c9f9a90394ce5c532fdd5e"
BASE="a8049bc103afb1cbbbce6f8fc3707a21de9613b23034599641b688994fc5caa3"
GUARD_REF=dict(path="research/reviews/concurrent_completed_scope_credits_v3/completed_scope_credits_v3.py",sha256="ea14c12c41b9385a86182aa9c24058f7b1276107fc5706c70e47828e8b2c31ef")
POLICY_REF=dict(path="research/reviews/completed_scope_credits_root_activation_20261015_v1/activation_policy.json",sha256="a0885b5209172dd79a835d442e0ad3495f5c1a0eac61a1c5c08154ec877ecf85")
REPAIR_REF=dict(path="research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json",sha256="f6f2d628199e8be73db8b5d90d428570d8afdefeab9dc5cd94bb5eafb39247db")
DRIVER_REF=dict(path="research/reviews/H044_marker_resolution_root_v1/root_driver_v4.py",sha256="a458d8fb7606fc9d3a7aa679e1a7a0f4f7e84d85a74d7ce700a5de645d9d2da6")
CONTEXT_REF=dict(path="research/reviews/H044_marker_resolution_root_v1/context_factory_v2.py",sha256="245f9dcdff47efeacba6a3aa40377375466f9d7abe746b6bd492d021dfa0b2fe")
WORKER_REF=dict(path="src/arggnn/train_marker_resolution_readout_v1.py",sha256="386814feb14a64310b8c51c2cfbaf681a59b0273f8be0f72ffde5a222eb08c3c")
MODEL_REF=dict(path="src/arggnn/marker_resolution_readout_v1.py",sha256="27ecd30683024def2d408bf16250102b3252d0ae112687b9664fca086b141310")
CONFIG_REF=dict(path="research/reviews/H044_marker_resolution_root_v1/train_config_root_20261015_v3.json",sha256="bd657391a65b26fdcff76b295710b4b4cbcf0650978e9f5091c65ff6e9183ec6")
INPUT_REF=dict(path=PACKET+"/input.json",sha256="d34005aca334f6313494fa0f67061dcd7b405ddb544a25ee008635017fb04bdb")
STORAGE_REF=dict(path=PACKET+"/storage.json",sha256="2dd37f960807be92c71bd0204d9800f93d5b31ab6faa059db1b171acf58438ba")
LAUNCH_REF=dict(path=PACKET+"/launch.json",sha256="9b07f706ac4c3bbcd396c2643e2ab44e6ebb92fc7a164c6d4e52c4e8d81637b1")
ADMITTED_REF=dict(path=PACKET+"/admitted.json",sha256="9a5a7fd9d6a428a7a159eb783b9046ed1bc3aa6a93c0fdfc62d814f0409e9284")
ROSTER_REF=dict(path="research/reviews/H044_marker_resolution_root_v1/train_execution_status_root_20261015_v3.json",sha256="fbd9306b3d160d5058c6e3289fda2fa04c3c333132f46131d67e095b4d082c1d")
ARMS=("localized","tree_pooled")
PASSES=(5,10,15,20,25,30)
ROOT_PID=2613394
ROOT_START=471251695
LAUNCHER_PID=2613472
LAUNCHER_START=471253709
WORKER_PID=2613542
WORKER_START=471255666
INITIAL_STATE_SHA256="0811bac8e8e2f80fca78e56d4472b5437505268d9d8f397a2c1abea45501a55a"
MAX_JSON=1048576
COMPLETED_IDENTITY_FIELDS=("schema","hypothesis_id","status","input_ref","config_ref","arms","steps","history",
    "checkpoint_groups","core_ref","initial_state_sha256","initialization","observations_seal",
    "preparation_completion_ref","warmstart_checkpoint_ref","warmstart_completion_ref","VAL_truth_read",
    "outer_truth_read","selection_deferred","same_VAL_is_development_evidence","marker_cache_peak_bytes",
    "marker_builds","marker_cache_hits","flag_cache_peak_bytes","target_residency_policy")

def require(ok,message):
    if not ok:raise ValueError(message)

def local(path):
    p=Path(path);p=p if p.is_absolute() else ROOT/p
    require(".." not in p.parts and p.resolve()==p and p.is_relative_to(ROOT),"Canonical repository path required")
    return p

def reference(path):
    p=local(path);require(p.is_file(),"Existing canonical evidence file required")
    return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def record_ok(record):
    return type(record) is dict and set(record)=={"path","sha256"} and type(record["path"]) is str and re.fullmatch("[0-9a-f]{64}",str(record["sha256"])) is not None

def read(record):
    require(record_ok(record) and reference(record["path"])==record,"Exact original evidence SHA required")
    raw=local(record["path"]).read_bytes();require(len(raw)<=MAX_JSON,"Compact evidence JSON at most1MiB")
    return json.loads(raw)

def digest(value):
    # Exact unchanged project_budget_v9.digest -> project_budget_v4.encoded.
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()

def save(folder,name,value):
    require(Path(name).name==name,"Flat exclusive root certificate name")
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    require(len(raw)<=65536,"Compact root authority/certificate at most64KiB")
    p=local(folder/name)
    with p.open("xb") as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    return reference(p)

def immutable_evidence():
    for record in (GUARD_REF,POLICY_REF,REPAIR_REF,DRIVER_REF,CONTEXT_REF,WORKER_REF,MODEL_REF):
        require(reference(record["path"])==record,"Frozen source/policy/repair authority changed")
    cfg,spec,storage,launch,admitted,status=(read(r) for r in (CONFIG_REF,INPUT_REF,STORAGE_REF,LAUNCH_REF,ADMITTED_REF,ROSTER_REF))
    own=storage["reservation"]
    require(spec["schema"]=="H044_marker_root_execution_input_v1" and spec["phase"]=="train"
        and spec["root_authorizer"]=="root_agent" and spec["job_id"]==KEY.split("/",1)[1]
        and spec["physical_gpu"]==4 and spec["output_directory"]==OUTPUT and spec["worker_auxiliary_scope"]==AUX
        and spec["main_source_ref"]==WORKER_REF and spec["root_context_module_ref"]==CONTEXT_REF
        and spec["root_driver_ref"]==DRIVER_REF and spec["refs"]["config"]==CONFIG_REF
        and spec["refs"]["storage"]==STORAGE_REF and spec["completed_overlay_policy_ref"]==POLICY_REF,
        "Exact original TRAIN input/context/driver/storage required")
    require(storage["active"] is True and storage["job_id"]==spec["job_id"]
        and storage["accounting_mode"]=="concurrent_completed_scope_credits_v3"
        and storage["completed_overlay_policy_ref"]==POLICY_REF
        and storage["output_directory"]==OUTPUT and storage["reserved_new_bytes"]==CAP
        and own["key"]==KEY and own["reserved_bytes"]==CAP and own["output"]==str(ROOT/OUTPUT)
        and own["auxiliary_scopes"]==[str(ROOT/AUX)],"Exact original100MB output+aux reservation required")
    require(admitted["input_ref"]==INPUT_REF and admitted["driver_ref"]==DRIVER_REF and admitted["phase"]=="train"
        and admitted["physical_gpu"]==4 and admitted["auxiliary_scope"]==AUX,"Original admitted metadata differs")
    require(launch["schema"]=="H044_marker_original_launch_v1" and launch["phase"]=="train"
        and launch["direct_child"] is True and launch["launcher_pid"]==LAUNCHER_PID
        and launch["launcher_start"]==LAUNCHER_START and launch["physical_gpu"]==4
        and launch["input_ref"]==INPUT_REF,"Original direct launcher identity required")
    require(status["original_launch_ref"]==LAUNCH_REF and status["original_input_ref"]==INPUT_REF
        and status["original_driver_ref"]==DRIVER_REF and status["completed_training_claim"] is False,
        "Original live snapshot is identity evidence, not completion")
    require(len(status["arms"])==2 and {r["arm"] for r in status["arms"]}==set(ARMS)
        and all(r["pass_index"]==25 and r["additional_optimizer_steps"]==800 and r["teacher_used"] is False
            and r["initial_state_sha256"]==INITIAL_STATE_SHA256 for r in status["arms"]),
        "Original pass25 snapshot initial-state identity required, without opening checkpoints")
    rows=status["live_original_writer_roster"]
    require(len(rows)==3 and {r["role"] for r in rows}=={"root_H044_supervisor","approved_GPU_launcher","scientific_H044_worker"},"Original complete recorded initial writer roster")
    by_role={r["role"]:r for r in rows};root=by_role["root_H044_supervisor"];launcher=by_role["approved_GPU_launcher"];worker=by_role["scientific_H044_worker"]
    require((root["pid"],root["start"],launcher["pid"],launcher["start"],worker["pid"],worker["start"])==
        (ROOT_PID,ROOT_START,LAUNCHER_PID,LAUNCHER_START,WORKER_PID,WORKER_START)
        and launcher["parent_pid"]==ROOT_PID and worker["parent_pid"]==LAUNCHER_PID
        and launcher["group"]==LAUNCHER_PID and worker["group"]==WORKER_PID
        and shlex.split(launcher["command"])==launch["command"] and worker["command"]=="AI Auto Research Pipeline Test",
        "Bound root-to-launcher-to-worker IDs/start/commands required")
    expected_root=[str(ROOT/".runtime/env/bin/python"),"-B","-m","research.reviews.H044_marker_resolution_root_v1.root_driver_v4","launch","--execute","--record",ADMITTED_REF["path"],"--sha256",ADMITTED_REF["sha256"]]
    require(shlex.split(root["command"])==expected_root,"Original root supervisor exact invocation required")
    return cfg,spec,storage,launch,rows

def terminal_evidence(wait_ref,completed_ref,cfg,spec,launch,initial_rows):
    require(wait_ref["path"]==WAIT_PATH and completed_ref["path"]==COMPLETED_PATH,"Only exact original terminal paths")
    wait,completed=read(wait_ref),read(completed_ref)
    require(wait["schema"]=="H044_marker_original_direct_wait_v1" and wait["phase"]=="train"
        and wait["launcher_pid"]==LAUNCHER_PID and wait["launcher_start"]==LAUNCHER_START
        and wait["launch_ref"]==LAUNCH_REF and type(wait["returncode"]) is int and wait["returncode"]==0
        and wait["actual_direct_launcher_wait"] is True and wait["owned_group_drained"] is True
        and wait["error"] is None and wait["completed_ref"]==completed_ref and wait["physical_gpu"]==4
        and wait["log_ref"]["path"]==AUX+"/launch_log.json" and record_ok(wait["log_ref"]),
        "Genuine original direct launcher wait0/noerror/full owned drain and complete producer ref required")
    finished=datetime.fromisoformat(wait["waited_utc"].replace("Z","+00:00"))
    require(finished.tzinfo is not None and finished<=datetime.now(timezone.utc),"Actual nonfuture timezone-aware original wait")
    require(type(wait["peak_owned_RSS_bytes"]) is int and 0<=wait["peak_owned_RSS_bytes"]<=spec["max_cpu_rss_bytes"],"Original owned RSS cap evidence")
    require(completed["schema"]=="H044_marker_paired_train_completion_v1" and completed["hypothesis_id"]=="H044"
        and completed["status"]=="completed_fixed30pass_paired_TRAIN" and completed["input_ref"]==INPUT_REF
        and completed["config_ref"]==CONFIG_REF and completed["core_ref"]==MODEL_REF
        and completed["arms"]==list(ARMS) and completed["steps"]=={a:960 for a in ARMS}
        and completed["warmstart_checkpoint_ref"]==cfg["warmstart_checkpoint_ref"]
        and completed["warmstart_completion_ref"]==cfg["warmstart_completion_ref"]
        and completed["preparation_completion_ref"]==spec["preparation_completion_ref"]
        and completed["VAL_truth_read"] is False and completed["outer_truth_read"] is False
        and completed["selection_deferred"] is True and completed["same_VAL_is_development_evidence"] is True
        and completed["target_residency_policy"]==cfg["TRAIN_target_policy"],"Complete original paired TRAIN provenance required")
    require(all(k in completed for k in COMPLETED_IDENTITY_FIELDS),
        "Every original completion identity field required before certificates")
    history=completed["history"];groups=completed["checkpoint_groups"]
    require(type(history) is list and len(history)==30
        and all(row["pass_index"]==at and row["steps"]=={a:32*at for a in ARMS}
            and row["full_parent_updates_per_arm"]==32 for at,row in enumerate(history,1))
        and set(groups)=={str(at) for at in PASSES},"All30 passes and all six original checkpoint groups required")
    for at in PASSES:
        require(set(groups[str(at)])==set(ARMS),"Both original checkpoint arms required")
        for arm in ARMS:
            record=groups[str(at)][arm]
            require(record_ok(record) and record["path"]==OUTPUT+"/%s.pass_%02d.pt"%(arm,at),"Exact original checkpoint refs; payloads stay unopened")
    require(completed["initial_state_sha256"]==INITIAL_STATE_SHA256
        and all(type(completed[k]) is int and completed[k]>=0 for k in ("marker_cache_peak_bytes","marker_builds","marker_cache_hits","flag_cache_peak_bytes"))
        and completed["marker_cache_peak_bytes"]<=cfg["marker_cache_cap_bytes"]
        and completed["flag_cache_peak_bytes"]<=cfg["flag_cache_cap_bytes"],"Original completed cache/count budget evidence required")
    owned=wait["owned_process_identities"];historical=wait["historical_owned_groups"]
    require(type(owned) is list and 2<=len(owned)<=255 and all(type(r) is dict and set(r)=={"pid","start","group"}
        and all(type(r[k]) is int and r[k]>=2 for k in r) for r in owned)
        and len({r["pid"] for r in owned})==len(owned) and ROOT_PID not in {r["pid"] for r in owned},
        "Complete original launcher/worker/adopted descendant identity roster required")
    require(type(historical) is list and historical==sorted(set(historical)) and 1<=len(historical)<=255
        and all(type(g) is int and g>=2 for g in historical)
        and {r["group"] for r in owned}<=set(historical),"Complete original historical owned groups required")
    for initial in initial_rows:
        if initial["pid"]!=ROOT_PID:
            require(dict(pid=initial["pid"],start=initial["start"],group=initial["group"]) in owned,
                "Initial launcher/worker identities must remain in original terminal descendant roster")
    pids=sorted([ROOT_PID]+[r["pid"] for r in owned])
    require(len(pids)<=256,"Original primitive bounded complete writer roster")
    return wait,completed,pids,historical,owned

def absence(identity,group=False):
    # Future explicit root execution only. Present/reused/zombie/permission => stop.
    try:
        if group:os.killpg(identity,0)
        else:os.kill(identity,0)
    except ProcessLookupError:
        return dict(**({"process_group":identity} if group else {"pid":identity}),absent=True,
            method="targeted os.killpg(group,0) ESRCH" if group else "targeted os.kill(pid,0) ESRCH",
            checked_utc=datetime.now(timezone.utc).isoformat())
    except PermissionError:raise ValueError("Targeted absence cannot be certified") from None
    raise ValueError("Original writer/group remains present, reused or zombie; no credit")

def load_guard():
    require(reference(GUARD_REF["path"])==GUARD_REF,"Exact original credit-v3 primitive required")
    module_spec=importlib.util.spec_from_file_location("_H044_root_unchanged_credit_v3",ROOT/GUARD_REF["path"])
    module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
    module.configure_v2(REPAIR_REF,policy_ref=POLICY_REF)
    require(all(getattr(module.budget.v4,k).__module__==module.budget.v4.__name__ for k in ("canonical","file_bytes","mutex")),"Unmemoized original root guard functions required")
    return module

def run(expected_adapter_sha256,wait_sha256,completed_sha256):
    require(reference(SOURCE)["sha256"]==expected_adapter_sha256,"Exact reviewed adapter source required")
    cfg,spec,storage,launch,initial_rows=immutable_evidence();own=storage["reservation"]
    wait_ref=dict(path=WAIT_PATH,sha256=wait_sha256);completed_ref=dict(path=COMPLETED_PATH,sha256=completed_sha256)
    wait,completed,pids,groups,owned=terminal_evidence(wait_ref,completed_ref,cfg,spec,launch,initial_rows)
    # No outer SSH/shell OS-exit claim is needed. This exact root writer PID
    # must itself be absent in addition to every original descendant/group.
    first_pids=[absence(pid) for pid in pids];first_groups=[absence(g,True) for g in groups]
    require(not EXECUTION.exists(),"Fresh exclusive root close packet; no replay")
    EXECUTION.mkdir()
    revocation=save(EXECUTION,"same_scope_write_resume_revocation.json",dict(
        schema="H044_original_completed_TRAIN_same_scope_revocation_v1",root_authorizer="root_agent",key=KEY,
        reservation_sha256=digest(own),original_input_ref=INPUT_REF,original_admitted_ref=ADMITTED_REF,
        original_storage_ref=STORAGE_REF,original_launch_ref=LAUNCH_REF,original_root_snapshot_ref=ROSTER_REF,
        original_root_supervisor_identity=dict(pid=ROOT_PID,start=ROOT_START),original_owned_process_identities=owned,
        original_direct_wait_ref=wait_ref,completed_ref=completed_ref,output=OUTPUT,auxiliary_scope=AUX,
        all_old_original_same_scope_TRAIN_write_resume_retry_capabilities_revoked=True,
        revocation_applies_only_to_original_key_output_and_auxiliary_scope=True,
        same_config_sources_and_checkpoints_read_only_reuse_preserved=True,new_distinct_evaluation_capability_unaffected=True,
        preserve_all_files=True,historical_journal_mutation_authorized=False,deletion_authorized=False,
        outer_SSH_exit_claimed=False,pids=pids,observations=first_pids,worker_group_observations=first_groups,
        adapter_source_ref=reference(SOURCE)))
    m=load_guard()
    with m.budget.v4.mutex(ROOT):
        state=m._state_locked(CORE,BASE,fresh=True);m.assert_open(KEY,state[0],state[1])
        require(state[0][KEY]==own and m.budget.digest(own)==digest(own),"Exact original fully charged reservation unchanged")
        observations=[absence(pid) for pid in pids];group_observations=[absence(g,True) for g in groups]
        observation=save(EXECUTION,"root_observation.json",dict(
            schema="concurrent_completed_scope_targeted_root_observation_v1",root_authorizer="root_agent",key=KEY,
            reservation_sha256=m.budget.digest(own),storage_ref=STORAGE_REF,launch_ref=LAUNCH_REF,
            direct_wait_ref=wait_ref,completed_ref=completed_ref,launcher_pid=LAUNCHER_PID,
            all_root_owned_launcher_supervisor_worker_pids_listed=True,direct_wait_observed=True,
            completed_scope_all_old_original_resume_write_capabilities_revoked=True,preserve_all_files=True,
            external_NFS_writers_outside_observation=True,pids=pids,observations=observations,
            worker_group_observations=group_observations,scope_revocation_ref=revocation,
            bound_root_supervisor_identity=dict(pid=ROOT_PID,start=ROOT_START),initial_writer_snapshot_ref=ROSTER_REF,
            complete_original_descendant_roster_from_actual_wait=True,owned_process_identities=owned,
            outer_SSH_exit_claimed=False,adapter_source_ref=reference(SOURCE)))
        request=dict(key=KEY,reservation_sha256=m.budget.digest(own),storage_ref=STORAGE_REF,storage_locator=[],
            launch_ref=LAUNCH_REF,launch_pid_locator=["launcher_pid"],launch_identity=dict(launch),
            direct_wait_ref=wait_ref,wait_pid_locator=["launcher_pid"],wait_exit_locator=["returncode"],wait_identity=dict(wait),
            completed_ref=completed_ref,completed_identity={k:completed[k] for k in COMPLETED_IDENTITY_FIELDS},observation_ref=observation)
        request_ref=save(EXECUTION,"close_request.json",request)
        authority=m.operation_draft_v1("close_completed",request,expected_before=m._pins(state[2]),bindings=state[3])
    authority.update(active=True,expires_at_utc=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
    authority_ref=save(EXECUTION,"close_authority.json",authority)
    receipt=m.apply_close_completed_v1(authority_ref,expected_source_sha256=CORE,expected_launcher_sha256=BASE)
    require(receipt["key"]==KEY and receipt["scope_measurements"]==1 and receipt["artifacts_deleted"]==0
        and receipt["old_journal_mutated"] is False and receipt["value"]["future_writes_and_relaunch_revoked"] is True,
        "Unchanged original primitive receipt and preservation required")
    saved=save(EXECUTION,"close_receipt.json",receipt)
    print(json.dumps(dict(receipt_ref=saved,request_ref=request_ref,key=KEY,retained_bytes=receipt["retained_bytes"],
        credit_bytes=receipt["credit_bytes"],projected_bytes=receipt["projected_bytes"])),flush=True)
    return 0

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--execute",action="store_true")
    parser.add_argument("--expected-adapter-sha256");parser.add_argument("--expected-wait-sha256");parser.add_argument("--expected-completed-sha256")
    args=parser.parse_args(argv)
    if not args.execute:
        print(json.dumps(dict(status="inactive_source_only_original_H044_TRAIN_terminal_and_root_absence_required",key=KEY,
            scope_cap_bytes=CAP,wait_path=WAIT_PATH,completed_path=COMPLETED_PATH,
            terminal_refs_issued=False,process_or_guard_checks_performed=False,H018_credit_authorized=False)))
        return 0
    require(all(re.fullmatch("[0-9a-f]{64}",str(s)) for s in (args.expected_adapter_sha256,args.expected_wait_sha256,args.expected_completed_sha256)),
        "Future root must provide exact reviewed source and genuine original terminal SHA256 values")
    return run(args.expected_adapter_sha256,args.expected_wait_sha256,args.expected_completed_sha256)

if __name__=="__main__":raise SystemExit(main())
