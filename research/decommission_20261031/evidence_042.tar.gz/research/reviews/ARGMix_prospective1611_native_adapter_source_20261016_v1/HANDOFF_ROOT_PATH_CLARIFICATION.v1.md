# Additive root path clarification

The frozen HANDOFF.md API example defines `owned = project/data/ARGMix_prospective1611_native_v1/variant/parent`, then passes `owned/plan` and `owned/features` as fresh stage outputs. Root must create the dataset, variant and **owned parent namespace itself** after admission before those stage calls. The phrase saying only `owned.parent` is created is incorrect. The producer intentionally does not recursively create unadmitted parents. No source, scientific rule, frozen output, source hash or existing handoff file is changed by this clarification.
