"""Current-author ARGMix prospective1611 shared-example adapter.
Root owns admission, native build, CPU/GPU supervision and actual outcomes.
No numerical imports, work, source-copy mutation or file writes at import.
"""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import random
import sys

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
HERE=Path(__file__).resolve().parent
CONTRACT=HERE/'method_contract.proposed.v1.json'
AUTHOR=ROOT/'.runtime/author_sources/argmix_c2481248eb0d'
GENERATOR_REF={'path':'research/reviews/ARGMix_prospective1611_generator_source_20261016_v1/prospective1611_iid_v1.py','sha256':'7e6dc35934252f3d404da3b9c612e4580877e752de41e5f88fe2a58418633e0a'}
VARIANTS=('author_eligibility','focal_diploid_excluded')


def need(ok,message):
    if not ok:raise ValueError(message)


def path(value):
    p=Path(value);p=p if p.is_absolute() else ROOT/p
    need(p.resolve()==p and ROOT in p.parents,'Canonical repository path required')
    return p


def sha(value):
    h=hashlib.sha256()
    with path(value).open('rb') as f:
        for block in iter(lambda:f.read(4*2**20),b''):h.update(block)
    return h.hexdigest()


def ref(value):
    p=path(value);return dict(path=str(p.relative_to(ROOT)),sha256=sha(p),bytes=p.stat().st_size)


def checked(record):
    p=path(record['path'])
    need(p.is_file() and not p.is_symlink() and sha(p)==record['sha256'],'Pinned artifact changed: '+str(p))
    return p


def metadata(value):
    p=path(value);need(p.suffix=='.json' and p.stat().st_size<=8*2**20,'Bounded JSON metadata required')
    return json.loads(p.read_text())


def load_generator():
    p=checked(GENERATOR_REF)
    spec=importlib.util.spec_from_file_location('_prospective1611_shared_generator',p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def contract():
    c=metadata(CONTRACT)
    for r in c['fixed_refs'].values():checked(r)
    need(c['schema']=='ARGMix_prospective1611_native_method_contract_v1' and c['original_paper_reproduction'] is False,'Exact prospective contract')
    return c


def fresh(value,guard):
    p=path(value);need(callable(guard) and p.parent.is_dir() and not p.exists(),'Fresh admitted scope with actual root guard required')
    guard(16384);p.mkdir();return p


def save_json(p,value,guard,cap=8*2**20):
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    need(len(raw)<=cap,'Finite JSON cap');guard(len(raw))
    with path(p).open('xb') as f:f.write(raw)
    guard(0);return ref(p)


def materialize_author_copy(output,*,guard):
    """Copy authenticated86-file author release, change ONE declared Rust file."""
    c=contract();inventory=metadata(checked(c['fixed_refs']['author_inventory']))
    output=fresh(output,guard)
    total=sum(r['bytes'] for r in inventory['files'].values())
    need(total<16*2**20,'Bounded native source copy')
    guard(total+2**20)
    for relative,record in inventory['files'].items():
        source=AUTHOR/relative;need(sha(source)==record['sha256'],'Pinned author release drift')
        dest=output/relative;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(source.read_bytes())
    patch=checked(c['fixed_refs']['patched_rust'])
    changed=output/inventory['patched_relative_path']
    # The only replace target is the fresh owned copy just authored above.
    need(sha(changed)==inventory['files'][inventory['patched_relative_path']]['sha256'],'Fresh copied Rust preimage')
    changed.write_bytes(patch.read_bytes());guard(0)
    build=output/'build';build.mkdir()
    for n in ['cargo_home','target','tmp']:(build/n).mkdir()
    result=dict(schema='ARGMix_prospective1611_native_copy_v1',author_commit=inventory['author_commit'],source_copy=str(output.relative_to(ROOT)),
        author_inventory_ref=c['fixed_refs']['author_inventory'],patched_rust_ref=ref(changed),
        original_sources_mutated=False,modified_copy_files=[inventory['patched_relative_path']],
        build_argv=['cargo','build','--manifest-path',str(output/'src/rust/ancpath/Cargo.toml'),'--locked','--lib','--release','--no-default-features','--features','extension-module'],
        build_env=dict(CARGO_HOME=str(build/'cargo_home'),CARGO_TARGET_DIR=str(build/'target'),TMPDIR=str(build/'tmp'),
                       PYO3_PYTHON=str(ROOT/c['native_python']),CUDA_VISIBLE_DEVICES=''),
        expected_extension=str(build/'target/release/libancpath.so'),root_build_output_cap_bytes=8*2**30,
        build_and_dynamic_equivalence_qualification_pending=True)
    save_json(output/'native_copy.json',result,guard)
    return result


def _target_rows(support):
    with checked(support['targets_ref']).open() as f:
        keys=next(f).rstrip().split('\t')
        rows=[dict(zip(keys,line.rstrip().split('\t'))) for line in f]
    need(len(rows)==100000 and [int(r['target_row']) for r in rows]==list(range(100000)),'Exact frozen100000 target rows and order')
    return rows


def prepare_parent(generator_config,parent_id,parent_output,inferred_output,support_output,variant,output,*,guard,resource_check):
    """Observed-only native request/data plan. No local ancestry labels opened."""
    c=contract();need(variant in VARIANTS and callable(resource_check),'Named variant and real root resource callback')
    g=load_generator();cfg,parent,obs,observation,source_rows=g.observed_assets(generator_config,parent_id,parent_output)
    bridge=metadata(path(inferred_output)/'completed.json');support=metadata(path(support_output)/'completed.json')
    need(bridge['parent_id']==support['parent_id']==parent_id and bridge['config_ref']==support['config_ref']==ref(generator_config), 'Parent and shared config identity')
    need(support['inferred_bridge_ref']==ref(path(inferred_output)/'completed.json') and support['truth_or_labels_read'] is False,'Observed-only exact inferred shared support')
    import tskit
    ts=tskit.load(checked(bridge['tree_ref']));rows=metadata(checked(bridge['roster_ref']))
    need(len(rows)==len(source_rows) and all(all(r[k]==v for k,v in s.items()) for r,s in zip(rows,source_rows)), 'Explicit observed ID/role join, never ages as IDs')
    need([r['inferred_tree_node_id'] for r in rows]==list(map(int,ts.samples())),'Native sample node order differs')
    intervals=[(float(t.interval.left),float(t.interval.right)) for t in ts.trees()]
    targets=_target_rows(support);requests={};by_pair={}
    for index,r in enumerate(targets):
        sample=int(r['sample_index']);q=rows[sample];tree=int(r['inferred_tree_index']);lo,hi=intervals[tree]
        need(q['query_eligible'] and [r['sample_id'],int(r['haplotype']),r['cohort']]==[q['sample_id'],q['haplotype'],q['observed_cohort']], 'Frozen target focal identity')
        need(float(r['local_midpoint_bp'])==(lo+hi)/2 and float(r['rebased_midpoint_bp'])==(lo+hi)/2+bridge['local_to_rebased_offset_bp'],'Exact target coordinate/frame')
        node=q['inferred_tree_node_id'];need((tree,node) not in by_pair,'Distinct shared support pairs')
        by_pair[(tree,node)]=index;requests.setdefault(str(node),[]).append(tree)
    requests={node:sorted(trees) for node,trees in requests.items()}
    output=fresh(output,guard)
    request=dict(schema='ARGMix_prospective1611_native_requests_v1',tree_rel_file=str(checked(bridge['tree_ref'])),
        exclude_focal_diploid=variant=='focal_diploid_excluded',
        node_to_diploid={str(r['inferred_tree_node_id']):r['diploid_index'] for r in rows},targets_by_query=requests)
    rr=save_json(output/'native_requests.json',request,guard)
    plan=dict(schema='ARGMix_prospective1611_observed_method_parent_v1',parent_id=parent_id,split=parent['split'],variant=variant,
        source_ref=ref(__file__),contract_ref=ref(CONTRACT),generator_config_ref=ref(generator_config),
        observation_manifest_ref=ref(obs/'observation_manifest.json'),inferred_bridge_ref=ref(path(inferred_output)/'completed.json'),
        support_manifest_ref=ref(path(support_output)/'completed.json'),requests_ref=rr,tree_ref=bridge['tree_ref'],roster_ref=bridge['roster_ref'],
        source_map_ref=cfg['input_refs']['map'],local_to_rebased_offset_bp=bridge['local_to_rebased_offset_bp'],targets=100000,
        query_count=cfg['counts']['query_haplotypes'],reference_count_before_identity_exclusion=cfg['counts']['donor_haplotypes'],
        rank_key='unchanged author quantized log2(1+abs(quantized_TMRCA-quantized_focal_time))) castu32, tie by original reference-list index',
        reference_list_order='observed roster order restricted to reference_eligible, never sorted by distance or cohort label',
        shared_context='shared sampled rows only, ordered by focal query then genomic coordinate, current-author1024/512 chunks',
        feature_labels_read=False,core_architecture_changed=False,train_native_drop_top_m_nearest=1 if parent['split']=='train' else 0)
    save_json(output/'observed_plan.json',plan,guard)
    resource_check('after_observed_ARGMix_parent_plan')
    return plan


def _copy_source(copy_record):
    p=checked(copy_record);info=metadata(p);c=contract();root=path(info['source_copy'])
    need(info['author_inventory_ref']==c['fixed_refs']['author_inventory'] and info['patched_rust_ref']['sha256']==c['fixed_refs']['patched_rust']['sha256'],'Exact isolated patched copy')
    inv=metadata(checked(info['author_inventory_ref']))
    for relative,record in inv['files'].items():
        expected=c['fixed_refs']['patched_rust']['sha256'] if relative==inv['patched_relative_path'] else record['sha256']
        need(sha(root/relative)==expected,'Isolated native source copy changed')
    return root,info


def extract_native_features(plan_record,copy_record,qualified_extension_record,output,*,guard,resource_check):
    """Root CPU stage after separate native build qualification, exactly100k rows."""
    need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','CPU-only native preparation')
    c=contract();copy,_=_copy_source(copy_record);plan=metadata(checked(plan_record));need(plan['source_ref']==ref(__file__) and plan['contract_ref']==ref(CONTRACT),'Exact adapter source/config')
    request=metadata(checked(plan['requests_ref']));bridge=metadata(checked(plan['inferred_bridge_ref']));support=metadata(checked(plan['support_manifest_ref']))
    rows=metadata(checked(plan['roster_ref']));targets=_target_rows(support)
    import numpy as np
    import tskit
    ts=tskit.load(checked(plan['tree_ref']));starts=np.asarray([t.interval.left for t in ts.trees()],dtype=np.float64)
    ends=np.asarray([t.interval.right for t in ts.trees()],dtype=np.float64)
    pair_to_row={(int(r['inferred_tree_index']),rows[int(r['sample_index'])]['inferred_tree_node_id']):i for i,r in enumerate(targets)}
    need(len(pair_to_row)==100000,'Exact100k native requests')
    need('ancpath' not in sys.modules,'Fresh qualified native extension import')
    binary=checked(qualified_extension_record)
    need(binary==path(copy)/'build/target/release/libancpath.so','Exact separately built extension location')
    spec=importlib.util.spec_from_file_location('ancpath',binary);native=importlib.util.module_from_spec(spec);sys.modules['ancpath']=native;spec.loader.exec_module(native)
    meta={r['inferred_tree_node_id']:(r['observed_cohort'],int(r['age_generations'])) for r in rows}
    refs=[r['inferred_tree_node_id'] for r in rows if r['reference_eligible']]
    queries=[r['inferred_tree_node_id'] for r in rows if r['query_eligible']]
    need(len(refs)==594 and len(queries)==2972,'Exact native dual-role donor/query schema')
    all_pops=sorted({r['observed_cohort'] for r in rows});tokens={'<PAD>':0,'<UNK>':1,'<SAMPLE>':2,'<ANC>':3}
    for p in all_pops:tokens[p]=len(tokens)
    rust_pops=['<SAMPLE>','<ANC>','<PAD>']+all_pops
    lookup=np.asarray([tokens[p] for p in rust_pops],dtype=np.uint8)
    old=os.environ.get('ARGMIX_PROSPECTIVE1611_REQUESTS');os.environ['ARGMIX_PROSPECTIVE1611_REQUESTS']=str(checked(plan['requests_ref']))
    output=fresh(output,guard);guard(100000*(16+256)+2**20)
    with (output/'input_ids.u1').open('xb') as f:f.truncate(100000*16)
    with (output/'tmrca.u1').open('xb') as f:f.truncate(100000*256)
    ids=np.memmap(output/'input_ids.u1',mode='r+',dtype=np.uint8,shape=(100000,16))
    matrix=np.memmap(output/'tmrca.u1',mode='r+',dtype=np.uint8,shape=(100000,16,16));seen=np.zeros(100000,dtype=np.bool_)
    try:
        iterator=native.SampleBatchIterator(str(checked(plan['tree_ref'])),14,meta,15,
            int(plan['train_native_drop_top_m_nearest']) or None,0,0,refs,queries,False,True,False,'ids_only','fast',None,None,512)
        while True:
            resource_check('before_native_feature_batch');batch=iterator.next_flat()
            if batch is None:break
            values,pop_ids,nodes,intervals,n,width,_=batch
            need(width==16 and n>0,'Native16-node subgraphs')
            values=np.asarray(values,dtype=np.uint16).reshape(n,16,16);pop_ids=np.asarray(pop_ids,dtype=np.uint16).reshape(n,16)
            need(int(values.max())<=14 and int(pop_ids.max())<len(lookup),'Lossless native integer encoding')
            for j,(node,(left,right)) in enumerate(zip(nodes,intervals)):
                tree=int(np.searchsorted(starts,float(left),side='left'))
                need(tree<len(starts) and starts[tree]==left and ends[tree]==right and (tree,int(node)) in pair_to_row,'Unchanged requested native tree interval/focal ID')
                row=pair_to_row[(tree,int(node))];need(not seen[row],'Duplicate native feature row')
                ids[row]=lookup[pop_ids[j]];matrix[row]=values[j].astype(np.uint8);seen[row]=True
        need(bool(seen.all()),'Every exact shared target must have one native feature row')
        ids.flush();matrix.flush();guard(0)
    finally:
        if old is None:os.environ.pop('ARGMIX_PROSPECTIVE1611_REQUESTS',None)
        else:os.environ['ARGMIX_PROSPECTIVE1611_REQUESTS']=old
    del ids,matrix
    # Compute the unchanged native raw cM feature once on CPU, not during GPU fit startup.
    with checked(plan['source_map_ref']).open() as stream:
        next(stream);map_rows=[line.split() for line in stream]
    map_pos=np.asarray([int(r[0]) for r in map_rows],dtype=np.float64)
    map_morgans=np.asarray([float(r[2])/100.0 for r in map_rows],dtype=np.float64)
    ti=np.asarray([int(r['inferred_tree_index']) for r in targets],dtype=np.int64)
    physical=np.stack([starts[ti],ends[ti]],axis=1)+plan['local_to_rebased_offset_bp']
    need(bool((physical>=map_pos[0]).all()) and bool((physical<=map_pos[-1]).all()),'No empirical-map extrapolation')
    genetic=np.interp(physical.reshape(-1),map_pos,map_morgans).reshape(-1,2)*100.0
    cm=np.zeros((100000,2),dtype=np.float32);cm[:,0]=np.maximum(0.,genetic[:,1]-genetic[:,0]).astype(np.float32)
    # include_delta_cm_prev=False and native unweighted loss ignore the second feature.
    raw=cm.astype('<f4').tobytes();guard(len(raw))
    with (output/'cm_features.f4').open('xb') as stream:stream.write(raw)
    guard(0)
    result=dict(schema='ARGMix_prospective1611_observed_features_v1' ,parent_id=plan['parent_id'],split=plan['split'],variant=plan['variant'],
        plan_ref=plan_record,source_ref=ref(__file__),contract_ref=ref(CONTRACT),native_copy_ref=copy_record,qualified_extension_ref=qualified_extension_record,
        ids_ref=ref(output/'input_ids.u1'),tmrca_ref=ref(output/'tmrca.u1'),cm_ref=ref(output/'cm_features.f4'),shape=[100000,16],tmrca_shape=[100000,16,16],
        storage_precision='lossless uint8 native IDs and integer distance bins0..14, cast to native dtypes in dataset',token_to_id=tokens,
        row_order_ref=support['targets_ref'],labels_read=False,original_paper_reproduction=False)
    save_json(output/'completed.json',result,guard)
    return result


def _definitions(source,names,namespace):
    text=path(source).read_text();nodes=[n for n in ast.parse(text).body if getattr(n,'name',None) in names]
    need({n.name for n in nodes}==set(names),'Exact native definition set')
    future=ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)
    module=ast.fix_missing_locations(ast.Module(body=[future,*nodes],type_ignores=[]))
    exec(compile(module,str(source),'exec'),namespace)


def native_model(copy_record,device):
    """Exact author architecture definitions, isolated from CLI or telemetry."""
    c=contract();copy,_=_copy_source(copy_record)
    import numpy as np
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    ns=dict(np=np,torch=torch,nn=nn,F=F)
    exec(compile((copy/'src/tmrca_attn.py').read_text(),str(copy/'src/tmrca_attn.py'),'exec'),ns)
    _definitions(copy/'src/joint_support.py',['GruRefiner','masked_sequence_cross_entropy'],ns)
    _definitions(copy/'src/joint_interval_model.py',['default_joint_cm_features_config','normalize_joint_cm_features_config','joint_cm_feature_schema','joint_cm_feature_dim','transform_joint_cm_features','JointIntervalGru'],ns)
    vocab=12
    base=ns['TmrcaAttn'](vocab_size=vocab,num_classes=4,num_layer=4,d_model=128,num_heads=4,dim_feedforward_mult=4,
        dropout=.25,attn_dropout=.1,max_rel_distance=14,gt_output_dim=16)
    model=ns['JointIntervalGru'](base_model=base,final_layer_dim=16,num_classes=4,gru_hidden_size=128,gru_num_layers=1,
        gru_bidirectional=True,gru_dropout=.1,cm_features_config=c['cm_features']).to(device)
    need(all(p.dtype==torch.float32 for p in model.parameters()),'Native FP32 fit')
    return model,ns['masked_sequence_cross_entropy']


class ChunkDataset:
    """Lazy native1024/512 chunks over exactly shared rows, no dense chunk archive."""
    def __init__(self,feature_records,label_records=None):
        import numpy as np
        self.parents=[];self.specs=[];self.label_occurrences=0;self.unique_targets=0
        need(label_records is None or len(label_records)==len(feature_records),'One external target artifact per feature parent')
        for index,record in enumerate(feature_records):
            feature=metadata(checked(record));plan=metadata(checked(feature['plan_ref']));support=metadata(checked(plan['support_manifest_ref']))
            need(feature['source_ref']==ref(__file__) and feature['contract_ref']==ref(CONTRACT) and
                 feature['row_order_ref']==support['targets_ref'] and feature['shape']==[100000,16],'Exact cache source and shared support')
            targets=_target_rows(support);labels=None
            if label_records is not None:
                label=metadata(checked(label_records[index]))
                need(label['parent_id']==feature['parent_id'] and label['split']==feature['split'] and
                    label['support_manifest_ref']==plan['support_manifest_ref'] and label['class_order']==['Ana','CHG','WHG','EHG'],'Frozen same-parent label order')
                raw=checked(label['labels_ref']).read_bytes();need(len(raw)==100000,'Exactly100k external supervision labels')
                labels=np.frombuffer(raw,dtype=np.uint8).copy();need(bool((labels<4).all()),'Four-source labels')
            ids=checked(feature['ids_ref']);tmrca=checked(feature['tmrca_ref']);need(ids.stat().st_size==1600000 and tmrca.stat().st_size==25600000,'Exact native uint8 cache lengths')
            cm_path=checked(feature['cm_ref']);need(cm_path.stat().st_size==800000,'Exact100k native two-column FP32 cM features')
            cm=np.fromfile(cm_path,dtype='<f4').reshape(100000,2)
            groups={}
            for row,t in enumerate(targets):
                groups.setdefault(int(t['sample_index']),[]).append(row)
            for q in sorted(groups):
                order=sorted(groups[q],key=lambda j:float(targets[j]['local_midpoint_bp']))
                for start in range(0,len(order),512):
                    selected=order[start:start+1024];self.specs.append((index,selected));self.label_occurrences+=len(selected)
                    if start+1024>=len(order):break
            self.parents.append(dict(feature=feature,ids_path=str(ids),matrix_path=str(tmrca),cm=cm,labels=labels))
            self.unique_targets+=100000
        self._maps={}

    def __len__(self):return len(self.specs)

    def __getitem__(self,index):
        import numpy as np
        import torch
        parent,selected=self.specs[index];row=self.parents[parent]
        if parent not in self._maps:
            self._maps[parent]=(np.memmap(row['ids_path'],mode='r',dtype=np.uint8,shape=(100000,16)),
                                np.memmap(row['matrix_path'],mode='r',dtype=np.uint8,shape=(100000,16,16)))
        source_ids,source_tmrca=self._maps[parent];n=len(selected)
        ids=torch.zeros((1024,16),dtype=torch.long);tmrca=torch.zeros((1024,16,16),dtype=torch.int16)
        mask=torch.zeros(1024,dtype=torch.bool);cm=torch.zeros((1024,2),dtype=torch.float32)
        labels=torch.full((1024,),-100,dtype=torch.long);positions=torch.full((1024,),-1,dtype=torch.long)
        ids[:n]=torch.from_numpy(np.array(source_ids[selected],dtype=np.int64));tmrca[:n]=torch.from_numpy(np.array(source_tmrca[selected],dtype=np.int16))
        mask[:n]=True;cm[:n]=torch.from_numpy(row['cm'][selected]);positions[:n]=torch.as_tensor(selected,dtype=torch.long)
        if row['labels'] is not None:labels[:n]=torch.as_tensor(row['labels'][selected],dtype=torch.long)
        return ids,tmrca,labels,mask,cm,positions,parent


def _worker_init(_):
    import torch
    torch.set_num_threads(1)


def _loader(data,shuffle,seed):
    import torch
    return torch.utils.data.DataLoader(data,batch_size=16,shuffle=shuffle,num_workers=4,persistent_workers=True,
        prefetch_factor=2,pin_memory=True,drop_last=False,multiprocessing_context='fork',worker_init_fn=_worker_init,
        generator=torch.Generator().manual_seed(seed))


def _gpu_context():
    need(os.environ.get('CUDA_VISIBLE_DEVICES')=='0','Physical GPU0 only, separately root-admitted')
    from setproctitle import setproctitle
    setproctitle('AI Auto Research Pipeline Test')
    import torch
    need(torch.cuda.is_available() and torch.cuda.device_count()==1,'Single explicitly visible GPU0')
    return torch.device('cuda:0')


def _checkpoint(output,value,guard):
    import torch
    stream=io.BytesIO();torch.save(value,stream);raw=stream.getvalue();need(len(raw)<=64*2**20,'64MiB checkpoint serialization ceiling')
    guard(len(raw));temporary=output/'owned_checkpoint.tmp';need(not temporary.exists(),'No replay of partial checkpoint')
    with temporary.open('xb') as f:f.write(raw)
    os.replace(temporary,output/'checkpoint.pt');guard(0)


def fit(train_features,val_features,train_labels,val_labels,copy_record,variant,output,*,guard,resource_check):
    """One native finite fit. Target/cache order is fixed, IID truth is absent."""
    c=contract();need(variant in VARIANTS and callable(resource_check),'Exact variant and actual root monitor')
    device=_gpu_context()
    import numpy as np
    import torch
    seed=c['fit_seed'];random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    train=ChunkDataset(train_features,train_labels);val=ChunkDataset(val_features,val_labels)
    need([p['feature']['parent_id'] for p in train.parents]==['published_recon_train_%03d'%i for i in range(5)] and
         [p['feature']['parent_id'] for p in val.parents]==['published_recon_val_000'] and
         all(p['feature']['variant']==variant for p in train.parents+val.parents),'Exact fiveTRAIN/oneVAL and one disclosed eligibility variant')
    need(train.unique_targets==500000 and val.unique_targets==100000,'Exact common target budget')
    output=fresh(output,guard);model,loss_fn=native_model(copy_record,device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=2e-4,weight_decay=1e-4)
    loaders=(_loader(train,True,seed),_loader(val,False,seed));best=float('inf');best_epoch=0;best_state=None;patience=2;history=[];updates=0
    for epoch in range(1,21):
        model.train();train_loss=0.;train_batches=0;exposures=0
        for batch in loaders[0]:
            resource_check('before_ARGMix_TRAIN_batch')
            ids,dist,labels,mask,cm,_,_=batch
            ids,dist,labels,mask,cm=[x.to(device,non_blocking=True) for x in (ids,dist,labels,mask,cm)]
            optimizer.zero_grad();_,logits=model.forward_chunks(ids,dist,mask,cm,pad_id=0)
            loss=loss_fn(logits,labels,mask,label_smoothing=.1);need(bool(torch.isfinite(loss)),'Finite native loss')
            loss.backward();optimizer.step();updates+=1;train_loss+=float(loss.detach());train_batches+=1;exposures+=int((mask&(labels!=-100)).sum())
            resource_check('after_ARGMix_TRAIN_update')
        need(exposures==train.label_occurrences,'Every original native overlap occurrence included exactly once per pass')
        model.eval();value=0.;batches=0
        with torch.no_grad():
            for batch in loaders[1]:
                resource_check('before_ARGMix_VAL_batch');ids,dist,labels,mask,cm,_,_=batch
                ids,dist,labels,mask,cm=[x.to(device,non_blocking=True) for x in (ids,dist,labels,mask,cm)]
                _,logits=model.forward_chunks(ids,dist,mask,cm,pad_id=0)
                value+=float(loss_fn(logits,labels,mask,label_smoothing=.1));batches+=1
        val_loss=value/batches;need(math.isfinite(val_loss),'Finite native checkpoint selection loss')
        improved=val_loss<best
        if improved:
            best=val_loss;best_epoch=epoch;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};patience=2
        else:patience-=1
        row=dict(epoch=epoch,optimizer_updates=updates,train_batch_mean_loss=train_loss/train_batches,val_batch_mean_loss=val_loss,
            train_target_occurrences=exposures,unique_TRAIN_targets=500000,selected_epoch=best_epoch)
        history.append(row);save_json(output/('epoch%02d.json'%epoch),row,guard,65536)
        _checkpoint(output,dict(schema='ARGMix_prospective1611_checkpoint_v1',variant=variant,source_ref=ref(__file__),contract_ref=ref(CONTRACT),
            copy_ref=copy_record,train_feature_refs=train_features,val_feature_refs=val_features,train_label_refs=train_labels,val_label_refs=val_labels,
            class_order=['Ana','CHG','WHG','EHG'],best_epoch=best_epoch,best_val_loss=best,selected_state_dict=best_state,
            last_epoch=epoch,last_state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},optimizer_state_dict=optimizer.state_dict(),updates=updates),guard)
        resource_check('after_ARGMix_epoch_checkpoint')
        if patience<=0:break
    result=dict(schema='ARGMix_prospective1611_fit_completed_v1',variant=variant,checkpoint_ref=ref(output/'checkpoint.pt'),source_ref=ref(__file__),
        contract_ref=ref(CONTRACT),epochs_completed=len(history),max_epochs=20,optimizer_updates=updates,
        native_early_stop_patience=2,best_epoch=best_epoch,best_val_loss=best,unique_TRAIN_targets=500000,unique_VAL_targets=100000,
        native_overlap_TRAIN_occurrences_per_epoch=train.label_occurrences,train_chunks=len(train),VAL_chunks=len(val),history=history,
        native_validation_objective='unchanged mean of batch masked CE with label_smoothing0.1',
        IID_truth_read=False,original_paper_reproduction=False)
    save_json(output/'completed.json',result,guard);return result


def predict(feature_record,fit_record,copy_record,output,*,guard,resource_check):
    """Seal exact-row probabilities before any IID ancestry labels are read."""
    c=contract();device=_gpu_context()
    import numpy as np
    import torch
    feature=metadata(checked(feature_record));fit_info=metadata(checked(fit_record));checkpoint=checked(fit_info['checkpoint_ref'])
    need(feature['variant']==fit_info['variant'],'Same eligibility pipeline')
    state=torch.load(checkpoint,map_location='cpu',weights_only=False)
    need(state['source_ref']==ref(__file__) and state['contract_ref']==ref(CONTRACT) and state['copy_ref']==copy_record,'Frozen selected model provenance')
    model,_=native_model(copy_record,device);model.load_state_dict(state['selected_state_dict'],strict=True);model.eval()
    data=ChunkDataset([feature_record],None);loader=_loader(data,False,c['fit_seed'])
    sums=np.zeros((100000,4),dtype=np.float32);counts=np.zeros(100000,dtype=np.uint32)
    with torch.no_grad():
        for ids,dist,_,mask,cm,positions,parent in loader:
            resource_check('before_ARGMix_sealed_prediction_batch')
            ids,dist,mask,cm=[x.to(device,non_blocking=True) for x in (ids,dist,mask,cm)]
            _,logits=model.forward_chunks(ids,dist,mask,cm,pad_id=0);prob=logits.softmax(-1).cpu().numpy()
            valid=positions.numpy()>=0;indexes=positions.numpy()[valid]
            np.add.at(sums,indexes,prob[valid]);np.add.at(counts,indexes,1)
    need(bool((counts>0).all()),'Complete exact100k prediction row coverage')
    probabilities=sums/counts[:,None];need(np.isfinite(probabilities).all() and np.allclose(probabilities.sum(1),1,atol=1e-5,rtol=0),'Finite native averaged probabilities')
    output=fresh(output,guard);raw=probabilities.astype('<f4').tobytes();guard(len(raw))
    with (output/'probabilities.f4').open('xb') as f:f.write(raw)
    guard(0)
    result=dict(schema='ARGMix_prospective1611_prediction_seal_v1',parent_id=feature['parent_id'],split=feature['split'],variant=feature['variant'],
        feature_ref=feature_record,selected_fit_ref=fit_record,checkpoint_ref=fit_info['checkpoint_ref'],source_ref=ref(__file__),contract_ref=ref(CONTRACT),
        probabilities_ref=ref(output/'probabilities.f4'),shape=[100000,4],dtype='little-endian float32',row_order_ref=feature['row_order_ref'],
        class_order=['Ana','CHG','WHG','EHG'],overlap_aggregation='unchanged equal mean of overlapping native chunk softmax probabilities',
        truth_or_labels_read=False,optimizer_steps=0,scientific_accuracy_score_claimed=False)
    save_json(output/'prediction_seal.json',result,guard);return result
