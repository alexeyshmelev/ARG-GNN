# Current-release ARGMix prospective1611 concrete adapter

This is a frozen source-only packet. No numerical/project module, Rust build, simulation, model, guard/admission, GPU/process probe, scientific array/checkpoint read or Git operation was executed by its author. All writes are confined to this dedicated packet. Root must independently review and bind actual source, runtime and capacity before each execution.

`adapter_v1.py` implements source-copy materialization, exact shared-row planning, native feature extraction, a lazy dataset, finite native-model fits and sealed predictions. `sample_iterator.prospective1611_v1.diff` is the only native source patch. Its complete postimage is included. The pinned author release is never modified. The paper/current-release/exclusion differences and superseded raw-TMRCA rule are in `FIDELITY_AUDIT.md`.

## Concrete protocol

Both `author_eligibility` and `focal_diploid_excluded` retain the current author15reference/0ancestor distance matrices and transformer+BiGRU architecture. NF/Yam have independent donor/query roles. The latter variant excludes both focal haplotypes before native rank. The former preserves author candidate inclusion. Both retain author quantized-log rank and original reference-list-index ties, including TRAIN's native nearest-drop1. Our earlier raw-TMRCA donor helper is not used.

The exact frozen100k shared rows per parent are selected by the generator packet, not sampled again. An observed-only request sidecar carries actual inferred node IDs, explicit diploid IDs and exact requested tree indices. No age-based identity recovery or assumed cohort node ranges is used. Native requests are filtered before LCA/feature work when a tree has no selected query. Native matrix/token output is placed directly into original shared-row order.

Observed cache size is exactly28,000,000bytes per parent:1,600,000token bytes,25,600,000native integer distance bytes and800,000FP32 cM feature bytes. Integer caches are lossless because native tokens fituint8 and distance bins are0..14. Dataset tensors cast to native long/int16, while model computation remainsFP32. Map interpolation follows the original cumulative-Morgans then multiply-by100 arithmetic. No chromosome-times-query or dense padded-chunk archive is materialized.

The primary context consists of shared sampled rows only, ordered per query and genomic position. This is a disclosed common-row reconstruction rather than a claim of the author's original full-context sampling. Native1024/512 chunks and padding/overlap behavior are retained lazily. Native code still evaluates padded rows, preserving its core implementation. The differing information/context budget must be disclosed in any pipeline comparison with a model using every local tree. No architecture-only attribution or original-paper performance claim follows from this setup.

Fit budget is fiveTRAIN parents/500k unique labels and oneVAL parent/100k labels, AdamW lr2e-4/weight_decay1e-4, smoothing0.1, batch16, max20epochs, patience2, native batch-mean masked VAL loss selection, no gradient clipping and no scheduler. The preexisting ARGMix fit seed2144125403 is reused. Native overlap occurrence counts are logged separately from unique targets. Checkpoints are saved atomically each completed epoch. The task title is `AI Auto Research Pipeline Test`, and only `CUDA_VISIBLE_DEVICES=0` is accepted. Four persistent DataLoader workers, prefetch2 and pinned memory are configured. Root owns actual CPU/GPU/resource supervision.

## Exact root API and native build

Use a fresh root-supervised process per stage. The established native interpreter is `.runtime/official_argmix_abi210_v1/cu129/env/bin/python -B`. The source packet does not install or modify that environment. It imports no numerical library at module import.

```python
from pathlib import Path
import importlib.util
project=Path('/workspace-SR003.nfs2/ARG-GNN')
packet=project/'research/reviews/ARGMix_prospective1611_native_adapter_source_20261016_v1'
spec=importlib.util.spec_from_file_location('argmix1611_adapter_v1',packet/'adapter_v1.py')
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
# guard and resource_check are root's ACTUAL admitted write/resource callbacks.
copy=project/'data/ARGMix_prospective1611_native_v1/author_copy'
a.materialize_author_copy(copy,guard=guard)
```

Root creates only the dataset-level parent directory first, after admission. Materialization verifies the86-file author inventory and changes exactly the one declared Rust file in the fresh copy. Its `native_copy.json` contains exact build argv/environment. The compiler command is:

```text
cargo build --manifest-path /workspace-SR003.nfs2/ARG-GNN/data/ARGMix_prospective1611_native_v1/author_copy/src/rust/ancpath/Cargo.toml --locked --lib --release --no-default-features --features extension-module
```

Use the returned environment with CARGO_HOME, CARGO_TARGET_DIR and TMPDIR inside `author_copy/build`, plus the existing native interpreter as PYO3_PYTHON and empty CUDA_VISIBLE_DEVICES. Root must qualify the installed existing cargo/rustc toolchain without triggering global installation and bind actual executables/environment. No new dependency is added to Cargo.toml. Disabling optional TorchScript features builds only the CPU sampling extension, not a different neural model. The expected extension is `author_copy/build/target/release/libancpath.so`. Build cap is8GiB and must cover build/cache/temp. Actual compile/import/core parity remains unqualified.

After root has actual generator/inference/support products, CPU calls for one parent and one variant are:

```python
parent='published_recon_train_000'
generation=project/'data/ARGMix_prospective1611_IID_v1'/parent
variant='author_eligibility'  # or separately frozen 'focal_diploid_excluded'
owned=project/'data/ARGMix_prospective1611_native_v1'/variant/parent
# Root creates only owned.parent after admission. Stage outputs themselves must be fresh.
a.prepare_parent(generator_contract_path,parent,generation,generation/'inferred',generation/'shared_support',
                 variant,owned/'plan',guard=guard,resource_check=resource_check)
a.extract_native_features(a.ref(owned/'plan/observed_plan.json'),a.ref(copy/'native_copy.json'),
                          actual_qualified_extension_ref,owned/'features',guard=guard,resource_check=resource_check)
```

Run native extraction with empty CUDA_VISIBLE_DEVICES and a fresh process because it imports the exact separately built extension once. The extension record must have the actual path/SHA256 and come from root's successful build qualification, not this source-only handoff. It must not point at the older stock extension. Shape and every shared tree/focal row are checked before feature completion is written. Every original input hash is verified by the generator's observed-asset interface. Runtime tree intervals and IDs are checked directly, never inferred by cohort age.

Collect exact actual feature-completion refs and separately generated TRAIN/VAL external label-completion refs in registered parent order, then run on root-admitted physicalGPU0:

```python
# train_feature_refs: five original TRAIN000..004 in that order, all same named variant
# val_feature_refs: one VAL000
# train_label_refs/val_label_refs: corresponding truth_targets/completed.json, same exact shared support
# actual copy_ref remains a.ref(copy/'native_copy.json')
a.fit(train_feature_refs,val_feature_refs,train_label_refs,val_label_refs,copy_ref,variant,
      actual_fresh_fit_output,guard=guard,resource_check=resource_check)
```

Predict each IID parent using only its observed feature cache and the selected fit:

```python
a.predict(actual_IID_feature_ref,actual_fit_completed_ref,copy_ref,actual_fresh_prediction_output,
          guard=guard,resource_check=resource_check)
```

Predictions average native overlapping chunk softmax probabilities and scatter to original shared row order. `prediction_seal.json` binds the exact target-row manifest, feature cache, selected fit and raw100000x4 little-endianFP32 probability matrix. It reads no local ancestry labels. Root must apply its common scoring protocol and read IID truth only after required prediction seals. No native-score or original-table number is supplied by this packet.

## Finite scope and review limits

Source copy is below16MiB. Parent observed planning is bounded by two8MiB JSONs. Each feature scope has a64MiB ceiling around28MB raw feature bytes. Each fit scope is256MiB, checkpoint serialization is capped at64MiB with at most an old and atomic temporary file concurrently, and prediction scope is8MiB. Source callbacks check actual required writes. These are per-stage ceilings, not available-capacity statements. Root monitors actual aggregate resources, wall time, native-build downloads and dedicated temporary/cache paths using the existing runtime. There is no new launcher, service, capacity monitor or admission framework.

`static_scientific_review.v1.json` checks Python AST/compile-without-execution, exact original neural definition extracts, prior seed reuse and unchanged native rank/matrix sections. Rust has not been compiled. No dynamic core equivalence or model forward has been claimed. Actual native build/import, requested-row parity, lazy-chunk integration and one first fit remain root execution work. These steps do not require any FP64 training or a second precision campaign.

Generator v1 itself is source only. This adapter therefore consumes future actual frozen manifests and never fabricates target arrays, successful outputs or benchmark results. The five misspecification dictionaries and common scorer remain separate unfinished stages. This concrete source advances the prospective comparison, but neither variant has been trained or scored.
