# H060 legacy-fast failure diagnosis

The legacy-fast attempt is a genuine scientific failure: direct return 1, OS wait status 256, completed ref null, owned drain true. ROOT reports consumed tool 1723 outer 0; that outer status does not convert the scientific failure to success.

The actual traceback fails at warmstart_train_v2.py:469 while saving TRAIN_observation_barrier.json. The shared bounded writer rejects the 3,145,728-byte aggregate JSON cap before opening the product. Only started.json (615 bytes) preceded this call, so the attempted barrier exceeded 3,145,113 bytes. Its exact serialization was not retained. The earlier NumPy warning is not the exception.

failed_training.json records zero attempted updates in both arms, zero complete new paired updates and no checkpoint. The source places this failure after all 20 observation/cache preparations and before the target factory/joins and training loop. The accepted saved-600 history is unchanged.

Global-only v2 uses the same cap and writer but a different typed barrier without legacy block hashes. It still embeds shared per-hold episode/cut metadata. This establishes a serialization risk, not a current failure or fit result for execution 71501. No global output, process, payload or truth was probed.

Preserve this failure and leave the existing global run unchanged until its genuine terminal is consumed. Preventative compact-commitment source work is separately authorized; it must preserve full support, checks, 20-parent barriers and 1,200 updates without raising caps or adopting into the current run.
