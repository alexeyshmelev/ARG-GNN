# ARGMix original-input recovery, 15 October 2026

Public-source recovery produced useful upstream metadata, but **did not recover the original 1,611-person/no-BAA input or an executable paper-era recipe**. All eleven required-input gates remain open. The new lookups leave ARGMix membership, cohort, simulation population, generation age and eligibility blank. They are not complete-roster inputs.

## Recovered assets

| Asset | Recovered content | Limitation |
|---|---|---|
| `upstream_ancient_candidate_lookup.v1.tsv` | 1,015 distinct ancient IDs, raw ages/date bounds, dating source, country, group labels and QC/relative flags | AP upstream painted metadata, not authenticated ARGMix subset |
| `upstream_modern_EUR_candidate_lookup.v1.tsv` | 788 distinct European source IDs, original/updated populations, release/relatedness flags, released chr22 membership | Exact ARGMix 660-person selection remains unknown |
| `HGDP1KGP_chr22_released_sample_ids.txt` | 4,091 released chr22 sample IDs | Header metadata only; no variant rows decoded or retained |
| `iceman_source_metadata.v1.json` | SAMEA114266904, PRJEB56570, five run records and 3350–3120 calibrated BCE date range | Exact final alias, selected BAM and generation age remain unknown |
| `mesoneo__data__Ancestral_paths_new__simulation_metadata.tsv` | 1,518 synthetic upstream IDs/populations with fixed ages | Upstream config identifies chromosome 3, not ARGMix panel/perturbations |
| `mesoneo__data__ancestral_paths_v3__simulated_relate_painted.sampleInfo.tsv` | 476 synthetic IDs/populations/ages, including 7 BAA | Original AP example, not an ARGMix replacement |

The ancient source is the pinned [ekirving/mesoneo_paper](https://github.com/ekirving/mesoneo_paper/tree/ef3bb42fa8739b7dbf56af51f54f691e3e2e3989) file `data/Ancestral_paths_new/ancestral_paths_merged_filtered_age.sampleInfo.tsv`, saved as `mesoneo__data__Ancestral_paths_new__ancestral_paths_merged_filtered_age.sampleInfo.tsv`. Its SHA256 is `de75ca6cfb7502864603f0ce9c9483ac0744de95f7cebd9149d6c929ba87abab`.

It has 1,312 unique IDs: 1,015 ancient and 297 modern (107 TSI, 91 GBR, 99 FIN). Every ancient `popId` equals that person's `sampleId`, so **popId is not a simulation population assignment**. All ancient `age` values equal `ageAverage`, range 250–14,800, and eleven rows lack date bounds. The table does not explicitly declare age units. Its calibrated-date context and upstream `gen_time: 28` do not establish the ARGMix generation ages; no conversion was made. The recovered alternate neo.impute metadata has the same ages for all 1,312 IDs.

The modern source `gnomad_meta_updated.tsv` has SHA256 `e18e7a29d0567b8063edc1a714bd31e57dc422823ba51af2c63fecef0dbc3cf1`, 6,158,624 bytes, 4,150 rows and 198 columns. Its exact cloud URI is cited by the pinned [atgu/hgdp_tgp README](https://github.com/atgu/hgdp_tgp/blob/bf8ef3b4e6099380225072f0df546b69842f8e8d/README.md). The saved object generation is `1714521690603290`. Original and updated population labels are retained; original Italian is updated to BergamoItalian.

### Modern selection diagnostics

These are source-policy counts, not recovered ARGMix rules.

| Policy | Raw metadata | Intersect actual released chr22 IDs |
|---|---:|---:|
| Genetic.region = EUR | 788 | 771 |
| Above plus release_related = false | 671 | 668 |
| EUR plus release = true | 666 | 663 |

None gives 660. Do not remove three people or choose other filters merely to force the published count. The released phased-v2 chr22 BCF object has 4,091 header sample IDs, generation `1691452839099606`. One bounded 131,072-byte HTTP range was read; only the header was decoded and only header text/IDs retained. The header ended within the first 11,889 compressed bytes. No variant records were parsed. This resource does not authenticate the authors' subset.

The Iceman source paper is [Wang 2023](https://doi.org/10.1016/j.xgen.2023.100377), PMC10504632. It states 3350–3120 calibrated BCE and ENA study PRJEB56570. The 1,771-byte ENA report identifies four library BAMs plus combined-BAM candidate ERR11837081, all for SAMEA114266904. No BAM or index was downloaded. The range midpoint and any chosen generation conversion are not claimed as ARGMix's sample time.

## What a successor can use

The ancient lookup supplies exact source IDs and raw date/group fields for joining an authenticated membership/reference table. The modern lookup supplies candidate IDs, population labels and existing metadata filters. The Iceman record supplies a public biological-sample identity/date range. Each transformed lookup row carries source filename/hash and `provenance_kind=upstream_candidate_metadata`.

The strict roster still needs final ancient/modern ID selections, cohort-to-simulation-population mapping, precise ADMIXTURE/QC reference split, generation ages and explicit reference/query exclusion policy. Modern age zero follows the simulation contract only after membership is established. A geographic/population label does not assign a simulation population or role.

Recreate the saved lookups from the server repository root:

~~~sh
source scripts/project_env.sh
"$ARGGNN_PYTHON" -B research/reviews/ARGMix_original_input_recovery_20261015_v1/recover_metadata_tables_v1.py
~~~

This local transformer has no network calls and writes only this folder. It does not emit the prior packet's complete-roster schema.

## Map, perturbations and original code

No original chr22 map/interval was recovered. The upstream AP selection config/rules specify GRCh37 and `genetic_map_chr{chr}_combined_b37.txt`, but map bytes are absent from that tree. The August ARGMix tutorial points to GRCh38 Relate inputs and `genetic_map_22.txt`. Neither source context identifies the April simulation build, map/version, length, interval or coordinate transform. The modern header does not establish a simulated interval.

The recovered upstream config has `gen_time=28`, `Ne=30000` and `mu=1.25e-8` with selection-analysis Relate rules; these are upstream source facts, not authenticated ARGMix settings. The fixed-date 1,518-row chr3 simulation table has Present919, BronzeAge238, Neo174, Yam13, WHG73, EHG62, Ana25 and CHG14. It supplies no five realized OOD models, draw distributions or no-BAA graph change.

The current ARGMix tree, its one public branch/no forks, linked AP/selection repositories and bounded inventories yielded no April coalescent config, original 1,611-ID roster, map or perturbation manifest. The prior paper-revision audit remains the evidence for nine August commits and empty tags/releases; that search was not repeated. The inspected tspaint inventory identified no author-original execution input and was not promoted to evidence of the ARGMix recipe. Missing public assets may still exist in private or unindexed archives.

## Remaining required gates

`required_input_gate_update.v1.json` mirrors all eleven IDs in the previous plan, preserves each unresolved status and closes none:

1. Full roster, point generation ages, cohorts, simulation populations and Iceman alias/time.
2. Reference/query eligibility, NF/Yamnaya roles and focal/haplotype/diploid exclusion.
3. Actual no-BAA demographic graph modification.
4. Actual chr22 map/hash/build/version, interval and coordinate transform.
5. Mutation model and all-cohort 0.001 error implementation.
6. Relate version/options/size iterations/final reestimation/seeds.
7. Five realized OOD models or complete demographic draw recipe.
8. Sampling/target/stride/tie/ancestor/quota/shortfall rules.
9. Paper 25-reference/3-ancestor ARGMix and PyTorch AP implementations.
10. Optimizer/loss/hyperparameters/epochs, seeds and checkpoint lineage.
11. Table uncertainty statistic/denominator/ddof and original replicate products.

The strongest remaining public upstream target is the AP paper's reference-list Supplementary Tables XLSX, `41586_2023_6705_MOESM4_ESM.xlsx`. Allentoft full metadata/date XLSX are also relevant. Those would still not establish the ARGMix-specific ADMIXTURE split and final QC/intersection.

## Retrieval and checks

Public read-only requests had explicit byte caps. The `*_HTTP_receipts.json` files retain URLs, UTC times, status/errors and saved hashes. Ancient/simulation bytes match pinned Git blob hashes. The modern cloud object's byte count and published MD5 are verified in `RECOVERY_RECEIPT.v1.json`.

Attachment recovery failed: Springer CDN DNS failed; individual PMC attachments returned challenge HTML and were discarded; Europe PMC mirrors returned 403; supported supplementary-archive HEAD calls timed out; NCBI OA-service requests returned 404. The cited AP/mesoneo Zenodo record APIs timed out. No challenge or access control was bypassed; no oversized response was retained.

Actual local checks cover unique IDs, finite raw ages, table sizes, ages across upstream versions, popId identity, modern diagnostic counts, Iceman sample/run consistency, all eleven gate IDs, pinned Git blob hashes and cloud checksums. Details are in `metadata_recovery_summary.v1.json`; `source_recovery_inventory.v1.json` pins this directory.

Only this new folder was written. No simulation, training, scoring, GPU use, active scientific payload/checkpoint read, guard/admission/accounting mutation, author message or Git command occurred. Root retains integration and execution authority.
