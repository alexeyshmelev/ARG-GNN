#!/usr/bin/env python3
"""Materialize upstream metadata lookups, never an ARGMix roster."""
import collections
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ANCIENT = "mesoneo__data__Ancestral_paths_new__ancestral_paths_merged_filtered_age.sampleInfo.tsv"
MODERN = "gnomad_meta_updated.tsv"

def rows(name):
    with (ROOT / name).open(newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))

def sha(name):
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()

def save_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def save_tsv(name, data, columns):
    with (ROOT / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(data)

def counts(data, key):
    return dict(sorted(collections.Counter(x[key] for x in data).items()))

def main():
    upstream = rows(ANCIENT)
    ancient = [x for x in upstream if x["groupAge"] == "Ancient"]
    upstream_modern = [x for x in upstream if x["groupAge"] == "Modern"]
    assert len(upstream) == 1312 and len(ancient) == 1015 and len(upstream_modern) == 297
    assert len({x["sampleId"] for x in upstream}) == len(upstream)
    assert all(math.isfinite(float(x["age"])) for x in upstream)
    assert all(x["age"] == x["ageAverage"] for x in ancient)
    assert all(x["popId"] == x["sampleId"] for x in ancient)
    assert all(float(x["age"]) == 0 for x in upstream_modern)
    old = {x["sampleId"]: x for x in rows("mesoneo__data__neo.impute__neo.impute.1000g.sampleInfo.tsv")}
    assert all(x["age"] == old[x["sampleId"]]["age"] for x in upstream)
    aout = []
    for x in ancient:
        aout.append({
            "source_sample_id": x["sampleId"],
            "upstream_popId_raw": x["popId"],
            "upstream_groupLabel_raw": x["groupLabel"],
            "age_raw": x["age"],
            "ageAverage_raw": x["ageAverage"],
            "ageLow_raw": x["ageLow"],
            "ageHigh_raw": x["ageHigh"],
            "age14C_raw": x["age14C"],
            "datingSource_raw": x["datingSource"],
            "country_raw": x["country"],
            "region_raw": x["region"],
            "flag_raw": x["flag"],
            "age_generations": "",
            "argmix_cohort": "",
            "sampling_population": "",
            "argmix_membership_confirmed": "",
            "reference_eligible": "",
            "query_eligible": "",
            "provenance_kind": "upstream_candidate_metadata",
            "source_file": ANCIENT,
            "source_sha256": sha(ANCIENT),
        })
    save_tsv("upstream_ancient_candidate_lookup.v1.tsv", aout, list(aout[0]))
    modern = rows(MODERN)
    assert len(modern) == 4150 and len(modern[0]) == 198
    ids = set((ROOT / "HGDP1KGP_chr22_released_sample_ids.txt").read_text().splitlines())
    assert len(ids) == 4091
    eur = [x for x in modern if x["hgdp_tgp_meta.Genetic.region"] == "EUR"]
    assert len(eur) == 788
    mout = []
    for x in eur:
        mout.append({
            "source_sample_id": x["project_meta.sample_id"],
            "source_s": x["s"],
            "project": x["hgdp_tgp_meta.Project"],
            "population_updated": x["population"],
            "population_original": x["hgdp_tgp_meta.Population"],
            "genetic_region": x["hgdp_tgp_meta.Genetic.region"],
            "release_related": x["sample_filters.release_related"],
            "hard_filtered": x["sample_filters.hard_filtered"],
            "high_quality": x["high_quality"],
            "release": x["release"],
            "in_released_chr22_header": str(x["project_meta.sample_id"] in ids).lower(),
            "argmix_membership_confirmed": "",
            "argmix_cohort": "",
            "sampling_population": "",
            "reference_eligible": "",
            "query_eligible": "",
            "provenance_kind": "upstream_candidate_metadata",
            "source_file": MODERN,
            "source_sha256": sha(MODERN),
        })
    assert len({x["source_sample_id"] for x in mout}) == 788
    save_tsv("upstream_modern_EUR_candidate_lookup.v1.tsv", mout, list(mout[0]))
    in_header = [x for x in eur if x["project_meta.sample_id"] in ids]
    policies = {
        "all_EUR": lambda x: True,
        "EUR_release_related_false": lambda x: x["sample_filters.release_related"] == "false",
        "EUR_release_true": lambda x: x["release"] == "true",
    }
    policy_counts = {
        context: {name: sum(pred(x) for x in group) for name, pred in policies.items()}
        for context, group in [("raw_metadata", eur), ("intersect_released_chr22_header", in_header)]
    }
    assert policy_counts == {
        "raw_metadata": {"all_EUR": 788, "EUR_release_related_false": 671, "EUR_release_true": 666},
        "intersect_released_chr22_header": {"all_EUR": 771, "EUR_release_related_false": 668, "EUR_release_true": 663},
    }
    sim = rows("mesoneo__data__Ancestral_paths_new__simulation_metadata.tsv")
    example = rows("mesoneo__data__ancestral_paths_v3__simulated_relate_painted.sampleInfo.tsv")
    assert len(sim) == 1518 and len(example) == 476
    ena = rows("Iceman_ENA_read_metadata.tsv")
    assert len(ena) == 5 and {x["sample_accession"] for x in ena} == {"SAMEA114266904"}
    save_json("iceman_source_metadata.v1.json", {
        "schema": "argmix_iceman_upstream_metadata_v1",
        "provenance_kind": "upstream_source_identification",
        "source_paper": {"doi": "10.1016/j.xgen.2023.100377", "pmcid": "PMC10504632",
                         "saved_file": "Iceman_paper_fulltext.xml", "sha256": sha("Iceman_paper_fulltext.xml")},
        "published_date_literal": "3350–3120 calibrated BCE",
        "study_accession": "PRJEB56570",
        "sample_accession": "SAMEA114266904",
        "ena_metadata_file": "Iceman_ENA_read_metadata.tsv",
        "ena_metadata_sha256": sha("Iceman_ENA_read_metadata.tsv"),
        "run_accessions": [x["run_accession"] for x in ena],
        "combined_BAM_candidate_run": "ERR11837081",
        "argmix_selected_BAM_confirmed": False,
        "argmix_sample_alias": None,
        "argmix_age_generations": None,
        "generation_time_and_date_point_selection": None,
        "note": "Published individual identity/date range and public submitted-file metadata only. No BAM or index downloaded."
    })
    save_json("metadata_recovery_summary.v1.json", {
        "schema": "argmix_original_input_metadata_recovery_summary_v1",
        "original_1611_roster_recovered": False,
        "ancient": {
            "source_file": ANCIENT, "source_sha256": sha(ANCIENT), "upstream_total": 1312,
            "ancient_rows": 1015, "modern_rows_in_upstream_table": 297,
            "all_ancient_popId_equals_sampleId": True,
            "all_ancient_age_equals_ageAverage": True,
            "ancient_age_raw_min": min(float(x["age"]) for x in ancient),
            "ancient_age_raw_max": max(float(x["age"]) for x in ancient),
            "age_bounds_missing_rows": sum(x["ageLow"] == "NA" or x["ageHigh"] == "NA" for x in ancient),
            "raw_age_interpretation": "Upstream calibrated date/age metadata, not generation ages. Table does not explicitly declare units; source config gen_time=28 is not adopted as an ARGMix setting.",
            "popId_warning": "All 1015 ancient popId values equal individual IDs; they are not simulation population IDs.",
            "groupLabel_counts": counts(ancient, "groupLabel"),
            "argmix_fields_not_established": ["membership", "cohort", "sampling_population", "age_generations", "reference_eligible", "query_eligible", "focal_exclusion"]
        },
        "modern": {
            "source_file": MODERN, "source_sha256": sha(MODERN), "metadata_rows": 4150,
            "metadata_columns": 198, "released_chr22_header_samples": 4091,
            "candidate_EUR_rows": 788, "policy_counts": policy_counts,
            "policy_counts_are_diagnostics_only": True,
            "population_original_to_updated": {"Italian": "BergamoItalian"},
            "none_of_inspected_policies_recovers_published_660": True
        },
        "upstream_simulation_metadata": [
            {"file": "mesoneo__data__Ancestral_paths_new__simulation_metadata.tsv",
             "rows": len(sim), "population_counts": counts(sim, "popId"),
             "raw_age_counts": counts(sim, "age"),
             "provenance": "Upstream config chr3_true_paths / chr3_inferred_paths. Fixed averaged dates; not ARGMix panel."},
            {"file": "mesoneo__data__ancestral_paths_v3__simulated_relate_painted.sampleInfo.tsv",
             "rows": len(example), "population_counts": counts(example, "popId"),
             "provenance": "Original AP 476-person example, including BAA; not ARGMix panel."}
        ],
        "validation": {
            "unique_source_ids": True,
            "finite_ancient_raw_ages": True,
            "no_age_conversion": True,
            "no_membership_or_role_inference": True,
            "no_1611_roster_emitted": True,
            "no_genomic_variant_rows_decoded_or_retained": True
        }
    })
    print(json.dumps({"ancient_lookup_rows": len(aout), "modern_lookup_rows": len(mout),
                      "modern_policy_counts": policy_counts, "original_roster_recovered": False}, indent=2))

if __name__ == "__main__":
    main()

