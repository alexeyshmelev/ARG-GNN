# H048 failure and one next architecture condition

H048 rejects its registered graph-rate utility condition. It does not establish that cross-tree latent memory is useless. H049 remains scientifically untrained and its frozen protocol is unchanged. I recommend one prospective condition: **H049’s sample-witness cut memory on the strong H045 own-state backbone with its direct readout**. Root decides whether to register and implement it.

| Present182, selected checkpoint | Accuracy % ± sample SD pp | NLL ± sample SD | Boundary F1 % | ECE % |
|---|---:|---:|---:|---:|
| H048 transition, pass5 | 96.379965 ± 0.600247 | 0.303922 ± 0.058599 | 16.6695 | 3.4109 |
| H048 confidence, pass20 | 96.388605 ± 0.609787 | 0.137125 ± 0.029011 | 16.7423 | 1.8190 |
| H045 foreign episode, pass30 | 96.827032 ± 0.586975 | 0.092980 ± 0.020423 | 18.1558 | 0.5594 |
| H045 own state, pass30 | 96.817464 ± 0.614204 | 0.092976 ± 0.020230 | 18.0557 | 0.5507 |

All four completed30passes/960updates per arm on32TRAIN/8reusedVAL simulations, one optimizer seed. Selection is development evidence. H048’s paired accuracy effect is −0.008640pp, SD0.144421pp, positive3/8parents; boundaryF1 is −0.072765pp. Its transition NLL, Brier and ECE worsen in all8parents. Both registered utility rules fail. Both H048 pipelines trail H045 by0.44pp accuracy and about1.4–1.5pp boundaryF1. [Exact saved-metric derivation](metrics.v1.json).

## What is controlled, and what is confounded

H048 compares graph context placed in a reset rate with the same information/capacity placed in confidence, inside a common four-state marker-grid chain. It tests that placement, not useful foreign internal-node memory. The transition arm’s2.22×control NLL and worse Brier/ECE show poorer probabilistic performance despite nearly equal hard accuracy. They do not identify the responsible confidence distribution or prove a numerical bug.

The historical H045 comparison is not a decoder ablation: episode coupling, marker representation, parameter count and decoding differ. However, source identifies a concrete shared risk. H045’s new episode projection starts at zero, preserving the H042 predictor. H048’s zero marker/rate heads still impose a new50kb initial reset chain and a learned common destination mix. Native-hold logits are repeated on the100bp grid and enter chain inference as unary evidence at each bin. Correlated repeated evidence and compulsory smoothing are plausible calibration/optimization bottlenecks, not diagnosed causes. H048 has no identity bypass that recovers the old direct predictor merely by zeroing its added heads.

H049 calls this exact H048 `graph_to_transition` decoder in every arm. It loads the original H042 checkpoint, **not H048’s trained bad weights**. Its matched memory contrasts remain valid conditional on the shared chain: the decoder is common, not an unfair between-arm treatment. A positive result could show memory helps that pipeline; a negative would reject only this memory/readout combination. Even a matched win could remain below H045. Changing frozen H049 silently would destroy its recorded scientific condition.

## One prospective condition and its biological purpose

Use the exact completed H045 **own-state** pass30 model as the common trainable backbone. Its96.8175% is within0.0096pp of the best foreign-episode model, whose episode-specific gain failed the practical criterion. Keep that whole model, including its own-state adapter, genomic BiGRU and direct classifier. This readout produces native-hold logits mapped onto the unchanged original100bp scoring support. It is not a new SNP-local decoder.

Add the existing513-parameter rank8 H049 memory before the second full-tree sweep: read first-sweep upward+outside states at the actual350-generation cut, propagate sample-supported clade-intersection history in both genomic directions, and inject the zero-initialized residual at current cut representatives. Proposed count:31812+513=32325weights per arm, requiring implementation verification. This composition has not been executed. It initially preserves the strong H045 predictor.

Biologically, a clade can split or merge across a recombination boundary while sampled descendants retain informative lineage correspondence. Pair-cell history can preserve which incoming clade supplied that context; the second tree sweep can then redistribute reference-informed evidence to queries. This crosses changing clade memberships, unlike exact-clade-only episodes. It may denoise weak inferred-tree states, or blur real ancestry changes. Neither a cut nor shared descendants certify ancestry or ancestral-individual identity.

## Controlled decision test

Keep the three H049 rules: true triple-support memory, adjacent-marginal independence null and stable-leaf memory. All share the exact H045 checkpoint, own-state adapter, cut features, parameter count, FP32 whole-parent loss, independent fresh AdamW and30passes/960updates. Require initial output equality to H045 with newO=0 in the genuine first-step qualification. Use all32TRAIN/8VAL parents and all144six-checkpoint products before VALtruth. Root owns registration, actual qualification and resources.

Suggested accuracy gate: true memory gains≥0.10pp over **each** control, with no mean1kb boundaryF1 or NLL regression, and beats frozen H04596.8270%. Report paired parent effects/SD and all cohorts. An NLL-only win does not satisfy the requested accuracy objective. Beating only the independence null supports history retention, not superiority of pair pooling over ordinary leaf history. All arms receive equal extra continuation training; comparison to historical H045 is pipeline performance, not causal attribution. Independent parents/seeds remain downstream of a useful result. [Exact proposal](proposal.v1.json).

## Prior art and no-repeat check

No new generic memory operator is claimed. [Rosvall et al.2014](https://doi.org/10.1038/ncomms5630) already expand previous/current states into memory nodes; [Scholtes et al.2014](https://doi.org/10.1038/ncomms6024) compare two-path dependence with a first-order-marginal null; [De Bruijn goes Neural](https://arxiv.org/html/2209.08311v1) learns on higher-order path graphs and projects back. Whole-tree GNN plus genomic recurrence is also established by [Whitehouse et al.2024](https://doi.org/10.1093/molbev/msae223). Cached primary sections and existing audits were checked; this bounded review establishes no priority.

H029/H030 carrier history, H043 single-neighbour transfer, H045 exact-clade episode averaging, H046 flank context and H048 rate placement already failed practical accuracy criteria. They are not rerun here. The new empirical condition is H049’s still-untested internal cut-history mechanism on the strong completed direct-readout pipeline, with exact memory controls. It is a readout/backbone-specific utility hypothesis, not evidence that another layer will improve accuracy.

Only saved metricJSON and source/cached literature were read. No truth, probabilities, checkpoint payloads, model imports, jobs, guards, GPU/resource queries, registration or Git operations occurred.
