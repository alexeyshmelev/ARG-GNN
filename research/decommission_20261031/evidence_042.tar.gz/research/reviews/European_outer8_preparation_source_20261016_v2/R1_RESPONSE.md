# R1 source response

Sealed v1 is unchanged. V2 is source only and awaits independent review and real integration qualification.

The v1 opaque-hash readiness checker is replaced by check_prediction_barrier_v2.py, which always reports PENDING_UNSUPPORTED / scientific_readiness=false and exits2. There is no JSON-only success path.

outer_prediction_validator_v2.py reads actual native probability archives through a no-follow, immutable, hash-checked observed-only reader. It enforces distinct canonical run/method/parent paths, exact native NPZ/NPY schema and bounded header geometry, FP32 probability shape/finiteness/nonnegativity/normalization, complete686 ordered query identities, native/raw node joins, C4 order and exact original observed retained centers/clipped bins. It validates all40 primary products and eight prespecified native top5 products. It binds frozen checkpoint/native completion lineage and separate actual OS-wait/launch/input/ROOT-terminal receipts; it does not treat seal booleans as sufficient.

score_outer_v2.py is the concrete submitted scorer and target-reader source, with actual source review and separate ROOT authority required. Each target boundary independently reruns full40 validation, then binds the original same-parent target/generation hashes. Existing exact-span C4, raw infinite NLL, unchanged diagnostics, AP native6 focal metrics and ARGformer raw top5 remain distinct.

outer_adapters_v2.py starts real full952 native outer integration: fixed H050 states/prediction without selection; AP complete features and Dense5; current ARGMix stock export/Rust/refinement with original overlap math; genuine ARGformer observed inference/corpus/MLM/contrastive/retrieval namespace. source_clone_plan.v2.json records all11 exact I/O/scope edits. Original sources/models/configs are untouched.

Not yet present or claimed: a reviewed actual native execution/wait driver; H050 complete outer bank/episode/corrected-cut/writer publication; qualified AP/ARGMix outer runtime and publication; qualified full952 ARGformer runtime/corpus and eight genuine MLM/contrastive fit/checkpoint pairs; actual runtime/resource/scoring admissions and reviews. These missing pieces keep readiness disabled. No job, probe, accounting call, scientific fixture, raw data/model/truth read or outer path inspection occurred.
