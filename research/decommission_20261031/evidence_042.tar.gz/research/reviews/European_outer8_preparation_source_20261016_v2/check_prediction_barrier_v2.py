"""Inactive checker; no readiness authority."""
import json
def main():
    print(json.dumps(dict(status="PENDING_UNSUPPORTED",scientific_readiness=False,scoring_authorized=False)))
    return 2
if __name__=="__main__":raise SystemExit(main())
