# European outer8 v2: source handoff

No fresh capacity exists now according to ROOT; this package makes no measurement or launch claim. It performs no admissions, jobs or scientific reads. V1 is preserved and its old readiness CLI is superseded for this workflow.

The first-parent wrapper is copied with only HERE changed to the fresh v2 package. It preserves outer000, original4GB scientific output cap, whole4GiB reservation, eight CPU threads, 32GiB RSS polling stop, 12h bound, finite owned cleanup and actual Census-child bindings. Original source/config/seeds and all eight reserved simulations remain unchanged.

Before generation, ROOT must record the existing prospective ledger/decision entry, obtain independent source review and an actual immutable fixed-method commitment. Future capacity and actual eligible CPU/runtime checks remain ROOT work. Inactive request/freeze templates contain no authority. The future entry is prepare_outer000_v1 in this v2 package, using the same separate admit-ref and execute-ref interface as v1. No command is run here.

Before prediction, finish the explicit integration blockers. outer_adapters_v2.py supplies callable native outer stage integrations; it is not a launcher. Requests must bind reviewed source, current actual admission, exact cell output and actual runtime/driver qualification. H050 still needs complete observed outer bank/episode/corrected-cut preparation and writer integration. Genuine ARGformer qualification and all eight MLM/contrastive fits/checkpoints are absent. AP/ARGMix also need actual runtime/driver review and native completion evidence.

The canonical namespace is experiments/results/European_outer8_predictions_<run>/cells/<method>/<parent>/. Products keep their native archive formats and filenames beneath that cell. The actual ROOT runner must produce separate native completion, launch/input, actual wait0/drain and ROOT terminal receipts. source_clone_plan.v2.json pins the exact isolated namespace adaptations. No original module is edited.

check_prediction_barrier_v2.py is always PENDING_UNSUPPORTED, exit2. The callable validate_matrix requires real arrays, all40 cells, observed identity/support joins, exact frozen checkpoint/native lineage and reviewed validator/adapter/scorer sources. No JSON-only boolean can yield readiness. The source is syntax/static audited only; it has not been executed on fixtures or payloads.

score_outer_v2.py is the submitted actual scorer/target-reader path. It requires a separate actual scoring request and independently reviewed complete integration qualification. It revalidates all40 actual products before every truth read. The scorer preserves exact-span C4/raw infinite NLL, original diagnostics, AP6 focal metrics separately and ARGformer raw top5 separately. Scoring requests/target hashes stay unresolved until their real artifacts exist.

No automatic loop, resume, reseed, reduced panel, new model selection, paper edit or H058 addition is introduced.
