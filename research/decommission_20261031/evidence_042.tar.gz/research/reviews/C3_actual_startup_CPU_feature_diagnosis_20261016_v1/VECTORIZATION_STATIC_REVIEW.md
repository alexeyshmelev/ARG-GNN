# Vectorized branch-support static review

Verdict: no blocking source concern for the root-owned bounded CPU comparison. This is an independent source-only review. It does not establish runtime correctness, memory use or a speedup, and does not authorize live C3 integration.

Reviewed source: research/reviews/C3_vectorized_branch_support_source_20261016_v1/branch_concordance_support_torch_v2.py
SHA256: bd9bdc32a1e48a4cd5ec0d6ebff33d1b7fabfcdec40cd7b6d88e6cf8389d9abe

Reference: src/arggnn/mutation_routed_tree_observations_v1.py::branch_concordance_support_v1
SHA256: 922df286e595370ade23595420a325014e4df64aac88060e8a1a846684eab068

API: branch_concordance_support_torch_v2(tree, genotype, allele_count, sample_ids, *, site_chunk_size=32). The chunk range is 1..256. Return is a fresh NumPy float32 [N,5] array. Implementation identity is branch_concordance_torch_int64_levels_fp32_v2.

The source reuses the original allele, integer, connected-tree and unique sample-identity validators. Integer descendant counts are initialized at all called sample nodes, including sampled internal nodes. Missing calls contribute zero. The ascending child-height schedule propagates each non-root edge once with int64 index_add_. Sibling contributions add into shared parents, while parent source rows are not propagated until their descendants are complete.

The proper-allele masks retain site-specific declared alleles, ncalled>=2, positive observed allele counts and total<ncalled. Every proper split counts, including both biallelic complements and all proper multiallelic alleles. The branch-only minimum mismatch and all tied winners preserve unary-branch ties. The global integer split count normalizes the accumulated sums once. Empty sites, no proper splits, singleton trees and root flags have explicit paths.

Reference classes, donor cohorts, ages, alpha=.5 smoothing and query ancestry truth are not inputs. All observed genotypes, including query genotypes, remain included under the original helper semantics. The C3 caller's isolated-forest bypass remains untouched.

Floating accumulation changes from the reference helper's internal float64 sums to reordered float32 sums. This is explicitly documented under a new feature identity. Normal rounding differences are expected and acceptable. No bitwise or FP64 model-equivalence campaign is required.

Performance remains unmeasured by this review. The topology grouping adds stable O(N log N) sorting after the existing _layout. For zero sites the early return avoids Torch import. With only a few informative sites, scheduling, tensor conversion and allocation can exceed the saved Python-node-loop cost. The existing encoder also constructs layout before calling the helper, whose own _layout remains necessary under its standalone validation contract. A broad speedup should not be inferred from the vectorized source or from one tree.

The site chunk bounds the site axis, but RSS still depends on N, allele channels and framework workspace. Existing caller-owned worker memory guards remain necessary. Feature workers create CPU tensors only, and the module does not change thread counts, environment, resource policies or live routing.

No code execution, scientific-module import, numerical check, GPU action, integration, probe or Git action was performed in this review. Root separately reported completion of a bounded three-tree FP32-output comparison. That runtime result was not independently audited here and is not needed for this static verdict.
