# Minimal Torch descendant-count optimization design

Source-only design prepared for the root and implementation worker on 2026-10-16. No scientific code was changed, imported or executed. No numerical qualification, model fit or new live probe was run. Current C3 warming and training must continue uninterrupted.

## Implementation target

Implement a fresh successor of src/arggnn/mutation_routed_tree_observations_v1.py::branch_concordance_support_v1, lines 262-312. Base source SHA256: 922df286e595370ade23595420a325014e4df64aac88060e8a1a846684eab068.

The narrow target is its Python loop over postorder nodes for each eligible site. Replace that integer descendant-count loop with bounded site-chunk Torch CPU operations over tree levels. Keep the existing observation equations. This is an execution optimization, with no claim of a new biological feature or neural architecture.

C3 calls this function from src/arggnn/american_c3_gnn_observations_isolated_v2.py::encode_block, SHA256 adf1be0aab14e54b0d48c8cb577b3df541bed2ee88ac846f16bab8a75d56f781. Its caller retains full trees and all samples, including unary branches, and already handles a fully isolated sampled forest separately.

Proposed implementation folder assigned by root: research/reviews/C3_vectorized_branch_support_source_20261016_v1. This design does not activate that source.

## Exact existing algorithm

Let g[s,h] be the categorical genotype for site s and observed sample column h. The validator accepts -1 for missing calls and allele integers 0 through k[s]-1, with 1 <= k[s] <= 4. It rejects allele recoding, invalid shapes and out-of-range calls.

Keep _layout validation, its rooted native tree, parent array p, sample-node array sn, unique sample identities sid and the existing identity-based join from sample_ids to genotype columns. Tree labels and array positions cannot be assumed interchangeable.

For each site in its original order:

1. Join sample genotypes using sample_column. Define called as genotype >= 0, and ncalled as the number of called observed samples. Skip sites with fewer than two calls.
2. Count total[a] among called samples for every declared allele. Proper alleles have 0 < total[a] < ncalled. Skip sites without a proper allele.
3. Initialize integer descendant allele counts C[u,a] with one at each called sample node and its observed allele. Missing calls contribute zero. Traverse every node in postorder and add its counts to its parent, excluding roots.
4. For every branch u with p[u] >= 0, let d[u] be the sum of C[u,a] over alleles. For each proper allele a, compute difference[u,a] = d[u] + total[a] - 2*C[u,a]. The symmetric mismatch is min(difference, ncalled-difference).
5. Find the minimum mismatch across ALL native branches. Every tied branch wins, including native unary branches.
6. Channel 0 receives 1/number_of_winners at winning branches only when the minimum is zero. Channel 1 receives (1-minimum/ncalled)/number_of_winners at all winning branches. Channel 2 receives mismatch/ncalled on every branch. Count this proper allele as one split.
7. At the end, divide channels 0-2 by the total number of proper allele splits. Channel 3 equals that total on every branch. If there are no splits, channel 4 is one on every branch. Roots always have channel 4 equal to one and channels 0-3 equal to zero.
8. Return the existing [nodes,5] float32 array.

Both complementary biallelic splits count. Multiallelic sites contribute every observed nonempty proper allele split. Do not switch to a minor-allele rule or infer an ancestral allele.

The generic helper permits a sampled internal node if _layout accepts it, even though this particular C3 caller requires observed samples to be leaves. Initialize all sampled nodes before propagation so the successor preserves the generic behavior too.

## Minimal level-wise Torch DP

Keep the original validation and sample join. Obtain the validated height array from the existing _layout result. For every non-root edge, height[parent] is strictly larger than height[child].

For a bounded chunk of B eligible sites and A <= 4 allele channels:

- Allocate integer C with shape [N,B,A]. Use int64 initially, matching the original count type and avoiding a new overflow assumption.
- Initialize exactly the called sample-node/site/allele positions. A padded allele channel a >= k[s] stays zero. Do not clamp missing calls into allele zero without an explicit zero mask.
- Visit height levels in ascending order. Select non-root nodes at the current level. Gather their [B,A] counts and add them into their parent rows with Torch index_add_ along the node axis.
- No parent is in the same height level as its child, so the source values for a level are complete before that level is propagated.
- After propagation, use the branch rows and the original proper-allele masks for the unchanged mismatch and winner equations.

Use in-place index_add_ or an equivalent bounded scatter-add. A naive PyG scatter that allocates and zeros a full [N,B,A] result at every level introduces unnecessary height-times-full-buffer work. If using PyG scatter, reduce into compact parent rows for that level, then update the retained count tensor. Torch feature preparation alongside the existing PyG Data/model pipeline is sufficient. A MessagePassing model layer is not required for this preprocessing operation.

Only eligible sites need count propagation. Preserve their physical order and their mapping to original site indices. Site chunking is a memory partition, not subsampling. Every original eligible site and proper split remains included exactly once.

## Floating arithmetic and identity

The smallest change can keep the final per-site, per-allele NumPy vector calculations and accumulation order, while replacing only the integer DP. Integer additions are exact and order-independent within their range. This minimizes changes around sealed features.

Preserving bitwise identity is not a prerequisite for useful optimization. A further vectorized floating reduction may change rounding while preserving the mathematical features. Record it as a new implementation and feature identity, and use an appropriately small representative FP32 correctness and timing comparison if root later authorizes execution. Do not start another exhaustive bitwise or FP64 equivalence campaign.

The original helper uses a float64 accumulator internally and casts its small [N,5] feature output to float32. This existing preprocessing choice does not require training in FP64. Meaningful model training remains FP32. A successor may use normal FP32 feature reductions with an explicit identity and ordinary tolerance-based correctness assessment.

## Inputs and biological semantics that must remain unchanged

Branch support is observation-only and deliberately uses genotypes from ALL observed samples, including queries and references. The unknown quantity is query ancestry truth, which must remain unavailable. Excluding query genotypes from this unsupervised branch feature would change the method.

Do not modify donor_frequencies, its caller or any of the following:

- Observed reference_class values and the unknown/query value -1.
- Donor cohorts selected by the existing age_split, including the original less-than versus greater-than-or-equal boundary, or the one-cohort path when age_split is None.
- The original alpha=.5 categorical frequency smoothing.
- The rule requiring a site to have at least one called donor in every present class group of a cohort before that cohort's donor channels are callable.
- The masked behavior for absent donor groups and invalid padded alleles.
- Panel frequency and entropy, which use all observed calls under the existing equations.
- Sample dates, native endpoint times, positive branch durations, topology geometry, query columns and complete-tree coverage.
- Focal record positions, readout joins and external target separation.

The branch support function does not use donor class labels or age cohorts to choose its allele counts. Changing those neighboring features is outside this optimization.

## Risk cases

| Case | Required behavior |
|---|---|
| Missing genotype calls | Use ncalled as the cut universe, rather than the full haplotype count. Missing samples contribute no allele counts. |
| k=1 or a monomorphic called site | No proper split, so the site contributes nothing. |
| Biallelic variation | Count both complementary proper splits, preserving their normalization. |
| Tri- or tetra-allelic sites | Keep all observed proper alleles and site-specific k masks. |
| Unary chains | Retain all nodes and branches. Minimum-discrepancy ties include every unary branch. |
| Internal sampled node | Its own observed count plus descendant sampled counts propagate to the parent. |
| Root | Exclude from minimum/winner and branch-normalization arrays. Set its channel 4 to one. |
| Fully isolated C3 sampled forest | Preserve encode_block's current bypass. Do not invent connecting edges or feed the forest to the connected-tree helper. |
| No sites or no eligible splits | Preserve the existing no-evidence indicator without reducing an empty winner dimension. |
| Sample-node or genotype-column permutations | Join by the original unique identities, not by presumed array order. |
| Different tree sizes or large unary depth | Bound site chunks by actual N and channels. Tall trees reduce the degree of level parallelism. |
| Chunk boundary | Never reset the global split count or average per-chunk averages. Normalize once over all original proper splits. |
| Duplicate parent targets in a level | Use additive integer accumulation, not indexed assignment that loses sibling contributions. |
| FP32 reduction order | Permit normal numerical differences, document a new identity and avoid loading old sealed features under that identity. |
| CPU workers | Keep CUDA visibility empty and avoid CUDA contexts in feature workers. |

## Work and memory comparison

Let S be eligible sites, N nodes, E branches, A <= 4 allele channels and D tree height.

The current integer propagation does O(S*N*A) arithmetic with approximately S*N Python node iterations. Its final discrepancy and winner work is O(S*E*A) in vectorized arrays.

The level-wise DP has the same leading arithmetic complexity. It replaces the Python node iterations with approximately ceil(S/B)*D native scatter calls, plus the unchanged per-split vector calculations if using the minimal variant. It trades bounded [N,B,A] temporary storage for fewer Python calls and larger native operations. A chain with D near N and a tiny B benefits less than a broad tree. No speedup magnitude is established without measurement.

One int64 count tensor uses 8*N*B*A bytes. A gathered source tensor can add at most the same payload during one level operation. For N=3200, B=64 and A=4, these two tensors total 13107200 bytes, or 12.5 MiB. This example is a payload calculation, not an observed allocation or an RSS guarantee. A real scratch cap must also allow genotype staging, masks, branch arrays, output, allocator overhead and framework workspace, and must remain under the worker RSS cap.

Choose B from actual N, A and a small explicit scratch-byte allowance. Do not allocate counts for all sites unconditionally. Avoid constructing an N-by-N ancestry matrix, a sample-pair matrix or a full dense scatter output per level.

Increasing producers from 2 to 8 leaves per-block work unchanged, but exposes independent blocks to more CPU cores. The conservative operational envelope retaining the current margins is aggregate 168 GiB and root 176 GiB, with 88 GiB main RSS and 8 GiB per worker. The host must have available memory before a fresh admission. More producers also duplicate observation loading and native per-parent state, so linear scaling is not established.

The two changes are compatible. More producers provide coarse parallelism. The integer DP reduces Python overhead within each producer. Parent-side hashing, private tensor cloning, ordered delivery, serial parent sealing, NFS access and deep unary trees can limit either improvement. The observed 10-second CPU counters do not identify which limit will dominate after optimization.

## Handoff

Implement only the bounded integer DP successor first. Preserve validation and the output contract, document its source and feature identity, and leave activation, memory admission and any representative correctness/timing run to root. No new architecture claim, biological claim or measured performance claim follows from this design.

Diagnosis: research/reviews/C3_actual_startup_CPU_feature_diagnosis_20261016_v1/REPORT.md
SHA256: 8edf19ea929cd722627cbf869107a2e657ed09b2779f321dca1cc847e4db598c
