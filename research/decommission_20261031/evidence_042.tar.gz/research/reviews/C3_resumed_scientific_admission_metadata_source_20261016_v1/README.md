# Deferred C3 continuation and two-job GPU0 metadata

This packet is source preparation. It has not stopped a job, migrated a checkpoint, configured a guard, reserved storage, admitted a job, or launched a process. No numerical package was imported during its inspection.

The concrete builders are prepare_resume_v1.py and finite_envelopes_v1.py. They return dictionaries. Root alone writes actual metadata through the existing exclusive metadata writer, performs every unchanged original guard operation, and starts the reviewed finite controller.

## Preserved science

The fresh C3 input copies the complete original input, all 71 original transitive source-map entries and the exact TRAIN bindings. It retains 20 TRAIN parents, whole trees with 1,600 haplotypes, 10,000 focals per complete-parent update, 30 passes, and 600 effective optimizer updates. The existing reviewed resume runtime retains model, AdamW, cursor, RNG, history and every scheduled checkpoint. The migrated boundary is outside the new training scope. It is not a fresh initialization.

The scientific CUDA guard remains 40 GiB and CPU RSS remains 128 GiB. The additional logical scheduling and efficient-step abort ceiling is 24 GiB, with the original 2 GiB per-job margin. Training remains FP32 without autocast or TF32. Existing cache and two-worker prefetch caps are unchanged.

The native nested method is returned by deep copy from the genuine original capability. Its input, storage, caps, name, literal arguments, 7 GiB scientific charge and absolute expiry remain exact. Reuse requires the actual original row to be cancelled with no PID, start time or owned identities. This packet cannot manufacture that proof or extend the expiry.

## Count-derived prospective storage

The fresh C3 scientific cap is 32 MiB, comprising a 28 MiB phase allowance, 1 MiB TMP allowance, 1 MiB worker auxiliary allowance and 2 MiB packet overhead allowance. All are positive.

The phase plan allows up to 600 durable progress records, each with 8,192 serialized bytes plus the original 8,192-byte write overhead, all remaining scheduled checkpoints plus one failure-boundary file, 8 MiB for original runtime initialization, and 512 KiB for other phase control. At least one genuine original scheduled candidate must have been retained, as expected from the already verified step-100 checkpoint. With one retained candidate there are at most six new checkpoint files and the phase plan is 28,229,632 bytes, or 26.921875 MiB. Each checkpoint has a prospective 1.5 MiB serialized planning allowance. This is not a measured or proven serialization bound. The unchanged actual storage guard remains authoritative and must stop an over-cap write.

Each outer operational scope is a separate 4 MiB reservation with no auxiliary scopes and no scientific charge duplication. The controller is a separate 32 MiB reservation with no auxiliary scopes. The controller has two logical jobs, capped logs of 256 KiB and 1 MiB, and the unchanged overwrite-in-place registry and guarded writer. 32 MiB retains the existing controller checker minimum and leaves over 30 MiB after both bounded worker logs. This is a conservative operational allowance, not measured peak use.

The complete guard family is mandatory in every new reservation. The historical guard bindings are read from the original genuine reserve authority only for pre-stop source-shape planning. Root must obtain the current actual bindings from the unchanged guard at each admission.

## Pre-stop complete direct-union inspection

The worst included branch has both explicit checkpoint rollback and the original transport exit remaining UNKNOWN. Counts are:

| Reservation | Direct paths | Remaining slots |
|---|---:|---:|
| Fresh C3 scientific | 60 | 4 |
| C3 outer operational | 62 | 2 |
| Native outer operational | 64 | 0 |
| Controller | 61 | 3 |

Base finite common requirements contain 24 paths. Migration adds 12 and the transport-UNKNOWN family adds eight, giving 44 common paths. The original 15 guard bindings add 12 distinct paths, giving 56 before each scope's own metadata.

The native outer scope has no spare direct slot. Its runtime list contains only the exact original native runtime and module. The original scientific reservation retains its complete native consumer closure. Every native and C3 source-map entry remains in the controller's authenticated transitive source map, which has no 64-entry ceiling. No direct requirement is made transitive merely to fit.

source_shape_inspection.v1.json contains actual current source/metadata references and clearly tagged uncreated future-path descriptors. Those descriptors have no SHA and are not event references. Root must recompute all actual complete unions before reserve. Any additional required source can change these counts and must not be dropped.

## Exact deferred root recipe

The following is an ordered API recipe, not an executed script. All references below must be obtained from actual saved files. Never synthesize a future event's path/SHA pair.

1. Preserve both live jobs while independently reviewing this packet. The source-shape inspection can run now. It does not observe processes, devices, accounting state or leases. If a transition is later chosen, first obtain genuine H050 completion, the actual C3 terminal and owned drain, full-state migration output with actual outer wait 0 and root-sealed manifest, original queued-native cancellation, old-controller future capability revocation, and the reviewed old-controller handover proof. Retain the original controller external tool status UNKNOWN when that is the actual evidence. Use the already passed FP32 qualification. Do not rerun it.

2. With actual sealed migration metadata, call prepare_resume_v1(OLD_INPUT_REF, actual_manifest_ref, names). Names have four keys: job_id, packet_directory below this source folder, a fresh experiments/results output_directory, and a fresh .runtime/tmp/gpu0_shared short_tmp_directory. The builder authenticates the actual migration via the unchanged integration reader and validates copied caps through the original source contract. At least one original scheduled candidate must appear in the actual migration manifest.

3. In the fresh packet, use the existing contract c.save(packet, filename, value), where c = original_contract_v1(). Save caps, then worker_request_v1(materials, caps_ref), then operational_config_v1(materials, request_ref). Save a fresh byte-identical JSON runtime copy from the original refs.runtime record. Save admission_authorization_v1(materials, created_at_utc=actual_root_time, expires_at_utc=actual_root_time_plus_at_most_24h), followed by source_closure_v1(materials, request_ref, authorization_ref). This authorization allows a new scientific reservation and explicitly forbids changes to old/native files, charges or expiries.

4. Root, in its genuine marker-renewed environment, obtains the unchanged configured guard c.original_guard(). Inside guard.budget.v4.mutex(ROOT), call guard._state_locked(c.CORE, c.BASE, fresh=True), then retain view=state[2] and bindings=state[3]. Outside the lock call direct_scientific_consumers_v1(materials, refs, actual_guard_bindings=list(bindings.values())). refs has exactly caps, request, config, runtime, closure and admission_authorization. The actual returned full list must contain at most 64 entries.

   Build the original reserve request with key H041/ plus the fresh scientific job_id, output equal to the fresh absolute results path, auxiliary_scopes equal to the fresh packet/worker_aux and fresh TMP absolute paths, reserved_bytes=33554432 and the complete consumers list. Call guard.operation_draft_v1("reserve", request, expected_before=guard._pins(view), bindings=bindings). Root sets active=True and the same fresh expires_at_utc, saves it exclusively, then calls guard.apply_reserve_v1(actual_authority_ref, expected_source_sha256=c.CORE, expected_launcher_sha256=c.BASE). Do not clone or replace any guard function.

   Save the genuine reserve receipt. storage_from_actual_reserve_v1 reconstructs the standard storage record from that actual receipt, request, exact job identity/expiry, the original implementation/launcher/consumer_adapter refs and original prospective policy. Save storage, call finish_scientific_input_v1(materials, refs, storage_ref, actual_guard_bindings=list(bindings.values())), and save the returned input. If another admission advanced the prefix, leave the rejected/unadmitted metadata intact and build a fresh exclusive authority against actual current state. Never alter historical records.

5. Call native_reuse_proof_v1(actual_prior_controller_completion_ref), save its returned metadata, and authenticate it through the unchanged finite contract. c3_method_v1(actual_new_scientific_input_ref) gives the resumed method. native_method_unchanged_v1() gives the exact original native method.

   For each of slots C3_RESUME_TRAIN and NATIVE_MLM, save operational_request_v1(slot, method, actual_prior_controller_completion_ref, actual_native_reuse_ref=actual_reuse_ref_for_native_only). Obtain actual current guard state and call outer_reserve_request_v1(actual_request_ref, job_id=distinct_outer_name, output_directory=fresh_outer_results_path, actual_guard_bindings=list(actual_bindings.values())). Reserve its exact 4 MiB request through the same original operation_draft/_pins/apply_reserve sequence and save the actual receipt/storage. Use the original native absolute expiry for native outer authority and the fresh C3 scientific expiry for C3 outer authority.

   Save operational_envelope_v1(actual_request_ref, actual_operational_storage_ref, actual_guard_bindings=actual_current_bindings). Then save finite_job_map_v1(actual_C3_envelope_ref, actual_native_envelope_ref). No native scientific reserve operation occurs.

6. Save controller_plan_v1(actual_map_ref, actual_prior_controller_completion_ref, pool=fresh_safe_pool_name, controller_job_id=fresh_controller_id, expires_at_utc=explicit_pool_expiry, drain_expires_at_utc=explicit_drain_expiry, actual_guard_bindings=actual_current_bindings). Pool expiry must cover both actual scientific expiries. Drain must be at least 35 seconds later and strictly before the genuine marker renewal expires. The native scientific expiry is not extended.

   Obtain fresh actual guard state and use controller_reserve_request_v1(actual_plan_ref, output_directory=fresh_controller_results_path, actual_guard_bindings=actual_current_bindings). Reserve the exact returned 32 MiB/no-aux request with the original APIs. The controller storage expiry must cover the drain expiry. Save actual controller storage, then controller_capability_v1(actual_plan_ref, actual_controller_storage_ref, actual_guard_bindings=actual_current_bindings).

7. Only root may call the finite pool's original load_cap against that saved actual capability, or start the already reviewed bootstrap. No bootstrap invocation was performed here. The controller interpreter must start with empty CUDA_VISIBLE_DEVICES and the exact marker renewal certificate/source arguments. The canonical module is research.reviews.GPU0_declared_C3_resume_transport_unknown_source_20261016_v2.gpu0_declared_pool_v1. Its start command takes --execute --capability actual_path --sha256 actual_sha. Submit both actual declared logical job ids through the same reviewed finite CLI. Workers inherit the original GPU0 UUID lease and set AI Auto Research Pipeline Test before CUDA. The unchanged actual memory gate decides whether both fit concurrently. Obtain real logical waits, owned drain, controller terminal and original guard checks before reporting completion.

The future recipe is blocked until the genuine later transition/migration evidence exists. This is a deferred evidence dependency, not a reason to stop the present live jobs automatically.
