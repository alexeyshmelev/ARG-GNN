#!/usr/bin/env python3
"""Metadata-only ARGMix panel preparation and derived-count aggregation.

No simulation, Relate, model import, fit, truth read, admission or launch API.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PLAN = HERE / "published_panel_plan.v1.json"
SOURCES = HERE / "source_refs.v1.json"
COHORTS = {"Ana": 22, "CHG": 13, "EHG": 42, "WHG": 48,
           "Neolithic Farmer": 159, "Yamnaya": 13,
           "Post-Neolithic": 654, "Present Day": 660}
QUERY_COHORTS = ("Present Day", "Post-Neolithic", "Neolithic Farmer", "Yamnaya")
METHODS = ("AP", "ARGMix")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_metadata(value):
    path = Path(value)
    if not path.is_absolute():
        path = ROOT / path
    if path.is_symlink() or not path.is_file():
        raise ValueError("Metadata must be a regular, nonsymlink JSON file")
    path = path.resolve()
    if ROOT not in path.parents or path.suffix != ".json":
        raise ValueError("Only JSON metadata inside this repository is accepted")
    if path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError("Metadata exceeds the 8 MiB bound")
    return json.loads(path.read_text())


def emit(value):
    print(json.dumps(value, indent=2, sort_keys=True, allow_nan=False))


def digest_string(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def positive_int(value):
    return type(value) is int and value > 0


def check_plan():
    plan = load_metadata(PLAN)
    if plan["panel"]["diploids_by_cohort"] != COHORTS:
        raise ValueError("Published cohort counts changed")
    parents = plan["parents"]
    if Counter(p["split"] for p in parents) != {"train": 5, "val": 1, "iid": 3, "misspec": 5}:
        raise ValueError("Replicate split changed")
    if len({p["parent_id"] for p in parents}) != 14:
        raise ValueError("Parent IDs must be unique")
    if sum(p["planned_examples"] for p in parents) != 1400000:
        raise ValueError("Finite reconstruction budget changed")
    if any(p["planned_examples"] != 100000 for p in parents):
        raise ValueError("Prospective equal TRAIN allocation changed")
    seeds = [s for p in parents for s in p["new_seed_values"].values()]
    seeds += list(plan["new_fit_seeds"].values())
    if len(seeds) != len(set(seeds)) or any(not positive_int(s) for s in seeds):
        raise ValueError("Invalid/colliding prospective seeds")
    refs = load_metadata(SOURCES)
    checked = []
    for ref in refs["sources"]:
        path = ROOT / ref["path"]
        if not path.is_file() or path.is_symlink() or sha(path) != ref["sha256"]:
            raise ValueError("Pinned source changed: " + ref["path"])
        checked.append(ref["path"])
    return plan, checked


def inspect():
    plan, checked = check_plan()
    return {"schema": "argmix_published_panel_preflight_v1",
            "status": "blocked_on_scientific_inputs",
            "execution_authorized": False, "source_only": True,
            "source_files_verified": len(checked),
            "diploids": sum(COHORTS.values()), "haplotypes": 2 * sum(COHORTS.values()),
            "pure_founder_haplotypes": 250, "query_cohort_candidate_haplotypes": 2972,
            "possible_reference_pool_upper_bound_haplotypes": 594,
            "reference_pool_upper_bound_is_not_eligibility_rule": True,
            "parents": 14, "planned_examples": 1400000,
            "unresolved_inputs": plan["required_scientific_inputs"],
            "scientific_payloads_read": False, "simulation_fit_or_admission_performed": False}


def materialize_roster(value):
    """Validate supplied observed metadata, then expand diploids to two haps."""
    check_plan()
    data = load_metadata(value)
    if data.get("schema") != "argmix_published_diploid_roster_v1":
        raise ValueError("Wrong roster schema")
    if data.get("provenance_kind") not in ("recovered_paper_input", "declared_prospective_reconstruction"):
        raise ValueError("Declare recovered/prospective roster provenance")
    if not str(data.get("provenance_note") or "").strip():
        raise ValueError("Roster provenance note required")
    if not str(data.get("reference_query_policy") or "").strip():
        raise ValueError("Explicit reference/query/focal-exclusion policy required")
    rows = data.get("diploids", [])
    fields = {"sample_id", "cohort", "sampling_population", "age_generations",
              "is_iceman", "reference_eligible", "query_eligible"}
    if len(rows) != 1611 or Counter(r.get("cohort") for r in rows) != COHORTS:
        raise ValueError("Exact published diploid cohort counts required")
    names = []
    haps = []
    for i, row in enumerate(rows):
        if set(row) != fields:
            raise ValueError("Roster fields must be observed metadata only: " + str(sorted(fields)))
        for name in ("sample_id", "sampling_population"):
            if not isinstance(row[name], str) or not row[name].strip():
                raise ValueError("Missing ID/sampling population")
        names.append(row["sample_id"])
        age = row["age_generations"]
        if type(age) not in (int, float) or not math.isfinite(age) or age < 0:
            raise ValueError("Each individual requires an explicit nonnegative finite age")
        if row["cohort"] == "Present Day" and age != 0:
            raise ValueError("Present Day ages must be zero generations")
        if any(type(row[k]) is not bool for k in ("is_iceman", "reference_eligible", "query_eligible")):
            raise ValueError("Explicit Boolean eligibility/Iceman flags required")
        if row["query_eligible"] and row["cohort"] not in QUERY_COHORTS:
            raise ValueError("Only the four published accuracy cohorts are scored here")
        for hap in (0, 1):
            haps.append(dict(row, diploid_index=i, haplotype=hap, sample_index=2*i+hap))
    if len(set(names)) != 1611:
        raise ValueError("Diploid sample IDs must be unique")
    iceman = [r for r in rows if r["is_iceman"]]
    if len(iceman) != 1 or iceman[0]["cohort"] != "Neolithic Farmer":
        raise ValueError("Exactly one identified Iceman must be a Neolithic Farmer")
    return {"schema": "argmix_published_haplotype_roster_v1",
            "source_roster_sha256": sha(Path(value) if Path(value).is_absolute() else ROOT / value),
            "provenance_kind": data["provenance_kind"],
            "provenance_note": data["provenance_note"],
            "reference_query_policy": data["reference_query_policy"],
            "population_lifetimes_and_demographic_membership_verified": False,
            "simulation_or_inference_performed": False,
            "reference_haplotypes": sum(r["reference_eligible"] for r in haps),
            "query_haplotypes": sum(r["query_eligible"] for r in haps),
            "reference_query_overlap_haplotypes": sum(r["reference_eligible"] and r["query_eligible"] for r in haps),
            "rows": haps}


def aggregate(value):
    """Consume derived correct/total counts only; never read truth or predictions."""
    plan, _ = check_plan()
    receipt = load_metadata(value)
    if receipt.get("schema") != "argmix_published_example_counts_v1":
        raise ValueError("Wrong derived-count schema")
    if receipt.get("plan_sha256") != sha(PLAN):
        raise ValueError("Count receipt must bind the frozen plan")
    if not isinstance(receipt.get("condition_id"), str) or not receipt["condition_id"].strip():
        raise ValueError("Condition ID required")
    if not digest_string(receipt.get("scientific_protocol_sha256")):
        raise ValueError("Frozen scientific protocol SHA256 required")
    development = {p["parent_id"]: p["split"] for p in plan["parents"] if p["split"] in ("train", "val")}
    for method in METHODS:
        checkpoint = receipt.get("checkpoint_provenance", {}).get(method, {})
        if not digest_string(checkpoint.get("checkpoint_sha256")):
            raise ValueError("Actual checkpoint hash required: " + method)
        if checkpoint.get("development_parent_splits") != development:
            raise ValueError("Checkpoint must bind the five TRAIN and one VAL parents")
        if checkpoint.get("selection_rule") != "minimum_validation_loss":
            raise ValueError("Frozen best-VAL-loss selection required")
    expected_parents = {p["parent_id"]: p["split"] for p in plan["parents"] if p["split"] in ("iid", "misspec")}
    expected = {(p, method, cohort) for p in expected_parents for method in METHODS for cohort in QUERY_COHORTS}
    cells = {}
    for row in receipt.get("rows", []):
        key = (row.get("parent_id"), row.get("method"), row.get("cohort"))
        if key not in expected or key in cells:
            raise ValueError("Unexpected/duplicate replicate-method-cohort cell")
        correct, total = row.get("correct"), row.get("total")
        if type(correct) is not int or not positive_int(total) or not 0 <= correct <= total:
            raise ValueError("Require actual integer 0 <= correct <= total with total > 0")
        if not digest_string(row.get("support_sha256")):
            raise ValueError("Each cohort requires its frozen sampled-example support hash")
        cells[key] = row
    if set(cells) != expected:
        raise ValueError("Require all 64 cells: 8 independent tests x 2 methods x 4 cohorts")
    for parent in expected_parents:
        for method in METHODS:
            if sum(cells[parent, method, c]["total"] for c in QUERY_COHORTS) != 100000:
                raise ValueError("Each method must score exactly 100000 examples per test replicate")
        for cohort in QUERY_COHORTS:
            a, b = cells[parent, "AP", cohort], cells[parent, "ARGMix", cohort]
            if (a["total"], a["support_sha256"]) != (b["total"], b["support_sha256"]):
                raise ValueError("AP and ARGMix must use identical cohort example support")
    rows = []
    deltas = []
    for split in ("iid", "misspec"):
        parents = sorted(p for p, s in expected_parents.items() if s == split)
        for cohort in QUERY_COHORTS:
            values_by_method = {}
            for method in METHODS:
                values = [100.0 * cells[p, method, cohort]["correct"] / cells[p, method, cohort]["total"] for p in parents]
                values_by_method[method] = values
                rows.append({"split": split, "cohort": cohort, "method": method,
                             "n_independent_simulation_replicates": len(values),
                             "mean_accuracy_percent": statistics.mean(values),
                             "sample_sd_percentage_points": statistics.stdev(values),
                             "sd_ddof": 1, "replicate_accuracy_percent": values,
                             "parent_ids": parents})
            differences = [b-a for a, b in zip(values_by_method["AP"], values_by_method["ARGMix"])]
            deltas.append({"split": split, "cohort": cohort, "n": len(parents),
                           "mean_ARGMix_minus_AP_percentage_points": statistics.mean(differences),
                           "sample_sd_paired_delta_percentage_points": statistics.stdev(differences), "sd_ddof": 1})
    return {"schema": "argmix_prospective_example_accuracy_summary_v1",
            "condition_id": receipt["condition_id"], "plan_sha256": sha(PLAN),
            "scientific_protocol_sha256": receipt["scientific_protocol_sha256"],
            "input_count_receipt_sha256": sha(Path(value) if Path(value).is_absolute() else ROOT / value),
            "aggregation_unit": "independent_simulation_replicate",
            "metric": "equal_weight_sampled_example_hard_accuracy_within_cohort",
            "weighting": "arithmetic_mean_of_replicate_percentages",
            "reported_paper_pm_definition_recovered": False,
            "raw_support_or_truth_recomputed": False,
            "support_hashes_and_count_provenance_asserted_by_upstream_scorer": True,
            "optimizer_seed_variation_estimated": False, "rows": rows, "paired_deltas": deltas}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("inspect")
    sub.add_parser("preflight")
    roster = sub.add_parser("roster")
    roster.add_argument("--input", required=True)
    metrics = sub.add_parser("aggregate")
    metrics.add_argument("--input", required=True)
    args = parser.parse_args()
    try:
        if args.command in ("inspect", "preflight"):
            result = inspect()
        elif args.command == "roster":
            result = materialize_roster(args.input)
        else:
            result = aggregate(args.input)
        emit(result)
        return 2 if args.command == "preflight" else 0
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as error:
        emit({"status": "rejected", "error": str(error), "simulation_fit_or_admission_performed": False})
        return 2


if __name__ == "__main__":
    sys.exit(main())
