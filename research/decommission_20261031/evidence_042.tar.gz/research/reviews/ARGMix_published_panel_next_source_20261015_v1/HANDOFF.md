# ARGMix published-panel reconstruction source packet

Prepared 2026-10-15. Source only. Root owns registration, resource admission, scientific execution, integration and Git.

This packet makes the known panel counts, finite replicate/example budget, new seed registry, observed-roster expansion and replicate metric aggregation executable. **It does not provide a scientifically complete simulation/fit launcher.** No existing inspected producer accepts this panel and published architecture unchanged. Preflight deliberately exits 2 until a separately reviewed successor resolves the scientific inputs.

## Files and immediate commands

Run from /workspace-SR003.nfs2/ARG-GNN:

```sh
.runtime/env/bin/python -B research/reviews/ARGMix_published_panel_next_source_20261015_v1/published_panel_source_v1.py inspect
.runtime/env/bin/python -B research/reviews/ARGMix_published_panel_next_source_20261015_v1/published_panel_source_v1.py preflight
```

The first prints verified source hashes, panel arithmetic and unresolved inputs with exit 0. The second prints the same blocked state with exit 2. Neither admits or launches anything. The script imports only the Python standard library and works without PYTHONPATH.

- published_panel_plan.v1.json: exact published counts/known settings, 14 named independent parents, 1,400,000 planned examples, 77 **new** deterministic seeds, exact unknowns and execution order.
- source_refs.v1.json: hashes of 13 inspected source/evidence files, including both author commits.
- roster.template.v1.json: intentionally incomplete observed-metadata input. No ages or individual IDs have been invented.
- counts.template.v1.json: all 64 future test replicate/method/cohort cells. Counts/support/checkpoint/protocol fields are deliberately null.
- published_panel_source_v1.py: source preflight, supplied-roster validator/expander and future derived-count aggregator.
- validation_receipt.v1.json: actual source-only checks.
- source_handoff.v1.json: hashes and ownership boundary.

The public current ARGMix commit is c2481248eb0de5fda659d68f59c51e0e27becd20. The existing AP source commit is 77db3cfae100641c35218b87e1451e14f3074666. No paper-era April code archive was recovered; available public history begins in August. The prior audit and extracted paper evidence are reused, not fetched again.

## Exact count panel and finite plan

| Published cohort | Diploids | Haplotypes |
|---|---:|---:|
| Ana | 22 | 44 |
| CHG | 13 | 26 |
| EHG | 42 | 84 |
| WHG | 48 | 96 |
| Neolithic Farmer, including the Iceman | 159 | 318 |
| Yamnaya | 13 | 26 |
| Post-Neolithic | 654 | 1,308 |
| Present Day | 660 | 1,320 |
| Total | 1,611 | 3,222 |
| BAA | 0 | 0 |

The four pure founder groups total 250 haplotypes. The four accuracy cohorts contain 2,972 candidate query haplotypes. Including all NF/Yamnaya with the founders gives a **594-haplotype upper bound**, not a recovered reference eligibility rule. Query/reference eligibility are independent Boolean fields in the supplied roster, allowing the published mixed groups' dual role. Focal exclusion still requires an explicit policy.

| Split | Replicates | Published examples | Packet allocation |
|---|---:|---:|---|
| TRAIN | 5 | 500,000 total | 100,000 each, newly chosen |
| VAL | 1 | 100,000 | 100,000 |
| IID | 3 | 100,000 each | 100,000 each |
| Misspecified | 5 | 100,000 each | 100,000 each |

The 100,000 allocation to each TRAIN parent is a transparent new reconstruction choice. The paper specifies only the aggregate 500,000. All 77 seeds in the packet are newly chosen, not paper seeds. No seed has been executed. A source SHA256 domain creates 75 parent-purpose seeds plus one AP and one ARGMix fit seed, with collision checks.

The literal TRAIN and VAL skip phrases are retained. Their stride/origin semantics and the IID skip rule are unresolved rather than silently converted to an executable sampler. Misspecified data explicitly have no skipped trees. No class/cohort quotas, shortfall replacement, target coordinate or ancestry-node selection rule is guessed.

## Concrete reusable pieces and required producer changes

| Existing source and function | Reuse decision for 3,222 haplotypes |
|---|---|
| scripts/infer_biological_paths_relate_v1.py:118 filter_vcf | Function is count-generic and uses supplied observed sample names/coordinates. Reuse only if its phased, biallelic, segregating nucleotide/MAC1 policy is explicitly adopted; that filter is not recovered as a paper setting. |
| Same file:165 canonical_sample_text | Count-generic ordered converter ID normalization; reusable after the actual Relate converter/sample order is frozen. |
| Same file:246 inferred_sample_mapping and :262 write_inferred_roster | Count-generic actual NODE_IS_SAMPLE/age/order join. Preserve this mapping primitive; do not assume inferred node IDs 0..3221. |
| Same file:178 prepare_inputs | Cannot reuse unchanged: line 186 writes a fixed uniform 2 Mb map. Supply the recovered empirical chr22 map and its coordinate transform, retaining observed-only inputs and sample identity checks. |
| Same file:61 validate_sample_assets, :200 verify_native_haps, :279 clean_converted_tree | Cannot reuse unchanged: 280-haplotype, 2 Mb and fixed 100 bp grid assumptions appear in validation, mapping bounds and receipts. Extract only the generic join/metadata removal logic, parameterizing the frozen physical interval and real sample count. |
| src/arggnn/prepare_ancestralpaths_full_panel_discovery_v1.py:62 roster, :323 generate_parent, :420 observed_assets, :534 infer_parent | Cannot point this CLI at new counts: it enforces 952/686/266, 476 diploids, original age rows and a uniform 2 Mb map. A new producer must consume the explicit roster, map, simulation/error and Relate recipes. Preserve old producers unchanged. |
| src/arggnn/biological_paths_simulation.py:173 build_demography | Exact original AP demographic graph is available as a source starting point. It includes a BAA branch and census event. The paper's exclusion change was not recovered. Keeping the graph but taking zero BAA samples is a new disclosed condition unless authors confirm it. |
| src/arggnn/expanded_native_argmix_v1.py:422 _reference_metadata | Hardcodes 952/266/686 slots and pure founders only; cannot supply the published NF/Yamnaya informative-reference design. |
| Current ARGMix config_loader.py:38/:404 and tree_sampler.py:150 | Explicitly reject ancestor nodes. A config with num_refs=25 and num_ancs=3 will fail. This is not a viable paper-era launcher. |
| Current ARGMix final_test_metrics.py:565 | Scores inferred intervals at SNP truth positions, including dose r-squared and jackknife metrics. Reuse only for a separately labeled SNP-based endpoint; it is not a recovered implementation of the paper's 100,000 sampled-example metric. |

The minimal next scientific producer must therefore accept an explicit diploid roster, no-BAA demographic decision, empirical chr22 map/interval, mutation/error observation recipe, Relate options, realized perturbations and frozen shared sampled-example manifests. It should retain the generic observed-only filtering/converter identity primitives above, then call a recovered paper-era model/AP implementation or a separately labeled adapted implementation. Merely modifying old count assertions would leave the map, roles, target and architecture wrong.

The current author template's 15-reference/no-ancestor transformer+GRU condition, its optimizer/loss/defaults and our H038 common-C4 protocol remain separate conditions. None supplies missing paper-era settings. The current relative-key implementation in tmrca_attn.py:111 uses the query-row key before distance gather, while paper Eq. 3 shows the other endpoint's key. Architectural equivalence remains unresolved.

## Supplied-roster materialization

After an actual roster or an explicitly declared prospective roster is obtained, populate roster.template.v1.json in a **new** input file. Each of the 1,611 rows must contain exactly:

```json
{
  "sample_id": "actual individual ID",
  "cohort": "one of the eight exact published cohort names",
  "sampling_population": "population from the separately frozen demography",
  "age_generations": 123,
  "is_iceman": false,
  "reference_eligible": true,
  "query_eligible": false
}
```

This single row demonstrates schema only, not an identified person, date or chosen reference. The complete file also requires schema=argmix_published_diploid_roster_v1, provenance_kind (recovered_paper_input or declared_prospective_reconstruction), provenance_note and an explicit reference_query_policy covering focal/diploid exclusion.

```sh
.runtime/env/bin/python -B research/reviews/ARGMix_published_panel_next_source_20261015_v1/published_panel_source_v1.py roster --input PATH_TO_COMPLETE_ROSTER_JSON
```

The command emits 3,222 metadata rows to stdout. It checks counts, unique IDs, finite ages, present-day age zero, a single identified NF Iceman, explicit eligibility flags and absence of extra truth fields. It reports reference/query overlap. It does not validate population lifetimes or establish that claimed paper provenance is correct. No simulation is performed and no file is written by the script.

Do not cycle, quantile-resample or relabel the existing 476-person age input into this panel. Its counts differ, and Bronze_Age is not established as the published Post-Neolithic cohort.

## IID/misspecification metric contract

Freeze the same 100,000 sampled-example IDs and target labels per test replicate for AP and ARGMix before extracting their method-specific features. Cohorts partition these examples; each method must score exactly 100,000 across the four cohorts. No omitted/extra cells, empty cohorts or unmatched supports are accepted.

An upstream reviewed scorer must compute integer correct/total counts from the agreed hard target/prediction ontology and attach the same canonical example-support hash to both methods' cohort cell. The support manifest must cover the parent, focal haplotype, sampled inferred-tree/target coordinate and target definition. Counts and hashes in this packet are placeholders, not measured results. This aggregator cannot verify upstream scoring or support contents without reading them, and it explicitly reports that limit.

Populate a new copy of counts.template.v1.json using actual outputs, with the frozen plan/protocol SHA256, condition ID and actual checkpoint SHA256 for each method. Both checkpoints must name exactly the five TRAIN and one VAL parents and minimum_validation_loss selection.

```sh
.runtime/env/bin/python -B research/reviews/ARGMix_published_panel_next_source_20261015_v1/published_panel_source_v1.py aggregate --input PATH_TO_ACTUAL_COUNT_RECEIPT_JSON
```

For each cohort and method, the output is the arithmetic mean of per-replicate hard accuracy percentages and **sample SD, ddof=1, in percentage points**, across n=3 IID or n=5 misspecified independent simulations. The script also reports paired ARGMix-minus-AP mean differences and sample SD across the same replicates. It never pools all replicates into one accuracy, estimates optimizer-seed SD or treats a single fit as repeated training.

This is an explicit prospective statistic. The meaning of the paper's reported plus/minus, original denominator and original per-replicate values remains unrecovered. Do not rename SNP-weighted or physical-bp-weighted scores as these sampled-example values. The paper's Table 1/2 numbers remain in the pinned published_table_values.json as published reference values only.

## Exact remaining scientific inputs

1. Individual IDs, dates, Iceman identity/date and precise cohort definitions.
2. Reference eligibility, query sampling and focal/diploid exclusion, especially NF/Yamnaya dual roles.
3. Paper modification of the AP demographic graph when excluding BAA.
4. Empirical chromosome 22 map/build/version, interval/length and coordinate transform.
5. Mutation model and genotype-error implementation at rate 0.001 in every cohort.
6. Relate version/options, size iterations/final reestimation and original seeds.
7. Five realized OOD demographic parameter sets or exact draw distributions, sign probabilities, dependencies, rounding and chronology rules. Known ranges alone do not identify those draws: size +/-1–50%, admixture older 1–25%, divergence +/-1–25%.
8. Exact sampled-tree target/label rule, stride semantics/origin, IID spacing, reference ties, ancestor-node choices, quotas and shortfall handling.
9. Paper-era 25-reference/3-ancestor ARGMix, PyTorch AP, label ontology and Eq. 3 direction.
10. Optimizer/loss/model hyperparameters/epochs and original generation/sampler/fit seeds.
11. Table plus/minus definition, ddof/unit/denominator and original products.

An approximate reconstruction can proceed only after these are recovered or concrete prospective choices are separately frozen and disclosed. Exact numerical Table 1/2 reproduction additionally requires the original data/seed/config/checkpoint lineage. The packet does not claim either is ready.

## Validation and boundary

Actual checks: Python AST/compile, JSON/arithmetic/77-seed uniqueness, 13 pinned source hashes, direct inspect exit 0 and preflight exit 2 with PYTHONPATH removed, and rejection of both incomplete templates. No real or synthetic campaign was scored.

Only this assigned folder was written. No simulation, fit, data generation, scientific payload/truth read, GPU use, admission/accounting mutation or Git action occurred.
