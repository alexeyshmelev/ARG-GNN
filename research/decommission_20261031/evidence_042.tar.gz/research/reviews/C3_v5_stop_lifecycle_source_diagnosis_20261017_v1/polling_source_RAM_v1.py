"""Source-equivalent inventory query counting and lifecycle RAM examples only."""
from pathlib import Path
from types import SimpleNamespace
import ast,collections,copy,csv,errno,hashlib,json
R=Path('/workspace-SR003.nfs2/ARG-GNN');O=R/'research/reviews/C3_v5_stop_lifecycle_source_diagnosis_20261017_v1'
POOL='src/arggnn/gpu_pool_v1.py';EX='research/reviews/C3_remaining_cells_GPU0_source_20261017_v5/execution_v1.py';OW='research/reviews/American_C3_native_MLM_amendment_v12/owned_lifecycle_v2.py'
def ref(name):return dict(path=name,sha256=hashlib.sha256((R/name).read_bytes()).hexdigest())
def require(ok,label):
 if not ok:raise ValueError(label)
def get(t,name):return next(n for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name==name)
def extract(t,names,env):
 for name in names:exec(compile(ast.Module(body=[copy.deepcopy(get(t,name))],type_ignores=[]),'<polling_RAM_'+name+'>','exec'),env)
queries=[];gpu_uuid='GPU-ff06ca1f-403a-f2d0-b584-71e177452667'
def fake_run(command,**kwargs):
 queries.append(dict(command=command,kwargs=kwargs))
 return SimpleNamespace(stdout='0, '+gpu_uuid+', 0, 81920, 0\n'if command[1].startswith('--query-gpu=')else '')
env=dict(csv=csv,subprocess=SimpleNamespace(run=fake_run),canonical_gpu_uuid=lambda u:u)
extract(ast.parse((R/POOL).read_text()),['real_inventory'],env)
inventory=env['real_inventory']()
require(len(queries)==2 and all(q['command'][0]=='nvidia-smi'and q['kwargs']==dict(check=True,capture_output=True,text=True,timeout=15,shell=False)for q in queries),'Exact original query pair and launch predicates')
# A valid helper life cycle is sufficient to show that source alone does not force a negative group.
backend_env=dict(os=SimpleNamespace(getpid=lambda:1),_stat=lambda pid:None,_children=lambda pid:[])
extract(ast.parse((R/OW).read_text()),['_same','OwnedTree'],backend_env)
backend=SimpleNamespace(OwnedTree=backend_env['OwnedTree'],_same=backend_env['_same'])
rows={100:dict(pid=100,start=10,group=100,session=100,ppid=1,state='S')}
def read_stat(pid):return copy.deepcopy(rows.get(pid))
def children(pid):return sorted(p for p,r in rows.items()if r['ppid']==pid)
probes=[]
def absent_group(group,signum):
 probes.append(dict(group=group,signum=signum));require(group>0,'No synthetic sentinel here');raise ProcessLookupError(errno.ESRCH,'No such process')
limits=dict(pending=1024,discoveries=2**28,groups=65536,adopted_waits=2**28,history_rows=16)
env=dict(json=json,collections=collections,hashlib=hashlib,OWNED_LIMITS_V8=limits,os=SimpleNamespace(killpg=absent_group),time=SimpleNamespace(monotonic=lambda:0.0))
extract(ast.parse((R/EX).read_text()),['_HistoryV8','_PendingV8','OwnedLifecycleV8','observe_groups_v8'],env)
tree=env['OwnedLifecycleV8'](backend,100,owner=1,read_stat=read_stat,read_children=children)
rows[101]=dict(pid=101,start=11,group=100,session=100,ppid=100,state='S');tree.refresh()
require(len(tree.known)==2 and tree.complete,'Exact helper ancestry discovered')
del rows[101];tree.refresh();del rows[100];tree.refresh()
result=env['observe_groups_v8'](tree,1.0)
require(tree.complete and not tree.known and tree.discovered.total==tree.retired.total==2 and result['all_owned_groups_observed_absent']is True,'Positive known helper sequence drains without sentinel')
value=dict(schema='C3_v5_capacity_query_and_lifecycle_independent_RAM_source_check_v1',status='SOURCE_QUERY_CHAIN_CONFIRMED',
 exact_inventory_calls=queries,synthetic_inventory=inventory,positive_group_helper_sequence=dict(discovered=tree.discovered.total,retired=tree.retired.total,complete=tree.complete,groups=sorted(tree.groups),observations=result),
 source_refs=[ref(n)for n in [POOL,EX,OW]],
 limits='All rows, inventory and query execution are fake RAM APIs. This does not attribute historical4582identities, observe an actual kernel sentinel race or qualify a proposed proxy/NVML repair.',
 actual_subprocesses_process_state_guard_resource_or_GPU_calls=0,scientific_arrays_truth_checkpoint_reads=0,Git_actions=0)
with (O/'polling_source_RAM.result.v1.json').open('x')as f:f.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status=value['status'],result_ref=ref(str((O/'polling_source_RAM.result.v1.json').relative_to(R))))))
