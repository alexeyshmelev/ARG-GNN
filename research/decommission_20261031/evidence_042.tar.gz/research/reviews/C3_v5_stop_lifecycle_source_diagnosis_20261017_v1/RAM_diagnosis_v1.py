"""Exact pinned source AST diagnosis; all process/filesystem actions are fake RAM APIs."""
from pathlib import Path
from types import SimpleNamespace
import ast,collections,copy,errno,hashlib,json
R=Path('/workspace-SR003.nfs2/ARG-GNN');O=R/'research/reviews/C3_v5_stop_lifecycle_source_diagnosis_20261017_v1'
EXEC='research/reviews/C3_remaining_cells_GPU0_source_20261017_v5/execution_v1.py'
CONTRACT='research/reviews/C3_remaining_cells_GPU0_source_20261017_v5/contract_v1.py'
OWNED='research/reviews/American_C3_native_MLM_amendment_v12/owned_lifecycle_v2.py'
CASE='research/reviews/research_execution_ROOT_20261017_v33/C3_v5_actual_outer1_stop_consumed.root_v1.json'
checks=[]
def require(ok,label):
 if not ok:raise ValueError(label)
def check(ok,label):require(ok,label);checks.append(label)
def ref(name):
 p=R/name;return dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def get(t,name):return next(n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name==name)
def extract(t,names,env):
 for name in names:exec(compile(ast.Module(body=[copy.deepcopy(get(t,name))],type_ignores=[]),'<exact_RAM_'+name+'>','exec'),env)
exec_tree=ast.parse((R/EXEC).read_text());contract_tree=ast.parse((R/CONTRACT).read_text());owned_tree=ast.parse((R/OWNED).read_text())
limits=dict(pending=1024,discoveries=2**28,groups=65536,adopted_waits=2**28,history_rows=16)
# The original backend parser has no normalization; a purely synthetic /proc row is parsed.
class FakeStatPath:
 def __init__(self,name):self.name=name
 def read_text(self):
  fields=['X','1','-1','100']+['0']*15+['999']
  return '100 (RAM synthetic task) '+' '.join(fields)
parser_env=dict(Path=FakeStatPath)
extract(owned_tree,['_stat','_same'],parser_env)
parsed=parser_env['_stat'](100)
check(parsed==dict(pid=100,state='X',ppid=1,group=-1,session=100,start=999),'Exact backend parser accepts negative raw pgrp')
original=dict(pid=100,state='S',ppid=1,group=100,session=100,start=999)
check(parser_env['_same'](parsed,original),'Exact identity equality ignores state/group but matches PID/start')
# Fake backend is the exact original OwnedTree with injected readers; no real /proc call occurs.
current=[copy.deepcopy(original)]
backend_env=dict(os=SimpleNamespace(getpid=lambda:1),_stat=lambda pid:copy.deepcopy(current[0]),_children=lambda pid:[],_same=parser_env['_same'])
extract(owned_tree,['OwnedTree'],backend_env)
backend=SimpleNamespace(OwnedTree=backend_env['OwnedTree'],_same=parser_env['_same'])
probes=[]
def fake_killpg(group,signum):
 probes.append(dict(group=group,signum=signum))
 if group<=0:raise OSError(errno.EINVAL,'Invalid argument')
 raise ProcessLookupError(errno.ESRCH,'No such process')
env=dict(json=json,hashlib=hashlib,collections=collections,OWNED_LIMITS_V8=limits,
 os=SimpleNamespace(killpg=fake_killpg),time=SimpleNamespace(monotonic=lambda:0.0))
extract(exec_tree,['_HistoryV8','_PendingV8','OwnedLifecycleV8','observe_groups_v8'],env)
life=env['OwnedLifecycleV8'](backend,100,owner=1,read_stat=lambda pid:copy.deepcopy(current[0]),read_children=lambda pid:[])
check(life.groups=={100},'Original initial positive leader group retained')
current[0]=copy.deepcopy(parsed)
life.read_stat_v9(100)
check(life.groups=={-1,100}and life.complete is True,'Exact later read admits negative group without incomplete latch')
group_result=env['observe_groups_v8'](life,1.0)
check(probes==[dict(group=-1,signum=0),dict(group=100,signum=0)],'Exact observer calls nonpositive group before known positive group')
check(group_result['all_owned_groups_observed_absent']is False and group_result['expected_group_count']==2 and group_result['observed_group_count']==2 and group_result['absent_group_count']==1 and len(group_result['errors'])==1,'EINVAL forces false all-groups drain even positive group ESRCH')
# Independently show the pending-map ingress also admits a newly authenticated raw sentinel row.
new=dict(pid=101,start=1000,group=-1,state='X',ppid=100,session=100)
life.known[101]=new
check(life.known[101]['group']==-1 and -1 in life.groups,'Exact pending identity insertion also admits raw negative group')
# Exact packet budget and caller writer see a synthetic flat directory then the expected AUX child.
class Node:
 def __init__(self,name,kind='file',size=100):self.name=name;self.kind=kind;self.size=size
 @property
 def suffix(self):return Path(self.name).suffix
 def is_file(self):return self.kind=='file'
 def is_symlink(self):return self.kind=='symlink'
 def lstat(self):return SimpleNamespace(st_nlink=1)
 def stat(self):return SimpleNamespace(st_size=self.size)
class Directory:
 def __init__(self,nodes):self.nodes=nodes
 def exists(self):return True
 def iterdir(self):return iter(self.nodes)
 def __truediv__(self,name):return Node(name)
files=[Node(name)for name in ['config.json','reserve_authority.json','reserve_receipt.json','storage.json','input.json','admitted.json','caller_invocation.v5.json']]
directory=Directory(files)
open_calls=[]
def forbidden_open(*args,**kw):open_calls.append(args);raise AssertionError('Real/open backend must be unreachable')
budget_env=dict(require=require,ROOT_RECORD_CAP=454656,json=json,
 local=lambda p:SimpleNamespace(parent=directory),os=SimpleNamespace(open=forbidden_open),stat=SimpleNamespace())
extract(contract_tree,['record_budget_v1'],budget_env)
extract(exec_tree,['_put_supervisor_record_v5'],budget_env)
budget_env['record_budget_v1'](directory,1000)
check(True,'Exact flat preparation packet fits before AUX exists')
directory.nodes=files+[Node('worker_aux','directory')]
errors=[]
for name in ['caller_actual_supervisor_wait.v5.json','caller_supervisor_failure.v5.json']:
 try:budget_env['_put_supervisor_record_v5'](dict(worker_auxiliary_scope='RAM/packet/worker_aux'),name,dict(actual_Python_supervisor_wait=True,actual_Python_supervisor_returncode=1))
 except ValueError as error:errors.append(dict(filename=name,exception_type='ValueError',message=str(error)))
 else:raise AssertionError('Unexpected success with original AUX-containing packet')
check(all(e['message']=='Own bounded flat ROOT metadata only'for e in errors)and len(errors)==2,'Actual terminal writer and catch-path failure writer hit identical AUX-directory predicate')
check(open_calls==[],'Both exact terminal writes reject before any descriptor/open operation')
# Preserve the old ROOT cap rather than proposing a blanket directory or quota exemption.
directory.nodes=files
try:budget_env['record_budget_v1'](directory,454656)
except ValueError as e:cap_error=str(e)
else:raise AssertionError('Original cap bypassed')
check(cap_error=='Combined ROOT records plus65536event+4096node within524288 allowance','Original ROOT metadata cap remains a distinct failstop')
result=dict(schema='C3_v5_stop_lifecycle_independent_source_RAM_diagnosis_v1',status='SOURCE_CAUSES_CONFIRMED',checks=checks,positive=len(checks),
 source_refs=[ref(n)for n in [EXEC,CONTRACT,OWNED]],genuine_stop_case_ref=ref(CASE),
 negative_group=dict(raw_parser_result=parsed,synthetic_state_not_observed_historical_state=True,exact_original_read_path_group_set=sorted(life.groups),RAM_group_probes=probes,original_observer_result=group_result),
 packet_budget=dict(flat_preparation_passes=True,expected_AUX_directory_causes_errors=errors,actual_open_calls=0,original_ROOT_cap_bytes=454656,original_ROOT_total_allowance_bytes=524288,original_JSON_cap_bytes=65536,original_whole_output_AUX_cap_bytes=32*2**20),
 limitations=['No raw historical /proc row or exact kernel timing is available. Synthetic state X only demonstrates source ingress and is not evidence of the actual invalid row state.','No proposed repaired implementation is tested or approved by this diagnosis.','Genuine original drainFALSE and actual outer1/directworker-15/OSwait15 remain immutable. Positive targeted absence in the ROOT case does not establish full historical drain.'],
 operation_counts=dict(actual_process_state_guard_mutex_resource_probes=0,operational_imports=0,actual_arrays_truth_checkpoint_reads=0,GPU_operations=0,Git_actions=0,storage_accounting_operations=0,signals=0,live_source_edits=0))
with (O/'RAM_diagnosis.result.v1.json').open('x')as f:f.write(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status=result['status'],positive=len(checks),result_ref=ref(str((O/'RAM_diagnosis.result.v1.json').relative_to(R))))))
