# Unfinished sensitivity draft

Root redirected the primary comparator to untouched modern author build_training/train, implemented in ../ARGMix_prospective1611_primary_native_source_20261016_v1.

These three source files are an unfinished optional full-observed-context/common-target sensitivity design. No Python adapter or executable handoff exists here. They have not been compiled, imported, qualified, admitted or run. They must not be used or described as the primary ARGMix comparator. The original pinned author source and old sealed shared-row adapter are unchanged.
