# FLARE VAL000 native, seal and original scoring handoff

Native inference is source/metadata ready through the existing unchanged memo2 driver. Root may admit when the prospective980 ledger has headroom, then seal after genuine native/stage completion. Neither stage needs GNN completion or private truth. This packet is preparation, not an admission or truth-access authority.

Actual completed conversion: data/FLARE_val000_convert_memo2_980_root_v2/completed.json, SHA256 98ad24ffd27cff11fd4c130504ec7a91e93b938acffcee2f690a64d6f273cc32. Root reports genuine session20304 terminal0. SHA-bound minimal direct wait0 and outer wait0/no-error/group-ESRCH agree. All228477 supported sites,27558 expected native markers,600 reference/1000 query haplotypes and the original10000 common focals are retained. Query truth remains unopened.

## Exact native commands

Run on anogena in /workspace-SR003.nfs2/ARG-GNN. Root sets FLARE_EXPIRY_UTC to the actual absolute expiry. Use the shared admission lock only for admission, then launch outside it. Existing source/runtime/binding/capacity checks remain decisive. Native reservation is9000000000bytes.

~~~bash
set -euo pipefail
cd /workspace-SR003.nfs2/ARG-GNN
source scripts/project_env.sh
test -n "$FLARE_EXPIRY_UTC"
flock -x research/reviews/American_C3_short_train2mb_wave_source_v1/scheduler/admission.lock \
  env CUDA_VISIBLE_DEVICES='' "$ARGGNN_PYTHON" -B -m research.reviews.FLARE_consumer_memo2_root_source_20261015_v1.root_stage_980_driver \
  --admit --stage native \
  --target research/reviews/FLARE_VAL000_bridge_source_20261015_v1/bound_target_v1/target.json \
  --expected-target-sha256 463015a861151c77573ca7004001f6abc38c9bb8f273ff520517ab09fa1f3b74 \
  --conversion data/FLARE_val000_convert_memo2_980_root_v2/completed.json \
  --expected-conversion-sha256 98ad24ffd27cff11fd4c130504ec7a91e93b938acffcee2f690a64d6f273cc32 \
  --packet research/reviews/FLARE_val000_native_memo2_980_root_v1 \
  --output data/FLARE_val000_native_memo2_980_root_v1 \
  --job-id FLARE/VAL000-native-memo2-980-root-v1 \
  --expires-at-utc "$FLARE_EXPIRY_UTC"
~~~

After actual admitted_native_not_launched, set NATIVE_ADMISSION_SHA256 from its returned admission_ref.sha256. Do not launch a failed/partial admission.

~~~bash
test -n "$NATIVE_ADMISSION_SHA256"
env CUDA_VISIBLE_DEVICES='' "$ARGGNN_PYTHON" -B -m research.reviews.FLARE_consumer_memo2_root_source_20261015_v1.root_stage_980_driver \
  --launch \
  --admission research/reviews/FLARE_val000_native_memo2_980_root_v1/admission.json \
  --expected-admission-sha256 "$NATIVE_ADMISSION_SHA256"
~~~

Driver SHA256 is d2243197b92a6ca602409e148c6aebaf2547826a5834a8fca866c6f31b437928 and context SHA256 is a743425e5b290eec0bd53425f655ebc8f0c6180bd540376fcef830ce20c58418. All proposed native/seal packet/output scopes were absent at inspection. If one has since appeared, choose a fresh matching suffix for packet/output/job before admission; preserve target/conversion refs.

The driver reuses the actual successful installed-JDK source build and its provenance. No rebuild/direct Java bypass is needed. Preserve source ec0ad295aeebfacf10d8cbfb6486ab78981de1b1, version flare version0.6.0 [04ad73fd0 31-Oct-2025], heap16GiB,4threads,14400-second native/outer deadlines,24GiB aggregate RSS polling soft bound,1GiB JVM TMP and original placement/home/tmp flags. Author options stay:

~~~text
probs=true em=true update-p=false array=false min-maf=0.005 min-mac=50
gen=10 panel-probs=false nthreads=4 seed=-99999
~~~

Actual-site native VCF bound is7447753437bytes. Original formula including1GiB TMP is8573924061bytes plus524288auxiliary, below9GB. No filtering/compression saving is assumed. Retain all original .anc.vcf.gz, .model, .global.anc.gz and .log products unchanged.

## Exact seal commands

First consume genuine native-launch terminal0 and verify native native_actual_wait.json and stage worker_aux/actual_wait_minimal.json plus worker_aux/outer_wait.json: native/worker direct wait0, no operational errors, owned-group ESRCH and actual completion. Set NATIVE_COMPLETION_SHA256 from the actual completion ref. The driver checks actual native completion/inner wait/drain; root also checks the stage outer wait. Seal reservation is32000000bytes.

~~~bash
test -n "$NATIVE_COMPLETION_SHA256"
test -n "$FLARE_EXPIRY_UTC"
flock -x research/reviews/American_C3_short_train2mb_wave_source_v1/scheduler/admission.lock \
  env CUDA_VISIBLE_DEVICES='' "$ARGGNN_PYTHON" -B -m research.reviews.FLARE_consumer_memo2_root_source_20261015_v1.root_stage_980_driver \
  --admit --stage seal \
  --target research/reviews/FLARE_VAL000_bridge_source_20261015_v1/bound_target_v1/target.json \
  --expected-target-sha256 463015a861151c77573ca7004001f6abc38c9bb8f273ff520517ab09fa1f3b74 \
  --native-run data/FLARE_val000_native_memo2_980_root_v1/completed.json \
  --expected-native-run-sha256 "$NATIVE_COMPLETION_SHA256" \
  --packet research/reviews/FLARE_val000_seal_memo2_980_root_v1 \
  --output data/FLARE_val000_seal_memo2_980_root_v1 \
  --job-id FLARE/VAL000-seal-memo2-980-root-v1 \
  --expires-at-utc "$FLARE_EXPIRY_UTC"
~~~

Set SEAL_ADMISSION_SHA256 from the actual returned admission ref, then launch outside the lock:

~~~bash
test -n "$SEAL_ADMISSION_SHA256"
env CUDA_VISIBLE_DEVICES='' "$ARGGNN_PYTHON" -B -m research.reviews.FLARE_consumer_memo2_root_source_20261015_v1.root_stage_980_driver \
  --launch \
  --admission research/reviews/FLARE_val000_seal_memo2_980_root_v1/admission.json \
  --expected-admission-sha256 "$SEAL_ADMISSION_SHA256"
~~~

Sealing preserves all10000 exact common focals, nearest-retained-marker projection with midpoint ties right and edge extension, native AN1/AN2 calls as one-hot call transport, and untouched raw rounded ANP decimal/numeric sidecars. No rounded-posterior normalization/argmax substitution is introduced. Optional derived tract TSV stays disabled. Formula is21897216bytes plus524288auxiliary. No query truth is opened.

## Existing conversion-close helper locator

Existing generic API suffices: research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py, SHA256 fc71030865e0a3d5da31120d4daa2caa0b2d39ec7dd212b8c46c476b5a866d56, apply_close_completed_v1 at lines371–389. No new close helper is needed.

Prior pattern/adapter: research/reviews/VAL_FLARE_completed_close_source_20261015_v1/close_completed_v1.py, SHA256 fff7bbc9e5152573be83ccc50481bf86b40a888dc770068af81f43a64d7d82fa, FLARE branch89–108, execute111–159. Its --scope FLARE_convert is statically TRAIN000, so that old CLI is not a VAL000 command. The native-close wrapper is TRAIN000-specific too.

conversion_close_evidence.v1.json has actual VAL000 admission/storage/launch/direct-wait/outer-wait/completion refs, exact reservation digest and inactive request fields. Original supervisor2992440, worker2992771/start475912759 and group2992771 are recorded. Root must preserve files, cooperatively revoke exact-scope old write/resume/retry capabilities, obtain fresh PID/group ESRCH, fill the genuine observation_ref, then construct/activate the existing operation_draft_v1("close_completed",...) against the actual fresh ledger prefix. Apply under the existing admission lock with current policy/repair bindings. Do not fabricate absence/proof/authority hashes or reuse an old prefix.

~~~python
receipt = guard.apply_close_completed_v1(
    actual_root_close_authority_ref,
    expected_source_sha256="483d78bf2ef3c917d65ecf1dde5a7809bfadc21194c9f9a90394ce5c532fdd5e",
    expected_launcher_sha256="a8049bc103afb1cbbbce6f8fc3707a21de9613b23034599641b688994fc5caa3",
)
~~~

Close preserves read-only predecessor reuse/all retained files. Future old-v3 mutations remain revoked. This handoff performs no guard configuration, state query, scope measurement, PID probe or accounting action.

## Scorer capability and currently authorized truth barrier

The original FLARE scorer is per-parent. american_c3_flare_evaluate_v1.py:226–243 authenticates the actual seal/completion/prediction/focals then delegates unchanged to american_c3_evaluate_v1.py. Common line133 verifies complete predictions, then line135 opens full external truth. No FLARE all5 loop exists. A separately authorized single-parent score could honestly report VAL000 n=1 with confusion, accuracy, per-class P/R/F1 and macroF1; no SD/SEM, five-parent mean or completed-benchmark claim.

**This does not authorize a new interim truth opening.** Root directed preservation of joint pretruth commitments. The native-per-ARG audit requires all pipelines' exact common-focal predictions sealed before external query truth access. The unchanged GNN selection gate requires all30 genuine SHA-bound cells: original5VAL parents × frozen6 candidate epochs5/10/15/20/25/30 before any VAL resolver invocation (american_c3_gnn_selection_v1.py:17–43,57–80). Native inference/sealing proceeds independently; joint scoring waits for these original commitments. No new interim policy, truth-opening route or user question is introduced.

Actual full original VAL000 truth ref, recovered only from public simulation-completion metadata:

~~~text
experiments/results/American_C3_val000_full30mb_shared_v1/simulation/truth/c3_pulse_ancestry.npz
SHA256 831397e1cecdfde0c68b9c562e4c7947505b3809f834bc704a9f8ca3c12d4352
~~~

No truth bytes were opened/rehashed. Original truth has exactly intervals_bp, query_sample_indices, source_classes_0based, parent_id, class_order. Intervals are float64 positive finite contiguous half-open intervals starting0; query indices unique int64; classes uint8 [intervals,queries], values0..2, exact parent/EUR,EAS,AFR order. All focal positions lie inside the domain and all original genotype-column query identities are present. Join uses searchsorted(intervals[:,1], positions, side="right") then exact sample-column lookup. A focal-only truth vector is not this full-parent schema.

scoring_readiness.v1.json supplies the exact scorer source closure and inactive config with future seal/prediction refs null. The memo2 native driver has no scoring admission stage. After the original truth barrier and actual seal/outer completion, root separately binds/admits the original scorer under the current guard, actual CPU runtime, exact source/helper/config closure and charged output. Original CLI:

~~~bash
test -n "$SCORE_ADMISSION_PATH"
test -n "$SCORE_ADMISSION_SHA256"
env CUDA_VISIBLE_DEVICES='' "$ARGGNN_PYTHON" -B -m arggnn.american_c3_flare_evaluate_v1 \
  --execute \
  --admission "$SCORE_ADMISSION_PATH" \
  --expected-admission-sha256 "$SCORE_ADMISSION_SHA256"
~~~

There is no direct config/output CLI bypass or new scoring engine. All5 parents are needed for the planned five-parent mean/sample SD and GNN checkpoint selection; per-parent FLARE native execution is independent.

## Verification

Unchanged target_v1 and native config_v1 accepted the exact target/conversion and original completed build/tool waits. All19 base source pins and explicit current driver/context/guard/policy/memo/scorer refs match. metadata_qualification.v1.json records accepted config/resource formulas; activation_packet.v1.json contains structured argv with actual-only predecessors and future hashes left unresolved. Shell command blocks passed bash -n.

Only this dedicated handoff folder was written. No guard configuration/state query/mutation, PID probe, payload/model/checkpoint/truth read/hash, admission, runtime/scientific launch or Git occurred. This remains a disclosed current reconstruction, not exact Table1 reproduction or a measured ancestry result.
