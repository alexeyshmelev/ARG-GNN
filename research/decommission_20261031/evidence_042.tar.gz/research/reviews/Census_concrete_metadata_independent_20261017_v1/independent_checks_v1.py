"""Independent bounded immutable metadata/AST/RAM checks. No actual operation/staging probes."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
from types import SimpleNamespace
import ast, copy, hashlib, json, stat, traceback
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
OUT=ROOT/'research/reviews/Census_concrete_metadata_independent_20261017_v1'
P='research/reviews/Census_concrete_metadata_proposal_20261017_v1/'
S='research/reviews/Census_inspect_inline_ROOT_orchestration_source_20261017_v1/'
H='research/reviews/Census_retention_inline_source_20261017_v1/inline_ROOT_retire_v1.py'
G='research/reviews/Census_observation_two_scope_retention_source_20261017_v1/census_observation_retention_v1.py'
FUTURE='research/reviews/Census_retention_inline_ROOT_actual_inspect_root01_oct17'
assertions=[];negatives=[];authenticated={}
def check(name,value):
 if not value:raise AssertionError(name)
 assertions.append(name)
def need(ok,message):
 if not ok:raise ValueError(message)
def encode(value):return (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
def sha(data):return hashlib.sha256(data).hexdigest()
def bounded(path,expected=None):
 need(not path.startswith(FUTURE+'/') and path!=FUTURE,'Never inspect actual future staging')
 p=ROOT/path;before=p.lstat();need(p.resolve()==p and stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size<=1048576,'Bounded immutable selected metadata/source')
 data=p.read_bytes();after=p.lstat()
 identity=lambda v:(v.st_dev,v.st_ino,v.st_mode,v.st_nlink,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
 need(identity(before)==identity(after) and len(data)==before.st_size,'Stable bounded source bytes')
 digest=sha(data);need(expected is None or expected==digest,'Exact selected ref hash '+path)
 authenticated[path]=digest;return data
def doc(path,expected=None):return json.loads(bounded(path,expected))
def defs(source,names):
 tree=ast.parse(source);return [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
def compile_defs(nodes,scope,label):exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),label,'exec',dont_inherit=True,optimize=0),scope)
class FixtureDate(datetime):
 @classmethod
 def now(cls,tz=None):return cls(2001,1,1,12,0,0,tzinfo=timezone.utc)
class RAMPath(PurePosixPath):
 def is_dir(self):return True
class GateReached(Exception):pass

def main():
 handoff=doc(P+'HANDOFF.v1.json','0062882ddcea3c9f6a036403790c74eea7e8e30a22fc10ea2b83805810f2a804')
 manifest=doc(P+'MANIFEST.v1.json','cd411ecb949db6c31f3e6316ead1dc97a770b6a7c0c03155e3d78971beeca369')
 check('proposal_handoff_exact_manifest_join',handoff['manifest_ref']==dict(path=P+'MANIFEST.v1.json',sha256=authenticated[P+'MANIFEST.v1.json']))
 for ref in manifest['files']:bounded(ref['path'],ref['sha256'])
 check('all10proposal_manifest_members_authenticated',len(manifest['files'])==10)
 deps=doc(P+'exact_dependencies.v1.json')
 for ref in deps['selected_direct_ref_authentication']:bounded(ref['path'],ref['sha256'])
 check('all23selected_dependencies_authenticated',len(deps['selected_direct_ref_authentication'])==23)
 check('proposal_manifest_dependency_list_exact',manifest['dependency_refs']==deps['selected_direct_ref_authentication'])
 ip=doc(P+'ROOT_instruction.PROPOSED_INACTIVE.v1.json');tp=doc(P+'ROOT_actual_operation_intent.PROPOSED_INACTIVE.v1.json');rp=doc(P+'whole_join_review.PROPOSED_INACTIVE.v1.json')
 prefix=doc(P+'expected_prefix.LAST_KNOWN_RECORDED.v1.json');roles=doc(P+'expected_guard_roles.HISTORICAL_CAPTURE.v1.json')
 reserve=doc(prefix['source_reserve_receipt_ref']['path'],prefix['source_reserve_receipt_ref']['sha256']);capture=doc(roles['source_capture_ref']['path'],roles['source_capture_ref']['sha256'])
 check('three_proposal_complete_prefixes_equal_historical_receipt',ip['expected_before']==tp['expected_before']==rp['expected_before']==prefix['expected_before']==reserve['initial_ledger_pins'])
 check('three_proposal_all47role_maps_equal_historical_capture',ip['expected_guard_roles']==tp['expected_guard_roles']==rp['expected_guard_roles']==roles['expected_guard_roles']==capture['guard_roles'])
 check('prefix6_historical_not_current',prefix['current_state_asserted'] is False and prefix['fresh_capture'] is False and prefix['must_rebind_after_unresolved_ROOT_mutations'] is True and prefix['expected_before']['completed_overlay_prefix']==dict(events=6,tail_sha256='1aaf8cc65c7f28b2fa8bea43cfa04d12d8aed963c22cd156297255dee8859baf'))
 check('roles47_paths40_not_fresh',len(capture['guard_roles'])==47 and len({r['path'] for r in capture['guard_roles'].values()})==40 and roles['current_state_asserted'] is False and roles['fresh_capture'] is False)
 consumers={r['path']:r['sha256'] for r in reserve['value']['consumer_bindings']}
 check('every_historical_role_exact_recorded_reserve_consumer',all(consumers[r['path']]==r['sha256'] for r in capture['guard_roles'].values()))
 check('inactive_authorizers_clocks_and_capabilities',ip['active'] is tp['active'] is False and ip['root_authorizer'] is tp['root_authorizer'] is None and all(o[k] is None for o in (ip,tp) for k in ('created_at_utc','expires_at_utc')) and tp['ROOT_authorizes_one_actual_original_Census_retirement'] is False and rp['independent'] is False and rp['verdict']=='UNREVIEWED_INACTIVE')
 for old,new in [('ROOT_instruction.INACTIVE.template.v1.json',ip),('ROOT_actual_operation_intent.INACTIVE.template.v1.json',tp),('whole_join_review.INACTIVE.template.v1.json',rp)]:
  original=doc(S+old);actual=copy.deepcopy(new)
  for k in ('expected_before','expected_guard_roles'):actual[k]=original[k]
  if 'blockers' in original:actual['blockers']=original['blockers']
  check('template_keyset_and_only_documented_fill_'+old,actual==original and set(new)==set(original))
 layout=doc(S+'staging_layout.v1.json');recipe=doc(S+'ROOT_RECIPE.v1.json');integration_raw=bounded(S+'integration_manifest.INACTIVE.template.v1.json');integration=json.loads(integration_raw)
 for pair in layout['byte_identical_copies']:
  data=bounded(pair['from']['path'],pair['from']['sha256']);check('future_alias_bytes_'+pair['to']['path'].split('/')[-1],sha(data)==pair['to']['sha256'])
 check('fixed_control_fresh_output_names',layout['metadata_directory']==FUTURE and ip['fresh_metadata_paths']==layout['sole_helper_generated_metadata_paths'] and tp['outcome_metadata_paths']==layout['sole_orchestrator_generated_metadata_paths'] and rp['fresh_metadata_paths']==ip['fresh_metadata_paths'] and rp['outcome_metadata_paths']==tp['outcome_metadata_paths'])
 check('unchanged_integration_map217_and_caps',len(integration['source_sha256'])==217 and recipe['caps']['original_consumer_ref_cap']==64 and recipe['caps']['original_role_count']==47 and recipe['caps']['original_operation_seconds']==300 and recipe['caps']['original_target_fresh_seconds']==120)
 sourcepass=doc(S.replace('_source_','_independent_')+'review.v1.json')
 check('accepted_complete_source_pass_not_actual_whole_capability',sourcepass['independent'] is True and sourcepass['verdict']=='SOURCE_PASS' and sourcepass['blockers']==[] and sourcepass['actual_callback_complete_source_review'] is True and sourcepass['orchestration_complete_source_review'] is True and sourcepass['actual_whole_join_capability_reviewed'] is False and sourcepass['schema']!='Census_inline_ROOT_retirement_whole_join_review_v1')
 orch_raw=bounded(S+'orchestrate_v1.py');helper_raw=bounded(H);guard_raw=bounded(G);callback_raw=bounded(S+'ROOT_authorize_inline_retirement_v1.py')
 orch_tree=ast.parse(orch_raw);orch={'Path':RAMPath,'datetime':FixtureDate,'timezone':timezone,'need':need}
 assignments=[n for n in orch_tree.body if isinstance(n,ast.Assign)]
 compile_defs(assignments+defs(orch_raw,('stamp','controls')),orch,'exact_orchestration_controls_RAM')
 helper_tree=ast.parse(helper_raw);helper={'Path':RAMPath,'datetime':FixtureDate,'timezone':timezone,'need':need,'copy':copy}
 cls=next(n for n in helper_tree.body if isinstance(n,ast.ClassDef) and n.name=='InlineRootRetireStoppedMemo')
 methods=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in ('_authenticate','_inline_ROOT_authority')]
 compile_defs([n for n in helper_tree.body if isinstance(n,ast.Assign)]+methods,helper,'exact_helper_metadata_seams_RAM')
 guard={'datetime':FixtureDate,'timezone':timezone,'require':need,'copy':copy,'_raw':lambda r:need(isinstance(r,dict) and set(r)=={'path','sha256'} and isinstance(r['path'],str) and isinstance(r['sha256'],str) and len(r['sha256'])==64,'RAM explicit ref shape')}
 compile_defs(defs(guard_raw,('_expire','_pins','consumer_bindings_v1')),guard,'exact_guard_pure_metadata_RAM')
 sources={r['path']:bounded(r['path'],r['sha256']) for r in deps['selected_direct_ref_authentication'] if r['path'].endswith('.py')}
 for pair in layout['byte_identical_copies']:sources[pair['to']['path']]=bounded(pair['from']['path'],pair['from']['sha256'])
 selector=doc(ip['selector_ref']['path'],ip['selector_ref']['sha256']);policy=doc(ip['policy_ref']['path'],ip['policy_ref']['sha256']);memo_review=doc(ip['memo_review_ref']['path'],ip['memo_review_ref']['sha256'])
 fixture_prefix=copy.deepcopy(prefix['expected_before']);fixture_prefix['completed_overlay_prefix']=dict(events=123456,tail_sha256='a'*64)
 created='2001-01-01T11:00:00+00:00';expires='2001-01-01T13:00:00+00:00'
 def fixture(mutate=None):
  i,t,r=copy.deepcopy(ip),copy.deepcopy(tp),copy.deepcopy(rp)
  for obj in (i,t,r):obj['expected_before']=copy.deepcopy(fixture_prefix)
  r.update(independent=True,verdict='SOURCE_PASS',blockers=[],actual_callback_complete_source_review=True,orchestration_complete_source_review=True)
  for obj in (i,t):obj.update(active=True,root_authorizer='root_agent',created_at_utc=created,expires_at_utc=expires)
  t['ROOT_authorizes_one_actual_original_Census_retirement']=True
  if mutate:mutate(i,t,r)
  review_ref=dict(path=orch['REVIEW'],sha256=sha(encode(r)))
  i['whole_join_review_ref']=copy.deepcopy(review_ref);t['whole_join_review_ref']=copy.deepcopy(review_ref)
  intent_ref=dict(path=orch['INTENT'],sha256=sha(encode(t)));i['uncached_current_refs'][0]=copy.deepcopy(intent_ref)
  instruction_ref=dict(path=orch['INSTRUCTION'],sha256=sha(encode(i)))
  documents={orch['REVIEW']:encode(r),orch['INTENT']:encode(t),orch['INSTRUCTION']:encode(i),i['source_manifest_ref']['path']:integration_raw,
   i['selector_ref']['path']:encode(selector),i['policy_ref']['path']:encode(policy),i['memo_review_ref']['path']:encode(memo_review)}
  # Preserve authenticated raw bytes for every real inherited JSON; no canonical reserialization shortcut.
  for ref in (i['selector_ref'],i['policy_ref'],i['memo_review_ref']):documents[ref['path']]=bounded(ref['path'],ref['sha256'])
  ram={**sources,**documents,ip['permanent_revocation_ref']['path']:bounded(ip['permanent_revocation_ref']['path'],ip['permanent_revocation_ref']['sha256'])}
  def raw(ref):
   need(isinstance(ref,dict) and set(ref)=={'path','sha256'},'Exact RAM ref');data=ram[ref['path']];need(sha(data)==ref['sha256'],'RAM authenticated digest');return data
  def bound(root,ref,fresh):need(fresh is True,'Uncached RAM metadata');return json.loads(raw(ref))
  v4=SimpleNamespace(canonical=lambda root,path:root/path)
  g=SimpleNamespace(_expire=guard['_expire'],_pins=guard['_pins'])
  state=SimpleNamespace(helper_ref=copy.deepcopy(i['helper_ref']),manifest_ref=copy.deepcopy(i['source_manifest_ref']),review_ref=review_ref,memo_review_ref=copy.deepcopy(i['memo_review_ref']),callback_ref=copy.deepcopy(i['callback_source_ref']),callback_name=i['callback_name'],paths=copy.deepcopy(i['fresh_metadata_paths']),revocation_ref=copy.deepcopy(i['permanent_revocation_ref']),instruction_ref=instruction_ref,key=i['key'],metadata_directory=i['metadata_directory'],cache_refs=copy.deepcopy(i['cache_refs']),current_refs=copy.deepcopy(i['uncached_current_refs']),v4=v4,guard=g,memo=SimpleNamespace(source_bytes=raw))
  orch['raw']=raw;orch['document']=lambda ref:json.loads(raw(ref))
  return i,t,r,instruction_ref,intent_ref,state,bound
 def evaluate(mutate=None):
  i,t,r,iref,tref,state,bound=fixture(mutate)
  orch['controls'](iref,tref);got=helper['_authenticate'](state,bound)
  return i,t,r,state,bound,got
 i,t,r,state,bound,got=evaluate()
 check('exact_RAM_review_intent_instruction_digest_DAG_passes_both_authenticators',got==i and 'instruction_path' in t and 'instruction_ref' not in t and state.current_refs[0]['path']==orch['INTENT'] and state.current_refs[1]==t['orchestration_source_ref'])
 check('RAM_prefix_is_explicit_fixture_not_historical_current_claim',fixture_prefix!=prefix['expected_before'] and got['expected_before']==fixture_prefix)
 def reject(name,mutate):
  try:evaluate(mutate)
  except (ValueError,KeyError,TypeError):negatives.append(name);return
  raise AssertionError('Accepted invalid RAM fixture '+name)
 reject('inactive_instruction',lambda i,t,r:i.update(active=False))
 reject('inactive_intent',lambda i,t,r:t.update(active=False))
 reject('intent_extra_unknown_field',lambda i,t,r:t.update(unknown_fixture_field=True))
 reject('instruction_extra_unknown_field',lambda i,t,r:i.update(unknown_fixture_field=True))
 reject('instruction_prefix_differs_from_intent',lambda i,t,r:i['expected_before']['completed_overlay_prefix'].update(events=999))
 reject('review_prefix_differs_from_instruction',lambda i,t,r:r['expected_before']['completed_overlay_prefix'].update(events=999))
 reject('instruction_role_omission',lambda i,t,r:i['expected_guard_roles'].pop(next(iter(i['expected_guard_roles']))))
 reject('intent_role_mismatch',lambda i,t,r:t['expected_guard_roles'][next(iter(t['expected_guard_roles']))].update(sha256='f'*64))
 reject('review_role_mismatch',lambda i,t,r:r['expected_guard_roles'][next(iter(r['expected_guard_roles']))].update(sha256='f'*64))
 reject('nonindependent_whole_review',lambda i,t,r:r.update(independent=False))
 reject('whole_review_has_blocker',lambda i,t,r:r.update(blockers=['fixture blocker']))
 reject('whole_review_callback_unreviewed',lambda i,t,r:r.update(actual_callback_complete_source_review=False))
 reject('whole_review_orchestration_unreviewed',lambda i,t,r:r.update(orchestration_complete_source_review=False))
 reject('whole_review_wrong_schema',lambda i,t,r:r.update(schema='source_only_fixture'))
 reject('callback_digest_substitution',lambda i,t,r:i['callback_source_ref'].update(sha256='f'*64))
 reject('wrong_guard_digest',lambda i,t,r:i['guard_ref'].update(sha256='f'*64))
 reject('wrong_future_observation_path',lambda i,t,r:i['fresh_metadata_paths'].update(observation=FUTURE+'/other.json'))
 reject('wrong_outcome_name',lambda i,t,r:t['outcome_metadata_paths'].update(result=FUTURE+'/other.json'))
 reject('new_operation_deadline300_relaxed',lambda i,t,r:i.update(operation_wall_seconds=301))
 reject('target120_freshness_relaxed',lambda i,t,r:i.update(fresh_target_seconds=121))
 reject('expired_finite_clock',lambda i,t,r:i.update(expires_at_utc='2001-01-01T11:59:59+00:00'))
 reject('future_created_clock',lambda i,t,r:i.update(created_at_utc='2001-01-01T12:00:01+00:00'))
 reject('naive_clock',lambda i,t,r:i.update(created_at_utc='2001-01-01T11:00:00'))
 reject('intent_clock_differs_from_instruction',lambda i,t,r:t.update(expires_at_utc='2001-01-01T14:00:00+00:00'))
 reject('old_authorizer_reuse',lambda i,t,r:i.update(root_authorizer='prior_agent'))
 reject('automatic_retry_allowed',lambda i,t,r:t.update(automatic_retry=True))
 reject('prefix_discovery_allowed',lambda i,t,r:t.update(prefix_discovery=True))
 reject('credit_accepted_early',lambda i,t,r:t.update(credit_accepted=True))
 reject('wrong_inspect_key',lambda i,t,r:i.update(key='census_tsinfer_observation_v1/census-tsinfer-numerical-v1'))
 # Run exact helper prewrite gate with RAM lower providers, stopping before _put_attempt.
 def prewrite_case(prefix_change=False,role_change=False,cap_count=None):
  i,t,r,s,bound,got=evaluate();marks=[];own=dict(key=s.key,reserved_bytes=20000000000,RAM_fixture_only=True)
  s._tx=SimpleNamespace(original={'bound':bound});s._callback_calls=0;s._authority_ref=None
  s._authenticate=lambda provider:helper['_authenticate'](s,provider);s._check_callback=lambda:None
  s._put_attempt=lambda finite:(_ for _ in ()).throw(GateReached())
  s.guard.assert_open=lambda key,a,b:need(key in a,'RAM open target');s.guard._target=lambda key:dict(original_reservation=own)
  s.guard.consumer_bindings_v1=guard['consumer_bindings_v1']
  if cap_count is not None:
   def count_override(*groups):
    original=guard['consumer_bindings_v1'](*groups)
    return original+[dict(path='RAM_ONLY_'+str(n)+'.json',sha256='0'*64) for n in range(cap_count-len(original))]
   s.guard.consumer_bindings_v1=count_override
  fresh_roles=copy.deepcopy(i['expected_guard_roles']);fresh_prefix=copy.deepcopy(i['expected_before'])
  if prefix_change:fresh_prefix['completed_overlay_prefix']['events']+=1
  if role_change:fresh_roles[next(iter(fresh_roles))]['sha256']='0'*64
  try:helper['_inline_ROOT_authority'](s,({s.key:own},None,fresh_prefix,fresh_roles),lambda:None)
  except GateReached:return True,s
  except ValueError:return False,s
  raise AssertionError('Unexpected return before RAM write gate')
 check('exact_helper_prefix_roles_union_prewrite_gate_passes_RAM',prewrite_case()[0])
 for name,kwargs in [('same_mutex_prefix_drift_before_any_write',dict(prefix_change=True)),('same_mutex_role_drift_before_any_write',dict(role_change=True)),('existing62_plus3_rejected_before_any_write',dict(cap_count=62))]:
  ok,s=prewrite_case(**kwargs);check(name,not ok and s._callback_calls==0);negatives.append(name)
 check('existing61_plus3_exact64_prewrite_cap_boundary',prewrite_case(cap_count=61)[0])
 existing=guard['consumer_bindings_v1'](list(i['expected_guard_roles'].values()),[state.instruction_ref,state.manifest_ref,state.review_ref,state.memo_review_ref,state.helper_ref,helper['MEMO_REF'],helper['BRIDGE_REF'],helper['SELECTOR_REF'],helper['POLICY_REF'],state.callback_ref,state.revocation_ref])
 check('original_consumer_dedup_static50_plus3_is53',len(existing)==50 and len(existing)+len(state.paths)==53 and not ({r['path'] for r in existing}&set(state.paths.values())))
 check('no_conflicting_same_path_hash_in_static_union',len({r['path'] for r in existing})==len(existing))
 fn=next(n for n in ast.parse(callback_raw).body if isinstance(n,ast.FunctionDef))
 check('callback_entire_inert_one_function',len([n for n in ast.parse(callback_raw).body if isinstance(n,ast.FunctionDef)])==1 and all(isinstance(n,ast.FunctionDef) or isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) for n in ast.parse(callback_raw).body))
 text=callback_raw.decode();check('callback_copies_instruction_expiry_unchanged',"authority.update(active=True,expires_at_utc=instruction['expires_at_utc'])" in text)
 helper_text=helper_raw.decode();check('uncached_control_json_exclusions_before_first_helper_write',helper_text.index('records=[self.manifest_ref')<helper_text.index('yield\n') and 'list(self.paths.values())+[p for p in manifest["source_sha256"]if Path(p).suffix==".json"]' in helper_text and 'len(set(exclusions))<=2048' in helper_text and 'len(seen)<16' in helper_text)
 check('current_refs_include_intent_and_orchestrator',len(ip['uncached_current_refs'])==2 and ip['uncached_current_refs'][0]['path']==tp['instruction_path'].replace('ROOT_instruction.root_active_v1.json','ROOT_actual_operation_intent.root_active_v1.json') and ip['uncached_current_refs'][1]==tp['orchestration_source_ref'])
 check('original300timer_precedes_blocking_mutex',guard_raw.decode().index('started=time.monotonic();deadline=started+OPERATION_WALL_SECONDS')<guard_raw.decode().index('with budget.v4.mutex(ROOT):',guard_raw.decode().index('def apply_retire_stopped_v1')))
 preserve=doc(S+'preservation.v1.json')
 check('both20GB_charges_and_failure_unknowns_preserved',preserve['inspect_key_remains_fully_charged_until_genuine_ROOT_final_acceptance'] is True and preserve['numerical_key_remains_fully_charged'] is True and preserve['original_retention_credit_accepted_bytes']==0 and preserve['unknown_historical_descendants_supervisor_wait_and_drain_remain_unknown'] is True and preserve['original_phase32of32_and_direct_worker_wait0_not_relabelled'] is True)
 return {'schema':'Census_concrete_metadata_independent_checks_v1','status':'PASS','assertions':assertions,'negative_fixtures':negatives,'assertion_count':len(assertions),'negative_count':len(negatives),'authenticated_selected_unique_refs':authenticated,'proposal_manifest_member_count':len(manifest['files']),'selected_dependency_count':len(deps['selected_direct_ref_authentication']),'historical_roles':47,'historical_role_unique_paths':40,'static_existing_union_paths':50,'static_union_with_three_future_paths':53,'original_cap':64,'integration_map_entries':217,'all217entries_rehashed':False,'fixture_clock':'2001-01-01T12:00:00+00:00','actual_prefix_current_asserted':False,'actual_authority_created':False,'actual_future_staging_inspected_or_created':False,'actual_operations':0,'actual_credit_accepted_bytes':0,'validation_disclosure':'Only selected exact AST controls/_authenticate/prewrite-gate and original pure metadata functions executed. RAM bound/raw/Path/guard lower providers; prewrite stops before helper token. No candidate module imported or operational code run; accepted source campaigns inherited, not repeated.'}
try:
 result=main()
except BaseException:
 diagnostic=traceback.format_exc();(OUT/'first_diagnostic.v1.txt').write_text(diagnostic);raise
with (OUT/'checks.result.v1.json').open('xb') as stream:stream.write(encode(result))
print(json.dumps({k:result[k] for k in ('status','assertion_count','negative_count','static_union_with_three_future_paths','actual_operations','actual_future_staging_inspected_or_created')},sort_keys=True))
