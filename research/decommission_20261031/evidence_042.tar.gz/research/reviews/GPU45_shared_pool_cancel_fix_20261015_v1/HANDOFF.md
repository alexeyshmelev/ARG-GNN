# GPU45 shared pool: focused owned cancellation fix

Source-only successor. Nothing is installed, activated, admitted or launched.
Current exclusive C3GPU4 (root-reported36510) and nativeGPU5v12 are untouched.

The fix services requested cancellation before host scans, again after scan
exceptions and after persistence errors. Supervision failure blocks admissions,
cancels queued work and requests fail-stop drain of already proven-owned jobs.
The direct Popen leader's PID/UID/start/session is captured immediately after
spawn, before a whole-host scan can fail. Original title/lease validation,
physicalGPU4/5 selection, external usage accounting and worker science remain
unchanged.

Only recorded job identities are targets. Fresh PIDFDs and current UID/start
checks reject reused PIDs or changed UIDs. Same-title external PIDs, unknown
processes and group broadcasts are excluded. One target's error cannot block
attempts for another known-owned target.

TERM is sent once per exact identity; after the proposed30second grace KILL is
sent once if the exact identity is still present. Failed real sends may retry
and remain recorded. No successful send, wait or absence is invented.
Future active capabilities must explicitly authorize owned escalation, use
positive grace<=120seconds, and leave grace+5seconds inside the expiry window.
The inactive example keeps escalation authorizationfalse. After drain
authority expiry no signal is sent; root manual reconciliation is required.

TERM/KILL attempts release nothing. Original real leader/descendant waits,
complete process visibility, NVML-owned PID disappearance and ambiguity checks
still decide terminal/drain/close. Persistent opaque unrelated metadata still
prevents child polling/reaping, successful drain and close, even while known
owned TERM/KILL works. Reservations and inherited physical lease stay held.
No blanket unrelated-PID skip or new ownership framework is introduced.

17pure source fixtures passed with fake clock, identities, PIDFD functions and
signals. Cases cover isolation, known descendants, escalation timing,
persistent scan/persistence failures, shutdown, same-title external PIDs,
PID/UID reuse, one-target failures, expiry and leader capture. No actual
process, PIDFD, guard, GPU, socket or scientific job was used.

~~~bash
.runtime/env/bin/python -B research/reviews/GPU45_shared_pool_cancel_fix_20261015_v1/fixtures_source_only_v1.py
~~~

Static checks preserve original lease/title/worker/memory/opaque/guard methods,
thin launcher and frozen C3/base validator sources. Source files outside this
packet were not edited. The base pool remains inherited; no scientific worker
or canonical lease validator is cloned.

## Concrete readiness and remaining integration

readiness_gate.inactive.json is explicitly blocked. It lists root's required
independent review and live ownership-visibility/device/admission checks.
It is not an active capability, a host qualification, or a bypass. The
unchanged _process_scan check is the actual automatic launch/drain gate.

Current C3 and H049 allowances are both40GiB. Two jobs plus2GiB/job margin
and4GiB device headroom total88GiB, which cannot fit80GiB. The fixed inactive
examples now state this explicitly. No21GiB H049 fit is assumed.

Current H049 canonical dispatcher is exec_v2; the old pool whitelist/example
still names historical exec_v1. Currentv2 integration is explicitly blocked,
with its exact reference in remaining_integration_v1.json. Its source and
canonical GPUv2 driver/context must be reviewed and bound before a future
allowlist/operational change. CPUprep v4 is separate and must bind its actual
successful completion. No ready H049 pool route is claimed here.

There is no honest drop-in shared outer command for the currently admitted C3
exclusive job: its driver/contract bytes and actual-launcher field are pinned.
Do not edit or reroute active consumers. After they finish, the smallest
integration is an explicit shared branch in the existing canonical operational
interfaces, retaining exclusive mode and frozen science. Fresh input/source/
storage/actual-launcher bindings are mandatory. If isolation requires a
separate operational successor, extend its canonical dispatcher binding
explicitly; do not silently clone science or add another scheduler.

The original thin command constructor is reusable only after those bindings
are honest. Root owns independent review, future exact-file installation,
controller reservation, active capability, actual UUID/memory checks, same
kernel physical lease, real worker/client waits and completed-scope close.
The present executable route remains the unchanged exclusiveGPU4 job; the
nativeGPU5 run is never modified by this packet.

Files include the focused diff, two staged targets, blocked inactive examples,
actual17case fixture summary, static receipt and exact remaining integration.
No install/activation/guard/probe/job/signal/Git action occurred here.
