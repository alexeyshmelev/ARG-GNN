"""Pure source fixtures. No pool import, CUDA, /proc, PIDFD, guard, socket or job."""
import ast, contextlib, hashlib, json, signal, types
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE=HERE/"gpu45_shared_pool_v1.staged.py"
tree=ast.parse(SOURCE.read_text())
controller=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="Shared45Controller")
methods={n.name:n for n in controller.body if isinstance(n,ast.FunctionDef)}
class Clock:
    wall=1000.;mono=0.
    def time(self):return self.wall
    def monotonic(self):return self.mono
clock=Clock()
signals=[];opened=[];closed=[];identities={};denied=set()
def require(ok,message):
    if not ok:raise ValueError(message)
def identity(pid):
    if pid not in identities:raise ProcessLookupError(pid)
    return dict(identities[pid])
def open_pidfd(pid):
    opened.append(pid)
    if pid in denied:raise PermissionError("fixture denied PIDFD")
    if pid not in identities:raise ProcessLookupError(pid)
    return pid+10000
def send_pidfd(fd,sig):
    signals.append(dict(pid=fd-10000,signal=int(sig),mono=clock.mono))
base=types.SimpleNamespace(proc_identity=identity,open_pidfd=open_pidfd,send_pidfd=send_pidfd)
fake_os=types.SimpleNamespace(getuid=lambda:77,close=lambda fd:closed.append(fd))
namespace=dict(time=clock,base=base,os=fake_os,signal=signal,require=require,
    ACTIVE=frozenset({"launching","running","draining"}))
for name in ["_fail_owned_supervision","_service_termination","tick","cancel_declared","_signal_job","_signal_own"]:
    module=ast.Module(body=[methods[name]],type_ignores=[]);ast.fix_missing_locations(module)
    exec(compile(module,"<isolated_"+name+">","exec"),namespace)
def row(pid,start,uid=77):
    return dict(pid=pid,start_ticks=start,uid=uid,state="S",ppid=1,pgid=pid,sid=pid)
def fixture(scan_error=False,persist_error=False):
    signals.clear();opened.clear();closed.clear();denied.clear();identities.clear()
    clock.wall=1000.;clock.mono=0.
    records={"A":[row(1001,11),row(1004,44)],"B":[row(1002,22)]}
    identities.update({r["pid"]:dict(r) for rs in records.values() for r in rs})
    # Same title and UID do not establish ownership.
    identities[1003]=dict(row(1003,33),title="AI Auto Research Pipeline Test")
    jobs={name:dict(state="running",process_identities=rs,pid=rs[0]["pid"],
        leader_start_ticks=rs[0]["start_ticks"],descendant_waits=[])
        for name,rs in records.items()}
    obj=types.SimpleNamespace(lock=contextlib.nullcontext(),lifecycle="running",
        cap=dict(expires_unix=1500.,drain_expires_unix=2000.,termination_grace_seconds=30,
            owned_termination_escalation_authorized=True),jobs=jobs,
        children={name:types.SimpleNamespace(pid=rs[0]["pid"],poll=lambda:None) for name,rs in records.items()},
        processes={r["pid"]:dict(r) for rs in records.values() for r in rs},
        pid_jobs={r["pid"]:name for name,rs in records.items() for r in rs},ambiguous=[],
        logs={},terminate_requested=False,_lease_check=lambda:None,_drain_logs=lambda:None,
        _reap_owned_adopted=lambda:None,_memory=lambda:dict(overrun_jobs=[],owned_compute_jobs=["A","B"]),
        _launch_queue=lambda:None)
    def scan():
        if scan_error:raise RuntimeError("fixture opaque unrelated PID metadata")
    def persist():
        if persist_error:raise RuntimeError("fixture persistence/guard failure")
    obj._process_scan=scan;obj._persist=persist
    for name in ["_fail_owned_supervision","_service_termination","tick","cancel_declared","_signal_job","_signal_own"]:
        setattr(obj,name,types.MethodType(namespace[name],obj))
    return obj
results=[]
def passed(name,condition,detail=None):
    assert condition,(name,detail)
    results.append(dict(case=name,passed=True,detail=detail))
x=fixture();x.jobs["A"]["cancel_requested"]=True;x._service_termination()
passed("per_job_cancel_targets_only_owned_A_and_known_descendant",
    {r["pid"] for r in signals}=={1001,1004} and all(r["signal"]==signal.SIGTERM for r in signals),list(signals))
clock.mono=29.;x._service_termination();passed("no_KILL_before30seconds",len(signals)==2)
clock.mono=30.;x._service_termination();passed("KILL_after30seconds_only_exact_owned",
    [(r["pid"],r["signal"]) for r in signals[-2:]]==[(1001,signal.SIGKILL),(1004,signal.SIGKILL)],list(signals))
x._service_termination();passed("KILL_not_repeated",len(signals)==4)
passed("TERM_or_KILL_does_not_release_children_or_logical_state",
    len(x.children)==2 and all(j["state"]=="running" for j in x.jobs.values()))
x=fixture(scan_error=True);x.jobs["A"]["cancel_requested"]=True;x.tick(False)
passed("opaque_scan_still_services_cancel_and_fail_stop_owned_drain",
    {r["pid"] for r in signals}=={1001,1002,1004} and x.lifecycle=="draining"
    and all(j["state"]=="draining" for j in x.jobs.values()),list(signals))
clock.mono=30.;x.tick(False)
passed("opaque_scan_still_services_bounded_owned_KILL",
    {r["pid"] for r in signals if r["signal"]==signal.SIGKILL}=={1001,1002,1004})
passed("external_same_title_never_opened_or_signalled",1003 not in opened and all(r["pid"]!=1003 for r in signals))
x=fixture(scan_error=True);x.terminate_requested=True;x.tick(False)
passed("explicit_shutdown_terminate_with_opaque_scan",
    {r["pid"] for r in signals}=={1001,1002,1004})
x=fixture(persist_error=True);x.jobs["A"]["cancel_requested"]=True;x.tick(False)
passed("persistence_failure_does_not_suppress_owned_signal",
    {r["pid"] for r in signals}=={1001,1002,1004} and x.lifecycle=="draining")
clock.mono=30.;x.tick(False)
passed("persistence_failure_does_not_suppress_escalation",
    {r["pid"] for r in signals if r["signal"]==signal.SIGKILL}=={1001,1002,1004})
x=fixture();identities[1004]["start_ticks"]=4444;x.jobs["A"]["cancel_requested"]=True;x._service_termination()
passed("reused_historical_PID_not_signalled",all(r["pid"]!=1004 for r in signals)
    and x.jobs["A"]["owned_termination"]["1004:44"]["identity_mismatch_observed"] is True)
x=fixture();identities[1004]["uid"]=88;x.jobs["A"]["cancel_requested"]=True;x._service_termination()
passed("changed_UID_not_signalled",all(r["pid"]!=1004 for r in signals))
x=fixture();denied.add(1001);x.terminate_requested=True;x._service_termination()
passed("one_PIDFD_error_does_not_block_other_owned_targets",
    {r["pid"] for r in signals}=={1002,1004} and "last_signal_error" in x.jobs["A"]["owned_termination"]["1001:11"])
x=fixture();clock.wall=2000.;x.terminate_requested=True;x._service_termination()
passed("no_signals_after_bounded_drain_authority_expiry",signals==[]
    and x.termination_authority_expired is True and len(x.children)==2)
x=fixture(scan_error=True)
# Execute only the real source block immediately AFTER its Popen result, with
# fake already-owned leader data. No Popen call or process is executed.
launch=methods["_launch_queue"]
block=next(n for n in ast.walk(launch) if isinstance(n,ast.Try)
    and any(isinstance(a,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="leader" for t in a.targets) for a in n.body))
first=next(i for i,n in enumerate(block.body) if isinstance(n,ast.Assign)
    and any(isinstance(t,ast.Name) and t.id=="leader" for t in n.targets))
captured=ast.Module(body=block.body[first:],type_ignores=[]);ast.fix_missing_locations(captured)
x.jobs["A"]["process_identities"]=[];x.jobs["A"]["leader_start_ticks"]=None
x.pid_jobs.clear();x.processes.clear()
local=dict(namespace,self=x,child=types.SimpleNamespace(pid=1001),name="A",job=x.jobs["A"])
try:exec(compile(captured,"<exact_post_Popen_capture_block>","exec"),local)
except RuntimeError as error:assert "opaque" in str(error)
else:raise AssertionError("Expected fixture host-scan failure")
passed("direct_leader_captured_before_opaque_host_scan",
    x.jobs["A"]["leader_start_ticks"]==11 and x.pid_jobs[1001]=="A"
    and x.jobs["A"]["process_identities"][0]["uid"]==77)
x.jobs["A"]["cancel_requested"]=True;x._service_termination()
passed("new_leader_can_cancel_after_first_host_scan_failed",
    [(r["pid"],r["signal"]) for r in signals]==[(1001,signal.SIGTERM)])
print(json.dumps(dict(schema="GPU45_cancel_fix_pure_source_fixtures_v1",
    source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),cases=results,cases_passed=len(results),
    actual_pool_imports_guard_calls_PIDFDs_processes_jobs_GPU_queries_signals_or_Git=0),indent=2,sort_keys=True))
