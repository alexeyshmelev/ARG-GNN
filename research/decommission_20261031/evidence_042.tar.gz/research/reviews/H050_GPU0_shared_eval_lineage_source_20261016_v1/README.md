# H050 GPU0 shared EVALUATE source packet

Status: source only. No certificate or EVAL input has been bound, no storage
reserved, no guard called, no TRAIN/EVAL run, no GPU queried, and no Git action
performed by this packet's author. Existing scientific and admitted source files
are untouched. The static receipt uses only in-memory synthetic terminal and
scientific-completion fixtures, actual count metadata, and source bytes.

## Scientific invariants

The actual original GPU0 full TRAIN input is pinned to SHA
1100941aaf8b1431cb0c4ea963daf568843ed1b76caa397c98bedb0fe3e57576.
The EVAL config copies its exact config and changes only output_cap_bytes to
110100480 (105 MiB). Every other field, including the original source manifest,
GPU0 TRAIN context, registration, preparation, H045 warmcheckpoint JSON proxy,
scientific protocol and historical operational annotations, remains identical.
These inherited fields describe TRAIN provenance. The actual new EVAL context,
runtime and finite-controller sources are declared separately on the EVAL input
and in a directly bound operational closure.

Original producer load_checkpoints, run_evaluate, paired_criteria, model/hooks,
metrics, selection and probability handling remain unchanged. The original
producer verifies all 24 actual checkpoint payloads and their SHA/provenance.
The 192 dense probability products remain RAM only; the original ram.verify()
barrier precedes opening VAL truth. No outer truth or optimization is added.
Only original physical eligibility checks are privately changed from GPUs4/5
to GPU0. No installed guard or frozen scientific module is edited.

The original complete TRAIN lineage checks remain: 30 complete passes, 32
parents/pass, four arms, 960 steps/arm, 3840 total, finite FP32 first scheduled
step/full-model update qualifications, identical source/protocol/preparation,
and six prescribed groups containing exactly 24 scheduled checkpoint refs.
Only the old exclusive receipt/namespace/output checks are privately replaced
with genuine shared certificate validation. No shared wait is relabelled as an
exclusive launcher wait.

## Exact count plan and caps

The exact original pure count_plan_v1, validate_plan_caps_v1 and
bounds_from_counts_v1 were used with actual count/preparation metadata.

- Minimum original reviewed durable scope: 104939520 bytes = 100.078125 MiB.
- Root proposal: 110100480 bytes = 105 MiB.
- Dense RAM probabilities: 2046014208 bytes for all 192 products.
- New checkpoint files in EVAL: zero.
- Original durable allowances retained: fixed metadata64 MiB, qualification8
  MiB, root auxiliary16 MiB, six logs at2 MiB, serialization/waits81920 bytes.
- CPU RSS cap remains64 GiB; CUDA reserved cap remains28 GiB. Every other
  original cap, including RAM/grid/episode/preparation caps, remains unchanged.

This is source planning with original reviewed allowances, not a measured fit,
observed peak, or a scientific result. The future controller must enforce full
caps, margins and GPU0 headroom independently.

## Future root APIs

All refs are exact {path, sha256} objects relative to the remote project root
/workspace-SR003.nfs2/ARG-GNN. Import is standard-library only.

1. shared_terminal_v1.bind_certificate_v1(request_ref, fresh_folder)

   Requires an active root-authored
   GPU0_root_shared_terminal_binding_request_v1 with capability_ref,
   registry_snapshot_ref, client_tool_terminal_ref, input_ref and completed_ref.
   The client terminal record schema is GPU0_shared_client_actual_tool_terminal_v1.
   It must describe the actually root-consumed run/wait tool terminal0 and match
   the exact terminal job row. The authentic fixed TRAIN pool registry must
   prove successful leader wait0, all adopted waits0, exact PID/start identities,
   owned drain, no cancellation/resource error/ambiguity, exact input/storage/
   caps/arguments, and unchanged original completed marker. The binder never
   polls, signals, waits or infers completion.

2. runtime_metadata_adapter_v1.prepare_evaluate_metadata_v1(request_ref, folder)

   Requires an active root-authored
   H050_GPU0_shared_EVAL_metadata_binding_request_v1 with:
   root_authorizer="root_agent", status="active", output_cap_bytes=110100480,
   train_shared_terminal_certificate_ref, fresh job_id/output_directory,
   created_at_utc/expires_at_utc (aware timestamps, at most24 hours apart), and
   controller_source_refs. Required controller roles are pool, launcher,
   bootstrap. The future facade also declares declared_runtime and
   finite_job_contract. Each value is its exact reviewed source ref.

   Returns input_draft_ref, output_plan, output_cap_bytes and consumer_bindings.
   Writes only fresh metadata config/runtime/VAL target refs/consumer manifest/
   operational closure/draft. Does not reserve, admit, call guards or create
   scientific output files. The request and complete TRAIN lineage are
   transitively authenticated through the directly bound operational closure.

3. Root uses its original reviewed storage admission APIs to reserve exactly
   105 MiB for the fresh EVAL output and its worker_auxiliary_scope, using the
   returned exact consumer_bindings and normal ledger/policy/capacity checks.
   There is no storage-admission implementation in this packet.

4. runtime_metadata_adapter_v1.finalize_evaluate_input_v1(draft_ref, storage_ref, folder)

   Writes fresh input.json in the prepared folder after validating actual root
   v9 storage identity,105 MiB charge, expiry, auxiliary scope and bindings.
   It never reserves or rebases a charge.

5. The fresh finite-declared controller may call invoke_job_v1(j). j is the
   original-style method_job with worker_kind="H050", original canonical
   module_ref for src/arggnn/H050_direct_readout_cut_memory_exec_v1.py,
   runtime_entry_ref for this packet's runtime_metadata_adapter_v1.py,
   exact input_ref/storage_ref/job_id/cpu_rss_cap_bytes/cuda_cap_bytes, and args:
   ["--execute","--input",input_path,"--expected-input-sha256",input_sha256].

   The input must be active H050 evaluate on physical0/cuda, carry the exact
   original scientific source map, explicit actual operational_eval_source_refs,
   operational_eval_runtime_ref and operational_eval_context_override_ref
   (both this runtime source), plus the bound operational_eval_closure_ref.
   The entry installs the unchanged pinned canonical GPU0 guard before Torch,
   uses the original context body with its private shared-lineage namespace,
   and calls the original producer main. build_context_v1 is exposed only for
   this explicit private context-loader substitution.

required_bindings_v1(cfg,spec) retains all original core source/guard refs and
the original H045 checkpoint proxy. Exactly three read-only JSON refs (count
manifest, preparation source manifest, metrics config) are authenticated
through the explicit closure instead of duplicating direct slots. All eight
original budget sources, original GPU0 helper runtime, original canonical module,
actual runtime, terminal validator, guard and controller role refs are directly
bound. Planning gives57 refs with three controller roles,59 with five; limit64
is unchanged. No new scientific payload is added as a direct metadata binding.

## Clean future controller / queued native handover boundary

The currently admitted TRAIN-only controller is immutable. This packet does not
make it EVAL-capable. Only the never-started native queue entry may be cancelled
by root. Its authentic frozen registry must show PID/start timestamps/process
identities/worker creation absent and preserve exact original requested job,
input, output, storage, caps and arguments.

Root must consume the genuine final old-controller wait0 and owned drain, with
all actual jobs terminal, before any fresh controller takes the canonical GPU0
singleton lock itself. The old controller must have no future-writer authority.
No live patching, FD borrowing, duplicate controller or unsupported old-writer
claim is allowed.

The exact native input, scientific output/storage scope, original7 GiB charge,
caps and original expiry can be reused only after that genuine never-started
cancellation and terminal handover. No native re-reservation, reset, replay,
expiry extension or old-writer/storage-credit claim is established here.
The future controller's separate operational envelope/scope must authenticate
its actual facade/runtime/bootstrap without mutating the original native input.

The disjoint future controller source packet is
research/reviews/GPU0_declared_experiments_pool_source_20261016_v1.
It must be separately reviewed and root-bound. Its finite worker contract must
support explicit H050 evaluate and retain original method guards, full memory
caps/margins/headroom, maximum three logical concurrent jobs, and the singleton
GPU0 UUID GPU-ff06ca1f-403a-f2d0-b584-71e177452667.
