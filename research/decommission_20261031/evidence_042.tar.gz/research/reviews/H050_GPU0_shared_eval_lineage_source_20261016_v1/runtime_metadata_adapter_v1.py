"""H050 GPU0 shared EVALUATE: operational lineage only; original science frozen.

Import is standard-library only. Explicit execution installs the unchanged GPU0
canonical guard before importing the original producer. Binding functions write
metadata only and never reserve storage, call a guard, launch, poll or wait.
"""
from pathlib import Path
from types import SimpleNamespace
import ast,copy,datetime,hashlib,importlib.util,json,sys,types
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
HERE="research/reviews/H050_GPU0_shared_eval_lineage_source_20261016_v1"
SOURCE=HERE+"/runtime_metadata_adapter_v1.py"
TERMINAL=HERE+"/shared_terminal_v1.py"
EVAL_CAP_BYTES=105*1024**2
GPU0="research/reviews/GPU0_shared_execution_source_20261016_v1"
OLD_CONTEXT=GPU0+"/gpu0_h050_context_v1.py"
OLD_RUNTIME=GPU0+"/gpu0_runtime_adapter_v1.py"
GUARD=GPU0+"/gpu0_native_guard_v1.py"
COMMON="research/reviews/H050_direct_readout_cut_memory_source_20261015_v1/producer_integration_v1/root_bridge_v1/bridge_common_v1.py"
CONTEXT="research/reviews/H050_direct_readout_cut_memory_source_20261015_v1/producer_integration_v1/root_bridge_v1/context_factory_v1.py"
PRODUCER="research/reviews/H050_direct_readout_cut_memory_source_20261015_v1/producer_integration_v1/producer_v1.py"
CANONICAL="src/arggnn/H050_direct_readout_cut_memory_exec_v1.py"
METADATA="research/reviews/H050_shared_admission_source_metadata_closure_fix_20261016_v1/context_metadata_fix_v1.py"
TRAIN_INPUT="research/reviews/GPU0_shared_root_integration_20261016_v1/admitted_H050_GPU0_train_v1/input.json"
TRAIN_CONFIG="research/reviews/GPU0_shared_admission_draft_20261016_v1/bound_metadata_v1/H050_config.json"
PINS={
 TRAIN_INPUT:'1100941aaf8b1431cb0c4ea963daf568843ed1b76caa397c98bedb0fe3e57576',
 CANONICAL:"f32a1deb64858549f77cd0ad7b7de7cf4c0cbfaaa975a7be32b631c89bce8a56",
 COMMON:"5ec43d65bde777d18c071be2cdf4ee5c14ef2784bfe54ac27582f187ee93552b",
 CONTEXT:"58bf94db37f8fb63afeca64352fd362ddf580d7117ef794481dfe4395f087fa2",
 PRODUCER:"1efd84ea51ed05b20e713f6a39ef33dfc08ce3921730d8ce8aa39ef184506130",
 METADATA:"6c704a0b47d5b6f136479879ad9c11036f6d80760a93933ae3d0f222db3ce67d",
 OLD_RUNTIME:"957ec724bb345a76932d5ea43b0df527bc9d12b068815db91cf17da1b0c85896",
 OLD_CONTEXT:"5337794e0c779db2bd1f05057f35ec14afc75a33d14ac41556f3ae679777f741",
 GUARD:"3a08d3bd84adc95aafd332bc224fdb7aa38730d6c2f48dee8108944251b7ee69",
 TRAIN_CONFIG:"926856f74b0bf9f083baa128beedfcdbebbe7fdb9ffac3557b002397ec8f22a3",
}
TERMINAL_FIELDS=("preparation_completion_ref","preparation_actual_wait_ref",
 "cut_preparation_completion_ref","cut_preparation_actual_wait_ref","cut_preparation_admission_ref",
 "cut_preparation_input_ref","cut_preparation_config_ref","cut_preparation_runtime_ref","cut_preparation_launch_ref")
PREPARATION_SOURCE_FIELDS=("cut_preparation_producer_ref","cut_preparation_codec_ref","cut_preparation_source_manifest_ref")
INDIRECT_JSON_FIELDS=("count_manifest_ref","cut_preparation_source_manifest_ref","metrics_source_config_ref")
BUDGET_PATHS=("scripts/project_budget_v9.py","scripts/launch_reserved_gpu_v6.py",
 "src/arggnn/project_storage_cpu_closed_scopes_v1.py","src/arggnn/project_storage_terminal_scopes_v1.py",
 "src/arggnn/project_storage_terminal_success_scopes_v1.py","src/arggnn/project_storage_terminal_retired_scopes_v1.py",
 "research/reviews/concurrent_completed_scope_credits_v3/completed_scope_credits_v3.py",
 "research/reviews/completed_scope_credits_root_activation_20261015_v1/activation_policy.json")

def require(ok,message):
    if not ok:raise ValueError(message)

def path(name):
    require(isinstance(name,str) and not Path(name).is_absolute() and ".." not in Path(name).parts,"Contained relative metadata path")
    p=ROOT/name
    require(p.resolve()==p and p.is_relative_to(ROOT) and not p.is_symlink(),"Canonical non-symlink metadata")
    return p

def ref(name):
    p=path(name);require(p.is_file(),"Existing source/metadata")
    return dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def is_ref(value):
    return isinstance(value,dict) and set(value)=={"path","sha256"} and isinstance(value["path"],str) and isinstance(value["sha256"],str) and len(value["sha256"])==64 and all(c in "0123456789abcdef" for c in value["sha256"])

def read(record):
    require(is_ref(record) and Path(record["path"]).suffix in (".json",".py",".sh"),"Metadata/source only; no scientific payload read")
    require(ref(record["path"])==record,"Exact pinned metadata/source")
    data=path(record["path"]).read_bytes();require(len(data)<=32*1024**2,"Bounded metadata")
    return json.loads(data)

def save(folder,name,value):
    p=path(folder+"/"+name);require(not p.exists(),"Fresh immutable metadata file")
    p.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n");return ref(folder+"/"+name)

def unique(rows):
    out=[]
    for row in rows:
        if row not in out:out.append(row)
    return out

def exact(name):
    require(PINS.get(name)==ref(name)["sha256"],"Frozen source/config unchanged:"+name)
    return path(name).read_text()

def load(name,label):
    if name in PINS:exact(name)
    sp=importlib.util.spec_from_file_location(label,path(name));m=importlib.util.module_from_spec(sp)
    sys.modules[label]=m;sp.loader.exec_module(m);return m

def terminal():
    return load(TERMINAL,"_H050_GPU0_shared_eval_terminal_v1")

def resource_caps_v1():
    tree=ast.parse(exact(PRODUCER))
    n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="RESOURCE_CAPS" for t in n.targets))
    return tuple(ast.literal_eval(n.value))

def validate_inherited_config_v1(cfg,reader=None):
    old=json.loads(exact(TRAIN_CONFIG));caps=resource_caps_v1()
    require({k:v for k,v in cfg.items() if k not in caps}=={k:v for k,v in old.items() if k not in caps},
        "Every non-resource TRAIN config field, source manifest, warm proxy and historical provenance unchanged")
    require(cfg["output_cap_bytes"]==EVAL_CAP_BYTES and all(cfg[k]==old[k] for k in caps if k!="output_cap_bytes"),
        "Only output_cap_bytes changes to root-selected105MiB; all other original caps unchanged")
    return cfg

def inherited_sources_v1(reader,cfg):
    if cfg!=json.loads(exact(TRAIN_CONFIG)):validate_inherited_config_v1(cfg)
    manifest=reader.decode_json(cfg["source_manifest_ref"])
    require(manifest.get("schema")=="H050_root_bridge_exact_source_manifest_v1" and manifest.get("hypothesis_id")=="H050","Original inherited scientific source manifest")
    for name,sha in manifest["source_sha256"].items():
        require(ref(name)==dict(path=name,sha256=sha),"Every inherited scientific source unchanged")
    return manifest["source_sha256"]

def _validate_shared_train_v1(reader,spec,cfg):
    exact(TRAIN_INPUT)
    proof=terminal().validate_certificate(spec["train_actual_wait_ref"],reader)
    cert,old,train=proof["certificate"],proof["input"],proof["completion"]
    require(cert["phase"]=="train" and spec["train_completion_ref"]==cert["completed_ref"]
        and spec["train_launch_ref"]==cert["capability_ref"] and train["input_ref"]==cert["input_ref"]
        and cert["input_ref"]==ref(TRAIN_INPUT)
        and old.get("schema")=="H050_direct_readout_root_input_v1" and old.get("hypothesis_id")=="H050"
        and old.get("arm")=="joint_four_arm" and old.get("phase")=="train"
        and old.get("physical_gpu")==0 and old.get("root_context_module_ref")==ref(OLD_CONTEXT)
        and old.get("operational_pool_source_ref")==terminal().TRAIN_POOL_REF
        and old["refs"]["config"]==train["config_ref"]==ref(TRAIN_CONFIG),
        "Actual original GPU0 full TRAIN, shared capability and honest wait0/owned-drain certificate")
    validate_inherited_config_v1(cfg)
    return dict(output_directory=old["output_directory"],input_ref=train["input_ref"],physical_gpu=0)

def lineage_source_v1():
    src=exact(COMMON);node=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=="validate_train_lineage_v1")
    fn=ast.get_source_segment(src,node)
    def statement(label):
        rows=[n for n in node.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=="require" and label in ast.get_source_segment(src,n)]
        require(len(rows)==1,"Exact original operational lineage block");return ast.get_source_segment(src,rows[0])
    changes=[
     (statement("Genuine same-identity original supervisor"),'shared=_validate_shared_train_v1(reader,spec,cfg)'),
     ('packet=HERE+"/admitted_train/"','packet=None  # No exclusive receipt/namespace is relabelled'),
     (statement("Only fresh H050 bridge TRAIN admission"),'require(train["input_ref"]==shared["input_ref"],"Exact genuine shared TRAIN input")'),
     ('old["output_directory"]=="experiments/results/H050_GPU%d_direct_readout_cut_memory_train_seed101_v1"%launch["physical_gpu"]','old["output_directory"]==shared["output_directory"]')]
    for before,after in changes:
        require(fn.count(before)==1,"Single exact operational lineage substitution");fn=fn.replace(before,after)
    return fn

def metadata_namespace_v1(cfg):
    original=json.loads(exact(TRAIN_CONFIG));p=original["scientific_protocol"]
    worker=SimpleNamespace(SOURCE=PRODUCER,ARMS=tuple(p["arms"]),TRAIN=tuple(p["TRAIN_parent_ids"]),
        PASSES=tuple(p["checkpoint_passes"]),VAL=tuple(p["VAL_parent_ids"]),RESOURCE_CAPS=resource_caps_v1(),
        model=SimpleNamespace(PARAMETERS=p["parameters_per_arm"]),hooks=SimpleNamespace(fixed_protocol_v1=lambda:p))
    ns=dict(ROOT=ROOT,HERE=str(Path(COMMON).parent),DRIVER=str(Path(COMMON).parent/"root_driver_v1.py"),
        CONTEXT=OLD_CONTEXT,require=require,ref=ref,unique=unique,worker=worker,
        TERMINAL_FIELDS=TERMINAL_FIELDS,TRAIN_FIELDS=("train_completion_ref","train_launch_ref","train_actual_wait_ref"),
        is_ref_v1=is_ref,validate_config_v1=lambda value,reader:require(value==json.loads(exact(TRAIN_CONFIG)),"Exact actual TRAIN config bytes"),exact_sources_v1=inherited_sources_v1,
        _validate_shared_train_v1=_validate_shared_train_v1,
        framework=SimpleNamespace(declared_cut_preparation_source_refs_v2=lambda c:dict(cut_preparation_producer_ref=c["preparation_producer_ref"],cut_preparation_codec_ref=c["cut_preparation_codec_ref"],cut_preparation_source_manifest_ref=c["cut_preparation_source_manifest_ref"])))
    constants={
     "H045_CONFIG_REF":"research/reviews/H045_GPU45_episode_root_source_v1/config.json",
     "GUARD_REF":"research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py",
     "POLICY_REF":"research/reviews/prospective_980GB_capacity_source_v1/activation_policy.root_active_v1.json",
     "LAUNCHER_REF":"scripts/launch_reserved_gpu_authorized_GPU45_980_v1.py",
     "REPAIR_REF":"research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json",
     "AUTH_REF":"research/reviews/H040_GPU45_migration_root_20261015_v1/GPU45_authorization.json",
     "MEMO_REF":"research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py",
     "V4_REF":"src/arggnn/project_budget_v4.py"}
    ns.update({k:ref(v) for k,v in constants.items()})
    return ns

class MetadataReaderV1:
    root=ROOT
    @staticmethod
    def decode_json(record):return read(record)

def metadata_train_lineage_v1(spec,cfg):
    ns=metadata_namespace_v1(cfg)
    exec(compile(lineage_source_v1(),"<original_H050_full_scientific_lineage_shared_operational_blocks>","exec"),ns)
    return ns["validate_train_lineage_v1"](MetadataReaderV1(),spec,cfg)

def declared_runtime_refs_v1(spec):
    rows=spec.get("operational_eval_source_refs")
    require(isinstance(rows,dict) and {"runtime","terminal","guard","pool","launcher","bootstrap"}<=set(rows)
        and all(isinstance(k,str) and is_ref(r) and Path(r["path"]).suffix in (".py",".sh",".json") and ref(r["path"])==r for k,r in rows.items()),
        "Explicit exact root-declared finite EVAL execution sources")
    require(rows["runtime"]==spec.get("operational_eval_runtime_ref")==spec.get("operational_eval_context_override_ref")==ref(SOURCE)
        and rows["terminal"]==ref(TERMINAL) and rows["guard"]==ref(GUARD)
        and spec.get("operational_GPU0_runtime_ref")==ref(SOURCE)
        and spec.get("operational_GPU0_guard_ref")==ref(GUARD)
        and spec.get("operational_pool_source_ref")==rows["pool"] and spec.get("operational_launcher_ref")==rows["launcher"],
        "Actual EVAL runtime/context/controller/guard declared outside immutable TRAIN config")
    return unique(list(rows.values()))

def expected_operational_closure_v1(spec,cfg):
    train=read(spec["train_completion_ref"]);old=read(train["input_ref"])
    return dict(schema="H050_GPU0_shared_EVAL_operational_closure_v1",hypothesis_id="H050",phase="evaluate",
        root_authorizer="root_agent",root_binding_request_ref=spec["operational_eval_root_request_ref"],
        operational_eval_source_refs=spec["operational_eval_source_refs"],
        runtime_adapter_ref=ref(SOURCE),context_override_ref=ref(SOURCE),terminal_validator_ref=ref(TERMINAL),
        inherited_train_input_ref=train["input_ref"],train_completion_ref=spec["train_completion_ref"],
        train_capability_ref=spec["train_launch_ref"],train_shared_terminal_certificate_ref=spec["train_actual_wait_ref"],
        train_config_ref=train["config_ref"],train_runtime_ref=old["refs"]["runtime"],train_io_lineage=spec["train_io_lineage"],
        inherited_source_manifest_ref=cfg["source_manifest_ref"],inherited_root_context_module_ref=cfg["root_context_module_ref"],
        exact_read_only_metadata_refs={k:cfg[k] for k in INDIRECT_JSON_FIELDS},
        output_cap_bytes=EVAL_CAP_BYTES,all_nonresource_train_config_fields_unchanged=True,
        no_exclusive_wait_receipt_emitted=True,checkpoint_payload_verification_by_original_producer=True)

def validate_operational_closure_v1(spec,cfg):
    validate_inherited_config_v1(cfg);declared_runtime_refs_v1(spec)
    require(read(spec["operational_eval_closure_ref"])==expected_operational_closure_v1(spec,cfg),"Exact directly bound EVAL operational and transitive TRAIN metadata closure")
    require(spec["train_io_lineage"]==metadata_train_lineage_v1(spec,cfg),"Original full TRAIN scientific qualification before EVALUATE")
    return spec

def required_bindings_v1(cfg,spec):
    ns=metadata_namespace_v1(cfg);src=exact(COMMON)
    n=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=="direct_required_refs_v1")
    exec(compile(ast.Module(body=[n],type_ignores=[]),"<unchanged_original_H050_direct_refs>","exec"),ns)
    base=ns["direct_required_refs_v1"](cfg,dict(spec,phase="train"))
    indirect=[cfg[k] for k in INDIRECT_JSON_FIELDS]
    require(all(r in base and Path(r["path"]).suffix==".json" for r in indirect),"Only three explicit original read-only JSON refs are transitive")
    base=[r for r in base if r not in indirect]
    proxy=load(METADATA,"_H050_original_warm_proxy_for_shared_EVAL")
    rows=proxy.source_metadata_refs_v1(base,cfg)
    rows=unique(rows+[spec["operational_eval_closure_ref"],ref(CANONICAL),ref(OLD_RUNTIME)]+declared_runtime_refs_v1(spec)+[ref(p) for p in BUDGET_PATHS])
    require(len(rows)<=64 and all(Path(r["path"]).suffix in (".py",".sh",".json") for r in rows),"Unchanged64 source/metadata binding ceiling; warm payload remains original JSON proxy")
    return rows

def private_h050_common_v1():
    old=load(OLD_RUNTIME,"_H050_unchanged_GPU0_metadata_base_for_shared_EVAL")
    c=old.private_h050_common_v1()
    ns=dict(c.__dict__);ns["_validate_shared_train_v1"]=_validate_shared_train_v1
    exec(compile(lineage_source_v1(),"<original_H050_shared_lineage_operational_only>","exec"),ns)
    c.validate_train_lineage_v1=ns["validate_train_lineage_v1"]
    original=c.validate_spec_v1
    def validate(reader,spec,cfg,storage=None):
        require(spec.get("phase")=="evaluate","This source admits only EVALUATE")
        validate_operational_closure_v1(spec,cfg)
        result=original(reader,spec,cfg,storage)
        if storage is not None:
            require(storage["reserved_new_bytes"]==EVAL_CAP_BYTES and all(r in storage["reservation"]["consumer_bindings"] for r in required_bindings_v1(cfg,spec)),
                "Actual105MiB original storage reservation and exact reviewed EVAL bindings")
        return result
    original.__globals__["validate_train_lineage_v1"]=c.validate_train_lineage_v1
    original.__globals__["direct_required_refs_v1"]=required_bindings_v1
    c.validate_spec_v1=validate;c.direct_required_refs_v1=required_bindings_v1
    return c

def build_context_v1(record,spec):
    """Explicit actual override; inherited cfg context remains immutable provenance."""
    c=private_h050_common_v1()
    original=load(CONTEXT,"_H050_original_context_body_for_GPU0_shared_EVAL")
    src=exact(CONTEXT);n=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=="build_context_v1")
    body=ast.get_source_segment(src,n);before='spec["physical_gpu"] in (4,5)'
    require(body.count(before)==1,"Only original context physical-GPU eligibility substitution")
    body=body.replace(before,'spec["physical_gpu"]==0')
    ns=dict(original.__dict__)
    for k in ("ROOT","HERE","CONTEXT","require","ref","cap_v1","worker","framework","load_guard_v1","POLICY_REF","LAUNCHER_REF","validate_spec_v1","count_plan_v1","validate_plan_caps_v1","authenticate_actual_cut_preparation_v1"):
        ns[k]=getattr(c,k)
    exec(compile(body,"<original_H050_context_GPU0_eligibility_and_private_operational_namespace>","exec"),ns)
    return ns["build_context_v1"](record,spec)

def invoke_job_v1(j):
    """Finite facade entry. No source override may select a scientific callable."""
    require(j.get("runtime_entry_ref")==ref(SOURCE) and j.get("module_ref")==ref(CANONICAL) and j.get("worker_kind")=="H050"
        and j.get("args")==["--execute","--input",j["input_ref"]["path"],"--expected-input-sha256",j["input_ref"]["sha256"]],"Exact finite H050 EVAL entry/arguments")
    spec=read(j["input_ref"]);cfg=read(spec["refs"]["config"]);storage=read(spec["refs"]["storage"])
    require(spec.get("phase")=="evaluate" and spec.get("hypothesis_id")=="H050"
        and spec.get("physical_gpu")==0 and spec.get("device")=="cuda" and spec.get("root_authorizer")=="root_agent"
        and spec.get("status")=="active" and spec["job_id"]==j["job_id"]
        and spec["refs"]["storage"]==j["storage_ref"] and spec["max_cuda_reserved_bytes"]==j["cuda_cap_bytes"]
        and spec["max_cpu_rss_bytes"]==j["cpu_rss_cap_bytes"],"Exact declared EVAL job/storage/unchanged full caps")
    validate_operational_closure_v1(spec,cfg)
    require(storage.get("reserved_new_bytes")==EVAL_CAP_BYTES
        and all(r in storage["reservation"]["consumer_bindings"] for r in required_bindings_v1(cfg,spec)),
        "Original durable charge covers the complete105MiB EVAL scope and declared sources")
    g=load(GUARD,"_H050_original_GPU0_guard_for_shared_EVAL");g.install_before_torch_v1()
    require(g.validate_lease()["physical_gpu"]==0,"Actual canonical GPU0 lease");g.apply_and_validate_title()
    source=exact(PRODUCER);require(source.count("in (4,5)")==2,"Exactly two original producer physical-GPU eligibility checks")
    source=source.replace("in (4,5)","in (0,)")
    name="research.reviews.H050_direct_readout_cut_memory_source_20261015_v1.producer_integration_v1._gpu0_shared_evaluate_private"
    m=types.ModuleType(name);m.__file__=str(path(PRODUCER));m.__package__=name.rsplit(".",1)[0]
    sys.modules[name]=m;exec(compile(source,"<original_H050_producer_GPU0_eligibility_only>","exec"),m.__dict__)
    original_util=importlib.util
    class OverrideLoader:
        def __init__(self,wrapped):self.wrapped=wrapped
        def create_module(self,s):return self.wrapped.create_module(s) if hasattr(self.wrapped,"create_module") else None
        def exec_module(self,module):module.build_context_v1=build_context_v1
    def context_spec(label,p,*args,**kwargs):
        require(Path(p)==path(OLD_CONTEXT) and spec["root_context_module_ref"]==ref(OLD_CONTEXT),"Only declared inherited context gets the explicit bound EVAL override")
        sp=original_util.spec_from_file_location(label,p,*args,**kwargs);sp.loader=OverrideLoader(sp.loader);return sp
    m.importlib=SimpleNamespace(util=SimpleNamespace(spec_from_file_location=context_spec,module_from_spec=original_util.module_from_spec))
    return m.main(j["args"])

def pure_count_plan_v1(cfg):
    """Exact original standard-library count plan, never reads an observation."""
    ns=metadata_namespace_v1(cfg);bounds_name="research/reviews/order2_cut_memory_implementation_20261015_v1/integration_hooks_v1.py"
    bounds_src=path(bounds_name).read_text()
    b=next(n for n in ast.parse(bounds_src).body if isinstance(n,ast.FunctionDef) and n.name=="bounds_from_counts_v1")
    bns=dict(require=require,_require=require);exec(compile(ast.Module(body=[b],type_ignores=[]),"<original_pure_count_bounds>","exec"),bns)
    ns["cut_hooks"]=SimpleNamespace(bounds_from_counts_v1=bns["bounds_from_counts_v1"])
    src=exact(COMMON)
    for name in ("count_plan_v1","validate_plan_caps_v1"):
        n=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name==name)
        exec(compile(ast.Module(body=[n],type_ignores=[]),"<original_pure_H050_count_plan>","exec"),ns)
    plan=ns["count_plan_v1"](read(cfg["count_manifest_ref"]),"evaluate",read(cfg["preparation_completion_ref"]),cfg)
    ns["validate_plan_caps_v1"](plan,cfg,EVAL_CAP_BYTES);return plan

def prepare_evaluate_metadata_v1(request_ref,folder):
    """Future root-only metadata assembly after genuine completed TRAIN proof.
    Does not admit, reserve, create outputs, call any guard, run or wait.
    """
    req=read(request_ref)
    require(req.get("schema")=="H050_GPU0_shared_EVAL_metadata_binding_request_v1"
        and req.get("root_authorizer")=="root_agent" and req.get("status")=="active"
        and req.get("output_cap_bytes")==EVAL_CAP_BYTES,"Explicit active root105MiB EVAL metadata request")
    cert_ref=req["train_shared_terminal_certificate_ref"];proof=terminal().validate_certificate(cert_ref)
    require(proof["certificate"]["input_ref"]==ref(TRAIN_INPUT),"Only actual fixed GPU0 full TRAIN")
    old=proof["input"];cfg=copy.deepcopy(read(old["refs"]["config"]));cfg["output_cap_bytes"]=EVAL_CAP_BYTES
    validate_inherited_config_v1(cfg)
    created=datetime.datetime.fromisoformat(req["created_at_utc"]);expires=datetime.datetime.fromisoformat(req["expires_at_utc"])
    require(created.tzinfo is not None and expires.tzinfo is not None and 0<(expires-created).total_seconds()<=86400,"Original at-most24h EVAL input lifetime")
    require(isinstance(req.get("job_id"),str) and req["job_id"]!=old["job_id"]
        and req["output_directory"].startswith("experiments/results/H050_GPU0_")
        and req["output_directory"]!=old["output_directory"] and not path(req["output_directory"]).exists(),"Fresh EVAL job/output identity")
    target=path(folder);require(not target.exists() and target.parent.is_dir(),"Fresh root metadata directory")
    controller=req["controller_source_refs"]
    require(isinstance(controller,dict) and {"pool","launcher","bootstrap"}<=set(controller)
        and not ({"runtime","terminal","guard"}&set(controller)),"Explicit finite future-controller role refs")
    rows=dict(controller,runtime=ref(SOURCE),terminal=ref(TERMINAL),guard=ref(GUARD))
    spec=copy.deepcopy(old)
    spec.update(phase="evaluate",job_id=req["job_id"],output_directory=req["output_directory"],
        created_at_utc=req["created_at_utc"],expires_at_utc=req["expires_at_utc"],worker_auxiliary_scope=folder+"/worker_aux",
        train_completion_ref=proof["certificate"]["completed_ref"],train_launch_ref=proof["certificate"]["capability_ref"],
        train_actual_wait_ref=cert_ref,operational_eval_runtime_ref=ref(SOURCE),operational_eval_context_override_ref=ref(SOURCE),
        operational_eval_root_request_ref=request_ref,operational_eval_source_refs=rows,
        operational_GPU0_runtime_ref=ref(SOURCE),operational_pool_source_ref=controller["pool"],
        operational_launcher_ref=controller["launcher"],operational_root_entry_ref=ref(SOURCE),
        operational_launch_mode="GPU0_fresh_finite_declared_pool_shared_EVALUATE_v1")
    spec["refs"].pop("storage",None)
    spec["train_io_lineage"]=metadata_train_lineage_v1(spec,cfg)
    declared_runtime_refs_v1(spec)
    plan=pure_count_plan_v1(cfg)
    original=read(cfg["original_H038_input_ref"]);targets=read(original["refs"]["target_bindings"])
    val=cfg["scientific_protocol"]["VAL_parent_ids"]
    phase_targets=dict(schema="H050_original_phase_target_bindings_v1",phase="evaluate",outer_included=False,
        TRAIN_included=False,VAL_included=True,parents={p:targets["parents"][p] for p in val})
    runtime=copy.deepcopy(read(old["refs"]["runtime"]));runtime.update(job_id=spec["job_id"],output_directory=spec["output_directory"],
        created_at_utc=spec["created_at_utc"],expires_at_utc=spec["expires_at_utc"])
    target.mkdir()
    spec["refs"].update(config=save(folder,"config.json",cfg),runtime=save(folder,"runtime.json",runtime),
        target_bindings=save(folder,"phase_target_bindings.json",phase_targets))
    spec["operational_eval_closure_ref"]=save(folder,"operational_eval_closure.json",expected_operational_closure_v1(spec,cfg))
    manifest=copy.deepcopy(read(old["consumer_manifest_ref"]));manifest.update(phase="evaluate",refs=spec["refs"],
        train_io_lineage=spec["train_io_lineage"])
    spec["consumer_manifest_ref"]=save(folder,"consumer_manifest.json",manifest)
    validate_operational_closure_v1(spec,cfg)
    bindings=required_bindings_v1(cfg,spec)
    draft=save(folder,"input_draft_without_storage.json",spec)
    return dict(schema="H050_GPU0_EVAL_metadata_ready_not_admitted_v1",input_draft_ref=draft,
        output_cap_bytes=EVAL_CAP_BYTES,output_plan=plan,consumer_bindings=bindings,
        no_storage_reservation_or_guard_or_execution=True)

def finalize_evaluate_input_v1(draft_ref,storage_ref,folder):
    """Attach an already root-admitted original storage record; never reserves."""
    spec=copy.deepcopy(read(draft_ref));cfg=read(spec["refs"]["config"]);storage=read(storage_ref)
    require("storage" not in spec["refs"] and spec["phase"]=="evaluate","Only fresh prepared EVAL draft")
    validate_operational_closure_v1(spec,cfg);rows=required_bindings_v1(cfg,spec)
    require(storage.get("kind")=="project_budget_v9_storage_record" and storage.get("active") is True
        and storage.get("consumer_uses_v9_guard") is True and storage.get("accounting_mode")=="prospective_980gb_v1"
        and storage.get("expires_at_utc")==spec["expires_at_utc"]
        and storage["reservation"].get("auxiliary_scopes")==[str(ROOT/spec["worker_auxiliary_scope"])]
        and storage.get("job_id")==spec["job_id"]
        and storage.get("output_directory")==spec["output_directory"] and storage.get("reserved_new_bytes")==EVAL_CAP_BYTES
        and storage["reservation"].get("reserved_bytes")==EVAL_CAP_BYTES
        and storage["reservation"].get("output")==str(ROOT/spec["output_directory"])
        and len(storage["reservation"]["consumer_bindings"])<=64
        and all(r in storage["reservation"]["consumer_bindings"] for r in rows),"Actual root storage identity,105MiB charge and all original source bindings")
    spec["refs"]["storage"]=storage_ref
    return save(folder,"input.json",spec)
