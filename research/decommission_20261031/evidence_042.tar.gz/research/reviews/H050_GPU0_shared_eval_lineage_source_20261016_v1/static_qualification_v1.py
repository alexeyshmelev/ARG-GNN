"""Narrow source-only qualification: no guard, GPU, science import or execution."""
from pathlib import Path
import ast,copy,importlib.util,json,sys
HERE="research/reviews/H050_GPU0_shared_eval_lineage_source_20261016_v1"

def load(name,label):
    p=Path(name);s=importlib.util.spec_from_file_location(label,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def run_checks_v1():
    m=load(HERE+"/runtime_metadata_adapter_v1.py","_source_only_eval_adapter")
    t=load(HERE+"/shared_terminal_v1.py","_source_only_terminal")
    cases=[]
    def check(name,ok):
        if not ok:raise ValueError(name)
        cases.append(dict(case=name,passed=True))
    def reject(name,fn):
        try:fn()
        except (ValueError,KeyError,TypeError,AssertionError):cases.append(dict(case=name,passed=True));return
        raise ValueError("Unexpected acceptance:"+name)
    for name in ("runtime_metadata_adapter_v1.py","shared_terminal_v1.py","static_qualification_v1.py"):
        source=Path(HERE+"/"+name).read_text();compile(source,name,"exec");ast.parse(source)
    check("three_sources_parse_and_compile",True)
    producer=m.exact(m.PRODUCER);adapted=producer.replace("in (4,5)","in (0,)")
    check("producer_only_two_GPU_eligibility_boundaries",producer.count("in (4,5)")==2)
    p={n.name:n for n in ast.parse(producer).body if isinstance(n,ast.FunctionDef)}
    a={n.name:n for n in ast.parse(adapted).body if isinstance(n,ast.FunctionDef)}
    for name in ("load_checkpoints","run_evaluate","paired_criteria","load_observations","device_parent"):
        check("original_scientific_AST_unchanged:"+name,ast.dump(p[name],include_attributes=False)==ast.dump(a[name],include_attributes=False))
    evaluation=ast.get_source_segment(producer,p["run_evaluate"])
    check("original192_RAM_barrier_precedes_VAL_truth_gate",
        evaluation.index("ram.verify()")<evaluation.index("reader.truth_gate=True")
        and "dense_prediction_arrays_saved=False" in evaluation)
    source=m.exact(m.CONTEXT);n=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=="build_context_v1")
    context=ast.get_source_segment(source,n)
    check("original_context_only_one_GPU_eligibility_boundary",context.count('spec["physical_gpu"] in (4,5)')==1)
    lineage=m.lineage_source_v1();compile(lineage,"<shared_operational_lineage>","exec")
    original=m.exact(m.COMMON);n=next(n for n in ast.parse(original).body if isinstance(n,ast.FunctionDef) and n.name=="validate_train_lineage_v1")
    original_nodes=n.body
    adapted_nodes=ast.parse(lineage).body[0].body
    changed=[i for i,(left,right) in enumerate(zip(original_nodes,adapted_nodes))
        if ast.dump(left,include_attributes=False)!=ast.dump(right,include_attributes=False)]
    check("lineage_exactly_four_operational_statement_changes",len(original_nodes)==len(adapted_nodes) and changed==[5,6,7,11])
    check("original_scientific_lineage_initial_and_all_history_qualification_checkpoint_checks_preserved",
        ast.dump(original_nodes[4],include_attributes=False)==ast.dump(adapted_nodes[4],include_attributes=False)
        and all(ast.dump(l,include_attributes=False)==ast.dump(r,include_attributes=False) for l,r in zip(original_nodes[12:],adapted_nodes[12:])))
    cfg=json.loads(m.exact(m.TRAIN_CONFIG));old=copy.deepcopy(cfg);cfg["output_cap_bytes"]=m.EVAL_CAP_BYTES
    check("only_output_cap_changes_and105MiB_exact",m.validate_inherited_config_v1(cfg)==cfg and m.EVAL_CAP_BYTES==110100480)
    mutated=copy.deepcopy(cfg);mutated["root_context_module_ref"]=m.ref(m.SOURCE)
    reject("reject_changed_nonresource_context_in_cfg",lambda:m.validate_inherited_config_v1(mutated))
    mutated=copy.deepcopy(cfg);mutated["max_cuda_reserved_bytes"]+=1
    reject("reject_changed_unrelated_original_resource_cap",lambda:m.validate_inherited_config_v1(mutated))
    plan=m.pure_count_plan_v1(cfg)
    check("exact_original_actual_count_plan105MiB_passes",
        plan["total_output_scope_upper_bound_bytes"]==104939520 and plan["all192_native_hold_probability_bytes"]==2046014208
        and plan["checkpoint_files_written"]==0 and plan["VAL_probability_seals_before_truth"]==192)
    under=copy.deepcopy(cfg);under["output_cap_bytes"]=100*1024**2
    reject("reject_actual_count_plan_under100_078125MiB",lambda:m.pure_count_plan_v1(under))
    spec=json.loads(m.exact(m.TRAIN_INPUT))
    spec.update(operational_eval_source_refs=dict(runtime=m.ref(m.SOURCE),terminal=m.ref(m.TERMINAL),guard=m.ref(m.GUARD),
        pool=m.ref(m.GPU0+"/gpu0_shared_pool_v1.py"),launcher=m.ref(m.GPU0+"/launch_gpu0_shared_v1.py"),
        bootstrap=m.ref(m.GPU0+"/gpu0_bootstrap_renewal_v1.py")),
        operational_eval_runtime_ref=m.ref(m.SOURCE),operational_eval_context_override_ref=m.ref(m.SOURCE),
        operational_GPU0_runtime_ref=m.ref(m.SOURCE),
        operational_eval_closure_ref=m.ref(HERE+"/actual_count_only_EVAL_storage_plan_v1.json"))
    rows=m.required_bindings_v1(cfg,spec)
    check("binding_shape_plan57_with3controllerroles_plus2roles59_le64",len(rows)==57 and len(rows)+2<=64)
    check("original_warm_checkpoint_not_direct_bound",old["warmstart_checkpoint_ref"] not in rows and old["scientific_input_closure_ref"] in rows)
    check("all8_original_budget_source_refs_direct_bound",all(m.ref(p) in rows for p in m.BUDGET_PATHS))
    # Full scientific TRAIN validation with synthetic metadata only in memory.
    # The operational certificate is independently exercised below; it is not
    # invented or persisted for this fixture.
    actual_input=json.loads(m.exact(m.TRAIN_INPUT));protocol=old["scientific_protocol"]
    sr=dict(path=actual_input["output_directory"]+"/completed.json",sha256="1"*64)
    cr=dict(path="synthetic_only_in_memory_capability.json",sha256="2"*64)
    wr=dict(path="synthetic_only_in_memory_terminal.json",sha256="3"*64)
    train=dict(schema="H050_four_arm_train_completion_v1",hypothesis_id="H050",
        status="completed_fixed30pass_four_arm_TRAIN",arms=protocol["arms"],
        steps={a:960 for a in protocol["arms"]},VAL_truth_read=False,outer_truth_read=False,
        common_initial_predictor_verified=True,scientific_protocol=protocol,parameters_per_arm=protocol["parameters_per_arm"],
        input_ref=m.ref(m.TRAIN_INPUT),config_ref=actual_input["refs"]["config"],producer_ref=old["producer_ref"])
    for key in ("registration_ref","warmstart_checkpoint_ref","warmstart_completion_ref","cut_preparation_completion_ref","cut_preparation_actual_wait_ref"):
        train[key]=old[key]
    train["history"]=[dict(pass_index=i,steps={a:32*i for a in protocol["arms"]},full_parent_updates_per_arm=32,
        parent_order=protocol["TRAIN_parent_ids"]) for i in range(1,31)]
    train["first_step_qualification"]={a:dict(finite_FP32=True,part_of_continuous_960_updates=True,parent_id=protocol["TRAIN_parent_ids"][0],
        full_model_qualification=dict(parameters=protocol["parameters_per_arm"][a],actual_optimizer_step=1,no_extra_updates=True,
        warmstart_checkpoint_ref=old["warmstart_checkpoint_ref"],gradient_checks={"body.weight":dict(dtype="torch.float32",finite=True)},
        updated_parameters={"body.weight":True})) for a in protocol["arms"]}
    train["checkpoint_groups"]={str(at):{a:dict(path=actual_input["output_directory"]+"/"+a+".pass_%02d.pt"%at,sha256="4"*64)
        for a in protocol["arms"]} for at in protocol["checkpoint_passes"]}
    line_spec=dict(phase="evaluate",train_completion_ref=sr,train_launch_ref=cr,train_actual_wait_ref=wr)
    class FixtureReader:
        def __init__(self,value):self.value=value
        def decode_json(self,record):
            if record==sr:return self.value
            if record==cr:return dict(physical_gpu=0)
            if record==wr:return dict(synthetic_only_in_memory=True)
            return m.read(record)
    ns=m.metadata_namespace_v1(cfg)
    ns["_validate_shared_train_v1"]=lambda reader,spec,c:dict(input_ref=m.ref(m.TRAIN_INPUT),output_directory=actual_input["output_directory"])
    exec(compile(m.lineage_source_v1(),"<in_memory_scientific_fixture_only>","exec"),ns)
    check("original_full_TRAIN_science_checks_accept_complete_in_memory_fixture",
        len(ns["validate_train_lineage_v1"](FixtureReader(train),line_spec,cfg)["train_checkpoint_groups"])==6)
    for key,value in (("history",train["history"][:-1]),("VAL_truth_read",True),
        ("steps",{a:959 for a in protocol["arms"]}),("checkpoint_groups",{}),("first_step_qualification",{})):
        bad=copy.deepcopy(train);bad[key]=value
        reject("original_scientific_lineage_rejects_synthetic:"+key,
            lambda bad=bad:ns["validate_train_lineage_v1"](FixtureReader(bad),line_spec,cfg))

    r=dict(path="synthetic_only_in_memory.json",sha256="0"*64)
    name="synthetic_in_memory_H050_TRAIN"
    req=dict(job_id=name,input_ref=r,storage_ref=r,cuda_cap_bytes=10,cpu_rss_cap_bytes=20,
        args=["--execute","--input",r["path"],"--expected-input-sha256",r["sha256"]])
    ids=[dict(pid=1001,uid=1000,start_ticks=2001),dict(pid=1002,uid=1000,start_ticks=2002)]
    job=dict(logical_job=name,state="succeeded",exit_code=0,leader_wait_status_known=True,owned_drain_observed=True,
        pid=1001,leader_start_ticks=2001,process_identities=ids,
        descendant_waits=[dict(pid=1002,start_ticks=2002,wait_status_known=True,returncode=0,raw_wait_status=0)],
        started_unix=1.,started_monotonic=1.,finished_unix=2.,requested=req)
    cert=dict(schema=t.CERT_SCHEMA,status="completed_shared_job_wait0_owned_drain",root_authorizer="root_agent",
        actual_execution=True,exclusive_wait_relabelled=False,logical_job=name,phase="train",output_directory="synthetic/only",
        scientific_marker_unchanged=True,pool_source_ref=t.TRAIN_POOL_REF,
        **{k:copy.deepcopy(r) for k in ("capability_ref","registry_snapshot_ref","client_tool_terminal_ref","input_ref","terminal_validator_ref")})
    cert["completed_ref"]=dict(path="synthetic/only/completed.json",sha256="0"*64)
    cap=dict(schema="GPU0_shared_logical_pool_capability_v1",root_authorizer="root_agent",logical_job_sharing_authorized=True,
        physical_gpu=0,gpu_uuid="GPU-ff06ca1f-403a-f2d0-b584-71e177452667",pool="synthetic_in_memory",
        source_refs=dict(pool=t.TRAIN_POOL_REF),jobs={name:req})
    registry=dict(schema=t.REG_SCHEMA,capability_ref=r,pool=cap["pool"],physical_gpu=0,pool_job="gpu0_shared_v1:"+cap["pool"]+":gpu0",
        safety_error=None,controller=dict(pid=900,uid=1000,start_ticks=1900),jobs=[job],updated_unix=3.)
    input0=dict(job_id=name,physical_gpu=0,phase="train",refs=dict(storage=r),max_cuda_reserved_bytes=10,max_cpu_rss_bytes=20,output_directory="synthetic/only")
    done=dict(input_ref=r)
    tool=dict(schema=t.TOOL_SCHEMA,root_authorizer="root_agent",observation_source="actual_root_exec_or_write_stdin_terminal",
        actual_terminal_consumed=True,command="wait",capability_ref=r,logical_job=name,tool_exit_code=0,
        tool_session_id="synthetic-in-memory-only",terminal_chunk_id="synthetic-in-memory-only",terminal_job=job)
    values=[cert,registry,cap,input0,done,tool]
    check("in_memory_only_terminal_positive_control",bool(t.validate_records(*values)))
    def mutate(index,key,value):
        v=copy.deepcopy(values)
        if index==1 and key.startswith("job."):v[1]["jobs"][0][key[4:]]=value;v[5]["terminal_job"]=copy.deepcopy(v[1]["jobs"][0])
        else:v[index][key]=value
        return lambda:t.validate_records(*v)
    for key,value in (
        ("leader_wait_status_known",False),("exit_code",1),("owned_drain_observed",False),
        ("resource_abort",True),("cancel_requested",True),("owned_termination",True),("error","synthetic"),
        ("leader_start_ticks",999),("process_identities",[]),("finished_unix",float("nan")),
        ("descendant_waits",[dict(pid=1002,start_ticks=2002,wait_status_known=True,returncode=1,raw_wait_status=256)]),
        ("descendant_waits",[dict(pid=1002,start_ticks=2002,wait_status_known=False,returncode=0,raw_wait_status=0)])):
        reject("reject_synthetic_bad_terminal:"+key,mutate(1,"job."+key,value))
    for index,key,value,label in (
        (0,"exclusive_wait_relabelled",True,"exclusive_receipt_relabel"),
        (2,"gpu_uuid","synthetic-wrong-uuid","wrong_GPU_UUID"),(2,"physical_gpu",4,"wrong_physical_GPU"),
        (1,"ambiguous_descendants_or_lease_holders",True,"ambiguous_owned_scope"),
        (5,"actual_terminal_consumed",False,"unconsumed_root_tool"),
        (5,"tool_exit_code",1,"nonzero_root_tool")):
        reject("reject_synthetic_bad_terminal:"+label,mutate(index,key,value))
    check("no_Torch_PyG_or_canonical_guard_imported",not any(k in sys.modules for k in ("torch","torch_geometric","arggnn.native_argformer_exec")))
    return dict(schema="H050_GPU0_shared_EVAL_source_only_qualification_v1",status="PASS",cases=cases,
        case_count=len(cases),actual_count_plan_minimum_bytes=104939520,EVAL_cap_bytes=m.EVAL_CAP_BYTES,
        source_only_binding_shape_plan=dict(three_controller_roles=57,five_controller_roles_upper=59,limit=64),
        original_scientific_code_unchanged=True,actual_execution=False,
        synthetic_records_only_in_memory=True,no_training_completion_or_checkpoint_payload_read=True,
        no_guard_admission_GPU_job_or_Git_calls=True)
if __name__=="__main__":print(json.dumps(run_checks_v1(),indent=2,sort_keys=True))
