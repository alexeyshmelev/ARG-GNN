# Current980 native six-dataset counts: root handoff

Source-ready for root activation/admission/CPU launch. No MLM success, model checkpoint or native GPU qualification is required. No command below was run by this task. Actual future counts, admission/storage, PID and wait refs remain null.

The exact scientific producer is unchanged: src/arggnn/american_c3_native_concat_v1.py::count_preparation_v1, invoked by its existing canonical CPU CLI and validated by the existing american_c3_native_contract_v1. It reads all six original raw path datasets and full-ID sidecars, validates original reference labels and the entire10000-query focal join, and reports true split rows plus native release update budgets. No corpus sampling, decoding replacement or metadata-estimated contrastive count is substituted.

## Exact root commands

From the repository root, source scripts/project_env.sh and run ROOT_COMMANDS.sh with bash. It performs three explicit steps, each also usable separately:

~~~bash
"$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --activate
"$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --admit
setsid --wait "$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --launch counts
~~~

--activate creates fresh root_active caps/request metadata from the inactive templates and validates the existing closed preparation; it neither reserves nor launches. --admit uses the actual current980 journal/prefix through the existing guard; it refuses reused keys/scopes. --launch starts the unchanged CPU producer in a dedicated session, explicitly hides CUDA, binds a fresh repository TMP scope, monitors its actual owned RSS/deadline, buffers bounded logs in RAM, records genuine direct wait before postprocessing, and requires complete owned group drain before final boundary/log receipts.

Every executable source is hashed in source_inventory.json. source_successor.diff compares this narrow successor with the old generic root contract/driver/context. Do not call the old generic root --admit: it pins revoked v3 admissions and a v2 corpus. This successor never edits those frozen files or old journals.

After success, root consumes the real supervisor wait and uses admitted_counts980_v1/actual_wait.json plus the genuine completed_ref. Optional close is already wired to the current980 guard and requires root's actual terminal/writer-revocation certificate; no future approval or PID roster is prefilled:

~~~bash
"$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --close counts --root-approval ACTUAL_ROOT_APPROVAL_PATH --expected-root-approval-sha256 ACTUAL_ROOT_APPROVAL_SHA256
~~~

The close placeholders are intentionally unresolved. The three counts commands above need no unknown MLM/count result. Admission capacity and runtime/source checks still execute genuinely at root run time; source readiness is not an assertion that those checks have already passed.

## Actual prerequisites already bound

actual_prerequisite_metadata.json contains exact path/SHA refs verified from bounded existing JSON only:
- Actual v3 preparation completed.json: 3cc49fbf55bd4b4b3859a93ce1123e9218f407f7c7299ad5029be81f59c7c6fa.
- Original v3 preparation config: 9dfd5eb24274933816e9b5af122c1279aa132bc37afa2e7e3563aea04201e01c.
- Actual preparation direct wait0/drain: d4f8fd549a8b3610d21b9cebbf4e7690fd52dc95d24e11253aea29860520b336.
- Permanently closed READONLY preparation receipt: 46d972e3ea36a41a147b81fa310b739b487efc1d2808d72594a89ec0f854b533.
- Existing shared CPU runtime metadata: e0944a1c2c4b2a26d2edfe68fad11db691b4b6853ebeddd8e3b79692b43fa602.

The counts CPU-runtime binding honestly states that it points to existing metadata, with exact runtime comparison at execution. It does not invent a fresh runtime qualification. CUDA_VISIBLE_DEVICES is empty and no native interpreter/model/GPU lease is requested.

Preparation remains american_c3_train_000 engineering TRAIN, full30Mb,25,574,587 unique paths,106,769 observed vocabulary nodes,9,583,977 reference paths across splits, max raw path29 and10000 frozen query focals. Exact contrastive/train and val rows remain unknown until the genuine scientific counts stage runs. No truth input is accepted.

## Narrow current-policy changes and operational caps

The successor uses the exact active prospective980 guard/policy, original budget core/launcher pins, marker/repair authority, capacity-v1/v2 lineage, original mutex and root consumer memo2. CPU-only context reuses the original primitive JSON writer and original boundary APIs. Live storage checks/scope writes are absent from the per-path fast guard; it checks only own peak RSS, deadline and capability expiry.

Root admission/launch/close logic is reused from the existing generic driver. Source changes restrict phase to counts, choose fresh current980 key/output/TMP/packet, bind actual v3 closed inputs, use current policy, and use the existing pidfd identity helper for positive cleanup signals. Genuine direct wait is durably attempted before postprocessing; evidence-write failure still permits actual drain. No unrelated-process audit or blanket unreadable-PID exception is added.

Fresh planned charge32MiB covers4MiB producer JSON growth,8MiB auxiliary/log/TMP allowance and4MiB root packet allowance with slack. RAM log cap1MiB. CPU peak RSS cap384GiB and wall deadline21600s are monitored source-planning limits, not observed requirements or fit guarantees. max_preparation_file_bytes is the existing preparation's5,924,203,578-byte serialization bound, checked per input by the unchanged producer; it is not a RAM qualification. Checkpoint/embedding bounds1 are positive unused generic-schema placeholders, because this phase never opens or writes either.

Expected fresh output:
experiments/results/American_C3_native_train000_full30mb_counts980_v1/completed.json

Expected new root packet:
research/reviews/C3_native_counts980_root_handoff_20261015_v1/admitted_counts980_v1/

No result hash or actual admission/launcher/worker PID is guessed.

## Verification and follow-on

Source compilation, configuration-only existing contract validation, exact metadata-ref consistency, and the inert default entrypoint passed. No guard configure/state/admission call, process probe/inspection, scientific payload/model/checkpoint/truth read, counts execution, GPU operation, accounting or Git mutation occurred. source_checks.json records that narrow scope. No fake completion fixture was needed.

The earlier postMLM bridge/RAM adapter remains separately source-ready in C3_native_post_MLM_root_handoff_20261015_v1. Its actual counts dependency can be satisfied by this genuine receipt. Current980 contrastive/RAM executable integration is a follow-on, with genuine MLM weights/waits and native full4096 qualification still unresolved; it is not silently activated by this counts packet.
