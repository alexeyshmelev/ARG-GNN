#!/usr/bin/env bash
# Root alone invokes this reviewed source packet. No phase has been admitted here.
set -euo pipefail
cd /workspace-SR003.nfs2/ARG-GNN
source scripts/project_env.sh
"$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --activate
"$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --admit
setsid --wait "$ARGGNN_PYTHON" -B research/reviews/C3_native_counts980_root_handoff_20261015_v1/root_native_driver_v1.py --launch counts
