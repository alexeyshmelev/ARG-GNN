"""Specific default-inert root contracts; no guard/state/runtime work at import."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,importlib.util,json,os,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
REL="research/reviews/C3_native_VAL000_MLM980_root_source_20261015_v1"
SOURCE=REL+"/root_native_contract_v1.py"
DRIVER=REL+"/root_native_driver_v1.py"
CONTEXT=REL+"/context_factory_v1.py"
RUNTIME_HELPER=REL+"/native_runtime_v1.py"
PARENT='american_c3_val_000'
GPU_PHASES=('mlm',)
CPU_PHASES=()
PHASES=GPU_PHASES
GPU_MAIN=REL+"/entry_mlm980_v1.py"
CPU_MAIN=None
CORE="483d78bf2ef3c917d65ecf1dde5a7809bfadc21194c9f9a90394ce5c532fdd5e"
BASE="a8049bc103afb1cbbbce6f8fc3707a21de9613b23034599641b688994fc5caa3"
GUARD_REF={'path': 'research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py', 'sha256': 'fc71030865e0a3d5da31120d4daa2caa0b2d39ec7dd212b8c46c476b5a866d56'}
POLICY_REF={'path': 'research/reviews/prospective_980GB_capacity_source_v1/activation_policy.root_active_v1.json', 'sha256': 'eb3408004a508136aa434c0a2e02a9d14a5598a96b8483c264c93026f9326018'}
REPAIR_REF=dict(path="research/reviews/H039_missing_marker_repair_v1/repair_authority_20261015.json",sha256="f6f2d628199e8be73db8b5d90d428570d8afdefeab9dc5cd94bb5eafb39247db")
MEMO_REF=dict(path="research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py",sha256="c972e9a779d424ceafdb258848614bf40994d1004e2c73fc5cd225ae99621364")
V4_REF=dict(path="src/arggnn/project_budget_v4.py",sha256="a093c7d86f57fee569cb99f4712250e9505a1119f3950fa44282c7ba8c57df47")
LAUNCHER_REF=dict(path=REL+"/launcher_mlm980_v1.py",sha256=None)
GPU_AUTH_REF=dict(path="research/reviews/H040_GPU45_migration_root_20261015_v1/GPU45_authorization.json",sha256="0231ae8edb05f8dd34ce127a0de0b97c1dd64fa461ad081e7a83bb92c558d26c")
BASE_CONFIG_REF=dict(path="research/reviews/C3_bert_base_configuration_root_v1/config.json",sha256="7160e1553ad2ca51d8c1cb066be533db31826e12d173824c1bb0cb1a4f187d20")
NATIVE_CPU_QUAL_REF=dict(path="research/reviews/C3_bert_base_configuration_root_v1/native_CPU_qualification.json",sha256="56ed247a09484753a64e9ed3bee6c80eea4e5bfb156ab5acdb09c24ce828e515")
NATIVE_INVENTORY_REF=dict(path="experiments/results/native_argformer_tsinfer_fit_v7_root/environment_inventory.json",sha256="077d3e950c3bb3efdecc7292e06c8157506663293b4efe4723ccf7b877973461")
LEGACY_RUNTIME_REF=dict(path="src/arggnn/native_argformer_tsinfer_fit_v7.py",sha256="b94a4e16a6a9dc230256974b9a0e45a6edd1b41b9ecc8ac4171c4461ec514712")
PROC_HELPER="research/reviews/American_C3_native_paths_root_v1/root_native_paths_driver.py"
OBS_REF={'path': 'experiments/results/American_C3_val000_full30mb_shared_v1/inference/observed/manifest.json', 'sha256': '899e00e64880a0f8c8c34897e6c6d5d6e6c8be886557add343d65d0f70c90c44'}
PREP_OUTPUT='experiments/results/American_C3_val000_full30mb_shared_v1/native_paths'
PREP_REF={'path': 'experiments/results/American_C3_val000_full30mb_shared_v1/native_paths/completed.json', 'sha256': '40a3b588d0aa2b474c3f4aab492e34feb0a753a0f8cb73c20d9c0059d8a8c16b'}
PREP_CONFIG_REF={'path': 'research/reviews/prospective_980GB_capacity_source_v1/admitted_native_paths_v1/config.json', 'sha256': 'c7c95390e12daa2216babc8ccf82d04227a2c96f4e9af8a04dfb626443fa3146'}
PREP_CLOSE_REF={'path': 'research/reviews/VAL000_native_paths_completed_close_20261015_v1/closed_VAL000_native_paths_v1/close_receipt.json', 'sha256': '6fbf88b2ddabf0450a24f91b1d6499f11aa9f5a25a77acb86535821bfa28ac94'}
PREP_WAIT_REF={'path': 'research/reviews/prospective_980GB_capacity_source_v1/admitted_native_paths_v1/actual_wait.json', 'sha256': '3b7e0d9a2e0b83c968c8e2340b850d44e27db1783990a07e933cfa09b58975b8'}
COUNTS_REF={'path': 'experiments/results/American_C3_native_val000_full30mb_counts980_namespace_v1/completed.json', 'sha256': '502c111b443c46eea789dc03ee3ff8b6454546ce6e86e3f9fcddba25e82489a7'}
COUNTS_WAIT_REF={'path': 'research/reviews/C3_native_VAL000_counts_namespace_root_20261015_v1/admitted_counts980_v1/actual_wait.json', 'sha256': 'ab2d1f7a7e09756009556ae6f793899c9e4fd5a7cc202e25d877104d3b2f9c91'}
PREP_IO_REF={'path': 'research/reviews/prospective_980GB_capacity_source_v1/root_VAL_cpu_execution_v2.py', 'sha256': '9f684478aca4d7f4867dc58cc3542bb651559e137a168bf35a9f61570ecc5847'}

def require(ok,message):
    if not ok:raise ValueError(message)
def local(value):
    p=Path(value);p=p if p.is_absolute() else ROOT/p
    require(p!=ROOT and p.resolve()==p and ".." not in p.parts and p.is_relative_to(ROOT),"Canonical project path")
    return p
def ref(value):
    p=local(value);h=hashlib.sha256()
    with p.open("rb") as stream:
        for b in iter(lambda:stream.read(8388608),b""):h.update(b)
    return dict(path=str(p.relative_to(ROOT)),sha256=h.hexdigest())
def read(record,cap=1048576):
    require(isinstance(record,dict) and set(record)=={"path","sha256"},"Exact actual path/SHA ref")
    p=local(record["path"]);require(p.stat().st_size<=cap and ref(p)==record,"Bounded exact metadata SHA")
    return json.loads(p.read_text())
def save(directory,name,value):
    p=local(directory/name);raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
    require(len(raw)<=65536,"Root authority/evidence file <=64KiB")
    with p.open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return ref(p)
def load(record,name):
    require(ref(record["path"])==record,"Exact helper source")
    spec=importlib.util.spec_from_file_location(name,local(record["path"]))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def active(spec):
    now=datetime.now(timezone.utc)
    start=datetime.fromisoformat(spec["created_at_utc"]);end=datetime.fromisoformat(spec["expires_at_utc"])
    require(start.tzinfo and end.tzinfo and start<=now<end and (end-start).total_seconds()<=259200,
        "Actual unexpired fresh native capability <=72hours")
def original_guard():
    # Only future root actions call this. Never install memo2 in this process.
    for record in (GUARD_REF,POLICY_REF,REPAIR_REF,V4_REF):require(ref(record["path"])==record,"Fixed current authority source")
    sys.path[:0]=[str(ROOT),str(ROOT/"src"),str(ROOT/"scripts")]
    guard=load(GUARD_REF,"_C3_native_counts_current980")
    guard.configure_v2(REPAIR_REF,policy_ref=POLICY_REF)
    require(all(getattr(guard.budget.v4,n).__module__==guard.budget.v4.__name__
        for n in ("canonical","file_bytes","mutex")),"Root reserve/close must use unwrapped originalv4")
    return guard
def consumer_guard():
    guard=original_guard();memo=load(MEMO_REF,"_C3_native_consumer_memo2")
    adapter=memo.install(guard.budget.v4,expected_source_path=ROOT/V4_REF["path"],
        expected_source_sha256=V4_REF["sha256"])
    return guard,adapter
def phase_paths(phase):
    require(phase=="mlm","Fresh VAL000 native MLM only")
    return ROOT/REL/"admitted_mlm_v1","experiments/results/American_C3_native_val000_full30mb_MLM980_v1"
def validate_upstream(completed_ref,wait_ref,*,preparation=False):
    completed=read(completed_ref);wait=read(wait_ref)
    if preparation:
        require(wait.get("actual_direct_worker_wait") is True and wait.get("owned_worker_group_ESRCH") is True
            and wait.get("operational_failure") is None
            and wait.get("parent_id")==PARENT and wait.get("stage")=="native_paths"
            and wait.get("root_IO_source_ref")==PREP_IO_REF
            and completed.get("status")=="completed_native_C3_path_preparation"
            and completed.get("parent_id")==PARENT and completed.get("observation_ref")==OBS_REF
            and completed_ref["path"]==PREP_OUTPUT+"/completed.json","Actual original complete native corpus/wait/drain")
    else:
        require(wait.get("actual_direct_launcher_wait") is True and wait.get("all_owned_processes_and_groups_drained") is True
            and wait.get("operational_failure") is None,"Actual completed native root stage wait/drain")
    require(wait.get("returncode")==0 and wait.get("completed_ref")==completed_ref,"Exact actual completion/directwait0")
    return completed,wait
def validate_caps(caps,request):
    phase=request["phase"];refs=request["refs"]
    require(caps.get("schema")=="american_c3_native_actual_stage_caps_v1"
        and caps.get("root_authorizer")=="root_agent" and caps.get("active") is True
        and caps.get("parent_id")==PARENT and caps.get("phase")==phase
        and caps.get("runtime_ref")==refs["runtime"] and caps.get("preparation_ref")==refs["preparation"]
        and caps.get("counts_ref")==refs.get("counts") and caps.get("driver_source_ref")==ref(DRIVER),
        "Root must bind actual same-stage corpus/counts/runtime/caps and exact driver")
    for key in ("reservation_cap_bytes","phase_write_budget_bytes","max_cpu_rss_bytes",
        "operational_deadline_seconds","max_preparation_file_bytes","max_checkpoint_files",
        "max_checkpoint_bytes","max_embedding_input_bytes","outer_log_cap_bytes","outer_auxiliary_cap_bytes",
        "root_packet_overhead_cap_bytes","child_log_ram_bytes"):
        require(type(caps.get(key)) is int and caps[key]>0,"Root must fill positive actual source/count-derived bounds")
    require(caps["phase_write_budget_bytes"]+caps["outer_auxiliary_cap_bytes"]+caps["root_packet_overhead_cap_bytes"]<=caps["reservation_cap_bytes"]
        and caps["root_packet_overhead_cap_bytes"]>=12*(65536+8192)
        and caps["outer_auxiliary_cap_bytes"]>=6*caps["outer_log_cap_bytes"]+65536
        and caps["operational_deadline_seconds"]<=259200
        and caps.get("bound_method")=="actual_source_and_corpus_counts_no_fit_or_timing_guarantee",
        "Whole phase/temp/log/metadata growth must fit actual reserved cap")
    if phase in GPU_PHASES:
        require(type(caps.get("max_cuda_reserved_bytes")) is int and 0<caps["max_cuda_reserved_bytes"]<=50000000000
            and request.get("physical_gpu") in (4,5) and caps.get("physical_gpu")==request["physical_gpu"],
            "Exact root actual CUDA cap and eligible device, no invented fit guarantee")
    return caps
def make_config(req,caps):
    cfg=copy.deepcopy(native_contract().DEFAULTS)
    cfg.update(execution_enabled=True,parent_id=PARENT,phase="mlm",
        phase_write_budget_bytes=caps["phase_write_budget_bytes"],
        short_tmp_directory=".runtime/tmp/c3valmlm980/m",child_log_ram_bytes=caps["child_log_ram_bytes"])
    for key in ("max_preparation_file_bytes","max_checkpoint_files","max_checkpoint_bytes","max_embedding_input_bytes"):
        cfg[key]=caps[key]
    return cfg

NVML_ACCEPTANCE_REF=dict(path="research/reviews/American_C3_native_MLM_full_fit_v8/nvml_abi_acceptance.root_active_v1.json",
 sha256="69b13084c5275629e194651b71a9db2b233f0ef924e6c12394b2971aa70e195b")
def native_contract():
    return load(ref(REL+"/consumer_contract_v1.py"),"_VAL000_MLM980_native_contract")
def source_paths():
    native=native_contract()
    return tuple(dict.fromkeys((*native.PROJECT_SOURCES,SOURCE,DRIVER,CONTEXT,RUNTIME_HELPER,
        "src/arggnn/census_tsinfer_fit_v1.py","src/arggnn/census_tsinfer_observation_v1.py",
        "src/arggnn/biological_candidate.py","src/arggnn/project_budget_v9_consumer.py",
        "scripts/launch_reserved_gpu_full_storage_v1.py","scripts/launch_reserved_gpu_terminal_retired_scopes_v1.py",
        PROC_HELPER,"research/reviews/American_C3_native_MLM_amendment_v12/owned_lifecycle_v2.py",
        "research/reviews/American_C3_native_MLM_full_source_v5/pidfd_backend_v1.py",
        "research/reviews/American_C3_native_MLM_amendment_v12/abstract_unix_bootstrap_v1.py",
        "research/reviews/American_C3_native_MLM_amendment_v12/terminal_namespace_v12.py",
        "research/reviews/American_C3_native_MLM_amendment_v12/terminal_bounds_v1.py",
        "research/reviews/American_C3_native_MLM_amendment_v12/corpus_auth_v2.py",
        "research/reviews/American_C3_native_MLM_full_fit_v8/gpu_monitor_v8.py",
        "research/reviews/American_C3_native_MLM_full_fit_v8/progress_v8.py",
        "research/reviews/American_C3_native_MLM_full_fit_v8/nvml_abi_provenance.json",
        REL+"/launcher_mlm980_v1.py","src/arggnn/resources.py","scripts/project_budget_v9.py")))
def counts_metadata_v1(record,wait_ref):
    require(record==COUNTS_REF and wait_ref==COUNTS_WAIT_REF,"Exact genuine VAL000 count and actual wait refs")
    value,wait=validate_upstream(record,wait_ref);prep=read(PREP_REF)
    require(value.get("schema")=="american_c3_native_actual_counts_v1"
        and value.get("status")=="completed_C3_native_observation_only_counts"
        and value.get("source_ref")==ref("src/arggnn/american_c3_native_concat_v1.py")
        and value.get("preparation_ref")==PREP_REF and value.get("preparation_config_ref")==PREP_CONFIG_REF
        and value.get("parent_id")==PARENT and value.get("class_order")==["EUR","EAS","AFR"]
        and value.get("native_training_eligible") is True and value.get("query_ancestry_truth_opened") is False
        and value.get("haplotypes")==1600 and value.get("query_focal_count")==10000
        and value.get("tokenizer_vocab_size")==107144 and value.get("vocabulary_nodes")==107140
        and value.get("source_corpus_capped_or_sampled") is False and wait.get("phase")=="counts",
        "Genuine full held-out ARG counts/vocabulary; no corpus cap or substituted parent")
    expected={"mlm/train":23346222,"mlm/val":2594025,"contrastive/train":8748479,
        "contrastive/val":972757,"query_paths/train":9003,"query_paths/val":997}
    require(set(value["datasets"])==set(prep["native_dataset_refs"])==set(expected),"All six original datasets")
    for key,item in value["datasets"].items():
        require(item["dataset_ref"]==prep["native_dataset_refs"][key]
            and item["row_order_ref"]==prep["full_path_id_order_refs"][key] and item["rows"]==expected[key],
            "Exact actual complete raw path rows/identity/order, no new split")
    require(value["MLM_optimizer_updates"]==5*(expected["mlm/train"]//512)==227990
        and value["contrastive_optimizer_updates"]==expected["contrastive/train"]//4096==2135,
        "Actual release drop_last budgets227990MLM/2135contrastive")
    return value
def engineering_acceptance_v1(record,runtime):
    accepted=read(record);native=native_contract()
    require(accepted.get("schema")=="C3_native_VAL000_MLM_engineering_acceptance_v1"
        and accepted.get("active") is True and accepted.get("root_authorizer")=="root_agent"
        and accepted.get("native_GPU5_engineering_completed_and_reviewed") is True
        and accepted.get("execution_or_storage_authority_reused") is False
        and accepted.get("engineering_checkpoint_used_as_initializer") is False
        and accepted.get("author_source_manifest_ref")==native.AUTHOR_MANIFEST_REF
        and accepted.get("native_inventory_ref")==NATIVE_INVENTORY_REF
        and accepted.get("native_python_ref")==runtime["native_python_ref"],
        "Root actual completed native GPU5 engineering review; evidence only")
    completed=read(accepted["engineering_completion_ref"]);wait=read(accepted["engineering_actual_wait_ref"])
    child=read(completed["child_completion_ref"])
    require(completed.get("status")=="completed_C3_native_full_MLM_v1"
        and completed.get("completed_epochs")==5 and completed.get("observed_counters_verified") is True
        and completed.get("actual_optimizer_updates",0)>0 and completed.get("query_ancestry_truth_opened") is False
        and completed.get("author_source_manifest_ref")==native.AUTHOR_MANIFEST_REF
        and child.get("parent_id")==completed.get("parent_id") and child.get("stage")=="mlm"
        and child.get("completed_epochs")==5 and child.get("observed_counters_verified") is True
        and child.get("actual_optimizer_updates")==completed["actual_optimizer_updates"]
        and child.get("initializer_checkpoint_ref") is None and child.get("physical_gpu")==5
        and child.get("runtime_validation",{}).get("status")=="passed"
        and child["runtime_validation"].get("native_inventory_ref")==NATIVE_INVENTORY_REF
        and wait.get("actual_direct_launcher_wait") is True and wait.get("returncode")==0
        and wait.get("all_owned_processes_and_groups_drained") is True
        and wait.get("operational_failure") is None and wait.get("completed_ref")==accepted["engineering_completion_ref"],
        "Genuine successful native engineering completion and actual wait0/drain")
    return accepted


def validate_request(record):
    req=read(record);native=native_contract()
    require(req.get("schema")=="american_c3_native_specific_stage_request_v1"
        and req.get("root_authorizer")=="root_agent" and req.get("execution_authorized") is True
        and req.get("parent_id")==PARENT and req.get("phase")=="mlm" and req.get("physical_gpu") in (4,5),
        "Explicit fresh VAL000 native MLM request")
    native.no_private_refs(req);refs=req["refs"]
    require(set(refs)=={"runtime","preparation","preparation_config","preparation_close","counts","native_engineering_acceptance"}
        and refs["preparation"]==PREP_REF and refs["preparation_config"]==PREP_CONFIG_REF
        and refs["preparation_close"]==PREP_CLOSE_REF
        and req["upstream_wait_refs"]==dict(preparation=PREP_WAIT_REF,counts=COUNTS_WAIT_REF),
        "Own exact held-out corpus/counts and engineering evidence; no prior checkpoint or v12 authority")
    validate_upstream(PREP_REF,PREP_WAIT_REF,preparation=True)
    close=read(PREP_CLOSE_REF)
    require(close["value"]["future_writes_and_relaunch_revoked"] is True
        and close["value"]["request"]["completed_ref"]==PREP_REF,"Closed original corpus stays READONLY")
    counts_metadata_v1(refs["counts"],COUNTS_WAIT_REF)
    caps=validate_caps(read(req["caps_ref"]),req);runtime=read(refs["runtime"])
    require(caps.get("root_resource_caps_reviewed") is True,"Explicit root review of actual fresh native resources")
    require(runtime.get("schema")=="american_c3_native_VAL000_MLM_runtime_binding_v1"
        and runtime.get("status")=="existing_inventory_bound_actual_GPU_at_execution"
        and runtime.get("root_authorizer")=="root_agent"
        and runtime["target_physical_gpu"]==req["physical_gpu"] and runtime["target_GPU_UUID"]==req["GPU_UUID"]
        and runtime["bert_base_config_ref"]==BASE_CONFIG_REF
        and runtime["native_CPU_qualification_ref"]==NATIVE_CPU_QUAL_REF
        and runtime["native_inventory_ref"]==NATIVE_INVENTORY_REF,
        "Exact existing native author runtime inventory; actual held GPU/UUID checked at execution")
    import re
    require(re.fullmatch(r"GPU-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",req["GPU_UUID"]),
        "Actual root GPU UUID")
    read(runtime["shared_cpu_runtime_ref"]);read(NATIVE_CPU_QUAL_REF)
    acceptance=read(NVML_ACCEPTANCE_REF)
    require(acceptance.get("active") is True and acceptance.get("root_accepts_actual_UUID_memory_comparison") is True,
        "Prior ABI compatibility evidence only; no prior execution authority")
    engineering_acceptance_v1(refs["native_engineering_acceptance"],runtime)
    require(caps["checkpoint_live_allowance_bytes"]==8*2**30+65536 and caps["cache_allowance_bytes"]==4*2**30
        and caps["temp_allowance_bytes"]==256*2**20 and caps["child_artifact_allowance_bytes"]==256*2**20
        and caps["max_checkpoint_files"]==2 and caps["max_checkpoint_bytes"]==4*2**30,
        "Explicit source-derived retention1/max2 checkpoint/cache/TMP policy; no fit guarantee")
    return req,caps,runtime

def launcher_ref_v1():return ref(LAUNCHER_REF["path"])
