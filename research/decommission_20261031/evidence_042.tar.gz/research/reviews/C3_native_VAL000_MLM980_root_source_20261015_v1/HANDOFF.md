# Fresh VAL000 native MLM source handoff

This packet is source-only and default-inert. It provides one native MLM phase for the genuinely completed full30Mb VAL000 corpus. Root must finish and review the native GPU5 engineering run, review actual resources, bind a GPU/UUID, then create a fresh reservation and launch. No admission, reservation, job, model, fixture, GPU/process inspection, native interpreter invocation, real corpus/checkpoint/truth read, guard installation, Git operation or install was performed for this packet.

The exact genuine counts completion is 502c111b443c46eea789dc03ee3ff8b6454546ce6e86e3f9fcddba25e82489a7 and its actual launcher wait is ab2d1f7a7e09756009556ae6f793899c9e4fd5a7cc202e25d877104d3b2f9c91. Counts imply 5*floor(23,346,222/512)=227,990 MLM updates; contrastive would later have floor(8,748,479/4096)=2,135 updates. This packet executes only MLM. The actual ARG tokenizer has 107,144 tokens (107,140 vocabulary nodes); the author model loads that ARG vocabulary and resizes its embeddings. No fixed 30,528-token substitution is introduced.

All original author training settings remain pinned: native runtime/inventory, 5 epochs, global and microbatch512, amp_bf16, seed17, seq128, 12 layers and 12 heads, complete raw corpus, train drop_last, native 90/10 path split and split seed42. The pinned author MLM YAML already has save_interval500ba and retention1; the wrapper applies no retention override. The child starts with load_path=None, autoresume=False, and no initializer checkpoint. It verifies actual Trainer and optimizer counters, final checkpoint counters, and actual tokenizer length107144. Six scientific helper bodies compare byte-for-byte equal to the approved v12 child.

The only v12 reuse is approved source utilities for owned lifecycle, abstract IPC, terminal namespace/bounds and corpus authentication. No TRAIN000 or v12 allocation, storage/execution/cleanup authority, input capability or checkpoint initializer is reused. The fresh root contract accepts only original registered VAL000 with split=val and engineering_TRAIN_only=False. Engineering evidence is read as JSON evidence only and never grants authority or supplies an initializer.

Fresh output: experiments/results/American_C3_native_val000_full30mb_MLM980_v1
Fresh admission: this packet/admitted_mlm_v1/
Fresh TMP: .runtime/tmp/c3valmlm980/m (child /mlm)
Fresh job: American-C3-native-val000-MLM980-mlm-v1
Fresh reservation key: H041/American-C3-native-val000-MLM980-mlm-v1

The current980 full-storage reservation/launcher/close machinery is preserved. The original scheduler sharing contract remains GPUs4/5, at most two project devices, eligibility50,000,000,000+4,000,000,000 free bytes. Root-selected CUDA caps must not exceed the original50,000,000,000 authority. Fast live resource checks remain separate from post-drain storage scanning. After actual direct child wait and complete owned identity drain, the approved utility independently regularizes only the own Composer latest alias before terminal accounting. Unexpected filesystem IPC sockets fail rather than acquiring legacy cleanup authority.

Root inputs still unresolved:
- A new reviewed caps JSON copied from caps_mlm.proposed.inactive.json, with root_resource_caps_reviewed=true, actual positive max_cpu_rss_bytes, max_cuda_reserved_bytes and operational_deadline_seconds (<=259200). The 16GiB reservation and 14GiB phase policy are proposed allowances, not a RAM/GPU/cache/timing fit proof. Checkpoint max2 files/max4GiB each, live8GiB+65536, cache4GiB, temp256MiB, child artifacts256MiB stay explicit.
- A new actual engineering acceptance JSON copied from engineering_acceptance.inactive.json, active=true and native_GPU5_engineering_completed_and_reviewed=true, binding the genuine successful native GPU5 MLM completion and actual root launcher wait0/drain. Its validator also checks native inventory, original author closure, full5ep and actual verified matching counters. Do not populate it from an unfinished job.
- Actual eligible physical GPU4/5 and UUID, chosen by root resource review. Runtime inventory evidence is preserved; this packet makes no new model or runtime qualification claim.

Root commands are in ROOT_COMMANDS.md. Run bind, then admit, then a dedicated-session launch only after all gates are met. Bind writes metadata only; admission creates the new capability/reservation. No automatic retry, replay, renewal, source edit, cap escalation or post-failure resume is provided. Preserve failed files and original charge; any successor needs fresh root review and authority.

Validation: 9 new Python sources syntax-compiled without bytecode; source and author-source hashes verified; all declared local import dependencies present in the32-path consumer source map; genuine counts/preparation/wait/closed-corpus metadata checks passed; shared-Python default driver and entry CLIs both returned0 with actual_execution=false. No launcher was invoked, including help. This is source/inert validation only. See source_only_checks.v1.json and source_deltas.v1.json.

Freeze code and inactive templates against source_handoff.v1.json. Root may add new root_active metadata and admitted/terminal evidence without changing the sealed source files.
