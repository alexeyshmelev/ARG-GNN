"""Append-only progress with explicit per-record and per-attempt byte bounds."""
import os
from arggnn.benchmarking import contracts as c

MAX_RECORD_BYTES = 65536
MAX_PROGRESS_BYTES = 8 * 2**20


def append_progress(path, raw, lock):
    with lock:
        if len(raw) > MAX_RECORD_BYTES or (path.stat().st_size if path.exists() else 0) + len(raw) > MAX_PROGRESS_BYTES:
            raise c.ContractError("Bounded per-attempt progress log")
        with path.open("ab") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
