"""Exact attempt-8 history restore and logging-only continuation from update593."""
from __future__ import annotations
import copy
import json
from pathlib import Path
from arggnn.benchmarking import contracts as c
from arggnn.benchmarking.paper_campaign import runtime as r, processes
from research.preprocessing_optimization_20261026.integration import treeloom_resume as history
from research.efficiency_20261027.integration_candidate.qualification_combined_v5 import validate_release
from . import training_logger_v1 as training

MODULE = 'research.recovery_20261028.treeloom.restore_entrypoint_v1'
BASE = 'research/recovery_20261028/treeloom/'
NO_WALL_LIMIT = 9223372036854775807
ENVELOPE_KEYS = ('id','kind','python','cpu_threads','dependencies','max_rss_bytes',
    'max_output_bytes','minimum_free_gpu_bytes','preferred_gpus','output_directory')


def need(ok,message):
    if not ok:raise ValueError(message)


def read(reference):
    history._reference(reference)
    path=history._ordinary_path(reference['path'],regular_file=True)
    need(path.stat().st_size<=8*2**20,'Bounded immutable continuation metadata required')
    return r.read(reference)


def local_refs():
    return [r.ref(BASE+name) for name in ('logger_v1.py','training_logger_v1.py','restore_entrypoint_v1.py')]


def preflight(request):
    need(type(request) is dict and set(request)=={'continuation_ref','preserved_history_ref'},
         'Exact captured continuation and archive references required')
    payload=read(request['continuation_ref'])
    need(payload.get('schema')=='TreeLoom_logging_only_update593_continuation_v1',
         'Explicit logging-only update593 continuation required')
    prior=read(payload['predecessor_job_ref'])
    need(prior['id']=='paper_american_treeloom_fit'
         and prior['call']['module']=='research.efficiency_20261027.integration_candidate.restore_entrypoint_combined_v5',
         'Exact attempt8 predecessor task required')
    wait=read(payload['predecessor_wait_ref'])
    need(wait.get('actual_wait') is True and wait.get('owned_process_group_absent') is True
         and wait.get('attempt')==8 and wait.get('status')=='failed' and wait.get('actual_returncode')==1,
         'Genuine failed attempt8 wait and absent owned session required')
    process_stat=Path('/proc')/str(wait['pid'])/'stat'
    if process_stat.exists():
        ticks=process_stat.read_text().rsplit(')',1)[1].split()[19]
        need(ticks!=wait['process_start_ticks'],'Predecessor identity is still alive')
    need(not processes.session_members(wait['pid']),'Predecessor session must be absent')
    old=prior['call']['spec']['successor']
    release=validate_release(old['execution_release_ref'])
    preprocessing=history.authenticate_release(old['preprocessing_release_ref'])
    need(preprocessing['encoder_workers']==4,'Original four-process preparation required')
    arguments=copy.deepcopy(payload['arguments'])
    need(set(arguments)==set(old['arguments']),'Original scientific argument shape required')
    for key in set(arguments)-{'resume_checkpoint_ref','resume_evidence_ref','output_directory'}:
        need(arguments[key]==old['arguments'][key],'Scientific or resource argument changed: '+key)
    need(arguments['execution_configuration']==release['configuration'],'Original reviewed execution configuration required')
    captured=history._ordinary_path(arguments['resume_checkpoint_ref']['path'],regular_file=True)
    need(captured==c.ROOT/BASE/'update593.pt' and captured.stat().st_size<=8*2**20
         and c.file_ref(captured)==arguments['resume_checkpoint_ref'],'Exact captured update593 checkpoint required')
    evidence=read(arguments['resume_evidence_ref'])
    need(evidence['complete_parent_updates']==593 and evidence['next_update']==594
         and evidence['remaining_complete_parent_updates']==7,'Seven remaining complete updates required')
    root,manifest,files=history.validate_history(request['preserved_history_ref'])
    need(root.parent==r.path(prior['output_directory']),'Original outer output owns restored history')
    predecessor=root/'exact_preprocessing_from_update281_memory_selected_adaptive2_attempt8'
    sources={target:source for source,target,size,ref in files}
    required={predecessor/'latest_checkpoint.json',predecessor/'checkpoints/latest.pt',predecessor/'progress.jsonl'}
    need(required<=set(sources),'Complete latest checkpoint and failed progress journal must be retained')
    latest=json.loads(sources[predecessor/'latest_checkpoint.json'].read_text())
    need(latest['complete_parent_updates']==593
         and latest['checkpoint_ref']['sha256']==arguments['resume_checkpoint_ref']['sha256']
         and r.ref(sources[predecessor/'checkpoints/latest.pt'])['sha256']==arguments['resume_checkpoint_ref']['sha256'],
         'Archive must match actual latest593, not merely the last logged592')
    leaf=history.attempt_directory(root,593,'logger_attempt9')
    need(arguments['output_directory']==str(leaf.relative_to(c.ROOT)),'Fresh fixed update593 attempt leaf required')
    need(not any(target.is_relative_to(leaf) or target==root/(leaf.name+'.execution.json') for target in sources),
         'Successor namespace must not exist in restored history')
    spec=training.build_spec(**arguments)
    required_bytes=manifest['total_bytes']+spec['requirements']['output_scope_cap_bytes']+2**20
    need(spec['requirements']['output_scope_cap_bytes']==64*2**20 and required_bytes<=prior['max_output_bytes'],
         'Retained history plus fresh64MiB and outer metadata must fit unchanged output reservation')
    return dict(payload=payload,prior=prior,spec=spec,root=root,leaf=leaf,manifest=manifest,required_bytes=required_bytes)


def validate_task(task,checked,request):
    need(type(task) is dict,'Actual admitted task required')
    for key in ENVELOPE_KEYS:
        need(task.get(key)==checked['prior'].get(key),'Original scheduler resource envelope changed: '+key)
    need(task.get('max_seconds')==NO_WALL_LIMIT,'Explicit compatibility no-wall-limit sentinel required')
    need(task.get('call')==dict(module=MODULE,function='run_task',spec=request),'Exact admitted logging-only request required')
    refs={ref['path']:ref for ref in task.get('source_refs',[])}
    required=checked['prior']['source_refs']+checked['spec']['requirements']['source_refs']+local_refs()+[
        request['continuation_ref'],request['preserved_history_ref'],checked['payload']['predecessor_wait_ref']]
    for ref in required:
        need(refs.get(ref['path'])==ref and r.ref(ref['path'])==ref,'Every unchanged and new source must be pinned')


def run_task(request,*,resource_check):
    need(callable(resource_check),'Admitted worker resource callback required')
    checked=preflight(request)
    validate_task(getattr(resource_check,'task',None),checked,request)
    resource_check(checked['required_bytes'])
    history.restore_history(request['preserved_history_ref'],resource_check=resource_check)
    receipt=history._exclusive_json(checked['root']/(checked['leaf'].name+'.execution.json'),dict(
        schema='TreeLoom_logging_only_resume_execution_v1',continuation_ref=request['continuation_ref'],
        preserved_history_ref=request['preserved_history_ref'],complete_parent_updates=593,
        remaining_complete_parent_updates=7,new_progress_stream=True,old_journal_preserved=True,
        source_refs=checked['spec']['requirements']['source_refs'],required_output_bytes=checked['required_bytes']),resource_check)
    result=training.run_training(checked['spec'],resource_check=resource_check)
    need(result['complete_parent_updates']==600 and result['resumed_from_complete_parent_updates']==593,
         'Exact original final600 updates required')
    completion={key:value for key,value in result.items() if key!='completion_ref'}
    completion.update(nested_completion_ref=result['completion_ref'],execution_successor_ref=receipt)
    result['completion_ref']=history._exclusive_json(checked['root']/'training_completed.json',completion,resource_check)
    result['execution_successor_ref']=receipt
    return result
