"""CPU-only slow-admission/storage concurrency and immutable reuse checks."""
import ast
import errno
import json
from pathlib import Path
import threading
import time
from unittest.mock import patch
from . import aggregate_guard as fixed, contracts as c, worker
from research.resume_no_timeouts_20261027.fullval import aggregate_guard as prior

HERE=Path(__file__).resolve().parent

def run():
    base=HERE/'monitor_fixtures';base.mkdir()
    checks=[]
    def scope(name):
        p=base/name;p.mkdir();return p
    # The old stream reservation invokes a slow admission check while holding
    # the same lock needed to publish the monitor's measured sample.
    p=scope('old_locked_callback')
    owner=prior.AggregateOwner(p,execution_check=lambda:None,max_family_rss_bytes=2**30,max_seconds=None)
    blocked=threading.Event();release=threading.Event();measured=threading.Event();calls=[]
    def callback():
        if threading.current_thread().name=='reservation':
            calls.append(1)
            if len(calls)==2:
                blocked.set();assert release.wait(2)
    owner.execution_check=callback
    original_measure=prior.measure
    def measure(path):
        value=original_measure(path)
        if threading.current_thread().name=='full-validation-storage' and blocked.is_set():measured.set()
        return value
    errors=[]
    def reserve():
        try:owner.reserve_stream_write(1)
        except BaseException as error:errors.append(repr(error))
    with patch.object(prior,'MAX_SAMPLE_AGE',.05),patch.object(prior,'SCAN_INTERVAL',.001),patch.object(prior,'measure',measure):
        owner.start_monitor()
        thread=threading.Thread(target=reserve,name='reservation');thread.start()
        assert blocked.wait(2) and measured.wait(2)
        time.sleep(.1);release.set();thread.join(2)
        for _ in range(100):
            if owner._error:break
            time.sleep(.005)
        assert owner._error and 'five-second age' in str(owner._error)
        try:owner.close()
        except prior.GuardFailure:pass
        else:raise AssertionError('Old close swallowed monitor failure')
    assert not thread.is_alive()
    checks.append(dict(name='sealed_predecessor_reproduces_slow_callback_under_storage_lock_age_failure'))

    p=scope('independent_storage')
    owner=fixed.AggregateOwner(p,execution_check=lambda:None,max_family_rss_bytes=2**30,max_seconds=None)
    slow_started=threading.Event();slow_finished=threading.Event();full_threads=[];fast_calls=[]
    def slow():
        full_threads.append(threading.current_thread().name)
        slow_started.set();time.sleep(.20);slow_finished.set()
    slow.fast=lambda:fast_calls.append(time.monotonic())
    owner.execution_check=slow
    errors=[]
    def fixed_reserve():
        try:owner.reserve_stream_write(1)
        except BaseException as error:errors.append(repr(error))
    with patch.object(fixed,'MAX_SAMPLE_AGE',.05),patch.object(fixed,'SCAN_INTERVAL',.005):
        owner.start_monitor()
        start_scans=owner.metrics['scans']
        slow_started.clear();slow_finished.clear()
        thread=threading.Thread(target=fixed_reserve,name='reservation');thread.start()
        assert slow_started.wait(1)
        time.sleep(.10)
        assert not slow_finished.is_set()
        assert owner.metrics['scans']>=start_scans+3
        thread.join(2)
        assert not thread.is_alive() and not errors and owner._error is None
        assert 'full-validation-storage' not in full_threads and fast_calls
        owner.close()
    checks.append(dict(name='storage_monitor_advances_while_full_admission_is_slow_and_reservation_finishes',scans=owner.metrics['scans']))

    p=scope('stale_cache_rescan')
    owner=fixed.AggregateOwner(p,execution_check=lambda:None,max_family_rss_bytes=2**30,max_seconds=None)
    owner._last['started_monotonic']-=25
    scans=owner.metrics['scans'];before=time.monotonic()
    sample=owner.check()
    assert owner.metrics['scans']==scans+1 and sample['started_monotonic']>=before
    owner.close()
    checks.append(dict(name='stale_cache_requires_real_scan_not_timestamp_renewal'))

    p=scope('stale_actual_measurement')
    owner=fixed.AggregateOwner(p,execution_check=lambda:None,max_family_rss_bytes=2**30,max_seconds=None)
    original_measure=fixed.measure
    def stale(path):
        sample=original_measure(path);sample['started_monotonic']-=10;return sample
    with patch.object(fixed,'measure',stale):
        owner.refresh()
        try:owner.storage_check(refresh_stale=True)
        except fixed.GuardFailure as error:assert 'actual storage scan' in str(error)
        else:raise AssertionError('Old actual measurement relabeled fresh')
    owner.close()
    checks.append(dict(name='actual_stale_measurement_fails_after_real_rescan'))

    p=scope('io_error')
    payload=p/'payload';payload.write_text('retained\n')
    owner=fixed.AggregateOwner(p,execution_check=lambda:None,max_family_rss_bytes=2**30,max_seconds=None)
    original_lstat=Path.lstat
    for code in (errno.EIO,errno.EACCES,errno.ENOENT):
        def fail(path,*args,**kwargs):
            if path==payload:raise OSError(code,'injected real filesystem failure',str(path))
            return original_lstat(path,*args,**kwargs)
        with patch.object(Path,'lstat',fail):
            try:owner.refresh()
            except OSError as error:assert error.errno==code
            else:raise AssertionError('Actual filesystem error ignored')
    owner.close()
    checks.append(dict(name='EIO_EACCES_and_unregistered_ENOENT_remain_fatal'))

    p=scope('fast_guard_failure')
    callback=lambda:None
    callback.fast=lambda:None
    owner=fixed.AggregateOwner(p,execution_check=callback,max_family_rss_bytes=2**30,max_seconds=None)
    with patch.object(fixed,'SCAN_INTERVAL',.001):
        owner.start_monitor()
        def fast_failure():raise RuntimeError('guardian stale or execution hold')
        callback.fast=fast_failure
        for _ in range(100):
            if owner._error:break
            time.sleep(.005)
        assert owner._error and 'guardian stale' in str(owner._error)
        try:owner.close()
        except fixed.GuardFailure:pass
        else:raise AssertionError('Fast guardian failure lost')
    assert owner._lease.closed
    checks.append(dict(name='fast_guardian_liveness_error_latched_and_close_propagates'))

    # Every operational predicate still uses the original native function and
    # sampler arguments. No generator call exists in the continuation worker.
    old=ast.parse((c.ROOT/'research/resume_no_timeouts_20261027/fullval/worker.py').read_text())
    new=ast.parse(Path(worker.__file__).read_text())
    def calls(tree,attribute):
        return [ast.dump(n,include_attributes=False) for n in ast.walk(tree)
                if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr==attribute]
    assert calls(new,'infer_parent')==calls(old,'infer_parent')
    assert calls(new,'build_validation_registry')==calls(old,'build_validation_registry')
    assert not calls(new,'generate_validation_parent')
    frozen=c.validate_plan();directory,receipt,reuse_ref=c.authenticated_generation(frozen)
    config,tools,chain=c.native_bindings()
    assert receipt['sites']==1340560 and receipt['truth_intervals']==989981 and len(tools)==7
    assert receipt['seeds']==dict(ancestry=3519499615,mutations=1701692571)
    assert not c.AGGREGATE.exists()
    checks.append(dict(name='authenticated_generation_reused_same_native_and_sampler_calls_no_resimulation',reuse_ref=reuse_ref,
        native_seeds={k:frozen['parent']['seeds'][k] for k in ('relate_initial','relate_size_base')}))
    return checks

def main():
    checks=run()
    path=HERE/'MONITOR_TESTS.json'
    path.write_text(json.dumps(dict(passed=True,check_count=len(checks),checks=checks,
        scientific_native_or_simulation_executions=0,
        source_refs=[c.ref(HERE/name) for name in ('aggregate_guard.py','contracts.py','worker.py','guardian.py','native_supervisor.py','test_monitor.py','GENERATION_REUSE.json')]),indent=2)+'\n')
    print(json.dumps(dict(passed=True,checks=len(checks),receipt=c.ref(path))))

if __name__=='__main__':main()
