"""Existing completed report arithmetic only. No scientific arrays or model imports."""
from pathlib import Path
from collections import defaultdict
import json,hashlib,math
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
OUT=ROOT/"research/reviews/census_structural_viability_and_novelty_v1_author"
REPORTS={
 "Relate":"experiments/results/census_native_actual32_inspect_v1_cpu/evidence.json",
 "same_tsinfer_tsdate":"experiments/results/census_tsinfer_observation_v1/census-tsinfer-inspect-v1/evidence.json"}
Q=184;SCORED=120;checks=0
def check(value):
 global checks
 checks+=1
 assert value
def ref(path):return {"path":str(path.relative_to(ROOT)),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
def close(a,b):check(math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-9))
def add_hist(target,hist,weight):
 for key,value in hist.items():target[key]+=value*weight
def normalized(hist,total):return {key:value/total for key,value in sorted(hist.items(),key=lambda row:float(row[0]))}
def stats(rows):
 span=sum(row["span"] for row in rows);boundary_span=sum(row["boundary_span"] for row in rows)
 boundary_count=sum(row["boundary_count"] for row in rows)
 groups=defaultdict(float);rho=defaultdict(float);event_rho=defaultdict(float)
 for row in rows:
  add_hist(groups,row["size_hist"],row["span"])
  add_hist(rho,row["rho_hist"],row["boundary_span"])
  add_hist(event_rho,row["event_rho_sum"],1)
 groups=normalized(groups,span);rho=normalized(rho,boundary_span);event_rho=normalized(event_rho,boundary_count)
 close(sum(groups.values()),1);close(sum(rho.values()),1);close(sum(event_rho.values()),1)
 singleton=groups.get("1",0);changed=1-rho.get("1.0",0);mean_rho=sum(float(k)*v for k,v in rho.items())
 return {
  "tiles":len(rows),"parents":len({r["parent"] for r in rows}),"native_trees":sum(r["trees"] for r in rows),
  "query_count":Q,"scored_query_count":SCORED,"context_query_count":64,
  "retained_span_bp":span,"boundary_right_hold_span_bp":boundary_span,"tree_boundaries":boundary_count,
  "span_query_weighted_group_size_histogram":groups,"mean_query_group_size":sum(float(k)*v for k,v in groups.items()),
  "span_query_weighted_singleton_fraction":singleton,"cross_query_exchange_possible_fraction":1-singleton,
  "span_query_weighted_mean_group_count":Q*sum(v/float(k) for k,v in groups.items()),
  "group_size_at_least5_query_mass":sum(v for k,v in groups.items() if float(k)>=5),
  "group_size_at_least10_query_mass":sum(v for k,v in groups.items() if float(k)>=10),
  "maximum_group_size_seen":max(int(k) for k,v in groups.items() if v>0),
  "right_hold_span_query_weighted_rho_histogram":rho,"right_hold_span_query_weighted_rho1_fraction":1-changed,
  "right_hold_span_query_weighted_mean_rho":mean_rho,"right_hold_span_query_weighted_changed_fraction":changed,
  "mean_rho_given_changed":sum(float(k)*v for k,v in rho.items() if float(k)<1)/changed if changed else None,
  "boundary_event_query_weighted_rho1_fraction":event_rho.get("1.0",0),
  "boundary_event_query_weighted_mean_rho":sum(float(k)*v for k,v in event_rho.items()),
  "all184_initial_eta1_mean_retention_loss":1-mean_rho,
  "scored120_changed_fraction_upper_bound":min(1,Q/SCORED*changed),
  "scored120_initial_eta1_mean_retention_loss_upper_bound":min(1,Q/SCORED*(1-mean_rho)),
  "scored120_singleton_fraction_lower_bound":max(0,(Q*singleton-64)/SCORED),
  "scored120_singleton_fraction_upper_bound":min(1,Q*singleton/SCORED),
  "limited_mechanism_flag_true_tiles":sum(row["limited"] for row in rows),
  "tile_singleton_min_max":[min(row["singleton"] for row in rows),max(row["singleton"] for row in rows)],
  "tile_rho1_min_max":[min(row["rho_hist"].get("1.0",0) for row in rows),max(row["rho_hist"].get("1.0",0) for row in rows)]
 }
output={};report_refs={};raw_summaries={}
for condition,path in REPORTS.items():
 p=ROOT/path;report_refs[condition]=ref(p);report=json.loads(p.read_text())
 check(report["status"]=="inspection_complete_pending_root_freeze" and report["phase"]=="inspect")
 check(report["fixture_mode"] is False and report["GPU_used"] is False and report["fit_performed"] is False and report["biological_targets_opened"] is False)
 cells=report["cells"];check(len(cells)==32 and report["expected_cells"]==32 and report["failed_cells"]==[])
 check(len({(c["parent_id"],c["tile_id"]) for c in cells})==32)
 rows=[]
 for cell in cells:
  s=cell["structural"];spans=s["physical_spans_bp"];trees=cell["num_trees"]
  check(len(spans)==trees==len(s["per_tree_query_weighted_distributions"]))
  check(len(s["boundary_turnover"])==trees-1 and s["sample_count"]==280 and s["older_R_proxy_count"]==12)
  close(sum(s["physical_span_weighted_query_group_size"].values()),1)
  close(s["physical_span_weighted_singleton_Q_fraction"],s["physical_span_weighted_query_group_size"].get("1",0))
  close(s["cross_query_exchange_possible_fraction"],1-s["physical_span_weighted_singleton_Q_fraction"])
  reconstructed=defaultdict(float)
  for tree_row,span in zip(s["per_tree_query_weighted_distributions"],spans):
   h=tree_row["query_weighted_group_size"];close(sum(h.values()),1)
   for key,value in h.items():close(value*Q,round(value*Q))
   close(Q*sum(value/int(key) for key,value in h.items()),tree_row["group_count"])
   add_hist(reconstructed,h,span/sum(spans))
  for key in set(reconstructed)|set(s["physical_span_weighted_query_group_size"]):close(reconstructed.get(key,0),s["physical_span_weighted_query_group_size"].get(key,0))
  rho=defaultdict(float);event_rho=defaultdict(float);boundary_span=0
  for boundary,right_span in zip(s["boundary_turnover"],spans[1:]):
   close(boundary["right_hold_span_bp"],right_span);boundary_span+=right_span
   h=boundary["query_weighted_rho"];close(sum(h.values()),1)
   check(all(0<float(key)<=1 for key in h))
   for value in h.values():close(value*Q,round(value*Q))
   add_hist(rho,h,right_span);add_hist(event_rho,h,1)
  rho=normalized(rho,boundary_span)
  for key in set(rho)|set(s["right_hold_span_weighted_boundary_rho"]):close(rho.get(key,0),s["right_hold_span_weighted_boundary_rho"].get(key,0))
  rows.append({"parent":cell["parent_id"],"split":cell["split"],"tile":cell["tile_id"],"trees":trees,"span":sum(spans),
   "boundary_span":boundary_span,"boundary_count":trees-1,"size_hist":s["physical_span_weighted_query_group_size"],
   "rho_hist":rho,"event_rho_sum":dict(event_rho),"singleton":s["physical_span_weighted_singleton_Q_fraction"],
   "limited":s["limited_mechanism_opportunity"],"certificate_sha256":cell["certificate_sha256"]})
 output[condition]={"all":stats(rows),"train":stats([r for r in rows if r["split"]=="train"]),
  "val":stats([r for r in rows if r["split"]=="val"]),
  "parents":{parent:stats([r for r in rows if r["parent"]==parent]) for parent in sorted({r["parent"] for r in rows})}}
 raw_summaries[condition]=[{k:v for k,v in row.items() if k!="event_rho_sum"} for row in rows]
# The completed numerical report is qualification metadata, never predictive efficacy.
p=ROOT/"experiments/results/census_native_actual32_numerical_v1_cpu/evidence.json"
numerical=json.loads(p.read_text())
check(numerical["status"]=="numerical_complete_no_fitting_or_predictive_claim" and len(numerical["cells"])==32)
check(all(c["status"]=="numerically_qualified" and c["qualification"]["status"]=="qualified" and len(c["qualification"]["checks"])==10 for c in numerical["cells"]))
result={"schema":"census_existing_report_group_turnover_summary_v1","status":"existing_report_arithmetic_complete",
 "registration_id":"census_group_turnover_existing_evidence_diagnostic_v1","report_refs":report_refs,
 "completed_Relate_numerical_report_ref":ref(p),"conditions":output,"cell_summaries":raw_summaries,
 "metadata_consistency_assertions":checks,
 "weighting":"Group size/singletons: physical tree span times uniform184Q; rho: right hold span after each within-tile boundary times uniform184Q. Event weights additionally reported. No cross-tile boundary exists in these reports.",
 "query_semantics":"Q184=120 scored query+64 mixed-reference context;96 pure references outside census cut. Reports do not separately summarize scored120.",
 "limits":["Four development parents, twoTRAIN/twoVAL; tiles and marginal trees are correlated, not independent replicates.",
 "No learned eta, per-query aligned cumulative rho, scored120-only distribution, ancestry switches, targets, predictions or mechanism utility can be inferred from these report summaries.",
 "Structural/neural numerical qualification is not a predictive or biological-effect result."],
 "underlying_trees_banks_genotypes_targets_predictions_or_models_opened":False}
with (OUT/"group_turnover_summary.json").open("x") as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write("\n")
print(json.dumps({"assertions":checks,"reports":report_refs,"all_condition_summaries":{k:{field:v["all"][field] for field in
 ["mean_query_group_size","span_query_weighted_singleton_fraction","cross_query_exchange_possible_fraction","right_hold_span_query_weighted_rho1_fraction","right_hold_span_query_weighted_mean_rho","boundary_event_query_weighted_rho1_fraction","mean_rho_given_changed","scored120_changed_fraction_upper_bound","scored120_initial_eta1_mean_retention_loss_upper_bound","limited_mechanism_flag_true_tiles"]} for k,v in output.items()}},indent=2))
