"""Inactive H020 complete32 target-free CPU working-set qualification caller."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from dataclasses import fields,is_dataclass
from datetime import datetime,timezone
import hashlib,json,os,random,resource,statistics,sys,time
from pathlib import Path
from arggnn import biological_bank_snapshot_cache_v2 as m

ROOT=m.ROOT
SOURCE_PATH='research/reviews/biological_bank_snapshot_cache_v2_working_set_author/caller.py'
REGISTRATION_REF={'path':'research/reviews/biological_bank_snapshot_cache_v2_working_set_registration_root.json','sha256':'3f155887ada9d5ca724356b5e9b41a789f6c866cebfeb1f6cdbc59ca45e8957c'}
CACHE_SOURCE_REF={'path':'src/arggnn/biological_bank_snapshot_cache_v2.py','sha256':'5e51971a85c711894b1fd6d5f5d9df29f6a203cf3f638346c421f31e1158b099'}
CACHE_CONFIG_REF={'path':'configs/biological_bank_snapshot_cache_v2.json','sha256':'8a3222afab298105e297e64820f4242d33d32a24e3dc691de17966052db704cf'}

def require(value,message):
    if not value:raise ValueError(message)

def source_ref():
    return {'path':SOURCE_PATH,'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

def source_report():
    return {'schema':'biological_bank_snapshot_cache_working_set_source_report_v1','status':'inactive_source_and_handmade_only','caller_ref':source_ref(),'registration_ref':REGISTRATION_REF,'cache_source_ref':CACHE_SOURCE_REF,'cache_config_ref':CACHE_CONFIG_REF,'schedule':{'seed':101,'reference_epoch':1,'TRAIN_requests':16,'VAL_model_outer_passes':7,'VAL_requests':112,'total_requests':128,'distinct_banks':32},'actual_inputs_models_fit_targets_GPU_resources_or_Git':False}

def rss_peak_bytes():
    require(sys.platform.startswith('linux'),'Main Linux runtime required for ru_maxrss KiB semantics')
    return int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)*1024

def field_signature(value):
    """Exact fields/values plus original type, nested order and tensor layout."""
    if isinstance(value,m.torch.Tensor):return ('tensor',str(value.device),value.storage_offset(),m.frozen.field_fingerprint(value))
    if is_dataclass(value):return (type(value).__module__,type(value).__name__,tuple((f.name,field_signature(getattr(value,f.name))) for f in fields(value)))
    if isinstance(value,dict):return ('dict',tuple((key,field_signature(child)) for key,child in value.items()))
    if isinstance(value,(tuple,list)):return (type(value).__name__,tuple(field_signature(child) for child in value))
    if isinstance(value,float):return ('float',value.hex())
    if value is None or isinstance(value,(str,int,bool)):return (type(value).__name__,value)
    raise ValueError('Unsupported original fixed bank field type')

def request_order(parents,records):
    train=[p for p in parents if p['split']=='train'];val=[p for p in parents if p['split']=='val']
    require(len(train)==len(val)==2,'Complete original two TRAIN and two VAL parents required')
    require(all(len(records[p['parent_id']]['tiles'])==8 for p in parents),'All eight original tiles per parent required')
    tiles=[(p,t) for p in train for t in records[p['parent_id']]['tiles']]
    order=list(range(len(tiles)))
    random.Random(101+1).shuffle(order)
    result=[('TRAIN',None,*tiles[index]) for index in order]
    result.extend(('VAL',name,p,t) for name in m.controls.CONTROL_NAMES for p in val for t in records[p['parent_id']]['tiles'])
    require(len(result)==128 and len({(p['parent_id'],t['tile_id']) for _,_,p,t in result})==32,'Complete128 requests over32 banks required')
    return result

def summarize(values):
    return {'count':len(values),'minimum':min(values),'median':statistics.median(values),'mean':statistics.fmean(values),'maximum':max(values),'total':sum(values)}

@contextmanager
def measured_snapshot_decode(records):
    original=m.decode_bank_snapshot_v2
    def timed(snapshot,tile,cfg,parent,device,decode_budget_bytes,stats):
        start=time.perf_counter()
        try:return original(snapshot,tile,cfg,parent,device,decode_budget_bytes,stats)
        finally:records.append({'parent_id':parent['parent_id'],'tile_id':tile['tile_id'],'seconds':time.perf_counter()-start})
    m.decode_bank_snapshot_v2=timed
    try:yield
    finally:m.decode_bank_snapshot_v2=original

def qualify_working_set(cache,cfg,parents,records,limits,result):
    sequence=request_order(parents,records);seen=set();cold=[];hot=[];baseline_times=[];parity_times=[]
    rng=m._rng_v1('cpu');initial_peak=rss_peak_bytes()
    result.update(status='running',ru_maxrss_at_start_bytes=initial_peak,requests=[],bank_parity=[],cold_decodes=[],global_RNG_unchanged=False)
    def guard():
        cache._bindings()
        require(rss_peak_bytes()+limits['minimum_headroom_bytes']<=limits['RSS_ceiling_bytes'],'Measured ru_maxrss exceeds root RSS/headroom bound')
    guard()
    with measured_snapshot_decode(result['cold_decodes']):
        for index,(split,name,parent,tile) in enumerate(sequence):
            guard();identity=(parent['parent_id'],tile['tile_id']);first=identity not in seen
            before_peak=rss_peak_bytes();start=time.perf_counter()
            bank=cache(tile,cfg,parent,'cpu')
            elapsed=time.perf_counter()-start;after_cache_peak=rss_peak_bytes()
            guard();(cold if first else hot).append(elapsed)
            request={'index':index,'split':split,'model_identity':name,'parent_id':identity[0],'tile_id':identity[1],'cold':first,'cache_request_seconds':elapsed,'ru_maxrss_before_bytes':before_peak,'ru_maxrss_after_cache_bytes':after_cache_peak}
            result['requests'].append(request)
            if first:
                # Target-free original loader comparison, outside cache timing.
                comparison_upper=m.archive_storage_bytes_v2(cache.snapshots[identity])+m.transfer_upper_bytes_v1(bank)+max(t.numel()*t.element_size() for t in m._tensors(bank))
                require(comparison_upper<=limits['baseline_comparison_headroom_bytes'],'Original archive/field comparison tensor peak exceeds root separate headroom')
                start=time.perf_counter();baseline=m.BASE_LOAD_BANK(tile,cfg,parent,'cpu');baseline_seconds=time.perf_counter()-start
                baseline_size=m.resident_bytes_v1(baseline)
                require(baseline_size<=limits['baseline_comparison_headroom_bytes'],'Original baseline fixed-bank comparison exceeds root separate headroom')
                start=time.perf_counter();equal=field_signature(baseline)==field_signature(bank);parity_seconds=time.perf_counter()-start
                require(equal,'Original/snapshot complete bank fields/types/order/layout differ')
                result['bank_parity'].append({'parent_id':identity[0],'tile_id':identity[1],'bank_ref':dict(tile['bank']),'all_original_fields_exact':True,'baseline_loader_seconds':baseline_seconds,'field_comparison_seconds':parity_seconds,'baseline_fixed_resident_bytes':baseline_size,'baseline_comparison_tensor_upper_bytes':comparison_upper,'ru_maxrss_after_baseline_and_comparison_bytes':rss_peak_bytes()})
                baseline_times.append(baseline_seconds);parity_times.append(parity_seconds);del baseline
                seen.add(identity)
            require(m._rng_v1('cpu')==rng,'CPU bank load/comparison changed global RNG')
            del bank;guard()
    report=cache.report()
    require(len(seen)==32 and report['all_working_set_retained'] and report['retained_CPU_entries']==report['retained_snapshot_entries']==32,'All32 approved snapshots and CPU banks must remain retained')
    require([(x['parent_id'],x['tile_id']) for x in result['cold_decodes']]==[(x['parent_id'],x['tile_id']) for x in result['requests'] if x['cold']],'Exactly one measured cold decode per original first bank request required')
    stats=report['stats']
    require(stats['requests']==128 and stats['snapshot_reads']==stats['cold_snapshot_decodes']==32 and stats['CPU_hits']==96,'Original128 sequence must produce32 cold and96 hot requests')
    require(stats['CPU_evictions']==stats['CPU_oversized_bypass']==stats['GPU_evictions']==stats['GPU_oversized_bypass']==0 and stats['GPU_hits']==0,'CPU-only complete set must have no eviction/bypass or GPU use')
    require(cache.gpu_used==0 and not cache.gpu and not m.torch.cuda.is_initialized(),'CPU working-set caller cannot create CUDA state')
    guard();peak=rss_peak_bytes()
    result.update(status='complete32_CPU_working_set_and_target_free_fields_profile_complete',all32_verified_snapshots_and_decoded_CPU_banks_retained=True,all32_original_fields_exact=True,global_RNG_unchanged=True,ru_maxrss_peak_bytes=peak,remaining_root_RSS_headroom_bytes=limits['RSS_ceiling_bytes']-peak,root_limits=dict(limits),cache_before_close=report,
                  timing_seconds={'cold_snapshot_requests':summarize(cold),'cold_decode_only':summarize([x['seconds'] for x in result['cold_decodes']]),'hot_requests':summarize(hot),'original_baseline_loads':summarize(baseline_times),'target_free_field_comparisons':summarize(parity_times)},
                  bounds={'retained_snapshot_peak_bytes':stats['snapshot_peak_bytes'],'retained_decoded_CPU_tensor_peak_bytes':stats['CPU_peak_resident_bytes'],'cold_decode_tensor_stream_upper_bytes':stats['CPU_decode_peak_upper_bytes'],'root_baseline_comparison_headroom_bytes':limits['baseline_comparison_headroom_bytes'],'minimum_root_noncache_headroom_bytes':limits['minimum_headroom_bytes']},
                  actual_complete_working_set_RSS_and_cold_decode_headroom_qualified=False,qualification_scope='Measured actual resources/field equality if root-executed; root independently assesses watchdog/headroom and throughput. No neural parity, fitting, predictions, targets or accuracy claim.')
    return result

def validate_root_admission(a,cache_ref,now):
    require(a.get('schema')=='biological_bank_snapshot_cache_working_set_admission_v1' and a.get('status')=='active' and a.get('root_authorizer')=='root_agent','Fresh root working-set CPU admission required')
    require(m._utc(a['created_at_utc'])<=now<m._utc(a['expires_at_utc']) and (m._utc(a['expires_at_utc'])-m._utc(a['created_at_utc'])).total_seconds()<=86400,'Fresh bounded root admission dates required')
    require(a.get('caller_ref')==source_ref() and a.get('cache_admission_ref')==cache_ref and a.get('source_registration_ref')==REGISTRATION_REF,'Exact caller/cache phase/registration refs required')
    require(a.get('device')=='cpu' and a.get('observed_CPU_profile_authorized') is True and all(a.get(k) is False for k in ('models_authorized','scientific_fit_authorized','target_access_authorized','GPU_authorized')),'Only target-free CPU bank working-set profiling authorized')
    require(a.get('external_RSS_watchdog_started') is True and a.get('row_resource_admission_ref') and a.get('job_id') and a.get('output_directory'),'Root row/resource admission and external RSS watchdog required')
    limits=a['limits']
    require(set(limits)=={'RSS_ceiling_bytes','minimum_headroom_bytes','baseline_comparison_headroom_bytes'} and all(type(x) is int and x>0 for x in limits.values()) and limits['minimum_headroom_bytes']<limits['RSS_ceiling_bytes'],'Explicit positive separate root RSS/comparison/headroom bounds required')
    return limits

def execute(root_ref,cache_ref):
    require(os.environ.get('CUDA_VISIBLE_DEVICES')=='','Explicit empty CUDA visibility required')
    root=m.verified_json_v2(root_ref);limits=validate_root_admission(root,cache_ref,datetime.now(timezone.utc))
    m.verified_json_v2(REGISTRATION_REF);m.frozen.checked(root['row_resource_admission_ref'])
    require(hashlib.sha256((ROOT/CACHE_SOURCE_REF['path']).read_bytes()).hexdigest()==CACHE_SOURCE_REF['sha256'],'Registered cache source changed')
    cache,admission,ccfg=m.admit_cache_v2(cache_ref,phase='profile')
    output=m.frozen.path(root['output_directory'])
    result={'schema':'biological_bank_snapshot_cache_complete32_working_set_profile_v1','status':'initializing','root_admission_ref':root_ref,'cache_admission_ref':cache_ref,'caller_ref':source_ref(),'cache_source_ref':CACHE_SOURCE_REF,'cache_config_ref':CACHE_CONFIG_REF,'scientific_refs':{k:admission['refs'][k] for k in ('original_config','observed_manifest','prepared_manifest')},'seed':101,'reference_epoch':1,'models_instantiated':False,'scientific_fit_performed':False,'target_arrays_opened':False,'GPU_used':False,'root_limits':dict(limits),'external_RSS_watchdog_required':True}
    opened=False
    try:
        require(admission['device']=='cpu' and admission['job_id']==root['job_id'] and admission['output_directory']==root['output_directory'] and admission['refs']['cache_config']==CACHE_CONFIG_REF,'Same CPU job/output and exact cache config required')
        require(not output.exists(),'Exclusive new working-set result directory required')
        output.mkdir(parents=True);opened=True
        refs=admission['refs'];cfg,base,helpers=m.controls.load_protocol(m.frozen.path(refs['original_config']['path']),refs['original_config']['sha256'],m.controls.BASE_CONFIG_SHA256)
        parents=m.frozen.observed_contract(base,m.frozen.path(refs['observed_manifest']['path']),refs['observed_manifest']['sha256'],helpers)
        prepared=m.verified_json_v2(refs['prepared_manifest'])
        records=m.controls.validate_prepared_records(prepared,base,refs['observed_manifest']['sha256'],parents)
        original_guard=cache.active_guard
        def active():
            if original_guard:original_guard()
            require(datetime.now(timezone.utc)<m._utc(root['expires_at_utc']),'Root working-set phase expired')
        cache.active_guard=active
        return qualify_working_set(cache,cfg,parents,records,limits,result)
    except Exception as error:
        result.update(status='failed_partial_preserved',error_type=type(error).__name__,error=str(error),cache_before_close=cache.report(),ru_maxrss_peak_bytes=rss_peak_bytes())
        raise
    finally:
        try:cache.close()
        except Exception as error:
            result.update(status='failed_partial_preserved',error_type=type(error).__name__,error=str(error));raise
        finally:
            result['cache_closed']=cache.closed
            if opened:
                with (output/'working_set_profile.json').open('x') as stream:json.dump(result,stream,sort_keys=True,indent=2);stream.write(chr(10))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--root-admission');parser.add_argument('--expected-root-admission-sha256');parser.add_argument('--cache-admission');parser.add_argument('--expected-cache-admission-sha256')
    args=parser.parse_args()
    if not args.execute:print(json.dumps(source_report(),sort_keys=True,indent=2));return
    require(all((args.root_admission,args.expected_root_admission_sha256,args.cache_admission,args.expected_cache_admission_sha256)),'Both exact root and existing cache profile-phase admissions required')
    execute({'path':args.root_admission,'sha256':args.expected_root_admission_sha256},{'path':args.cache_admission,'sha256':args.expected_cache_admission_sha256})
if __name__=='__main__':main()
