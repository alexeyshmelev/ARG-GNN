"""Bounded handmade replay; no actual bank/data/model/targets/GPU."""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import importlib.util,json,os,random,sys,tempfile
from pathlib import Path
from unittest.mock import patch

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
OWN=ROOT/'research/reviews/biological_bank_snapshot_cache_v2_working_set_author'
os.environ['ARGGNN_SNAPSHOT_HANDMADE_OUTPUT']=str((OWN/'fixture_factory').relative_to(ROOT))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
q=load('working_set_caller',OWN/'caller.py')
h=load('working_set_handmade_fixture',ROOT/'research/reviews/biological_bank_snapshot_cache_v2_author/handmade_checks.py')
checks=[]
def check(name,value):
    if not value:raise AssertionError(name)
    checks.append({'name':name,'PASS':True})
def reject(name,fn,fragment=''):
    try:fn()
    except ValueError as e:check(name,fragment in str(e));return
    raise AssertionError(name+': did not reject')
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+chr(10));return h.ref(p)
def main():
    check('empty_CUDA_visibility',os.environ.get('CUDA_VISIBLE_DEVICES')=='')
    h.torch.set_num_threads(1)
    data=h.setup();parents,tiles,cfg,prep,cref,obs=data;records={p['parent_id']:{'parent_id':p['parent_id'],'tiles':tiles[p['parent_id']]} for p in parents}
    order=q.request_order(parents,records)
    original_tiles=[(p,t) for p in parents if p['split']=='train' for t in records[p['parent_id']]['tiles']]
    shuffled=list(range(16));random.Random(101+1).shuffle(shuffled)
    independent=[('TRAIN',None,original_tiles[i][0]['parent_id'],original_tiles[i][1]['tile_id']) for i in shuffled]
    independent += [('VAL',name,p['parent_id'],t['tile_id']) for name in q.m.controls.CONTROL_NAMES for p in parents if p['split']=='val' for t in records[p['parent_id']]['tiles']]
    check('all128_exact_original_seed101_epoch1_order',[(s,n,p['parent_id'],t['tile_id']) for s,n,p,t in order]==independent)
    rng=q.m._rng_v1('cpu');q.request_order(parents,records)
    check('local_TRAIN_shuffle_preserves_global_RNG',q.m._rng_v1('cpu')==rng)
    limits={'RSS_ceiling_bytes':1_000_000_000_000,'minimum_headroom_bytes':64_000_000,'baseline_comparison_headroom_bytes':1_000_000_000}
    c=h.cache(data);decoder=q.m.decode_bank_snapshot_v2;result={'fixture_mode':True}
    try:q.qualify_working_set(c,cfg,parents,records,limits,result)
    finally:c.close()
    check('working_set_fixture_complete',result['status']=='complete32_CPU_working_set_and_target_free_fields_profile_complete')
    check('all32_field_comparisons_and_retention',len(result['bank_parity'])==32 and result['all32_original_fields_exact'] and result['all32_verified_snapshots_and_decoded_CPU_banks_retained'])
    check('all128_identity_records_exact',[(x['split'],x['model_identity'],x['parent_id'],x['tile_id']) for x in result['requests']]==independent)
    check('32_cold96_hot_only32_decode_measurements',result['timing_seconds']['cold_snapshot_requests']['count']==32 and result['timing_seconds']['hot_requests']['count']==96 and len(result['cold_decodes'])==32)
    check('cache32_reads32_decodes96_hits128_requests',result['cache_before_close']['stats']['snapshot_reads']==32 and result['cache_before_close']['stats']['cold_snapshot_decodes']==32 and result['cache_before_close']['stats']['CPU_hits']==96 and result['cache_before_close']['stats']['requests']==128)
    check('decode_timer_restores_original_decoder',q.m.decode_bank_snapshot_v2 is decoder)
    check('cold_decode_timing_inside_request_timing',all(a['seconds']<=b['cache_request_seconds'] for a,b in zip(result['cold_decodes'],[x for x in result['requests'] if x['cold']])))
    check('separate_baseline_parity_and_peak_records',len(result['bank_parity'])==32 and all(x['baseline_comparison_tensor_upper_bytes']>0 and x['ru_maxrss_after_baseline_and_comparison_bytes']>0 for x in result['bank_parity']))
    check('RSS_positive_headroom_recorded',result['ru_maxrss_peak_bytes']>0 and result['remaining_root_RSS_headroom_bytes']>=limits['minimum_headroom_bytes'])
    check('no_auto_actual_qualification_claim',result['actual_complete_working_set_RSS_and_cold_decode_headroom_qualified'] is False)
    check('global_RNG_and_CPU_only_preserved',result['global_RNG_unchanged'] and q.m._rng_v1('cpu')==rng and not h.torch.cuda.is_initialized())
    partial=deepcopy(records);partial[parents[0]['parent_id']]['tiles'].pop()
    reject('missing_tile_fails_instead_of_reduced_working_set',lambda:q.request_order(parents,partial),'eight')
    c=h.cache(data,cpu=1)
    try:reject('capacity_shortage_fails_no_reduced_set',lambda:q.qualify_working_set(c,cfg,parents,records,limits,{}),'capacity')
    finally:c.close()
    check('failure_restores_decode_timer',q.m.decode_bank_snapshot_v2 is decoder)
    c=h.cache(data)
    try:
        with patch.object(q,'rss_peak_bytes',return_value=limits['RSS_ceiling_bytes']):
            reject('RSS_guard_stops_before_snapshot',lambda:q.qualify_working_set(c,cfg,parents,records,limits,{}),'RSS')
        check('RSS_failure_no_bank_read',c.stats['snapshot_reads']==0)
    finally:c.close()
    c=h.cache(data)
    try:reject('separate_baseline_headroom_guard',lambda:q.qualify_working_set(c,cfg,parents,records,{**limits,'baseline_comparison_headroom_bytes':1},{}),'headroom')
    finally:c.close()
    check('comparison_failure_restores_decode_timer',q.m.decode_bank_snapshot_v2 is decoder)
    path=OWN/'fixture_profile.json';dump(path,result)
    # Execute wrapper uses only patched handmade observed joins and fresh owned metadata.
    runs=OWN/'runs';runs.mkdir(exist_ok=True)
    now=datetime.now(timezone.utc);capref={'path':'handmade_cache_phase','sha256':'a'*64}
    a={'schema':'biological_bank_snapshot_cache_working_set_admission_v1','status':'active','root_authorizer':'root_agent','created_at_utc':now.isoformat(),'expires_at_utc':(now+timedelta(hours=1)).isoformat(),'caller_ref':q.source_ref(),'cache_admission_ref':capref,'source_registration_ref':q.REGISTRATION_REF,'device':'cpu','observed_CPU_profile_authorized':True,'models_authorized':False,'scientific_fit_authorized':False,'target_access_authorized':False,'GPU_authorized':False,'external_RSS_watchdog_started':True,'row_resource_admission_ref':dump(OWN/'handmade_row.json',{'handmade':True}),'job_id':'handmade_working_set','output_directory':'placeholder','limits':limits}
    check('root_metadata_accepts_exact_owned_CPU_case',q.validate_root_admission(a,capref,now)==limits)
    for name,change in [('old_schema',{'schema':'biological_bank_cache_admission_v1'}),('caller_pin',{'caller_ref':{'path':q.SOURCE_PATH,'sha256':'0'*64}}),('GPU_device',{'device':'cuda'}),('models',{'models_authorized':True}),('fit',{'scientific_fit_authorized':True}),('targets',{'target_access_authorized':True}),('GPU',{'GPU_authorized':True}),('watchdog',{'external_RSS_watchdog_started':False}),('expired',{'expires_at_utc':(now-timedelta(seconds=1)).isoformat()})]:
        reject('root_gate_'+name,lambda change=change:q.validate_root_admission({**a,**change},capref,now))
    def execute_case(case,tamper=False):
        directory=Path(tempfile.mkdtemp(prefix=case+'_',dir=runs));output=directory/'exclusive_output';rootcap={**a,'output_directory':str(output.relative_to(ROOT))}
        rootref=dump(directory/'root_admission.json',rootcap);cache=h.cache(data)
        adm={'device':'cpu','job_id':a['job_id'],'output_directory':rootcap['output_directory'],'refs':{'cache_config':q.CACHE_CONFIG_REF,'original_config':cref,'observed_manifest':obs,'prepared_manifest':prep}}
        original_loader=q.m.BASE_LOAD_BANK
        def bad_loader(*args,**kwargs):
            bank=original_loader(*args,**kwargs);bank.num_scales=7;return bank
        with patch.object(q.m,'admit_cache_v2',return_value=(cache,adm,{})),patch.object(q.m.controls,'load_protocol',return_value=(cfg,cfg,None)),patch.object(q.m.frozen,'observed_contract',return_value=parents),patch.object(q.m.controls,'validate_prepared_records',return_value=records),patch.object(q.m,'BASE_LOAD_BANK',side_effect=bad_loader if tamper else original_loader),patch.object(q.m.controls,'model_factory',side_effect=AssertionError('production model factory forbidden')):
            if tamper:reject('execute_field_failure_propagates',lambda:q.execute(rootref,capref),'fields')
            else:q.execute(rootref,capref)
        stored=json.loads((output/'working_set_profile.json').read_bytes())
        check(case+'_exclusive_receipt_and_closed_cache',stored['cache_closed'] and cache.closed and not cache.cpu and not cache.snapshots)
        check(case+'_preserved_status',stored['status']==('failed_partial_preserved' if tamper else 'complete32_CPU_working_set_and_target_free_fields_profile_complete'))
        check(case+'_no_models_targets_fit_GPU',stored['models_instantiated'] is stored['scientific_fit_performed'] is stored['target_arrays_opened'] is stored['GPU_used'] is False)
        check(case+'_decoder_restored',q.m.decode_bank_snapshot_v2 is decoder)
    execute_case('success');execute_case('field_failure',tamper=True)
    check('source_report_stays_inactive',q.source_report()['status']=='inactive_source_and_handmade_only')
    report={'schema':'biological_bank_snapshot_cache_working_set_caller_handmade_checks_v1','status':'PASS','checks_count':len(checks),'checks':checks,'actual_data_banks_models_targets_GPU_fits_resources_or_Git':False,'owned_handmade_only':True,'working_set_fixture_profile_ref':h.ref(path)}
    dump(OWN/'handmade_checks.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},sort_keys=True))
if __name__=='__main__':main()
