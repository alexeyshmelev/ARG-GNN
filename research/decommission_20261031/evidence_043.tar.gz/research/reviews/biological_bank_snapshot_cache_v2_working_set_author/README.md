# Complete32 CPU working-set qualification caller

The inactive caller reuses the source-reviewed snapshot-cache V2 profile-phase admission and exact original observed/prepared joins. An additional fresh root CPU-only caller admission pins this source, the source registration and that existing cache admission. It binds the same job and exclusive output, a root row/resource record, a started external RSS watchdog, an RSS ceiling, minimum noncache headroom and separate original-baseline comparison headroom. The author has not created or activated any resource reservation.

The sequence uses the genuine first-epoch TRAIN order: construct original TRAIN parent/tile pairs and shuffle indexes with local random.Random(101+1). Then iterate original CONTROL_NAMES with original VAL parents/tiles in model-outer order. It records every identity for all128 requests over all32 banks. It requires32 first reads/decodes,96 hits, all32 snapshots and decoded CPU banks retained, and no eviction/bypass/GPU actions. Missing tiles or insufficient capacity fail instead of reducing the working set.

Each first bank compares complete original fields against the unchanged BASE_LOAD_BANK result on CPU. The comparison includes exact tensor values, dtype/shape/stride/storage offset, dataclass type/field order, dict/list/tuple order and primitive/float values. Baseline loading and field hashing occur outside cache-request timing. The caller records cold request time, separately timed reviewed snapshot decode time, hot request time, original baseline load and field-comparison time. A timing-only scoped decoder wrapper delegates to the unchanged reviewed implementation and restores the alias even on failure.

RSS is Linux ru_maxrss converted from KiB to bytes. Before and after requests/comparison, the caller checks peak RSS plus root minimum headroom against the root ceiling. This polling is supplemental to the required root external watchdog and cannot catch allocations before they occur. The profile records retained snapshot/decoded tensor peaks, the cache cold decode stream/tensor upper bound, a conservative baseline archive/transfer/contiguous-field tensor bound, and remaining RSS headroom. Metadata/deserialization/runtime/allocator overhead remains root-qualified separately. The completion receipt records measured evidence and leaves the final actual memory/throughput qualification flag false for root assessment.

No neural model, optimizer, fit, target access, scoring, prediction compression or GPU is part of this caller. Original scientific and cache source files remain unchanged. The source-only author used41 handmade checks including original order/counts, complete retention/equality, scoped timer restoration, RSS/comparison/capacity failures, root admission scope, successful exclusive receipts and failed partial receipts.

Default source report:

    CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 .runtime/env/bin/python -B research/reviews/biological_bank_snapshot_cache_v2_working_set_author/caller.py

Root-only future execution, after actual authorization:

    CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 .runtime/env/bin/python -B research/reviews/biological_bank_snapshot_cache_v2_working_set_author/caller.py --execute --root-admission ROOT_PATH --expected-root-admission-sha256 ROOT_SHA --cache-admission ROOT_PROFILE_PATH --expected-cache-admission-sha256 ROOT_PROFILE_SHA

All result writes use a new exclusive root output. Failures preserve a partial working_set_profile.json and close the cache. Root owns CPU watchdog, resource/row admission, actual execution, assessment and Git.
