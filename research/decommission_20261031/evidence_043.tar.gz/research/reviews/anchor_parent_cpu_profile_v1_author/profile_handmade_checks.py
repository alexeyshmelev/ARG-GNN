
from pathlib import Path
from datetime import datetime,timezone
import ast,copy,hashlib,json,types
ROOT=Path.cwd();D=ROOT/"research/reviews/anchor_parent_cpu_profile_v1_author"
S=ROOT/"src/arggnn/anchor_parent_cpu_profile_v1.py";C=ROOT/"configs/anchor_parent_cpu_profile_v1.json"
cfg=json.loads(C.read_bytes());tree=ast.parse(S.read_text());records=[]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(name,fn,deny=False):
 try:fn()
 except Exception as error:
  if not deny:raise
  records.append({"case":name,"status":"PASS_expected_rejection","error_type":type(error).__name__})
 else:
  if deny:raise AssertionError(name+" accepted")
  records.append({"case":name,"status":"PASS"})
check("exact_source_registration_precedes_checks",lambda:None if digest(ROOT/cfg["root_registration_ref"]["path"])==cfg["root_registration_ref"]["sha256"]=="028fc72955d6346c2df33e82a5e1f04ea4010de52bd9a7bb6eca037444b69f56" else (_ for _ in ()).throw(AssertionError()))
check("fixed16_unique_cells",lambda:None if len(cfg["matrix"])==len({c["id"] for c in cfg["matrix"]})==16 else (_ for _ in ()).throw(AssertionError()))
check("complete_cartesian_cell_matrix",lambda:None if {(c["geometry"],c["mode"],c["dtype"],c["checkpoint_blocks"]) for c in cfg["matrix"]}=={(g,m,d,cp) for g in ("age","plain") for m in ("reset","carry") for d in ("float32","float64") for cp in (False,True)} else (_ for _ in ()).throw(AssertionError()))
check("inherited_tolerances_exact",lambda:None if cfg["qualification"]==json.loads((ROOT/"configs/anchor_parent_context_v3.json").read_bytes())["qualification"] else (_ for _ in ()).throw(AssertionError()))
check("all_baseline_source_pins_unchanged",lambda:None if all(digest(ROOT/p)==h for p,h in cfg["source_pins"].items()) else (_ for _ in ()).throw(AssertionError()))
check("full_readout_serialization_bound",lambda:None if cfg["serialization_bound"]["raw_output_context_bytes"]==25_710_305_280 and cfg["serialization_bound"]["total_serialized_bound_bytes"]==36_994_752_512<40_000_000_000 else (_ for _ in ()).throw(AssertionError()))
ns={"datetime":datetime,"timezone":timezone,"CONFIG_PATH":"configs/anchor_parent_cpu_profile_v1.json","CONFIG_SHA256":digest(C)}
wanted={"require","utc","validate_admission_metadata_v1"}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted],type_ignores=[]),"<stdlib handmade admission metadata>","exec"),ns)
a=json.loads((D/"prospective_admission.template.json").read_bytes())
a.update(status="active",observed_profile_authorized=True,created_at_utc="2026-10-11T06:00:00+00:00",expires_at_utc="2026-10-11T07:00:00+00:00",
 job_id="handmade-cell",matrix_job_id="handmade-matrix",matrix_output_directory="fixture/matrix",output_directory="fixture/matrix/"+cfg["matrix"][0]["id"],
 initial_state_sha256="a"*64,external_watchdog=True,sequential_full_parent_cell=True)
now=datetime(2026,10,11,6,10,tzinfo=timezone.utc)
check("pure_metadata_full_first_cell_admitted",lambda:ns["validate_admission_metadata_v1"](a,cfg,now))
for name,mutate in [
 ("inactive",lambda x:x.update(status="inactive")),("fit_authority_forbidden",lambda x:x.update(scientific_fit_authorized=True)),
 ("supervised_loss_forbidden",lambda x:x.update(supervised_loss_authorized=True)),("GPU_forbidden",lambda x:x.update(GPU_authorized=True)),
 ("profile_false",lambda x:x.update(observed_profile_authorized=False)),("wrong_parent_cell",lambda x:x.update(cell_id="val_tile")),
 ("missing_reference_cell",lambda x:x.update(cell_id=cfg["matrix"][1]["id"])),
 ("extra_reference",lambda x:x["comparison_refs"].update(fake={})),("different_runtime",lambda x:x["refs"]["runtime"].update(sha256="0"*64)),
 ("different_observed_report",lambda x:x["refs"]["observed_report"].update(sha256="0"*64)),
 ("different_observed_binding",lambda x:x["refs"]["producer_binding"].update(sha256="0"*64)),
 ("different_config",lambda x:x["refs"]["config"].update(sha256="0"*64)),("smaller_headroom",lambda x:x.update(CPU_headroom_bytes=64_000_000_000)),
 ("no_watchdog",lambda x:x.update(external_watchdog=False)),("parallel_cell_denied",lambda x:x.update(sequential_full_parent_cell=False)),
 ("bad_init_SHA",lambda x:x.update(initial_state_sha256="bad")),("wrong_scope",lambda x:x.update(output_directory="fixture/out")),
 ("extra_admission_field",lambda x:x.update(relax_tolerance=True)),("expired",lambda x:x.update(expires_at_utc=now.isoformat())),
 ("future",lambda x:x.update(created_at_utc="2026-10-11T06:11:00+00:00")),
 ("oversized_lifetime",lambda x:x.update(expires_at_utc="2026-10-13T07:00:00+00:00"))]:
 b=copy.deepcopy(a);mutate(b);check("admission_"+name,lambda b=b:ns["validate_admission_metadata_v1"](b,cfg,now),True)
# Import profile math helpers only. No actual producer or model_factory call.
from arggnn import anchor_parent_cpu_profile_v1 as profile
import torch
torch.set_num_threads(1)
class HandmadeModel(torch.nn.Module):
 def __init__(self,dtype):
  super().__init__()
  self.weight=torch.nn.Parameter(torch.linspace(-.23,.37,12,dtype=dtype).reshape(3,4))
  self.rate=torch.nn.Parameter(torch.tensor([.13,-.17,.29],dtype=dtype))
 def forward(self,x):
  h=x*(1+self.rate)
  return h@self.weight,types.SimpleNamespace(anchors=h[:2],targets=h)
def optimizer(model):
 return torch.optim.AdamW([{"params":[model.weight],"weight_decay":.0001},{"params":[model.rate],"weight_decay":0.}],lr=.001)
widths=torch.tensor([80.,100.,13.],dtype=torch.float64)
outputs={}
for dtype in (torch.float64,torch.float32):
 x=torch.linspace(-.4,.7,18,dtype=dtype).reshape(3,2,3)
 results={}
 for matched in (False,True):
  model=HandmadeModel(dtype);opt=optimizer(model)
  results[matched],timing=profile.execute_method_v1(model,opt,lambda:model(x),widths,matched=matched)
  check("handmade_"+str(dtype)+"_"+str(matched)+"_all_raw_clipped_state_finite",lambda:profile.snapshot_v1(results[matched]))
  check("handmade_"+str(dtype)+"_"+str(matched)+"_exact_step1",lambda:None if all(float(s["step"])==1 for s in results[matched]["optimizer"]["state"].values()) else (_ for _ in ()).throw(AssertionError()))
 profile.compare_records_v1(results[True],results[False],cfg["qualification"][str(dtype).split(".")[-1]])
 check("handmade_"+str(dtype)+"_matched_manual_full_output_VJP_clipped_AdamW_parity",lambda:None)
 outputs[str(dtype)]=results
for matched in (False,True):
 check("handmade_FP32_FP64_complete_output_VJP_and_state_"+str(matched),
  lambda matched=matched:profile.compare_records_v1(outputs["torch.float32"][matched],outputs["torch.float64"][matched],cfg["qualification"]["float32"],cross_dtype=True))
for matched in (False,True):
 model=HandmadeModel(torch.float64);opt=optimizer(model);before=profile.snapshot_v1(model.state_dict())
 def dirty():
  model.rate.grad=torch.zeros_like(model.rate)
  return model(torch.ones(3,2,3,dtype=torch.float64))
 check("handmade_callback_grad_contamination_"+str(matched),
  lambda:profile.execute_method_v1(model,opt,dirty,widths,matched=matched),True)
 check("handmade_contaminated_no_parameter_update_"+str(matched),lambda:profile.assert_tree_close_v1(model.state_dict(),before,cfg["qualification"]["float64"]))
 check("handmade_contaminated_no_AdamW_state_"+str(matched),lambda:None if not opt.state else (_ for _ in ()).throw(AssertionError()))
for matched in (False,True):
 model=HandmadeModel(torch.float64);opt=optimizer(model)
 def missing():
  h=torch.ones(3,2,3,dtype=torch.float64)
  return h@model.weight,types.SimpleNamespace(anchors=h[:2],targets=h)
 check("handmade_missing_active_path_not_discovered_into_exemption_"+str(matched),
  lambda:profile.execute_method_v1(model,opt,missing,widths,matched=matched),True)
 check("handmade_missing_path_no_update_"+str(matched),lambda:None if not opt.state else (_ for _ in ()).throw(AssertionError()))
for matched in (False,True):
 model=HandmadeModel(torch.float64);opt=optimizer(model)
 def zero():
  h=(model.rate.sum()+model.weight.sum())*torch.zeros(3,2,3,dtype=torch.float64)
  logits=(model.rate.sum()+model.weight.sum())*torch.zeros(3,2,4,dtype=torch.float64)
  return logits,types.SimpleNamespace(anchors=h[:2],targets=h)
 value,_=profile.execute_method_v1(model,opt,zero,widths,matched=matched)
 check("handmade_connected_zero_VJP_is_legitimate_"+str(matched),lambda:None if all(torch.count_nonzero(g)==0 for g in value["raw_VJP"].values()) else (_ for _ in ()).throw(AssertionError()))
model=HandmadeModel(torch.float64);opt=optimizer(model);opt.state[model.weight]["step"]=torch.tensor(1.)
check("handmade_stale_optimizer_state_denied",lambda:profile.execute_method_v1(model,opt,lambda:model(torch.ones(3,2,3,dtype=torch.float64)),widths,matched=True),True)
for label,w in [("zero_bp",torch.tensor([80.,0.,13.],dtype=torch.float64)),("negative_bp",torch.tensor([80.,-1.,13.],dtype=torch.float64)),
 ("partial_bp",widths[:2]),("wrong_bp_dtype",widths.float())]:
 check("synthetic_objective_"+label,lambda w=w:profile.synthetic_numerator_v1(torch.ones(3,2,4,dtype=torch.float64),w),True)
bad=copy.deepcopy(outputs["torch.float64"][True]);bad["optimizer"]["state"]["rate"].pop("exp_avg_sq")
check("full_optimizer_moment_key_correspondence_required",lambda:profile.compare_records_v1(bad,outputs["torch.float64"][False],cfg["qualification"]["float64"]),True)
check("no_whole_project_scan_or_mutating_budget_API",lambda:None if not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ("reserve","measure_scopes","current","legacy_state") for n in ast.walk(tree)) else (_ for _ in ()).throw(AssertionError()))
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
check("unchanged_full_producer_qualification_delegated",lambda:None if sum(n.func.attr=="qualify_observed_v1" for n in calls)==1 else (_ for _ in ()).throw(AssertionError()))
check("unchanged_model_optimizer_factory_delegated",lambda:None if sum(n.func.attr=="original_model_optimizer_v1" for n in calls)==1 else (_ for _ in ()).throw(AssertionError()))
check("unchanged_full_parent_forward_delegated",lambda:None if sum(n.func.attr=="forward_parent_v1" for n in calls)==1 else (_ for _ in ()).throw(AssertionError()))
# Sticky rejection is tested before any runtime or budget path can be reached.
class DenialReader:
 def __init__(self):self.calls=0;self.value=copy.deepcopy(a);self.value["status"]="inactive"
 def json(self,record):self.calls+=1;return self.value
fake=DenialReader();authority=object.__new__(profile.AuthorityV1)
authority.reader=fake;authority.ref={"path":"fixture/not_written.json","sha256":"a"*64}
authority.cfg=cfg;authority.denied=False;authority.first=True;authority.a=None;authority.cell=None
check("sticky_initial_metadata_denial_latches",authority.check,True)
fake.value["status"]="active";before_calls=fake.calls;scope_writes=[]
def restored_write():
 authority.check();scope_writes.append("forbidden")
check("sticky_restored_metadata_cannot_write",restored_write,True)
check("sticky_reject_does_not_reread_or_write",lambda:None if fake.calls==before_calls and scope_writes==[] else (_ for _ in ()).throw(AssertionError()))
check("all_serialized_state_and_context_records_are_detached",lambda:None if all(not value.requires_grad for record in outputs["torch.float64"].values() for value in (record["logits"],record["anchors"],record["targets"],*record["raw_VJP"].values(),*record["clipped_gradients"].values())) else (_ for _ in ()).throw(AssertionError()))

for p,h in cfg["source_pins"].items():assert digest(ROOT/p)==h
proof={"kind":"anchor_parent_CPU_profile_unchanged_scientific_core_source_proof",
 "producer_source_ref":cfg["producer_source_ref"],"core_source_ref":cfg["core_source_ref"],
 "original_source_pins":cfg["source_pins"],"all_pins_before_and_after_equal":True,
 "qualification_exactly_inherited":True,"fixed_matrix":cfg["matrix"],"fixed_inactive_parameter_names":[],
 "actual_model_factory_or_actual_parent_invocation_in_handmade_checks":False,
 "production_qualify_original_model_optimizer_and_forward_delegation_verified":True,
 "no_mutating_budget_or_global_scan_call":True}
(D/"source_proof.json").write_text(json.dumps(proof,sort_keys=True,indent=2)+"\n")
(D/"handmade_checks.json").write_text(json.dumps({"kind":"anchor_parent_CPU_profile_handmade_checks","status":"PASS","total":len(records),
 "records":records,"actual_arrays_or955_tree_model_or_profile":False,"handmade_model":"two small parameter tensors only; not original production model",
 "GPU_or_live_budget_or_Git":False},sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":"PASS","handmade_checks":len(records),"source_sha256":digest(S),"config_sha256":digest(C),
 "actual_inputs_models_profile_budget_GPU_Git":False},indent=2))
