"""Root sequential supervisor for the complete accepted H024 CPU matrix."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, signal, subprocess, sys, time, traceback

ROOT = Path("/workspace-SR003.nfs2/ARG-GNN")
BASE = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_root"
PY = ROOT/".runtime/env/bin/python"

def digest(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()

def reference(path):
    path=Path(path)
    path.resolve().relative_to(ROOT)
    return {"path":str(path.relative_to(ROOT)),"sha256":digest(path)}

def verified(ref):
    p=ROOT/ref["path"]
    if p.is_symlink() or p.resolve()!=p: raise ValueError("Noncanonical frozen input")
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=ref["sha256"]: raise ValueError("Frozen input changed")
    return json.loads(raw)

def write(path,value):
    path=Path(path)
    path.resolve().relative_to(ROOT)
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("x") as f: json.dump(value,f,indent=2,allow_nan=False);f.write("\n")
    return reference(path)

def identity(pid):
    p=Path("/proc")/str(pid)
    x=(p/"stat").read_text().rsplit(")",1)[1].split()
    return {"pid":pid,"start_ticks":int(x[19]),"uid":p.stat().st_uid}

def stop_child(p,saved):
    if p.poll() is not None: return
    fd=os.pidfd_open(p.pid)
    try:
        if identity(p.pid)!=saved: raise ValueError("Child identity drift")
        signal.pidfd_send_signal(fd,signal.SIGTERM)
        try: p.wait(timeout=10)
        except subprocess.TimeoutExpired: signal.pidfd_send_signal(fd,signal.SIGKILL);p.wait(timeout=10)
    finally: os.close(fd)

def run(plan_ref,source_sha):
    if digest(Path(__file__))!=source_sha: raise ValueError("Supervisor source changed")
    plan=verified(plan_ref)
    if plan["kind"]!="root_anchor_parent_CPU_matrix_plan_v2" or plan["active"] is not True:
        raise ValueError("Inactive plan")
    registration=verified(plan["registration"])
    if registration["observed_input_CPU_numerical_profile_authorized"] is not True or registration["supervised_fit_authorized"] is not False:
        raise ValueError("Numerical scope not authorized")
    cfg=verified(plan["config"]); initial=verified(plan["external_initial_states"])
    review=verified(plan["review"])
    if review["verdict"]!="PASS" or review["implementation"]!=plan["source"] or review["config"]!=plan["config"]:
        raise ValueError("Exact source review absent")
    if plan["matrix"]!=cfg["matrix"] or plan["CPU_headroom_bytes"]!=128000000000 or plan["reservation"]["reserved_bytes"]!=40000000000:
        raise ValueError("Complete original matrix/resource bounds changed")
    if os.environ.get("CUDA_VISIBLE_DEVICES")!="" or os.environ.get("PYTHONDONTWRITEBYTECODE")!="1":
        raise ValueError("Original CPU-only environment absent")
    from arggnn import project_budget_v4 as budget
    from arggnn.anchor_parent_cpu_profile_v2 import load_config_v1,validate_admission_metadata_v1
    if load_config_v1()!=cfg: raise ValueError("Accepted protocol changed")
    started=time.monotonic()
    write(BASE/"matrix_started.json",{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"supervisor":identity(os.getpid()),"plan":plan_ref,"source_sha256":source_sha})
    completed={}
    child=None;saved=None;current=None
    try:
        for cell in plan["matrix"]:
            current=cell["id"]
            if time.monotonic()-started>plan["matrix_max_seconds"]: raise TimeoutError("Whole-matrix watchdog")
            for ref in [plan["source"],plan["config"],plan["review"],plan["external_initial_states"]]: verified(ref) if ref!=plan["source"] else None
            if digest(ROOT/plan["source"]["path"])!=plan["source"]["sha256"]: raise ValueError("Accepted profile source drift")
            c,b=budget.policy(ROOT,cfg["budget_source_ref"]["sha256"],cfg["budget_config_ref"]["sha256"])
            with budget.mutex(ROOT): _,_,view=budget.current(ROOT,c,b)
            now=datetime.datetime.now(datetime.timezone.utc);expiry=now+datetime.timedelta(hours=23)
            storage={"schema":"anchor_parent_CPU_profile_storage_v1","status":"active","job_id":plan["matrix_job_id"],"created_at_utc":now.isoformat(),"expires_at_utc":expiry.isoformat(),"reservation":plan["reservation"],"initial_ledger_pins":{k:view[k] for k in ("legacy_ledger_sha256","supplemental_ledger_sha256")}}
            storage_ref=write(BASE/"cells"/(current+".storage.json"),storage)
            comparison={k:{name:completed[k][name] for name in ("evidence","terminal","manual_original","matched_parent_v3")} for k in cell["reference_cells"]}
            a=verified(plan["admission_template"])
            a.update(status="active",observed_profile_authorized=True,external_watchdog=True,sequential_full_parent_cell=True,
                     cell_id=current,job_id=plan["matrix_job_id"]+"/"+current,matrix_job_id=plan["matrix_job_id"],
                     matrix_output_directory=plan["matrix_output_directory"],output_directory=plan["matrix_output_directory"]+"/"+current,
                     created_at_utc=now.isoformat(),expires_at_utc=expiry.isoformat(),comparison_refs=comparison,
                     initial_state_sha256=initial["states"][cell["geometry"]+"_"+cell["dtype"]]["state_sha256"])
            a["refs"]["review"]=plan["review"];a["refs"]["storage"]=storage_ref
            validate_admission_metadata_v1(a,cfg,now)
            admission_ref=write(BASE/"cells"/(current+".admission.json"),a)
            budget.check_reservation(ROOT,plan["reservation"],expected_source_sha256=cfg["budget_source_ref"]["sha256"],
                                     expected_config_sha256=cfg["budget_config_ref"]["sha256"],initial_ledger_pins=storage["initial_ledger_pins"],boundary=True)
            command=[str(PY),"-B","-m","arggnn.anchor_parent_cpu_profile_v2","--execute","--admission",admission_ref["path"],"--expected-admission-sha256",admission_ref["sha256"]]
            with (BASE/"cells"/(current+".stdout")).open("xb") as stdout, (BASE/"cells"/(current+".stderr")).open("xb") as stderr:
                child=subprocess.Popen(command,cwd=ROOT,env=os.environ.copy(),stdout=stdout,stderr=stderr,start_new_session=True)
                saved=identity(child.pid)
                write(BASE/"cells"/(current+".started.json"),{"utc":now.isoformat(),"child":saved,"command":command,"admission":admission_ref})
                begin=time.monotonic();peak=0;reason=None
                while child.poll() is None:
                    try:
                        if identity(child.pid)!=saved: raise ValueError("Child identity drift")
                        status=(Path("/proc")/str(child.pid)/"status").read_text()
                        rss_values=[int(l.split()[1])*1024 for l in status.splitlines() if l.startswith("VmRSS:")]
                        if rss_values: peak=max(peak,rss_values[0])
                        if peak>plan["CPU_headroom_bytes"]: reason="128GB measured RSS boundary exceeded"
                        if time.monotonic()-begin>plan["cell_max_seconds"]: reason="Six-hour cell watchdog"
                        if time.monotonic()-started>plan["matrix_max_seconds"]: reason="Whole-matrix watchdog"
                        if reason: stop_child(child,saved);break
                    except FileNotFoundError:
                        if child.poll() is None: raise
                    time.sleep(1)
                rc=child.wait()
            write(BASE/"cells"/(current+".exit_observed.json"),{"cell":current,"returncode":rc,"watched_peak_RSS_bytes":peak,"watchdog_reason":reason,"child":saved,"elapsed_seconds":time.monotonic()-begin})
            if rc or reason: raise RuntimeError("Actual full-support cell failed: "+current)
            scope=ROOT/a["output_directory"]
            evidence_ref=reference(scope/"evidence.json");evidence=verified(evidence_ref)
            if evidence["status"]!="completed_full_support_observed_only_CPU_synthetic_numerical_cell" or evidence["cell"]!=cell or evidence["admission_ref"]!=admission_ref:
                raise ValueError("Terminal evidence not exact completed cell")
            candidate={"evidence":evidence_ref}
            for method in ("manual_original","matched_parent_v3"):
                ref=evidence["methods"][method]["artifact"]
                if reference(ROOT/ref["path"])!=ref: raise ValueError("Actual numerical artifact changed")
                candidate[method]=ref
            terminal={"kind":"anchor_parent_CPU_profile_root_terminal_v1","status":"complete","returncode":0,"job_id":a["job_id"],"cell_id":current,"evidence_ref":evidence_ref,"admission_ref":admission_ref}
            candidate["terminal"]=write(BASE/"cells"/(current+".terminal.json"),terminal)
            completed[current]=candidate
            child=None;saved=None
        write(BASE/"matrix_terminal.json",{"status":"completed_all16_full_support_CPU_cells","plan":plan_ref,"completed":completed,"elapsed_seconds":time.monotonic()-started,"GPU_used":False,"ancestry_targets_read":False,"scientific_fit_performed":False})
    except BaseException as error:
        if child is not None and saved is not None:stop_child(child,saved)
        write(BASE/"matrix_failure.json",{"status":"failed_partial_no_fallback","cell":current,"completed":completed,"error_type":type(error).__name__,"error":str(error),"elapsed_seconds":time.monotonic()-started})
        raise

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--execute",action="store_true");p.add_argument("--plan");p.add_argument("--expected-plan-sha256");p.add_argument("--expected-source-sha256")
    a=p.parse_args()
    if not a.execute: print(json.dumps({"scope":"root source-only sequential CPU supervisor","actual_execution":False}));return
    if not all((a.plan,a.expected_plan_sha256,a.expected_source_sha256)): raise ValueError("Exact root plan/source required")
    run({"path":a.plan,"sha256":a.expected_plan_sha256},a.expected_source_sha256)
if __name__=="__main__":
    try: main()
    except BaseException:traceback.print_exc(file=sys.stdout);raise
