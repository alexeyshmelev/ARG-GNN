"""Reproduce both H024 V1 hash/parse counterexamples in an owned fresh folder."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import ast,json,hashlib,io,os,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
OUT=Path(__file__).resolve().parent/"snapshot_reproduction"
OUT.mkdir(exist_ok=False)
SOURCE=ROOT/"src/arggnn/anchor_parent_cpu_profile_v1.py"
cfg=json.loads((ROOT/"configs/anchor_parent_cpu_profile_v1.json").read_bytes())
tree=ast.parse(SOURCE.read_text())
ns={"ROOT":ROOT,"Path":Path,"json":json,"datetime":datetime,"timezone":timezone,
 "CONFIG_PATH":"configs/anchor_parent_cpu_profile_v1.json","CONFIG_SHA256":hashlib.sha256((ROOT/"configs/anchor_parent_cpu_profile_v1.json").read_bytes()).hexdigest()}
wanted={"require","utc","validate_admission_metadata_v1"}
nodes=[n for n in tree.body if (isinstance(n,ast.FunctionDef) and n.name in wanted) or (isinstance(n,ast.ClassDef) and n.name=="ReaderV1")]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),"exec"),ns)
now=datetime.now(timezone.utc)
a=json.loads((ROOT/"research/reviews/anchor_parent_cpu_profile_v1_author/prospective_admission.template.json").read_bytes())
a.update(status="active",observed_profile_authorized=True,created_at_utc=(now-timedelta(minutes=1)).isoformat(),
 expires_at_utc=(now+timedelta(minutes=20)).isoformat(),job_id="handmade",matrix_job_id="handmade_matrix",
 matrix_output_directory=str(OUT.relative_to(ROOT))+"/matrix",initial_state_sha256="b"*64,
 external_watchdog=True,sequential_full_parent_cell=True)
a["output_directory"]=a["matrix_output_directory"]+"/"+a["cell_id"]
frozen=dict(a,status="inactive",initial_state_sha256="a"*64)
encode=lambda value:(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
path=OUT/"metadata_fixture.json";path.write_bytes(encode(frozen))
pin={"path":str(path.relative_to(ROOT)),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
def substitute(p):
 raw=Path(p).read_bytes();Path(p).write_bytes(encode(a));return hashlib.sha256(raw).hexdigest()
ns["sha"]=substitute
parsed=ns["ReaderV1"]().json(pin);ns["validate_admission_metadata_v1"](parsed,cfg,now)
assert parsed["status"]=="active" and parsed["initial_state_sha256"]=="b"*64
path.unlink()
def audit(event,args):
 if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0])
  if p.startswith("/proc/") or p.startswith(str(ROOT/"data")+"/") or p.startswith(str(ROOT/".runtime/conda")+"/"):
   raise AssertionError("actual data/proc/native prefix forbidden")
 if event in {"subprocess.Popen","os.kill","os.killpg","socket.connect"}:raise AssertionError("launch/signal/network forbidden")
sys.addaudithook(audit)
import torch
def tensor_raw(value):
 b=io.BytesIO();torch.save({"value":torch.tensor([value],dtype=torch.float64)},b);return b.getvalue()
original=tensor_raw(.5);replacement=tensor_raw(1.5)
path=OUT/"payload_fixture.pt";path.write_bytes(original)
pin={"path":str(path.relative_to(ROOT)),"sha256":hashlib.sha256(original).hexdigest()}
def substitute_tensor(p):
 raw=Path(p).read_bytes();Path(p).write_bytes(replacement);return hashlib.sha256(raw).hexdigest()
ns["sha"]=substitute_tensor
value=torch.load(ns["ReaderV1"]().path(pin),map_location="cpu",weights_only=True)
assert float(value["value"][0])==1.5
path.unlink()
print(json.dumps({"metadata_snapshot_unbound":True,"payload_snapshot_unbound":True,"actual_profile":False}))
