"""Narrow independent H024 V2 snapshot regression and arithmetic preservation."""
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone,timedelta
import ast,hashlib,io,json,os,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
OUT=Path(__file__).resolve().parent
F=OUT/"fresh_fixtures";F.mkdir()
S=ROOT/"src/arggnn/anchor_parent_cpu_profile_v2.py"
C=ROOT/"configs/anchor_parent_cpu_profile_v2.json"
A=ROOT/"research/reviews/anchor_parent_cpu_profile_v2_author"
OLD=ROOT/"src/arggnn/anchor_parent_cpu_profile_v1.py"
OLD_C=ROOT/"configs/anchor_parent_cpu_profile_v1.json"
CHECKS=[];CASES=[];HASHED={};BLOCKED=[]
def ck(name,value):
 CHECKS.append({"check":name,"passed":bool(value)})
 if not value:raise AssertionError(name)
def ref(path):
 raw=path.read_bytes();r={"path":str(path.relative_to(ROOT)),"sha256":hashlib.sha256(raw).hexdigest()}
 HASHED[r["path"]]={**r,"bytes":len(raw)};return r
def reject(name,call):
 try:call()
 except (ValueError,KeyError,FileNotFoundError,json.JSONDecodeError):
  ck(name,True)
 else:raise AssertionError(name+" accepted")
def audit(event,args):
 if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]);p=Path(name)
  if p.is_absolute() and (name.startswith(str(ROOT/"data")+"/") or name.startswith("/proc/") or name.startswith(str(ROOT/".runtime/conda")+"/")
   or name in {str(ROOT/".runtime/gpup/storage_reservations.json"),str(ROOT/".runtime/storage/project_budget_v4.json")}):
   BLOCKED.append({"event":event,"path":name});raise AssertionError("actual data/proc/ledger/native prefix forbidden")
 if event in {"subprocess.Popen","os.kill","os.killpg","socket.connect"}:BLOCKED.append({"event":event});raise AssertionError("actual launch/signal/network forbidden")
sys.addaudithook(audit)
pins={S:"e5a14ee8a82da635da0e41b319c61efd95cee1f584e0187f301e039731d398cb",
 C:"f12ec01d6179b4b98d228108d1469982fb684b579d899f9b54cd8080cd5f332f",
 A/"author_receipt.json":"0557b4366b48e524327a0f9107223c43f3ad8781920766320e7698f5879550ce",
 OLD:"39c7b130a57f56faab06c9f125d6d57503c313483f95e26f0d441342275a897e",
 OLD_C:"fe978db8dd5fc63c52ec8cb4944b08ccdfb0dc299d549d0ba92323cb030f93d6"}
for path,value in pins.items():ck("exact pin "+str(path.relative_to(ROOT)),ref(path)["sha256"]==value)
source=S.read_text();oldsource=OLD.read_text();tree=ast.parse(source);oldtree=ast.parse(oldsource)
cfg=json.loads(C.read_bytes());oldcfg=json.loads(OLD_C.read_bytes())
functions=lambda t:{n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
newfn=functions(tree);oldfn=functions(oldtree);dump=lambda n:ast.dump(n,include_attributes=False)
unchanged=("peak_RSS_bytes_v1","snapshot_v1","optimizer_snapshot_v1","assert_tree_close_v1","synthetic_numerator_v1",
 "execute_method_v1","tensor_bytes_v1","bind_reconstructed_parent_v1","write_artifact_v1","compare_records_v1","validate_admission_metadata_v1")
for name in unchanged:ck("unchanged numerical/protocol AST "+name,dump(newfn[name])==dump(oldfn[name]))
cell=deepcopy(newfn["run_cell_v1"])
loads=[n for n in ast.walk(cell) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=="torch" and n.func.attr=="load"]
ck("exact one prior payload load",len(loads)==1)
load=loads[0];buffer=load.args[0]
ck("prior loader wraps verified bytes",isinstance(buffer,ast.Call) and isinstance(buffer.func,ast.Attribute) and buffer.func.attr=="BytesIO" and buffer.func.value.id=="io"
 and buffer.args[0].func.attr=="read_verified_bytes")
ck("CPU weights_only preserved",{k.arg:ast.literal_eval(k.value) for k in load.keywords}=={"map_location":"cpu","weights_only":True})
verified=buffer.args[0]
load.args[0]=ast.Call(func=ast.Attribute(value=verified.func.value,attr="path",ctx=ast.Load()),args=verified.args,keywords=[])
ck("whole cell body arithmetic and gates unchanged except payload snapshot",dump(cell)==dump(oldfn["run_cell_v1"]))
changed={k for k in set(cfg)|set(oldcfg) if cfg.get(k)!=oldcfg.get(k)}
ck("only protocol version registration predecessor fields changed",changed=={"kind","root_registration_ref","predecessor"})
for key in ("full_support","matrix","qualification","optimizer","inactive_parameter_names","serialization_bound","source_pins","seed","matrix_output_cap_bytes","CPU_headroom_bytes"):
 ck("preserved full protocol "+key,cfg[key]==oldcfg[key])
ck("no filename JSON parser remaining",not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="read_text" for n in ast.walk(tree)))

def namespace(config_path,config_sha):
 ns={"ROOT":ROOT,"Path":Path,"json":json,"hashlib":hashlib,"datetime":datetime,"timezone":timezone,
  "CONFIG_PATH":config_path,"CONFIG_SHA256":config_sha}
 names={"require","utc","sha","validate_admission_metadata_v1","load_config_v1"}
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 nodes.append(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="ReaderV2"))
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(S),"exec"),ns)
 return ns
ns=namespace(str(C.relative_to(ROOT)),pins[C])
a=json.loads((A/"prospective_admission.template.json").read_bytes())
now=datetime.now(timezone.utc)
a.update(status="inactive",observed_profile_authorized=True,created_at_utc=(now-timedelta(minutes=1)).isoformat(),
 expires_at_utc=(now+timedelta(minutes=20)).isoformat(),job_id="handmade_v2",matrix_job_id="handmade_matrix",
 matrix_output_directory=str(F.relative_to(ROOT))+"/matrix",initial_state_sha256="a"*64,external_watchdog=True,sequential_full_parent_cell=True)
a["output_directory"]=a["matrix_output_directory"]+"/"+a["cell_id"]
newa=deepcopy(a);newa.update(status="active",initial_state_sha256="b"*64)
encode=lambda value:(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
p=F/"admission.json";original=encode(a);replacement=encode(newa);p.write_bytes(original)
pin={"path":str(p.relative_to(ROOT)),"sha256":hashlib.sha256(original).hexdigest()}
# Swap inside the real stream read boundary, before hashing/parsing, rather than after a helper call.
realopen=Path.open;opens=[]
class SwapStream:
 def __init__(self,stream,path,replacement):self.stream,self.path,self.replacement=stream,path,replacement
 def __enter__(self):self.stream.__enter__();return self
 def __exit__(self,*args):return self.stream.__exit__(*args)
 def read(self,n):
  data=self.stream.read(n)
  with realopen(self.path,"wb") as out:out.write(self.replacement)
  return data
def swap_open(path,*args,**kwargs):
 mode=args[0] if args else kwargs.get("mode","r")
 stream=realopen(path,*args,**kwargs)
 if path==p and mode=="rb":opens.append(mode);return SwapStream(stream,path,replacement)
 return stream
Path.open=swap_open
try:parsed=ns["ReaderV2"]().json(pin)
finally:Path.open=realopen
ck("metadata original inactive snapshot retained",parsed==a and parsed["initial_state_sha256"]=="a"*64)
ck("metadata exactly one content open",opens==["rb"])
reject("original inactive snapshot remains denied",lambda:ns["validate_admission_metadata_v1"](parsed,cfg,now))
reject("changed active bytes rejected on next read",lambda:ns["ReaderV2"]().json(pin))
CASES.append({"case":"inactive_admission_external_initSHA_substitution","original_initSHA":"a"*64,"replacement_initSHA":"b"*64,
 "parsed_initSHA":parsed["initial_state_sha256"],"parsed_status":parsed["status"],"content_opens":len(opens),
 "inactive_metadata_denied":True,"changed_file_denied_next_read":True})
# Protocol snapshot uses unchanged real config; no real config file is modified.
protocol=F/"protocol.json";good=C.read_bytes();protocol.write_bytes(good);badcfg=deepcopy(cfg);badcfg["CPU_headroom_bytes"]=1
cfg_ns=namespace(str(protocol.relative_to(ROOT)),hashlib.sha256(good).hexdigest())
method=cfg_ns["ReaderV2"].read_verified_bytes
def cfg_swap(self,record):
 raw=method(self,record)
 if record["path"]==str(protocol.relative_to(ROOT)):
  protocol.write_bytes(encode(badcfg))
 return raw
cfg_ns["ReaderV2"].read_verified_bytes=cfg_swap
loaded=cfg_ns["load_config_v1"]()
ck("whole frozen protocol retained after file substitution",loaded==cfg and loaded["CPU_headroom_bytes"]==128000000000)
reject("changed protocol rejected next load",lambda:cfg_ns["load_config_v1"]())
CASES.append({"case":"protocol_128GB_to1byte_substitution","parsed_headroom":loaded["CPU_headroom_bytes"],"replacement_headroom":1,
 "parsed_complete_protocol_original":True,"changed_protocol_denied_next_load":True})
# Recreate the precise V1 one-element tensor swap: V2 CPU loader must retain .5.
import torch
def tensor_raw(value):
 buffer=io.BytesIO();torch.save({"value":torch.tensor([value],dtype=torch.float64)},buffer);return buffer.getvalue()
p=F/"payload.pt";original=tensor_raw(.5);replacement=tensor_raw(1.5);p.write_bytes(original)
pin={"path":str(p.relative_to(ROOT)),"sha256":hashlib.sha256(original).hexdigest()}
opens=[];Path.open=swap_open
try:snapshot=ns["ReaderV2"]().read_verified_bytes(pin)
finally:Path.open=realopen
value=torch.load(io.BytesIO(snapshot),map_location="cpu",weights_only=True)
ck("one-element payload retains original .5 after file substitution",float(value["value"][0])==.5)
ck("payload exactly one content open",opens==["rb"])
reject("changed payload denied next snapshot",lambda:ns["ReaderV2"]().read_verified_bytes(pin))
CASES.append({"case":"one_element_CPU_payload_substitution","original":.5,"replacement":1.5,"loaded":float(value["value"][0]),
 "content_opens":1,"changed_file_denied_next_read":True,"production_model_instantiated":False})
# Exact metadata closure only; no native runtime files or parent inputs are scanned.
receipt=json.loads((A/"author_receipt.json").read_bytes())
for path,value in receipt["artifact_sha256"].items():ck("author sealed artifact "+path,ref(ROOT/path)["sha256"]==value)
for record in cfg["predecessor"].values():ck("preserved V1 seal "+record["path"],ref(ROOT/record["path"])==record)
ck("preserved V1 independent verdict REJECT",json.loads((ROOT/cfg["predecessor"]["independent_REJECT"]["path"]).read_bytes())["verdict"]=="REJECT")
ck("exact source-only root registration",ref(ROOT/cfg["root_registration_ref"]["path"])==cfg["root_registration_ref"])
ck("all numerical helpers remain backed by V1 independent66 replay",json.loads((ROOT/"research/reviews/anchor_parent_cpu_profile_v1_independent/author_replay_results.json").read_bytes())["checks"]==66)
ck("blocked library probes only proc maps",all(e=={"event":"open","path":"/proc/self/maps"} for e in BLOCKED))
result={"kind":"H024_V2_narrow_independent_snapshot_preservation_checks","verdict":"PASS",
 "implementation":ref(S),"config":ref(C),"checks":CHECKS,"check_count":len(CHECKS),"cases":CASES,
 "reference_hashes_verified":len(HASHED),"verified_references":list(HASHED.values()),
 "all11_numerical_helpers_AST_unchanged":True,"whole_cell_body_unchanged_except_single_verified_payload_snapshot":True,
 "prior_V1_66_numerical_replay_reused_without_broad_rerun":True,"blocked_library_probe_attempts":BLOCKED,
 "actual_parent_model_profile_ancestry_truth_runtime_capture_budget_GPU_proc_launch_install_or_Git_actions":False}
with (OUT/"fresh_snapshot_preservation_checks.json").open("x") as f:json.dump(result,f,indent=2,allow_nan=False);f.write("\n")
print(json.dumps({"verdict":"PASS","checks":len(CHECKS),"fresh_snapshot_cases":len(CASES),"reference_hashes_verified":len(HASHED),"arithmetic_AST_preserved":True,"actual_profile":False},indent=2))
