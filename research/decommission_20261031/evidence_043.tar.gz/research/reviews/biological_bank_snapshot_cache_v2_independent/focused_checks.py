"""Proportionate independent IO snapshot, hot-path and preservation checks."""
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
from types import ModuleType
import ast,hashlib,json,os,sys
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
OUT=Path(__file__).resolve().parent
F=OUT/"fresh_fixtures";F.mkdir()
SOURCE=ROOT/"src/arggnn/biological_bank_snapshot_cache_v2.py"
CONFIG=ROOT/"configs/biological_bank_snapshot_cache_v2.json"
AUTHOR=ROOT/"research/reviews/biological_bank_snapshot_cache_v2_author"
CHECKS=[];CASES=[];HASHED={};BLOCKED=[]
def ck(name,value):
 CHECKS.append({"name":name,"PASS":bool(value)})
 if not value:raise AssertionError(name)
def ref(path):
 raw=path.read_bytes();r={"path":str(path.relative_to(ROOT)),"sha256":hashlib.sha256(raw).hexdigest()}
 HASHED[r["path"]]={**r,"bytes":len(raw)};return r
def reject(name,callback):
 try:callback()
 except ValueError:ck(name,True)
 else:raise AssertionError(name+" accepted")
def audit(event,args):
 if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]);p=Path(name)
  if p.is_absolute() and (name.startswith(str(ROOT/"data")+"/") or name.startswith("/proc/") or name.startswith(str(ROOT/".runtime/conda")+"/")
   or name in {str(ROOT/".runtime/gpup/storage_reservations.json"),str(ROOT/".runtime/storage/project_budget_v4.json")}):
   BLOCKED.append({"event":event,"path":name});raise AssertionError("actual banks/data/proc/ledger/native prefix forbidden")
 if event in {"subprocess.Popen","os.kill","os.killpg","socket.connect"}:BLOCKED.append({"event":event});raise AssertionError("actual launch/signal/network forbidden")
sys.addaudithook(audit)
import numpy as np,torch
torch.set_num_threads(1)
from arggnn import biological_bank_snapshot_cache_v2 as m
# Reuse only sealed handmade fixture definitions; independently written cases below.
fixture_text=(AUTHOR/"handmade_checks.py").read_text();fixture_tree=ast.parse(fixture_text)
fixture_nodes=[]
for node in fixture_tree.body:
 if isinstance(node,ast.FunctionDef) and node.name=="main":continue
 if isinstance(node,ast.If) and "__name__" in ast.unparse(node.test):continue
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in {"ROOT","OWN","FIX","checks"} for t in node.targets):continue
 if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=="OWN":continue
 if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=="relative_to":continue
 if isinstance(node,ast.If) and "OWN.relative_to" in ast.unparse(node.test):continue
 fixture_nodes.append(node)
module=ModuleType("independent_bank_fixture");module.__file__=str(OUT/"fresh_snapshot_checks.py")
module.__dict__.update(ROOT=ROOT,OWN=OUT,FIX=F,checks=[]);sys.modules[module.__name__]=module
exec(compile(ast.Module(body=fixture_nodes,type_ignores=[]),"<sealed handmade fixture definitions only>","exec"),module.__dict__)
parent={"parent_id":"independent_train","split":"train","observation":{"nodes":np.arange(280)},
 "dynamics_slots":np.arange(184),"reference_slots":np.arange(184,280),"query_slots":np.arange(120),"positions":np.array([123.,567.])}
cfg={"handmade":True,"training":{"learning_rate":.003},"source_sha256":{}}
tiles=[module.save_bundle(F/f"bank_{i}.pt",parent,i) for i in range(2)]
prep=module.json_ref(F/"prepared.json",{"status":"complete_observed_only_Q184_R96_actualQ120","truth_opened":False,"parents":[{"parent_id":parent["parent_id"],"tiles":tiles}]})
cref=module.json_ref(F/"config.json",cfg);obs=module.json_ref(F/"observed.json",{"handmade":True})
def cache(cpu=2000000,snapshot=2000000,decode=2000000):
 return m.BiologicalBankSnapshotCacheV2(prep,cref,obs,cpu_budget_bytes=cpu,snapshot_budget_bytes=snapshot,decode_budget_bytes=decode,gpu_budget_bytes=0)
p=ROOT/tiles[0]["bank"]["path"];raw=p.read_bytes()
baseline=m.BASE_LOAD_BANK(tiles[0],cfg,parent,"cpu")
initial_rng=m._rng_v1("cpu")
# Replace the file inside its first read, before the SHA check and decoder.
realopen=Path.open;content_opens=[]
class SwapStream:
 def __init__(self,stream):self.stream=stream
 def __enter__(self):self.stream.__enter__();return self
 def __exit__(self,*args):return self.stream.__exit__(*args)
 def read(self,n):
  data=self.stream.read(n)
  with realopen(p,"wb") as stream:stream.write(b"independent substituted unverified bank")
  return data
def swap_open(path,*args,**kwargs):
 mode=args[0] if args else kwargs.get("mode","r")
 stream=realopen(path,*args,**kwargs)
 if path==p and mode=="rb":content_opens.append(mode);return SwapStream(stream)
 return stream
c=cache()
with patch.object(Path,"open",swap_open):cold=c(tiles[0],cfg,parent,"cpu")
ck("first decode consumes verified original bytes after read-boundary substitution",module.ordered(cold)==module.ordered(baseline))
ck("first bank snapshot exactly one content open",content_opens==["rb"])
ck("retained snapshot exactly SHA bound",hashlib.sha256(c.snapshots[(parent["parent_id"],0)]).hexdigest()==tiles[0]["bank"]["sha256"])
ck("cold snapshot and decoder preserve RNG",m._rng_v1("cpu")==initial_rng)
# Delete the path altogether; hot hits must not depend on any bank filesystem operation.
p.unlink();opens=[];stats=[];resolves=[];sha_args=[]
realstat=Path.stat;realresolve=Path.resolve;realsha=hashlib.sha256
def blockopen(path,*args,**kwargs):
 if path==p:opens.append(str(path));raise AssertionError("hot bank open")
 return realopen(path,*args,**kwargs)
def blockstat(path,*args,**kwargs):
 if path==p:stats.append(str(path));raise AssertionError("hot bank stat")
 return realstat(path,*args,**kwargs)
def blockresolve(path,*args,**kwargs):
 if path==p:resolves.append(str(path));raise AssertionError("hot bank resolve")
 return realresolve(path,*args,**kwargs)
def blocksha(data=b""):
 if isinstance(data,(bytes,bytearray)) and bytes(data)==raw:sha_args.append(len(data));raise AssertionError("hot full-bank SHA")
 return realsha(data)
before=dict(c.stats)
with patch.object(Path,"open",blockopen),patch.object(Path,"stat",blockstat),patch.object(Path,"resolve",blockresolve),patch.object(hashlib,"sha256",blocksha),patch.object(m,"verified_bytes_v2",side_effect=AssertionError("hot snapshot read")),patch.object(torch,"load",side_effect=AssertionError("hot decode")):
 for i in range(3):ck("deleted-path hot hit returns same approved object "+str(i),c(tiles[0],cfg,parent,"cpu") is cold)
ck("hot path zero bank open stat resolve and full-byte SHA",opens==stats==resolves==sha_args==[])
ck("hot path snapshot decode verification counters stable",all(c.stats[k]==before[k] for k in ("snapshot_reads","cold_snapshot_decodes","bank_sha_verified_bytes")))
ck("hot path RNG preserved",m._rng_v1("cpu")==initial_rng)
CASES.append({"case":"read_boundary_substitution_then_deleted_path_hot_hits","first_content_opens":1,"hot_hits":3,"bank_opens":0,"bank_stats":0,"bank_resolves":0,"full_bank_SHA_calls":0,"decoder_calls_on_hits":0,"original_fields_equal":True})
# Original ordinary version guards still reject a mutated resident even with the path absent.
cold.operators["age"].add_(1)
reject("ordinary resident version mutation rejects hot object",lambda:c(tiles[0],cfg,parent,"cpu"))
reject("ordinary resident mutation rejects close while releasing state",c.close)
ck("close releases caches despite detected mutation",c.closed and not c.cpu and not c.snapshots)
p.write_bytes(raw)
# Capacity shortage does not evict, bypass, replace or return another approved entry.
probe=cache();first=probe(tiles[0],cfg,parent,"cpu");size=m.resident_bytes_v1(first);probe.close()
small=cache(cpu=size)
first=small(tiles[0],cfg,parent,"cpu")
reject("complete decoded working-set shortage rejects second entry",lambda:small(tiles[1],cfg,parent,"cpu"))
ck("CPU shortage preserves first approved entry and zero evictions",len(small.cpu)==len(small.snapshots)==1 and small.cpu[(parent["parent_id"],0)]["bank"] is first and small.stats["CPU_evictions"]==small.stats["CPU_oversized_bypass"]==0)
small.close()
small=cache(snapshot=len(raw))
first=small(tiles[0],cfg,parent,"cpu")
reject("complete snapshot shortage rejects second entry",lambda:small(tiles[1],cfg,parent,"cpu"))
ck("snapshot shortage preserves first approved bytes",len(small.snapshots)==1 and small.snapshots[(parent["parent_id"],0)]==raw)
small.close()
CASES.append({"case":"complete_working_set_capacity_refusal","CPU_and_snapshot_shortage_reject":True,"existing_entry_preserved":True,"CPU_evictions":0,"CPU_bypass":0})
# A changed caller SHA/path cannot turn deletion semantics into unreviewed rebinding.
c=cache();c(tiles[0],cfg,parent,"cpu")
bad=deepcopy(tiles[0]);bad["bank"]["sha256"]="0"*64
reject("changed caller hash cannot rebind resident snapshot",lambda:c(bad,cfg,parent,"cpu"));c.close()
# Exact independent source/metadata preservation closure.
pins={SOURCE:"5e51971a85c711894b1fd6d5f5d9df29f6a203cf3f638346c421f31e1158b099",
 CONFIG:"8a3222afab298105e297e64820f4242d33d32a24e3dc691de17966052db704cf",
 ROOT/"docs/biological_bank_snapshot_cache_v2.md":"29b6ddef1df320c7fd9d4fd6e66ff992646b2921d332041f0099db39f58d444c",
 AUTHOR/"author_receipt.json":"785a71b0a93787af0efbf74cccc12fca977a085b238edc506b2692e885516a0d"}
for path,value in pins.items():ck("sealed subject "+str(path.relative_to(ROOT)),ref(path)["sha256"]==value)
config=json.loads(CONFIG.read_bytes());author=json.loads((AUTHOR/"author_receipt.json").read_bytes())
ck("registered inactive throughput scope",ref(ROOT/config["source_registration"]["path"])==config["source_registration"] and "inactive_source_only" in config["status"])
for record in (config["predecessor"],config["original_config"]):ck("original source/config preserved "+record["path"],ref(ROOT/record["path"])==record)
for path,value in config["original_source_sha256"].items():ck("unchanged original scientific source "+path,ref(ROOT/path)["sha256"]==value)
ck("cache source pin set equals original scientific pin set",config["source_sha256"]==config["original_source_sha256"])
for key in ("implementation","config","documentation","handmade_replay_ref","handmade_checks_ref","source_delta_proof_ref","source_registration_ref"):
 r=author[key];ck("author bound metadata "+key,ref(ROOT/r["path"])==r)
for r in author["prospective_templates"].values():ck("inactive author template bound "+r["path"],ref(ROOT/r["path"])==r)
newtree=ast.parse(SOURCE.read_text());oldtree=ast.parse((ROOT/config["predecessor"]["path"]).read_text())
funcs=lambda t:{n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
newfn=funcs(newtree);oldfn=funcs(oldtree)
dump=lambda n:ast.dump(n,include_attributes=False)
for name in ("_utc","_identity","_tensors","resident_bytes_v1","transfer_upper_bytes_v1","_guard","_parent_join","_rng_v1","_sync_v1"):
 ck("original helper AST unchanged "+name,dump(newfn[name])==dump(oldfn[name]))
base=funcs(ast.parse((ROOT/"src/arggnn/biological_candidate.py").read_text()))["load_bank"].body[2:]
decoded=newfn["decode_bank_snapshot_v2"].body[1:]
ck("all11 original post-IO loader statements unchanged",len(base)==len(decoded)==11 and all(dump(x)==dump(y) for x,y in zip(base,decoded)))
oldgpu=next(n for n in ast.walk(oldtree) if isinstance(n,ast.If) and ast.unparse(n.test)=="target.type == 'cpu'")
newgpu=next(n for n in ast.walk(newtree) if isinstance(n,ast.If) and ast.unparse(n.test)=="target.type == 'cpu'")
ck("original GPU LRU branch AST unchanged",dump(oldgpu)==dump(newgpu))
for key in ("performance_or_accuracy_improvement","new_method","actual_working_set_memory_qualified","actual_cold_decode_peak_qualified"):
 ck("no empirical claim "+key,config["claims"][key] is False)
ck("separate snapshot decoded cold tensor and GPU caps explicit",[config[k] for k in ("CPU_snapshot_budget_bytes","CPU_budget_bytes","CPU_decode_peak_budget_bytes","GPU_budget_bytes")]==[64000000000,64000000000,64000000000,32000000000])
ck("only blocked library proc probe",all(x=={"event":"open","path":"/proc/self/maps"} for x in BLOCKED))
result={"schema":"biological_bank_snapshot_cache_v2_independent_focused_checks","verdict":"PASS",
 "implementation":ref(SOURCE),"config":ref(CONFIG),"checks_count":len(CHECKS),"checks":CHECKS,"cases":CASES,
 "reference_hashes_verified":len(HASHED),"verified_references":list(HASHED.values()),"blocked_library_probe_attempts":BLOCKED,
 "numerical_RNG_loop_helper_loader_and_GPU_LRU_preservation_verified":True,
 "complete32_working_set_and_143_author_replay_reused":True,
 "actual_bank_model_CPU_GPU_production_profile_budget_launch_installation_live_edit_or_Git_actions":False}
with (OUT/"focused_checks.json").open("x") as f:json.dump(result,f,indent=2,allow_nan=False);f.write("\n")
print(json.dumps({"verdict":"PASS","focused_checks":len(CHECKS),"reference_hashes_verified":len(HASHED),"fresh_cases":len(CASES),"hot_bank_IO_hash_stat":0,"actual_banks_or_production_models":False},indent=2))
