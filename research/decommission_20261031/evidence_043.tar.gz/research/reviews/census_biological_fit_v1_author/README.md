# Census biological fit v1 author handoff

Source-only and handmade CPU author work, pending fresh independent review and root registration. No actual arrays or GPU job were opened. The source/config/document are new separately versioned artifacts. Original pins remain intact.

Owned artifacts:

- src/arggnn/census_biological_fit_v1.py
- configs/census_biological_fit_v1.json
- docs/census_biological_fit_v1.md
- research/reviews/census_biological_fit_v1_author/**

Tests use handmade tskit full280-sample/two-tree fixtures and explicit synthetic interval targets. Thirty-epoch actual budgets are enforced by the immutable shipped config. The orchestration test changes only handmade admission/native adapters and shortens its test budget to one epoch/two tiles. It uses real full default model forward/backward, real target NPZ bytes, raw probability output files, exact scorer and selected checkpoint weight changes. It is not native fitting evidence.

Preserved attempts:22 cases14.24s,12 new admission/counterfactual cases6.15s,3 resource/execution cases12.28s,1 final-dependency preflight case2.85s. Thirty-six distinct cases,38 passing executions. No failure or threshold relaxation occurred. Replays were limited to changed wrapper/config behavior.

The root-capability terminal envelope proposed by the consumer has schema census_numerical_root_terminal_binding_v1, status complete, returncode0, numerical job_id and exact evidence_ref/admission_ref/inspection_ref/freeze_ref. Root must create it after the numerical worker terminates. Existing running evidence is rejected.

The root needs a fresh source review, a bound full-tree/device backward profile, current runtime/source pins, active storage reservation and lease/launcher/watchdog capability before fitting. A current-release biological performance comparison is developmental on the old two VAL parents. Independent20TRAIN/6VAL/12TEST biological confirmation, age/time sensitivity, paper-specific original-data branches and cross-domain scope are separately planned and inactive.

Known runtime issue: the unchanged CensusTreeGNNV1 wrapper ignores certified cert.forest and rebuilds forest geometry/cut checks on each forward. Its level-wise index_copy autograd, native/serialized replay and full certificate hashes remain expensive. No sampled-tree or smaller-backbone fallback was introduced. The40GB per-seed cap and450GB effective repository guard remain, while user-authorized1TB policy transition is root-owned.

Source test command, only when a new concern/change justifies execution:

```sh
cd /workspace-SR003.nfs2/ARG-GNN
source scripts/project_env.sh
CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
.runtime/env/bin/python -m pytest -q research/reviews/census_biological_fit_v1_author/test_fit_v1.py \
-p no:cacheprovider --basetemp research/reviews/NEW_REVIEW_OWNED_DIRECTORY/pytest_tmp
```

The actual root command contract is `python -m arggnn.census_biological_fit_v1 --admission ROOT_NEW_FIT_ADMISSION --expected-admission-sha256 ROOT_INDEPENDENT_FROZEN_SHA256`, under the root launcher for its declared device. These are placeholders and not an admitted command. `registration_request.json` is an unfinished H021 continuation request. It does not modify the ledger or authorize an experiment.
