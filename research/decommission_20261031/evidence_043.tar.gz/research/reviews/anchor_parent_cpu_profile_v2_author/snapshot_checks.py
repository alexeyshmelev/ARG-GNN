
from pathlib import Path
import ast,copy,hashlib,io,json
from datetime import datetime,timezone
ROOT=Path.cwd();D=ROOT/"research/reviews/anchor_parent_cpu_profile_v2_author";F=D/"fixtures";F.mkdir(exist_ok=True)
V1=ROOT/"src/arggnn/anchor_parent_cpu_profile_v1.py";V2=ROOT/"src/arggnn/anchor_parent_cpu_profile_v2.py"
C1=ROOT/"configs/anchor_parent_cpu_profile_v1.json";C2=ROOT/"configs/anchor_parent_cpu_profile_v2.json"
one=V1.read_text();two=V2.read_text();t1=ast.parse(one);t2=ast.parse(two);cfg1=json.loads(C1.read_bytes());cfg2=json.loads(C2.read_bytes())
def digest(b):return hashlib.sha256(b).hexdigest()
def ref(p,data=None):return {"path":str(p.relative_to(ROOT)),"sha256":digest(p.read_bytes() if data is None else data)}
def fn(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
def cls(tree,name):return next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
def dump(n):return ast.dump(n,include_attributes=False)
records=[]
def check(name,callback,deny=False):
 try:callback()
 except Exception as error:
  if not deny:raise
  records.append({"case":name,"status":"PASS_expected_rejection","error_type":type(error).__name__})
 else:
  if deny:raise AssertionError(name+" accepted")
  records.append({"case":name,"status":"PASS"})
numerical=["peak_RSS_bytes_v1","snapshot_v1","optimizer_snapshot_v1","assert_tree_close_v1","synthetic_numerator_v1",
 "execute_method_v1","tensor_bytes_v1","bind_reconstructed_parent_v1","write_artifact_v1","compare_records_v1",
 "validate_admission_metadata_v1"]
for name in numerical:check("unchanged_AST_"+name,lambda name=name:None if dump(fn(t1,name))==dump(fn(t2,name)) else (_ for _ in ()).throw(AssertionError()))
class NormalizePayload(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  if isinstance(node.func,ast.Attribute) and node.func.attr=="load" and isinstance(node.func.value,ast.Name) and node.func.value.id=="torch":
   if isinstance(node.args[0],ast.Call) and isinstance(node.args[0].func,ast.Attribute) and node.args[0].func.attr=="BytesIO":
    verified=node.args[0].args[0]
    node.args[0]=ast.Call(func=ast.Attribute(value=verified.func.value,attr="path",ctx=ast.Load()),args=verified.args,keywords=[])
  return node
check("complete_cell_body_unchanged_except_verified_payload_parse",
 lambda:None if dump(fn(t1,"run_cell_v1"))==dump(NormalizePayload().visit(copy.deepcopy(fn(t2,"run_cell_v1")))) else (_ for _ in ()).throw(AssertionError()))
changed={k for k in set(cfg1)|set(cfg2) if cfg1.get(k)!=cfg2.get(k)}
check("protocol_delta_only_version_registration_predecessor",lambda:None if changed=={"kind","root_registration_ref","predecessor"} else (_ for _ in ()).throw(AssertionError(changed)))
check("sealed_V1_source_config_preserved",lambda:None if digest(V1.read_bytes())=="39c7b130a57f56faab06c9f125d6d57503c313483f95e26f0d441342275a897e" and digest(C1.read_bytes())=="fe978db8dd5fc63c52ec8cb4944b08ccdfb0dc299d549d0ba92323cb030f93d6" else (_ for _ in ()).throw(AssertionError()))
check("new_registration_before_checks",lambda:None if digest((ROOT/cfg2["root_registration_ref"]["path"]).read_bytes())==cfg2["root_registration_ref"]["sha256"]=="5067f3a48c10b35d4318bd1a7af88018fa5b04780423e14d174398bc3299545d" else (_ for _ in ()).throw(AssertionError()))
def namespace(tree,reader_class,config_path,config_sha):
 env={"ROOT":ROOT,"Path":Path,"json":json,"hashlib":hashlib,"datetime":datetime,"timezone":timezone,
      "CONFIG_PATH":config_path,"CONFIG_SHA256":config_sha}
 wanted={"require","utc","sha","load_config_v1","validate_admission_metadata_v1"}
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted]+[cls(tree,reader_class)]
 exec(compile(ast.Module(body=nodes,type_ignores=[]),"<owned snapshot fixtures, no models/budget>","exec"),env)
 return env
old=namespace(t1,"ReaderV1",str(C1.relative_to(ROOT)),digest(C1.read_bytes()))
new=namespace(t2,"ReaderV2",str(C2.relative_to(ROOT)),digest(C2.read_bytes()))
a=json.loads((ROOT/"research/reviews/anchor_parent_cpu_profile_v1_author/prospective_admission.template.json").read_bytes())
a.update(status="inactive",observed_profile_authorized=True,created_at_utc="2026-10-11T07:00:00+00:00",
 expires_at_utc="2026-10-11T08:00:00+00:00",job_id="owned-fixture",matrix_job_id="owned-matrix",
 matrix_output_directory="fixture/matrix",output_directory="fixture/matrix/"+cfg1["matrix"][0]["id"],
 initial_state_sha256="a"*64,external_watchdog=True,sequential_full_parent_cell=True)
active=copy.deepcopy(a);active["status"]="active";active["initial_state_sha256"]="b"*64
oldbytes=(json.dumps(a,sort_keys=True)+"\n").encode();newbytes=(json.dumps(active,sort_keys=True)+"\n").encode()
p=F/"admission.json";p.write_bytes(oldbytes);record=ref(p,oldbytes)
realsha=old["sha"]
def swap_after_v1_hash(path):
 value=realsha(path)
 if Path(path)==p:p.write_bytes(newbytes)
 return value
old["sha"]=swap_after_v1_hash
parsed=old["ReaderV1"]().json(record)
check("sealed_V1_inactive_to_active_after_hash_reproduced",lambda:None if parsed["status"]=="active" and parsed["initial_state_sha256"]=="b"*64 else (_ for _ in ()).throw(AssertionError()))
check("sealed_V1_unpinned_active_metadata_validates",
 lambda:old["validate_admission_metadata_v1"](parsed,cfg1,datetime(2026,10,11,7,10,tzinfo=timezone.utc)))
p.write_bytes(oldbytes);reader=new["ReaderV2"]();original=reader.read_verified_bytes
def swap_after_v2_verified(record):
 data=original(record);p.write_bytes(newbytes);return data
reader.read_verified_bytes=swap_after_v2_verified
parsed=reader.json(record)
check("V2_JSON_parses_same_inactive_verified_snapshot",lambda:None if parsed==a else (_ for _ in ()).throw(AssertionError()))
check("V2_same_snapshot_rejects_inactive_cap",
 lambda:new["validate_admission_metadata_v1"](parsed,cfg1,datetime(2026,10,11,7,10,tzinfo=timezone.utc)),True)
check("V2_before_read_changed_bytes_rejected",lambda:new["ReaderV2"]().json(record),True)
# Count content opens on one owned JSON read; stat/resolve are metadata operations.
p.write_bytes(oldbytes);opens=[];realopen=Path.open
def counted_open(self,*args,**kwargs):
 if self==p:opens.append(args[0] if args else kwargs.get("mode","r"))
 return realopen(self,*args,**kwargs)
Path.open=counted_open
try:check("V2_JSON_one_content_open",lambda:new["ReaderV2"]().json(record))
finally:Path.open=realopen
check("V2_content_read_exactly_once",lambda:None if opens==["rb"] else (_ for _ in ()).throw(AssertionError(opens)))
# Genuine protocol copied to owned fixture; post-verification altered cap cannot parse.
protocol=F/"protocol.json";good=C2.read_bytes();changedcfg=copy.deepcopy(cfg2);changedcfg["CPU_headroom_bytes"]=1
bad=(json.dumps(changedcfg,sort_keys=True,indent=2)+"\n").encode();protocol.write_bytes(good)
nscfg=namespace(t2,"ReaderV2",str(protocol.relative_to(ROOT)),digest(good))
realread=nscfg["ReaderV2"].read_verified_bytes
def protocol_swap(self,record):
 data=realread(self,record)
 if record["path"]==str(protocol.relative_to(ROOT)):protocol.write_bytes(bad)
 return data
nscfg["ReaderV2"].read_verified_bytes=protocol_swap
parsedcfg=nscfg["load_config_v1"]()
check("V2_protocol_preserves_verified128GB_after_file_swap",lambda:None if parsedcfg==cfg2 and parsedcfg["CPU_headroom_bytes"]==128_000_000_000 else (_ for _ in ()).throw(AssertionError()))
check("V2_changed_protocol_hash_rejected_on_next_call",lambda:nscfg["load_config_v1"](),True)
# All direct JSON/torch decode routes in new source consume verified bytes.
check("V2_no_read_text_parse_path",lambda:None if not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="read_text" for n in ast.walk(t2)) else (_ for _ in ()).throw(AssertionError()))
check("V2_no_pinned_filepath_reader_API",lambda:None if not any(isinstance(n,ast.FunctionDef) and n.name=="path" for n in cls(t2,"ReaderV2").body) else (_ for _ in ()).throw(AssertionError()))
torchloads=[n for n in ast.walk(t2) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="load" and isinstance(n.func.value,ast.Name) and n.func.value.id=="torch"]
check("V2_all_prior_torch_loads_use_verified_BytesIO",lambda:None if len(torchloads)==1 and dump(torchloads[0].args[0])=="Call(func=Attribute(value=Name(id='io', ctx=Load()), attr='BytesIO', ctx=Load()), args=[Call(func=Attribute(value=Attribute(value=Name(id='authority', ctx=Load()), attr='reader', ctx=Load()), attr='read_verified_bytes', ctx=Load()), args=[Subscript(value=Name(id='refs', ctx=Load()), slice=Name(id='method', ctx=Load()), ctx=Load())], keywords=[])], keywords=[])" else (_ for _ in ()).throw(AssertionError()))
import torch
# Primitive metadata-only Torch file: no tensors/model/original data instantiated.
first=io.BytesIO();torch.save({"tag":"verified_old","initial_state_sha256":"a"*64},first)
second=io.BytesIO();torch.save({"tag":"changed_unpinned","initial_state_sha256":"b"*64},second)
payload=F/"payload.pt";payload.write_bytes(first.getvalue());payloadref=ref(payload,first.getvalue())
snapshot=new["ReaderV2"]().read_verified_bytes(payloadref)
payload.write_bytes(second.getvalue())
loaded=torch.load(io.BytesIO(snapshot),map_location="cpu",weights_only=True)
check("V2_Torch_post_hash_swap_loads_original_verified_bytes",lambda:None if loaded=={"tag":"verified_old","initial_state_sha256":"a"*64} else (_ for _ in ()).throw(AssertionError()))
check("V2_Torch_changed_file_rejected_next_snapshot",lambda:new["ReaderV2"]().read_verified_bytes(payloadref),True)
for name,value in [("wrong_SHA",dict(record,sha256="0"*64)),("bad_SHA",dict(record,sha256="bad")),
 ("extra_ref_field",dict(record,extra=True)),("missing_file",{"path":str((F/"missing.json").relative_to(ROOT)),"sha256":"a"*64})]:
 check("V2_"+name+"_rejects_before_parse",lambda value=value:new["ReaderV2"]().json(value),True)
for path,value in cfg2["source_pins"].items():assert digest((ROOT/path).read_bytes())==value
proof={"kind":"anchor_parent_CPU_profile_v2_snapshot_source_delta_proof","status":"PASS",
 "unchanged_numerical_AST_functions":numerical,"complete_cell_body_AST_equal_except_verified_payload_load":True,
 "protocol_delta_keys":sorted(changed),"all_original_source_math_tolerance_matrix_support_optimizer_state_resource_fields_unchanged":True,
 "V1_source_and_config_preserved":True,"source_registration_ref":cfg2["root_registration_ref"],
 "single_verified_JSON_snapshot":True,"single_verified_Torch_BytesIO_snapshot":True,
 "no_direct_filepath_parse_remaining_in_new_profile":True,
 "actual_inputs_or_production_models_or_numerical_profile_or_budget_GPU_Git":False}
(D/"source_delta_proof.json").write_text(json.dumps(proof,sort_keys=True,indent=2)+"\n")
(D/"snapshot_checks.json").write_text(json.dumps({"kind":"anchor_parent_CPU_profile_v2_owned_snapshot_checks","status":"PASS",
 "checks":len(records),"records":records,"fixtures_owned_only":True,"Torch_payload_contains_primitive_metadata_only":True,
 "actual_original_model_inputs_profile_budget_GPU_Git":False},sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":"PASS","snapshot_checks":len(records),"original_production_model_or_inputs_or_profile":False},indent=2))
