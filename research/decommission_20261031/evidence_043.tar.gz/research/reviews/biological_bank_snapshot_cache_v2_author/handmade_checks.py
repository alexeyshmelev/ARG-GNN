"""Replay only owned handmade tensors/bytes and a tiny synthetic linear model."""
from __future__ import annotations
import ast
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass,fields,is_dataclass,replace
import hashlib,io,json,os,random,sys
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from arggnn import biological_bank_snapshot_cache_v2 as m

ROOT=m.ROOT
OWN=(ROOT/os.environ.get('ARGGNN_SNAPSHOT_HANDMADE_OUTPUT','research/reviews/biological_bank_snapshot_cache_v2_author')).resolve()
OWN.relative_to(ROOT)
if not str(OWN.relative_to(ROOT)).startswith('research/reviews/biological_bank_snapshot_cache_v2_'):raise ValueError('Dedicated source-only review fixture output required')
OWN.mkdir(parents=True,exist_ok=True)
FIX=OWN/'fixtures'
checks=[]

def check(name,value):
    if not value:raise AssertionError(name)
    checks.append({'name':name,'PASS':True})

def reject(name,fn,fragment=''):
    try:fn()
    except ValueError as e:check(name,fragment in str(e));return
    raise AssertionError(name+': did not reject')

def ref(p):
    return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}

def json_ref(p,value):
    p.write_text(json.dumps(value,sort_keys=True)+'\n');return ref(p)

@dataclass
class Query:
    reference_ids:torch.Tensor
    identity:tuple

@dataclass
class Bank:
    leaf_x:torch.Tensor
    query_node_ids:torch.Tensor
    query_cache:Query
    sample_ids:torch.Tensor
    feature_columns:tuple
    positions:torch.Tensor
    intervals:torch.Tensor
    nested:dict

@dataclass
class Layout:
    anchors:torch.Tensor
    coordinates:torch.Tensor
    segment_duration:torch.Tensor
    anchor_graph:torch.Tensor
    order:tuple

@dataclass
class Prepared:
    bank:Bank
    layout:Layout
    operators:dict
    num_scales:int
    def to(self,device,dtype=None):
        target=torch.device(device);mock_gpu=target.type=='cuda'
        def move(x,name=''):
            if isinstance(x,torch.Tensor):
                use=dtype if x.is_floating_point() and name not in ('positions','intervals','anchors','coordinates','segment_duration') else None
                y=x.to(device='cpu' if mock_gpu else target,dtype=use)
                return y.clone() if mock_gpu else y
            if is_dataclass(x):return type(x)(**{f.name:move(getattr(x,f.name),f.name) for f in fields(x)})
            if isinstance(x,dict):return {k:move(v,k) for k,v in x.items()}
            if isinstance(x,tuple):return tuple(move(v) for v in x)
            if isinstance(x,list):return [move(v) for v in x]
            return x
        return move(self)

def ordered(x):
    if isinstance(x,torch.Tensor):
        return ('tensor',str(x.dtype),tuple(x.shape),tuple(x.stride()),x.storage_offset(),hashlib.sha256(x.detach().contiguous().numpy().tobytes()).hexdigest())
    if is_dataclass(x):return (type(x).__name__,tuple((f.name,ordered(getattr(x,f.name))) for f in fields(x)))
    if isinstance(x,dict):return ('dict',tuple((k,ordered(v)) for k,v in x.items()))
    if isinstance(x,(tuple,list)):return (type(x).__name__,tuple(ordered(v) for v in x))
    if isinstance(x,float):return ('float',x.hex())
    return x

def save_bundle(p,parent,number=0,mutate=None):
    leaf=(torch.arange(2*280*47,dtype=torch.float32).reshape(2,280,47)%29)/31
    flags=torch.isin(torch.arange(280),torch.as_tensor(parent['observation']['nodes'][parent['query_slots']])).float()
    leaf[:,:,4]=flags.expand_as(leaf[:,:,4])
    base=torch.arange(12,dtype=torch.float32).reshape(3,4)
    expanded=torch.ones(1,2).expand(5,2)
    bank=Bank(leaf,torch.arange(184),Query(torch.arange(184,280),('R',96)),torch.arange(280),tuple(c for c in range(48) if c!=7),torch.tensor(parent['positions'][[number%2]]/2000000,dtype=torch.float64),torch.tensor([[0.,.5],[.5,1.]],dtype=torch.float64),{'ordered_b':base[:,1:],'ordered_a':[expanded,expanded],'metadata':(-0.0,True,None,'fixed')})
    layout=Layout(torch.arange(32,dtype=torch.float64),torch.tensor([0.,.25,.5,1.],dtype=torch.float64),torch.tensor([.25,.25,.5],dtype=torch.float64),torch.tensor([0,1],dtype=torch.int64),(2,0,1))
    prepared=Prepared(bank,layout,{'plain':base,'age':base+1,'matched_scalar_age':base+2},3)
    bundle={'schema':'biological_candidate_full_age_bank_v1','age_bank':{'raw':torch.arange(21,dtype=torch.float64),'order':('first','last')},'fixed_prepared':prepared}
    if mutate:mutate(bundle)
    torch.save(bundle,p)
    return {'tile_id':number,'bank':ref(p),'position_indexes':[number%2],'exact_serialization_roundtrip_checked':True,'all_original_age_cache_fields_retained':True,'original_tree_ids':[number*2,number*2+1]}

def setup():
    FIX.mkdir(exist_ok=True)
    parents=[];tiles={};cfg={'handmade':True,'training':{'learning_rate':.003},'source_sha256':{}}
    for split in ('train','val'):
        for n in range(2):
            parent={'parent_id':f'handmade_{split}_{n}','split':split,'observation':{'nodes':np.arange(280)},'dynamics_slots':np.arange(184),'reference_slots':np.arange(184,280),'query_slots':np.arange(120),'positions':np.asarray([123.,567.])}
            parents.append(parent);tiles[parent['parent_id']]=[save_bundle(FIX/f"{parent['parent_id']}_{k}.pt",parent,k) for k in range(8)]
    prep=json_ref(FIX/'prepared.json',{'status':'complete_observed_only_Q184_R96_actualQ120','truth_opened':False,'parents':[{'parent_id':p['parent_id'],'tiles':tiles[p['parent_id']]} for p in parents]})
    cref=json_ref(FIX/'config.json',cfg);obs=json_ref(FIX/'observed.json',{'handmade':True})
    return parents,tiles,cfg,prep,cref,obs

def cache(data,**kw):
    parents,tiles,cfg,prep,cref,obs=data
    return m.BiologicalBankSnapshotCacheV2(prep,cref,obs,cpu_budget_bytes=kw.get('cpu',10_000_000),snapshot_budget_bytes=kw.get('snapshot',10_000_000),decode_budget_bytes=kw.get('decode',10_000_000),gpu_budget_bytes=kw.get('gpu',0),active_guard=kw.get('active'))

def main():
    check('explicit_empty_CUDA_visibility',os.environ.get('CUDA_VISIBLE_DEVICES')=='')
    torch.set_num_threads(1)
    data=setup();parents,tiles,cfg,prep,cref,obs=data
    p=parents[0];tile=tiles[p['parent_id']][0]
    c=cache(data);rng=m._rng_v1('cpu')
    baseline=m.BASE_LOAD_BANK(tile,cfg,p,'cpu');a=c(tile,cfg,p,'cpu')
    check('complete_original_field_dtype_shape_stride_offset_and_order_equality',ordered(a)==ordered(baseline))
    check('cold_load_RNG_unchanged',m._rng_v1('cpu')==rng)
    check('decoded_snapshot_SHA_and_byte_binding',hashlib.sha256(c.snapshots[(p['parent_id'],0)]).hexdigest()==tile['bank']['sha256'])
    check('float64_coordinates_retained',a.bank.positions.dtype==a.layout.coordinates.dtype==torch.float64)
    check('noncontiguous_and_expanded_strides_retained',a.bank.nested['ordered_b'].stride()==(4,1) and a.bank.nested['ordered_a'][0].stride()==(0,1))
    check('dict_and_operator_order_retained',tuple(a.operators)==('plain','age','matched_scalar_age') and tuple(a.bank.nested)==('ordered_b','ordered_a','metadata'))
    before=dict(c.stats)
    bankpaths={m.frozen.path(t['bank']['path']) for ts in tiles.values() for t in ts}
    original_open=Path.open;original_stat=Path.stat
    def failopen(self,*args,**kw):
        if self in bankpaths:raise AssertionError('hot bank path open')
        return original_open(self,*args,**kw)
    def failstat(self,*args,**kw):
        if self in bankpaths:raise AssertionError('hot bank path stat')
        return original_stat(self,*args,**kw)
    with patch.object(Path,'open',failopen),patch.object(Path,'stat',failstat),patch.object(m,'verified_bytes_v2',side_effect=AssertionError('hot snapshot acquisition')),patch.object(m.torch,'load',side_effect=AssertionError('hot decode')):
        for _ in range(4):check('hot_CPU_exact_same_resident_object_'+str(_),c(tile,cfg,p,'cpu') is a)
    check('hot_hits_no_bank_SHA_decode_or_snapshot_count',c.stats['bank_sha_verified_bytes']==before['bank_sha_verified_bytes'] and c.stats['cold_snapshot_decodes']==1 and c.stats['snapshot_reads']==1)
    check('hot_RNG_unchanged',m._rng_v1('cpu')==rng)
    path=m.frozen.path(tile['bank']['path']);original=path.read_bytes()
    path.write_bytes(b'changed external path after binding')
    check('path_mutation_after_binding_consumes_retained_approved_snapshot',c(tile,cfg,p,'cpu') is a and ordered(a)==ordered(baseline))
    changed=deepcopy(tile);changed['bank']['sha256']='0'*64
    reject('changed_external_SHA_cannot_rebind_hot_entry',lambda:c(changed,cfg,p,'cpu'),'differs')
    changed=deepcopy(tile);changed['bank']['path']=obs['path']
    reject('changed_external_path_cannot_rebind_hot_entry',lambda:c(changed,cfg,p,'cpu'),'differs')
    c.close();reject('cold_changed_bank_bytes_reject',lambda:cache(data)(tile,cfg,p,'cpu'),'changed')
    path.write_bytes(original)
    c=cache(data);realread=m.verified_bytes_v2
    def mutate_after_read(r,limit):
        snapshot=realread(r,limit)
        if r==tile['bank']:path.write_bytes(b'race after verification before decoder')
        return snapshot
    with patch.object(m,'verified_bytes_v2',mutate_after_read):race=c(tile,cfg,p,'cpu')
    check('between_verify_and_decode_mutation_cannot_substitute_unverified_payload',ordered(race)==ordered(baseline))
    path.write_bytes(original);c.close()
    jsonpath=FIX/'json_race.json';jref=json_ref(jsonpath,{'approved':'old'})
    def mutate_json(r,limit):
        snapshot=realread(r,limit);jsonpath.write_text('{"approved":"new"}');return snapshot
    with patch.object(m,'verified_bytes_v2',mutate_json):check('JSON_parser_uses_exact_verified_snapshot',m.verified_json_v2(jref)=={'approved':'old'})
    # All32 original caller cells, TRAIN then repeated model-outer VAL.
    c=cache(data)
    for parent in parents[:2]:
        for t in tiles[parent['parent_id']]:c(t,cfg,parent,'cpu')
    trainobjects={k:e['bank'] for k,e in c.cpu.items()}
    for model in range(7):
        for parent in parents[2:]:
            for t in tiles[parent['parent_id']]:c(t,cfg,parent,'cpu')
    check('all32_handmade_cells_retained',len(c.cpu)==len(c.snapshots)==32 and c.report()['all_working_set_retained'])
    check('model_outer_VAL_does_not_evict_TRAIN',all(c.cpu[k]['bank'] is value for k,value in trainobjects.items()))
    check('128_original_epoch_requests32_reads32_decodes96_hits',c.stats['requests']==128 and c.stats['snapshot_reads']==32 and c.stats['cold_snapshot_decodes']==32 and c.stats['CPU_hits']==96)
    check('no_CPU_eviction_or_oversize_bypass',c.stats['CPU_evictions']==c.stats['CPU_oversized_bypass']==0)
    check('bounded_resident_and_snapshot_accounting',c.cpu_used<=c.cpu_budget and c.snapshot_used<=c.snapshot_budget)
    size=m.resident_bytes_v1(baseline);snaplen=len(original);peak=c.stats['CPU_decode_peak_upper_bytes']
    check('decode_peak_accounted_separately',peak>=snaplen+m.archive_storage_bytes_v2(original))
    c.close();check('close_releases_all_caches_preserves_complete_set_receipt',c.closed and not c.cpu and not c.snapshots and not c.gpu and c.cpu_used==c.snapshot_used==c.gpu_used==0 and c.stats['complete_working_set_reached'])
    for name,limits,fragment in [('CPU',{'cpu':size},'capacity'),('snapshot',{'snapshot':snaplen},'capacity'),('decode_before_archive',{'decode':1},'capacity'),('decode_before_transform',{'decode':snaplen+m.archive_storage_bytes_v2(original)},'capacity')]:
        c=cache(data,**limits)
        if name in ('CPU','snapshot'):
            first=c(tile,cfg,p,'cpu');reject(name+'_shortage_fails_without_eviction',lambda:c(tiles[p['parent_id']][1],cfg,p,'cpu'),fragment)
            check(name+'_first_entry_remains_guarded',c.cpu[(p['parent_id'],0)]['bank'] is first and len(c.cpu)==1 and c.stats['CPU_evictions']==0)
        else:
            with patch.object(m.torch,'load',wraps=torch.load) as decoder:
                reject(name+'_fails_closed',lambda:c(tile,cfg,p,'cpu'),fragment)
                check(name+'_decode_count_expected',decoder.call_count==(0 if name=='decode_before_archive' else 1))
        c.close()
    # Existing resident guards catch ordinary mutation and metadata substitutions.
    for kind in ('tensor_version','dtype','shape','dict_order','requires_grad','primitive'):
        c=cache(data);a=c(tile,cfg,p,'cpu')
        if kind=='tensor_version':a.bank.leaf_x.add_(1)
        elif kind=='dtype':a.operators['age']=a.operators['age'].double()
        elif kind=='shape':a.bank.leaf_x=a.bank.leaf_x.reshape(280,2,47)
        elif kind=='dict_order':a.operators=dict(reversed(list(a.operators.items())))
        elif kind=='requires_grad':a.operators['age'].requires_grad_(True)
        else:a.layout.order=(0,1,2)
        reject('resident_guard_'+kind,lambda:c(tile,cfg,p,'cpu'))
        reject('close_guard_'+kind,c.close)
        check('close_cleanup_'+kind,c.closed and not c.cpu and not c.snapshots)
    for kind in ('roles','positions','split','config','dtype','device'):
        c=cache(data);c(tile,cfg,p,'cpu');parent=deepcopy(p);config=deepcopy(cfg);dtype=torch.float32;device='cpu'
        if kind=='roles':parent['reference_slots']=parent['reference_slots'][::-1].copy()
        elif kind=='positions':parent['positions'][0]+=1
        elif kind=='split':parent['split']='val'
        elif kind=='config':config['handmade']=False
        elif kind=='dtype':dtype=torch.float64
        else:device='cuda:1'
        reject('original_binding_guard_'+kind,lambda:c(tile,config,parent,device,dtype=dtype));c.close()
    c=cache(data,active=lambda:(_ for _ in ()).throw(ValueError('expired root reservation')))
    reject('root_expiry_before_cold_read',lambda:c(tile,cfg,p,'cpu'),'expired')
    check('expired_admission_no_snapshot',c.stats['snapshot_reads']==0);c.close()
    # GPU bookkeeping uses CPU-only fake transfers; no CUDA context is created.
    upper=m.transfer_upper_bytes_v1(baseline);c=cache(data,gpu=upper)
    g1=c(tile,cfg,p,'cuda');g2=c(tile,cfg,p,'cuda:0')
    check('mock_GPU_hit_identical_object_no_new_read',g1 is g2 and c.stats['GPU_hits']==1 and c.stats['snapshot_reads']==1)
    c(tiles[p['parent_id']][1],cfg,p,'cuda:0');c(tile,cfg,p,'cuda:0')
    check('original_GPU_whole_entry_LRU_CPU_bank_retained',c.stats['GPU_evictions']>=1 and c.gpu_used<=upper and len(c.cpu)==2 and c.stats['snapshot_reads']==2);c.close()
    c=cache(data,gpu=1);c(tile,cfg,p,'cuda:0');c(tile,cfg,p,'cuda:0')
    check('original_GPU_oversize_transfer_bypass_CPU_snapshot_retained',not c.gpu and c.stats['GPU_oversized_bypass']==2 and c.stats['snapshot_reads']==1);c.close()
    check('mock_transfers_never_created_CUDA_context',not torch.cuda.is_initialized())
    # Tiny handmade model only: exact forward/VJP/clipped AdamW plus RNG.
    c=cache(data);cached=c(tile,cfg,p,'cpu')
    torch.manual_seed(517);model=torch.nn.Linear(47,4);other=deepcopy(model)
    outcomes=[];gradients=[];states=[];rng=m._rng_v1('cpu');before=ordered(cached)
    for net,bank in ((model,baseline),(other,cached)):
        opt=torch.optim.AdamW(net.parameters(),lr=.003)
        logits=net(bank.bank.leaf_x);coeff=torch.linspace(-.7,1.1,logits.numel()).reshape_as(logits)
        (logits*coeff).mean().backward();outcomes.append(logits.detach());gradients.append([x.grad.clone() for x in net.parameters()])
        torch.nn.utils.clip_grad_norm_(net.parameters(),1.,error_if_nonfinite=True);opt.step();states.append(opt.state_dict())
    check('tiny_synthetic_forward_exact',torch.equal(*outcomes))
    check('tiny_synthetic_VJP_exact',all(torch.equal(x,y) for x,y in zip(*gradients)))
    check('tiny_synthetic_clipped_AdamW_model_and_state_exact',m.frozen.fingerprint_sha(model.state_dict())==m.frozen.fingerprint_sha(other.state_dict()) and m.frozen.fingerprint_sha(states[0])==m.frozen.fingerprint_sha(states[1]))
    check('tiny_synthetic_RNG_and_bank_unchanged',m._rng_v1('cpu')==rng and ordered(cached)==before);c.close()
    # Loader assertions copied exactly are exercised against bad handmade archives.
    mutations={
        'schema':lambda b:b.update(schema='wrong'),
        'leaf_dimensions':lambda b:setattr(b['fixed_prepared'].bank,'leaf_x',torch.zeros(2,279,47)),
        'query_dimensions':lambda b:setattr(b['fixed_prepared'].bank,'query_node_ids',torch.arange(183)),
        'reference_dimensions':lambda b:setattr(b['fixed_prepared'].bank.query_cache,'reference_ids',torch.arange(95)),
        'scales':lambda b:setattr(b['fixed_prepared'],'num_scales',2),
        'anchors':lambda b:setattr(b['fixed_prepared'].layout,'anchors',torch.arange(31)),
        'query_roles':lambda b:setattr(b['fixed_prepared'].bank,'query_node_ids',torch.arange(184).flip(0)),
        'reference_roles':lambda b:setattr(b['fixed_prepared'].bank.query_cache,'reference_ids',torch.arange(184,280).flip(0)),
        'sample_ids':lambda b:setattr(b['fixed_prepared'].bank,'sample_ids',torch.arange(1,281)),
        'features':lambda b:setattr(b['fixed_prepared'].bank,'feature_columns',tuple(range(47))),
        'positions':lambda b:setattr(b['fixed_prepared'].bank,'positions',torch.tensor([.999],dtype=torch.float64)),
        'query_flags':lambda b:b['fixed_prepared'].bank.leaf_x[:,:,4].zero_(),
    }
    for name,mutate in mutations.items():
        bad=save_bundle(FIX/('bad_'+name+'.pt'),p,mutate=mutate);snapshot=(ROOT/bad['bank']['path']).read_bytes()
        stats={'CPU_decode_peak_upper_bytes':0,'archive_storage_bytes_loaded':0}
        reject('original_loader_reject_'+name,lambda:m.BASE_LOAD_BANK(bad,cfg,p,'cpu'))
        reject('snapshot_loader_reject_'+name,lambda:m.decode_bank_snapshot_v2(snapshot,bad,cfg,p,'cpu',10_000_000,stats))
    # Scoped wrapper and original runner argument preservation without fitting.
    c=cache(data)
    try:
        with m.installed_cache_v2(c):
            check('only_original_TRAIN_VAL_aliases_patched',m.frozen.load_bank is c and m.controls.load_bank is c)
            raise RuntimeError('handmade exception')
    except RuntimeError:pass
    check('scoped_aliases_restored_on_exception',m.frozen.load_bank is m.BASE_LOAD_BANK and m.controls.load_bank is m.BASE_LOAD_BANK and c.closed)
    c=cache(data);output=FIX/'runner_output';output.mkdir(exist_ok=True)
    target=output/'bank_snapshot_cache_execution_v2.json'
    if target.exists():target.unlink()
    admission={'seed':101,'device':'cpu','output_directory':str(output.relative_to(ROOT)),'refs':{'original_config':cref,'observed_manifest':obs,'prepared_manifest':prep}}
    argv=['--train','--device','cpu','--seed','101','--output',admission['output_directory']]
    for role,arg in [('original_config','config'),('observed_manifest','observed-manifest'),('prepared_manifest','prepared-manifest')]:argv+=['--'+arg,admission['refs'][role]['path'],'--expected-'+arg+'-sha256',admission['refs'][role]['sha256']]
    argv+=['--expected-base-config-sha256','a'*64,'--storage-snapshot','handmade_original_storage','--expected-storage-snapshot-sha256','b'*64]
    before_argv=list(sys.argv);seen=[]
    def handmade_main():
        seen.append(sys.argv[1:]);check('runner_scoped_aliases',m.frozen.load_bank is c and m.controls.load_bank is c)
        m.controls.load_bank(tile,cfg,p,'cpu')
    with patch.object(m,'admit_cache_v2',return_value=(c,admission,{'original_source_sha256':{}})),patch.object(m.controls,'main',handmade_main):m.run_original_mechanisms_with_cache_v2({'path':'handmade','sha256':'a'*64},argv)
    check('original_scientific_argv_exact_and_sys_argv_restored',seen==[argv] and sys.argv==before_argv)
    check('runner_report_science_unchanged',json.loads(target.read_text())['original_science_argv']==argv and c.closed)
    obs_path=ROOT/obs['path'];obs_bytes=obs_path.read_bytes();c=cache(data)
    obs_path.write_bytes(obs_bytes+b' ')
    reject('source_manifest_identity_drift_remains_fail_closed',lambda:c(tile,cfg,p,'cpu'),'changed')
    check('metadata_drift_stops_before_bank_snapshot',c.stats['snapshot_reads']==0);c.close();obs_path.write_bytes(obs_bytes)
    oldcap=json_ref(FIX/'old_admission.json',{'schema':'biological_bank_cache_admission_v1','status':'active','phase':'fit'})
    reject('old_V1_capability_cannot_authorize_V2',lambda:m.admit_cache_v2(oldcap,phase='fit'),'Fresh')
    for budget in ('cpu','snapshot','decode','gpu'):
        reject('negative_'+budget+'_budget_reject',lambda budget=budget:cache(data,**{budget:-1}),'budgets')
    oldgpu=next(n for n in ast.walk(ast.parse((ROOT/'src/arggnn/biological_bank_cache_v1.py').read_text())) if isinstance(n,ast.If) and ast.unparse(n.test)=="target.type == 'cpu'")
    newgpu=next(n for n in ast.walk(ast.parse((ROOT/m.SOURCE_PATH).read_text())) if isinstance(n,ast.If) and ast.unparse(n.test)=="target.type == 'cpu'")
    check('AST_original_GPU_transfer_LRU_branch_identical',ast.dump(oldgpu,include_attributes=False)==ast.dump(newgpu,include_attributes=False))
    # AST proof: only bank IO statements changed, all remaining checks identical.
    def funcs(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
    old=funcs(ROOT/'src/arggnn/biological_bank_cache_v1.py');new=funcs(ROOT/m.SOURCE_PATH);original_funcs=funcs(ROOT/'src/arggnn/biological_candidate.py')
    same=lambda a,b:ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
    for name in ('_utc','_identity','_tensors','resident_bytes_v1','transfer_upper_bytes_v1','_guard','_parent_join','_rng_v1','_sync_v1'):check('AST_unchanged_'+name,same(old[name],new[name]))
    check('AST_all_original_loader_scientific_statements_unchanged',all(same(a,b) for a,b in zip(original_funcs['load_bank'].body[2:],new['decode_bank_snapshot_v2'].body[1:])) and len(original_funcs['load_bank'].body[2:])==len(new['decode_bank_snapshot_v2'].body[1:]))
    source=(ROOT/m.SOURCE_PATH).read_text()
    check('new_metadata_has_no_hash_then_read_text_JSON',not any(isinstance(n,ast.Attribute) and n.attr=='read_text' for n in ast.walk(ast.parse(source))))
    shipped=json.loads((ROOT/m.CONFIG_PATH).read_text())
    for path,sha in shipped['original_source_sha256'].items():check('original_source_pin_'+path,hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha)
    report=m.source_report_v2()
    check('default_report_inactive_no_actual_IO_or_execution',report['actual_inputs_opened'] is False and report['models_instantiated'] is False and report['actual_profile_fit_GPU_budget_or_reservation'] is False)
    artifact_manifest={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in FIX.rglob('*') if x.is_file()}
    (OWN/'handmade_fixture_manifest.json').write_text(json.dumps({'owned_handmade_only':True,'actual_data_read':False,'artifacts':artifact_manifest},indent=2,sort_keys=True)+'\n')
    result={'schema':'biological_bank_snapshot_cache_v2_handmade_checks','status':'PASS','checks_count':len(checks),'checks':checks,'actual_banks_models_data_GPU_or_fit':False,'tiny_synthetic_model_only':True,'production_model_instantiated':False,'actual_memory_throughput_qualified':False}
    (OWN/'handmade_checks.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},sort_keys=True))
if __name__=='__main__':main()
