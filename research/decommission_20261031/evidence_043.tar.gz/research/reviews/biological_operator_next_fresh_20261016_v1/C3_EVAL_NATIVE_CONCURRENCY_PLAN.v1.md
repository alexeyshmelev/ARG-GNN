# C3 full30Mb EVAL beside native MLM after TRAIN

Reuse the existing scientific EVAL algorithm unchanged under a fresh finite successor EVAL slot after current TRAIN genuinely completes and its controller is terminal/drained. Sealed native v3 source and the live pool were not edited. This source/metadata audit loaded or hashed no truth/checkpoint/focal/tree/genotype payload, imported no scientific module, probed no process/GPU, and launched no work.

## Scientific contract

Call predict_one_original_VAL_v1 for one original VAL parent at a time, all six frozen epochs sequentially. It creates one fresh C3 model; forward/reverse loaders explicitly use num_workers=0,pin_memory=False; candidate native Dataset state is released in finally. The existing inference/eval-mode stream encodes every original tree forward, then reencodes every tree in reverse, carries directional GRU state across blocks and saves only focal forward states on CPU. Global neighbor geometry crosses block boundaries. No query crop, tree pruning, finite halo, block-boundary recurrent reset or new approximation is needed.

Caps stay250000 complete node occurrences/32complete trees/4096original sites/all1600haplotypes; hidden32,site-chunk256,classesEUR,EAS,AFR. A single tree exceeding node/site caps fails explicitly rather than truncating. Keep all600references and1000query columns.

Require genuine completed30epochs/600updates/6000000focal exposures and all six frozen candidate refs at epochs5,10,15,20,25,30. Native ARGformer MLM completion/checkpoints are not a C3 EVAL prerequisite; exact native focal preparation is.

Six checkpoints × the five original full30Mb VAL parents must produce30ordinary prediction seals. Preserve the unchanged30-cell barrier before the separate truth resolver/score/select stage. TEST stays deferred. Ready parents may be predicted early, but missing parents cannot be waived and partial checkpoint selection is forbidden.

## 8GiB CUDA plan

The companion count-memory JSON uses the declared caps, not actual small observed blocks. Feature-bank planning term73240576bytes; one node-width FP32 tensor32000000bytes; one256×1600×32 site-chunk tensor52428800bytes; one32×1600×32 context/history6553600bytes; directional hidden204800bytes. Saved focal forward1280000bytes and probabilities120000bytes are CPU arrays.

The conservative allowance ledger includes32node-width workspaces;16site-chunk-width workspaces; retained pooled sum/max/count lists and cats bounded by16chunks×32holds; context/history/GRU input/flip buffers; model/classifier/focal transfers; and2GiB opaque CUDA/GRU workspace. Subtotal5208547328bytes(4.851GiB), leaving3381387264bytes(3.149GiB) inside8GiB for allocator fragmentation/unlisted transients. This is a count-derived operational plan, not a proof of PyTorch/cuDNN peak or an observed fit.

Enforce8589934592bytes before scientific block allocation using a narrow reviewed EVAL operational wrapper/allocator and owned-process monitor. Abort/drain on excess or OOM; do not change scientific inputs/semantics. The old current980 worker sets its allocator fraction from a50000000000-byte scientific guard and its contract hardcodes that guard. A smaller outer scheduling declaration alone is insufficient: avoid resetting the new allocator ceiling upward when reusing old worker code. Keep scientific checks while adding the new ceiling in fresh source.

Authenticate separate CPU RSS, deadline, output/log/temp scopes and source closure. CUDA8GiB does not bound two retained CPU native Dataset states/mmap mappings. No worker/prefetch/pinned-memory multiplication is present.

## Fresh successor slot

Root/h056 should extend a fresh copy of sealed v3 finite catalogue/envelope/dispatcher/validator source with one explicit C3 EVAL slot. Sealed v3 currently declares native MLM only and rejects extra slots. Preserve existing GPU0/UUID ownership, logical leases, genuine prior-controller wait/drain, expiry, storage, source closure, output and failure lifecycle. Add no scheduling framework and edit no live pool. Run only one EVAL parent at once; checkpoints stay sequential.

EVAL cap8192MiB + usual2048MiB margin => peak10240MiB. Native source is40GiB cap +2GiB margin =>43008MiB(42GiB); plan43GiB conservatively. With stipulated external14GiB and existing4GiB pool headroom:43+10+14+4=71GiB, leaving9GiB against stipulated80GiB. TRAIN26GiB including margin would instead give43+26+14+4=87GiB. Overlap native+EVAL only after TRAIN finishes. These are planning inputs; the unchanged actual device/external-usage gate decides admission.

Bind exact actual TRAIN completion/directwait, parent observation/native prep/focal/plan refs and completed/closed plan evidence, pinned Torch/PyG runtime, fresh operational caps/storage/expiry and full source closure. Truth capability is absent from EVAL. Keep completed preparation/plans read-only with existing charges/retention. No admission, accounting, credit, storage mutation or launch occurred here.

## Actual parent readiness

Full exact refs/hashes, preparation directwait0/drain and completed/closed block plans are in C3_EVAL_actual_refs.v1.json.

|Parent|Observation/native preparation|C3 block plan|
|---|---|---|
|VAL000|completed shared_v1 native_paths|completed/closed;76527trees,228477sites,2392blocks|
|VAL001|completed shared_v1 native_paths|completed/closed;76453trees,227316sites,2390blocks|
|VAL002|completed corrected H020v3|pending; exact future observation-only bindings supplied|
|VAL003|pending downstream observation/native/focals|pending; known simulation output directory was empty at audit|
|VAL004|no immutable upstream refs supplied|pending|

VAL000 plan sha f9f6bb3d834a049aeb1b899d43b038360b9e92c04895685567827ec066087637.
VAL001 plan sha ff8e933510bb3ed9fcd42f5c697490c2a3d4410d209c12fec1304fb2904ec02b.
VAL002 must use experiments/results/American_C3_val002_full30mb_native_paths_H020v3_v1/completed.json, sha aa5afa541e495ea4eda2b39fe522673a277c9759278bc40fa91f29206fcf559a, and focals in that same H020v3 directory. The old shared_v1/native_paths route is absent and must not be synthesized.

Prerequisites: genuine TRAIN completion/all-six refs; reviewed fresh EVAL slot with real8GiB enforcement; observation-only VAL002 plan completion/wait/closure using supplied corrected bindings; full original VAL003/004 upstream preparation/plans before the unchanged30-seal barrier can finish.
