"""Finite source-control mocks only: no Popen, /proc, budgets, arrays or models."""
from pathlib import Path
import ast, copy, datetime, hashlib, io, json, os, signal, subprocess, sys, types
from contextlib import nullcontext

ROOT = Path("/workspace-SR003.nfs2/ARG-GNN")
OWN = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_resume_v3_independent"
SUBMITTED = "--submitted" in sys.argv
STAGE = "submitted" if SUBMITTED else "corrected"
SOURCE = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_root/resume_v3"/(
    "run_matrix_draft_before_exit_binding.py" if SUBMITTED else "run_matrix.py")
SOURCE_SHA = ("769cf7daaa64788bb4ef8f05ba23ddb3115b1f32935327f707c276e47a244c44" if SUBMITTED
              else "d6507d6590e1fc78c93c7aa1dd3b2734a4c8df1eb14ebf32f9cfc32a8f0032ef")
PLAN_PATH = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_root/resume_v3/execution_plan.json"
PLAN_SHA = "6f61ac792cd84465cfb1dee53d81d35f450a452cef992543e6748b3a34a2f6ec"
source = SOURCE.read_bytes()
plan_bytes = PLAN_PATH.read_bytes()
assert hashlib.sha256(source).hexdigest() == SOURCE_SHA
assert hashlib.sha256(plan_bytes).hexdigest() == PLAN_SHA
plan = json.loads(plan_bytes)
cfg = json.loads((ROOT/plan["config"]["path"]).read_text())
metadata = {str(PLAN_PATH.relative_to(ROOT)): plan}
for field in ("registration","config","review","external_initial_states","admission_template"):
    ref = plan[field]
    raw = (ROOT/ref["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ref["sha256"]
    metadata[ref["path"]] = json.loads(raw)
recovery_raw = (ROOT/plan["recovery"]["path"]).read_bytes()
assert hashlib.sha256(recovery_raw).hexdigest()==plan["recovery"]["sha256"]
recovery_actual = json.loads(recovery_raw)
for field in ("evidence","terminal","actual_exit","original_matrix_failure"):
    ref = recovery_actual[field]
    raw = (ROOT/ref["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==ref["sha256"]
    metadata[ref["path"]] = json.loads(raw)
# Only compact JSON is read; no real tensor opens, sizes or hashes are performed.
# Use the actual accepted metadata-only validator, without importing production modules.
child_source = (ROOT/plan["source"]["path"]).read_bytes()
assert hashlib.sha256(child_source).hexdigest() == plan["source"]["sha256"]
tree = ast.parse(child_source)
selected = [n for n in tree.body if getattr(n,"name",None) in
            {"require","utc","validate_admission_metadata_v1"}]
validator = {"datetime":datetime.datetime,"timezone":datetime.timezone,"CONFIG_PATH":plan["config"]["path"],"CONFIG_SHA256":plan["config"]["sha256"]}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(ROOT/plan["source"]["path"]),"exec"),validator)
assert plan["matrix"] == cfg["matrix"] and len(plan["matrix"]) == 16
assert len({c["id"] for c in plan["matrix"]}) == 16
seen = set()
for cell in plan["matrix"]:
    assert set(cell["reference_cells"]) <= seen
    seen.add(cell["id"])

def encoded(x):
    return (json.dumps(x,sort_keys=True,allow_nan=False)+"\n").encode()

def case(name, *, failure_index=0, failure_method="manual_original"):
    case_root = OWN/"mock_cases"/"r003"/STAGE/name
    (case_root/"cells").mkdir(parents=True,exist_ok=False)
    ns = {"__file__":str(SOURCE),"__name__":"_supervisor_mock"}
    exec(compile(source,str(SOURCE),"exec"),ns)
    files = {}
    writes = []
    launched = []
    objects = []
    checks = []
    views = []
    clock = [0.]
    active = [0]
    max_active = [0]
    plan_case = copy.deepcopy(plan)
    if name == "matrix_order_change":
        plan_case["matrix"][0],plan_case["matrix"][1] = plan_case["matrix"][1],plan_case["matrix"][0]
    if name == "inactive_plan":
        plan_case["active"] = False
    def relative(path):
        return str(Path(path).relative_to(ROOT))
    def ref(path):
        key = relative(path)
        return {"path":key,"sha256":hashlib.sha256(files[key]).hexdigest()}
    def write(path,value):
        key = relative(path)
        assert key.startswith(str(OWN.relative_to(ROOT))+"/")
        if key in files: raise FileExistsError(key)
        files[key] = encoded(value)
        writes.append((key,copy.deepcopy(value)))
        return ref(path)
    def verified(r):
        assert set(r)=={"path","sha256"}, "Only strict two-field reader refs"
        if r["path"] == str(PLAN_PATH.relative_to(ROOT)):
            return copy.deepcopy(plan_case)
        if r["path"] in metadata and r["path"] not in files:
            return copy.deepcopy(metadata[r["path"]])
        if hashlib.sha256(files[r["path"]]).hexdigest() != r["sha256"]: raise ValueError("Frozen mock metadata changed")
        return json.loads(files[r["path"]])
    def digest(path):
        if Path(path) == SOURCE: return SOURCE_SHA
        if Path(path) == ROOT/plan["source"]["path"]:
            return "0"*64 if name == "profile_source_drift" else plan["source"]["sha256"]
        raise AssertionError("Unexpected content read")
    def identity(pid):
        if pid == 424242: return {"pid":pid,"start_ticks":10,"uid":123}
        return {"pid":pid,"start_ticks":pid+100,"uid":123}
    def current(*args):
        view = {"legacy_ledger_sha256":f"legacy_{len(views)}",
                "supplemental_ledger_sha256":f"fresh_{len(views)}"}
        views.append(view)
        return {},{},view
    def reservation(*args,**kwargs):
        assert args[1] == plan["reservation"]
        assert kwargs["expected_source_sha256"] == cfg["budget_source_ref"]["sha256"]
        assert kwargs["expected_config_sha256"] == cfg["budget_config_ref"]["sha256"]
        assert kwargs["initial_ledger_pins"] == views[-1]
        assert kwargs["boundary"] is True
        checks.append(copy.deepcopy(kwargs))
        return {}
    first = cfg["matrix"][0]["id"]
    resume_fixture = copy.deepcopy(plan_case["resume_completed"][first])
    first_evidence = copy.deepcopy(metadata[resume_fixture["evidence"]["path"]])
    original_exit_fixture = copy.deepcopy(metadata[recovery_actual["actual_exit"]["path"]])
    recovery_fixture = copy.deepcopy(recovery_actual)
    for method in ("manual_original","matched_parent_v3"):
        artifact_path = ROOT/resume_fixture[method]["path"]
        files[relative(artifact_path)] = ("tiny resumed mock "+method).encode()
        resume_fixture[method] = ref(artifact_path)
        first_evidence["methods"][method]["artifact"] = {
            **resume_fixture[method],"bytes":len(files[relative(artifact_path)])}
    if name=="resume_bad_digest":
        first_evidence["methods"]["manual_original"]["artifact"]["sha256"]="0"*64
        resume_fixture["manual_original"]["sha256"]="0"*64
    if name=="resume_bad_size":first_evidence["methods"]["manual_original"]["artifact"]["bytes"]+=1
    if name=="resume_bad_schema":first_evidence["methods"]["manual_original"]["artifact"].pop("bytes")
    if name=="resume_wrong_cell":first_evidence["cell"]=copy.deepcopy(cfg["matrix"][1])
    files[resume_fixture["evidence"]["path"]]=encoded(first_evidence)
    resume_fixture["evidence"]=ref(ROOT/resume_fixture["evidence"]["path"])
    terminal_fixture = {
        "kind":"anchor_parent_CPU_profile_root_terminal_v1","status":"complete","returncode":0,
        "job_id":first_evidence["job_id"],"cell_id":first,"evidence_ref":resume_fixture["evidence"],
        "admission_ref":first_evidence["admission_ref"]}
    if name=="resume_nonzero_terminal":terminal_fixture["returncode"]=3
    files[resume_fixture["terminal"]["path"]]=encoded(terminal_fixture)
    resume_fixture["terminal"]=ref(ROOT/resume_fixture["terminal"]["path"])
    if name=="original_nonzero_exit":original_exit_fixture["returncode"]=7
    if name=="original_watchdog":original_exit_fixture["watchdog_reason"]="mock watchdog"
    if name=="original_wrong_cell":original_exit_fixture["cell"]=cfg["matrix"][1]["id"]
    if name=="original_RSS_over":original_exit_fixture["watched_peak_RSS_bytes"]=128000000001
    files[recovery_fixture["actual_exit"]["path"]]=encoded(original_exit_fixture)
    recovery_fixture["actual_exit"]=ref(ROOT/recovery_fixture["actual_exit"]["path"])
    if name=="changed_original_exit_bytes":files[recovery_fixture["actual_exit"]["path"]]+=b" "
    recovery_fixture["evidence"]=resume_fixture["evidence"]
    recovery_fixture["terminal"]=resume_fixture["terminal"]
    recovery_fixture["artifacts"]={k:resume_fixture[k] for k in ("manual_original","matched_parent_v3")}
    if name=="recovery_reference_drift":recovery_fixture["artifacts"]["manual_original"]={"path":"wrong","sha256":"0"*64}
    plan_case["resume_completed"]={first:resume_fixture}
    if name=="resume_empty":plan_case["resume_completed"]={}
    if name=="resume_nonprefix":plan_case["resume_completed"]={cfg["matrix"][1]["id"]:resume_fixture}
    if name=="resume_missing_method":del plan_case["resume_completed"][first]["manual_original"]
    files[plan_case["recovery"]["path"]]=encoded(recovery_fixture)
    plan_case["recovery"]=ref(ROOT/plan_case["recovery"]["path"])
    if name=="changed_recovery_bytes":files[plan_case["recovery"]["path"]]+=b" "
    class VirtualPath(type(Path())):
        def stat(self,*args,**kwargs):
            key=relative(self)
            if key in files:return types.SimpleNamespace(st_size=len(files[key]))
            raise AssertionError("No actual artifact stat authorized")
        def open(self,*args,**kwargs):
            if str(self).startswith(str(case_root)+"/"):return io.BytesIO()
            raise AssertionError("No real artifact open authorized")

    def finish(child,rc):
        if child.returncode is not None: return
        child.returncode = rc
        active[0] -= 1
        a_ref = child.admission
        a = verified(a_ref)
        cell = next(c for c in cfg["matrix"] if c["id"] == a["cell_id"])
        methods = {}
        for method in ("manual_original","matched_parent_v3"):
            path = ROOT/a["output_directory"]/(method+".pt")
            files[relative(path)] = ("tiny mocked "+method+" "+cell["id"]).encode()
            method_ref = ref(path)
            if name in {"bad_artifact","bad_second_artifact"} and child.index == failure_index and method == failure_method:
                method_ref["sha256"] = "0"*64
            methods[method] = {"artifact":{**method_ref,"bytes":len(files[relative(path)])}}
            if name=="new_bad_size" and child.index==failure_index and method==failure_method:
                methods[method]["artifact"]["bytes"] += 1
        evidence = {"status":"completed_full_support_observed_only_CPU_synthetic_numerical_cell",
                    "cell":copy.deepcopy(cell),"admission_ref":a_ref,"methods":methods}
        if name == "wrong_evidence_cell" and child.index == failure_index:
            evidence["cell"] = copy.deepcopy(cfg["matrix"][(child.index+2)%16])
        files[relative(ROOT/a["output_directory"]/"evidence.json")] = encoded(evidence)
    class Child:
        def __init__(self,command,**kwargs):
            assert active[0] == 0, "Overlapping child"
            self.index = len(launched)
            self.pid = 600000+self.index
            self.returncode = None
            self.polls = 0
            path = command[command.index("--admission")+1]
            self.admission = {"path":path,"sha256":command[-1]}
            a = verified(self.admission)
            assert a["initial_state_sha256"] == metadata[plan["external_initial_states"]["path"]]["states"][
                next(c for c in cfg["matrix"] if c["id"]==a["cell_id"])["geometry"]+"_"+
                next(c for c in cfg["matrix"] if c["id"]==a["cell_id"])["dtype"]]["state_sha256"]
            assert set(a["comparison_refs"]) == set(next(c for c in cfg["matrix"] if c["id"]==a["cell_id"])["reference_cells"])
            for prior, refs in a["comparison_refs"].items():
                assert set(refs) == {"evidence","terminal","manual_original","matched_parent_v3"}
                if prior == cfg["matrix"][0]["id"]:
                    assert original_exit_fixture["returncode"] == 0 or SUBMITTED
                    assert refs==resume_fixture
                else:
                    assert any(k.endswith(prior+".exit_observed.json") and v["returncode"]==0 for k,v in writes)
                assert all(set(value)=={"path","sha256"} for value in refs.values())
            launched.append(a["cell_id"])
            objects.append(self)
            active[0] += 1
            max_active[0] = max(max_active[0],active[0])
        def poll(self):
            self.polls += 1
            if self.returncode is not None: return self.returncode
            if name in {"RSS_boundary","cell_timeout","matrix_timeout"} and self.index == failure_index: return None
            if self.polls == 1: return None
            finish(self,3 if name=="nonzero_exit" and self.index==failure_index else 0)
            return self.returncode
        def wait(self,timeout=None):
            if self.returncode is None: finish(self,0)
            return self.returncode
    class Proc:
        def __init__(self,text): self.text = text
        def __truediv__(self,key): return Proc(self.text+"/"+str(key))
        def read_text(self):
            child = objects[-1]
            assert self.text == "/proc/"+str(child.pid)+"/status"
            if name == "exit0_zombie_no_RSS" and child.index==failure_index:
                finish(child,0)
                return "State:\tZ (zombie)\n"
            if name == "exit0_missing_proc" and child.index==failure_index:
                finish(child,0)
                raise FileNotFoundError(self.text)
            if name == "cell_timeout" and child.index==failure_index:
                clock[0] = plan["cell_max_seconds"]+1
            if name == "matrix_timeout" and child.index==failure_index:
                clock[0] = plan["matrix_max_seconds"]+1
            rss = 128000000001 if name=="RSS_boundary" and child.index==failure_index else 1024*1024
            return "State:\tR\nVmRSS:\t"+str((rss+1023)//1024)+" kB\n"
    def path(value):
        return Proc(str(value)) if str(value).startswith("/proc") else Path(value)
    stopped = []
    def stop(child,saved):
        assert identity(child.pid) == saved
        stopped.append(saved)
        if child.returncode is None: finish(child,-15)
    budget = types.ModuleType("arggnn.project_budget_v4")
    budget.policy = lambda *a: ({},{})
    budget.mutex = lambda *a: nullcontext()
    budget.current = current
    budget.check_reservation = reservation
    profile = types.ModuleType("arggnn.anchor_parent_cpu_profile_v2")
    profile.load_config_v1 = lambda: copy.deepcopy(cfg)
    profile.validate_admission_metadata_v1 = validator["validate_admission_metadata_v1"]
    package = types.ModuleType("arggnn")
    package.project_budget_v4 = budget
    previous = {k:sys.modules.get(k) for k in ("arggnn","arggnn.project_budget_v4","arggnn.anchor_parent_cpu_profile_v2")}
    sys.modules.update({"arggnn":package,"arggnn.project_budget_v4":budget,"arggnn.anchor_parent_cpu_profile_v2":profile})
    ns.update(ROOT=VirtualPath(ROOT),BASE=VirtualPath(case_root),verified=verified,digest=digest,reference=ref,write=write,
              identity=identity,stop_child=stop,Path=path,
              os=types.SimpleNamespace(environ={"CUDA_VISIBLE_DEVICES":"","PYTHONDONTWRITEBYTECODE":"1"},getpid=lambda:424242),
              subprocess=types.SimpleNamespace(Popen=Child),
              time=types.SimpleNamespace(monotonic=lambda:clock[0],sleep=lambda n:clock.__setitem__(0,clock[0]+n)))
    error = None
    try:
        ns["run"]({"path":str(PLAN_PATH.relative_to(ROOT)),"sha256":PLAN_SHA},SOURCE_SHA)
    except BaseException as exc:
        error = {"type":type(exc).__name__,"message":str(exc)}
    finally:
        for key,prior in previous.items():
            if prior is None:sys.modules.pop(key,None)
            else:sys.modules[key] = prior
    terminal = [(k,v) for k,v in writes if k.endswith(".terminal.json")]
    failures = [v for k,v in writes if k.endswith("matrix_failure.json")]
    exits = [v for k,v in writes if k.endswith(".exit_observed.json")]
    final = [v for k,v in writes if k.endswith("matrix_terminal.json")]
    result = {"case":name,"error":error,"launched":launched,"max_concurrent_children":max_active[0],
              "fresh_ledger_snapshots":len(views),"reservation_checks":len(checks),
              "stops":len(stopped),"observed_exits":exits,"cell_terminals":len(terminal),
              "matrix_complete":bool(final),"failure_recorded":bool(failures)}
    if name=="all15_success":
        assert error is None and launched==[c["id"] for c in cfg["matrix"][1:]], str(result)
        assert max_active[0]==1 and len(views)==len(checks)==len(terminal)==15 and final
    elif name in {"matrix_order_change","inactive_plan"}:
        assert error and not launched and not terminal
    elif name=="profile_source_drift":
        assert error and not launched and failures
    elif name in {"bad_artifact","bad_second_artifact","new_bad_size"}:
        assert error["message"]=="Actual numerical artifact digest/size changed"
        assert len(launched)==failure_index+1 and failures
        result["complete_terminal_absent_on_artifact_failure"] = not terminal
        result["failed_current_absent_from_completed"] = launched[-1] not in failures[-1]["completed"]
        assert not terminal and result["failed_current_absent_from_completed"]
    elif name=="exit0_zombie_no_RSS":
        assert error is None and final and len(launched)==15
        result["exit0_zombie_observed_successfully"] = exits[0]["returncode"] == 0
        assert result["exit0_zombie_observed_successfully"]
    elif name=="exit0_missing_proc":
        assert error is None and final and len(launched)==15
    elif name in {"RSS_boundary","cell_timeout","matrix_timeout"}:
        assert error and len(launched)==failure_index+1 and stopped and exits[-1]["watchdog_reason"]
        assert not final
    elif name.startswith("resume_") or name.startswith("original_") or name in {
        "changed_original_exit_bytes","changed_recovery_bytes","recovery_reference_drift"}:
        if SUBMITTED and name in {"original_nonzero_exit","original_watchdog","original_wrong_cell",
                                  "original_RSS_over","changed_original_exit_bytes",
                                  "changed_recovery_bytes","recovery_reference_drift"}:
            assert error is None and final and len(launched)==15
            result["submitted_recovery_gap_reproduced"]=True
        else:
            assert error and not launched and not terminal and not final
    else:
        assert error and len(launched)==failure_index+1 and not final, str(result)
    return result

case_names = [
    "all15_success","matrix_order_change","inactive_plan","profile_source_drift",
    "nonzero_exit","wrong_evidence_cell","bad_artifact","bad_second_artifact","new_bad_size",
    "RSS_boundary","cell_timeout","matrix_timeout","exit0_missing_proc","exit0_zombie_no_RSS",
    "resume_bad_digest","resume_bad_size","resume_bad_schema","resume_wrong_cell",
    "resume_nonzero_terminal","resume_nonprefix","resume_missing_method",
    "original_nonzero_exit","original_watchdog","original_wrong_cell","original_RSS_over",
    "changed_original_exit_bytes","changed_recovery_bytes","recovery_reference_drift"]
cases=[case(name,failure_index=2 if name=="nonzero_exit" else 0,
            failure_method="matched_parent_v3" if name=="bad_second_artifact" else "manual_original")
       for name in case_names]
if not SUBMITTED:cases.append(case("resume_empty"))
# Direct mocked pidfd stopper exercises the original function without real signals.
ns = {"__file__":str(SOURCE),"__name__":"_stop_mock"}
exec(compile(source,str(SOURCE),"exec"),ns)
signals = []; closed = []; waits = []
saved = {"pid":777,"start_ticks":888,"uid":123}
class StopChild:
    pid = 777
    def poll(self):return None
    def wait(self,timeout):
        waits.append(timeout)
        if len(waits)==1:raise subprocess.TimeoutExpired(["mock"],timeout)
        return -9
ns.update(os=types.SimpleNamespace(pidfd_open=lambda pid:999,close=lambda fd:closed.append(fd)),
          identity=lambda pid:dict(saved),signal=types.SimpleNamespace(
              SIGTERM=signal.SIGTERM,SIGKILL=signal.SIGKILL,
              pidfd_send_signal=lambda fd,sig:signals.append([fd,int(sig)])))
ns["stop_child"](StopChild(),saved)
assert signals==[[999,int(signal.SIGTERM)],[999,int(signal.SIGKILL)]] and closed==[999] and waits==[10,10]
signals.clear();closed.clear()
ns["identity"] = lambda pid:{**saved,"start_ticks":889}
try:ns["stop_child"](StopChild(),saved)
except ValueError as exc:assert str(exc)=="Child identity drift"
else:raise AssertionError("Identity drift not rejected")
assert not signals and closed==[999]
result = {"kind":"bounded_independent_supervisor_control_mocks","source_sha256":SOURCE_SHA,
          "plan_sha256":PLAN_SHA,"cases":cases,"direct_pidfd_mock_checks":
          ["exact-child TERM then KILL after10seconds","pidfd always closed","identity drift sends no signal"],
          "actual_children_proc_queries_budget_calls_arrays_models_GPU":False,
          "source_mock_findings":(["recovery/original exit not read or bound"] if SUBMITTED else [])}
with (OWN/(STAGE+"_mock_results.json")).open("x") as f:json.dump(result,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps({"mock_cases":len(cases),"findings":result["source_mock_findings"],
                  "remaining15_success":cases[0]["matrix_complete"],"actual_execution":False},sort_keys=True))
