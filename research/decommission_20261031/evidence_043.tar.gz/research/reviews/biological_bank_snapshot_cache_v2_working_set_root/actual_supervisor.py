from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,traceback
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
BASE=ROOT/'research/reviews/biological_bank_snapshot_cache_v2_working_set_root'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write(chr(10))
a=json.loads((BASE/'root_admission.json').read_text())
a['external_RSS_watchdog_started']=True
a['actual_external_watchdog']={'pid':os.getpid(),'started_utc':utc(),'RSS_limit_bytes':256000000000,'wall_limit_seconds':1800}
ap=BASE/'root_admission_with_actual_watchdog.json';save(ap,a)
cp=BASE/'cache_admission.json'
caller=ROOT/'research/reviews/biological_bank_snapshot_cache_v2_working_set_author/caller.py'
cmd=[str(ROOT/'.runtime/env/bin/python'),'-B',str(caller),'--execute','--root-admission',str(ap.relative_to(ROOT)),'--expected-root-admission-sha256',sha(ap),'--cache-admission',str(cp.relative_to(ROOT)),'--expected-cache-admission-sha256',sha(cp)]
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')
child=None;started=time.monotonic();peak=0;reason=None
try:
 with (BASE/'actual_caller.stdout').open('xb') as stdout,(BASE/'actual_caller.stderr').open('xb') as stderr:
  child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  save(BASE/'actual_started.json',{'utc':utc(),'worker_pid':child.pid,'supervisor_pid':os.getpid(),'command':cmd,'CPU_only':True,'watchdog_active_before_worker_launch':True})
  while child.poll() is None:
   status=Path(f'/proc/{child.pid}/status')
   if status.exists():
    rss=next((int(x.split()[1])*1024 for x in status.read_text().splitlines() if x.startswith('VmRSS:')),0);peak=max(peak,rss)
    if rss>256000000000:reason='RSS_limit_exceeded'
   if time.monotonic()-started>1800:reason='wall_limit_exceeded'
   if reason:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(2)
  code=child.wait()
 save(BASE/'actual_terminal.json',{'utc':utc(),'worker_pid':child.pid,'supervisor_pid':os.getpid(),'returncode':code,'watchdog_trigger':reason,'sampled_peak_RSS_bytes':peak,'elapsed_seconds':time.monotonic()-started,'GPU_used':False,'scientific_fit_performed':False})
except BaseException:
 if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
 raise
