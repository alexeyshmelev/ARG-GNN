"""Independent source and deterministic mock checks for the sealed complete32 caller."""
from __future__ import annotations
from pathlib import Path
from copy import deepcopy
from contextlib import ExitStack
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone
from types import SimpleNamespace
from unittest.mock import patch
import ast,hashlib,importlib.util,json,os,random,resource,sys

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
OUT=Path(__file__).resolve().parent
AUTHOR=ROOT/'research/reviews/biological_bank_snapshot_cache_v2_working_set_author'
CHECKS=[];BLOCKED=[];HASHED={}
def ck(name,value):
    CHECKS.append({'name':name,'PASS':bool(value)})
    if not value:raise AssertionError(name)
def reject(name,fn,fragment=''):
    try:fn()
    except ValueError as error:ck(name,fragment in str(error));return
    raise AssertionError(name+': accepted')
def ref(path):
    raw=path.read_bytes()
    result={'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest()}
    HASHED[result['path']]={**result,'bytes':len(raw)}
    return result
def audit(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        name=os.fsdecode(args[0]);p=Path(name)
        if p.is_absolute() and (name.startswith(str(ROOT/'data')+'/') or name.startswith('/proc/') or name.startswith(str(ROOT/'.runtime/conda')+'/') or name in {str(ROOT/'.runtime/gpup/storage_reservations.json'),str(ROOT/'.runtime/storage/project_budget_v4.json')}):
            BLOCKED.append({'event':event,'path':name});raise AssertionError('actual data/proc/native runtime/ledger read forbidden')
        mode=args[1];flags=args[2]
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
        if writing and not str(p.absolute()).startswith(str(OUT)+'/'):
            raise AssertionError('write outside owned review forbidden')
    if event in {'os.mkdir','os.remove','os.rmdir','os.rename'}:
        for value in args[:2] if event=='os.rename' else args[:1]:
            if isinstance(value,(str,bytes,os.PathLike)) and not str(Path(os.fsdecode(value)).absolute()).startswith(str(OUT)+'/'):
                raise AssertionError('filesystem mutation outside owned review forbidden')
    if event in {'subprocess.Popen','os.kill','os.killpg','socket.connect','socket.bind'}:
        BLOCKED.append({'event':event});raise AssertionError('launch/signal/network forbidden')
sys.addaudithook(audit)
resource.getrusage=lambda *a,**k:(_ for _ in ()).throw(AssertionError('actual resource measurement forbidden'))
spec=importlib.util.spec_from_file_location('sealed_complete32_caller',AUTHOR/'caller.py')
q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
real_rss=q.rss_peak_bytes
q.rss_peak_bytes=lambda:10
q.m.controls.model_factory=lambda *a,**k:(_ for _ in ()).throw(AssertionError('production model factory forbidden'))
torch=q.m.torch

pins={
 AUTHOR/'caller.py':'38d0935e96f56686fd69708a9f5e7040a5b8c21e9dda237c57976da1cc480b8b',
 AUTHOR/'author_receipt.json':'a60b3f83174777d44c5152004ab051417e49580ef9dd532ec9545a74c9ef1a2f',
 AUTHOR/'handmade_checks.py':'41d9e6f73de185b444275cbda1c5ed8ea3f93ccddd834fda5bd9e6066ac817ce',
 AUTHOR/'handmade_checks.json':'0e0a0edc1869ea979c7ba55a315a47dc48266358822928583b78cedb98d04cf5',
 AUTHOR/'README.md':'696d2055e9db0ae3f57faefcd54ad77219b5a8a56b281b4b46d27ea630d633ca',
 AUTHOR/'source_preservation.json':'746ce540b8d202757dc71e79242337ab4e83139f7c56712fa50556cb4a760cb4',
 ROOT/q.CACHE_SOURCE_REF['path']:q.CACHE_SOURCE_REF['sha256'],
 ROOT/q.CACHE_CONFIG_REF['path']:q.CACHE_CONFIG_REF['sha256'],
 ROOT/q.REGISTRATION_REF['path']:q.REGISTRATION_REF['sha256'],
 ROOT/'src/arggnn/biological_mechanism_controls_v1.py':'28f3e7d3f28a48eeee0944b2e4ad55e3ea6ebb314d8b0342bd785facb08dcbeb',
 ROOT/'research/reviews/biological_bank_snapshot_cache_v2_independent/independent_review.json':'4fb072e7e0d0c3de5d17aa7ed5c876d92466274aafc2245ae47bd007459c0b35',
 ROOT/'research/reviews/biological_bank_snapshot_cache_v2_independent/receipt.json':'2809820547dc537ed4a4c3b8860536c03da6821d5b71acbbdde2f7ad082bec3e'}
for path,value in pins.items():ck('sealed reference '+str(path.relative_to(ROOT)),ref(path)['sha256']==value)
author=json.loads((AUTHOR/'author_receipt.json').read_bytes())
for key in ('checks_ref','docs_ref','replay_ref','root_template_ref','source_preservation_ref','source_report_ref','registration_ref','caller_ref','cache_source_ref','cache_config_ref'):
    r=author[key];ck('author metadata closure '+key,ref(ROOT/r['path'])==r)
original=json.loads((AUTHOR/'handmade_checks.json').read_bytes())
replay=json.loads((OUT/'author_replay/handmade_checks.json').read_bytes())
ck('all41_author_check_names_and_PASS_replayed',replay['checks_count']==original['checks_count']==41 and replay['checks']==original['checks'])
ck('author_replay_RSS_was_mocked_and_resource_reads_blocked',json.loads((OUT/'author_replay/audit_scope.json').read_bytes())['actual_getrusage_blocked'])

tree=ast.parse((AUTHOR/'caller.py').read_text())
funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
controls_text=(ROOT/'src/arggnn/biological_mechanism_controls_v1.py').read_text()
controls_tree=ast.parse(controls_text)
ck('original_shuffle_is_local_seed_plus_epoch',any(isinstance(n,ast.Call) and ast.unparse(n)=='random.Random(seed + epoch).shuffle(order)' for n in ast.walk(controls_tree)))
ck('caller_shuffle_is_exact_original_seed101_epoch1',any(isinstance(n,ast.Call) and ast.unparse(n)=='random.Random(101 + 1).shuffle(order)' for n in ast.walk(funcs['request_order'])))
for label,expr in [('original_protocol','m.controls.load_protocol'),('original_observed_join','m.frozen.observed_contract'),('original_prepared_join','m.controls.validate_prepared_records')]:
    ck('execute_reuses_'+label,any(isinstance(n,ast.Call) and ast.unparse(n.func)==expr for n in ast.walk(funcs['execute'])))
forbidden={'model_factory','ExternalTruthCapability','target_mass','target_arrays','optimizer_groups','sealed_prediction','seal_prediction','train','fit','backward','step','cuda','init','set_device'}
calls=[ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)]
ck('no_model_optimizer_target_fit_prediction_or_GPU_action_call',not any(x.split('.')[-1] in forbidden for x in calls))
ck('root_guard_extended_with_expiry_and_inherited_active_guard',all(s in ast.get_source_segment((AUTHOR/'caller.py').read_text(),funcs['execute']) for s in ('if original_guard:original_guard()',"datetime.now(timezone.utc)<m._utc(root['expires_at_utc'])",'cache.active_guard=active')))

# Independent adversarial parent/tile order, distinct from canonical fixture ordering.
parents=[{'parent_id':'v1','split':'val'},{'parent_id':'t1','split':'train'},{'parent_id':'v0','split':'val'},{'parent_id':'t0','split':'train'}]
tile_ids=[7,2,5,0,6,1,4,3]
records={p['parent_id']:{'tiles':[{'tile_id':i,'bank':{'path':'mock_only','sha256':'a'*64}} for i in tile_ids]} for p in parents}
expected_indexes=[1,12,7,0,3,15,14,6,11,13,8,2,5,9,10,4]
# Standard random.Random(102) exact reference; hardcoded below prevents caller comparator duplication.
reference=list(range(16));random.Random(102).shuffle(reference)
ck('hardcoded_original_shuffle_reference',reference==expected_indexes)
order=q.request_order(parents,records)
train_flat=[(p['parent_id'],i) for p in parents if p['split']=='train' for i in tile_ids]
ck('TRAIN_preserves_original_filtered_parent_and_tile_order_before_shuffle',[(p['parent_id'],t['tile_id']) for s,n,p,t in order[:16]]==[train_flat[i] for i in expected_indexes])
val=[(name,p['parent_id'],i) for name in q.m.controls.CONTROL_NAMES for p in parents if p['split']=='val' for i in tile_ids]
ck('VAL_exact_control_outer_original_parent_and_tile_order',[(n,p['parent_id'],t['tile_id']) for s,n,p,t in order[16:]]==val)
ck('full128_requests32_unique_banks16_TRAIN112_VAL',len(order)==128 and len({(p['parent_id'],t['tile_id']) for _,_,p,t in order})==32 and [s for s,_,_,_ in order].count('TRAIN')==16 and [s for s,_,_,_ in order].count('VAL')==112)
rng=random.getstate();q.request_order(parents,records);ck('independent_local_shuffle_preserves_global_python_RNG',rng==random.getstate())
missing=deepcopy(records);missing['t1']['tiles'].pop()
reject('missing_tile_fails_no_schedule_reduction',lambda:q.request_order(parents,missing),'eight')
duplicate=deepcopy(records);duplicate['t1']['tiles'][-1]=deepcopy(duplicate['t1']['tiles'][0])
reject('duplicate_identity_fails_no_schedule_reduction',lambda:q.request_order(parents,duplicate),'Complete128')
reject('missing_original_parent_fails_no_schedule_reduction',lambda:q.request_order(parents[:-1],records),'two TRAIN')

# Full field signature discrimination with tiny tensors, no neural instances.
@dataclass
class Bank:
    tensor:object
    nested:object
bank=Bank(torch.tensor([[1.,2.],[3.,4.]]),{'a':(None,True,-0.0),'b':[3,'observed']})
ck('signature_identical_complete_fields_match',q.field_signature(bank)==q.field_signature(deepcopy(bank)))
changed=deepcopy(bank);changed.tensor[0,0]=8
ck('signature_detects_tensor_value',q.field_signature(changed)!=q.field_signature(bank))
changed=deepcopy(bank);changed.tensor=changed.tensor.double()
ck('signature_detects_tensor_dtype',q.field_signature(changed)!=q.field_signature(bank))
changed=deepcopy(bank);changed.tensor=changed.tensor.reshape(4)
ck('signature_detects_tensor_shape',q.field_signature(changed)!=q.field_signature(bank))
changed=deepcopy(bank);changed.tensor=changed.tensor.T.contiguous().T
ck('signature_detects_tensor_stride_with_identical_values',torch.equal(changed.tensor,bank.tensor) and q.field_signature(changed)!=q.field_signature(bank))
offset=torch.arange(5,dtype=torch.float32)[1:];clone=offset.clone()
ck('signature_detects_storage_offset_with_identical_values',q.field_signature(offset)!=q.field_signature(clone))
changed=deepcopy(bank);changed.nested={'b':changed.nested['b'],'a':changed.nested['a']}
ck('signature_detects_dict_order',q.field_signature(changed)!=q.field_signature(bank))
ck('signature_detects_list_vs_tuple',q.field_signature([1,2])!=q.field_signature((1,2)))
ck('signature_detects_primitive_type_and_float_signed_zero',q.field_signature(True)!=q.field_signature(1) and q.field_signature(1)!=q.field_signature(1.0) and q.field_signature(0.0)!=q.field_signature(-0.0))
@dataclass
class OtherBank:
    tensor:object
    nested:object
ck('signature_detects_dataclass_type',q.field_signature(OtherBank(bank.tensor,bank.nested))!=q.field_signature(bank))
@dataclass
class ReorderedBank:
    nested:object
    tensor:object
ck('signature_detects_dataclass_field_order',q.field_signature(ReorderedBank(bank.nested,bank.tensor))!=q.field_signature(bank))
reject('unsupported_field_type_fails_instead_of_skipped_comparison',lambda:q.field_signature(object()),'Unsupported')

# Linux KiB conversion checked through mocks only.
with patch.object(q.resource,'getrusage',return_value=SimpleNamespace(ru_maxrss=123)) as usage,patch.object(q.sys,'platform','linux'):
    ck('mocked_linux_ru_maxrss_KiB_to_bytes',real_rss()==123*1024 and usage.call_args.args==(q.resource.RUSAGE_SELF,))
with patch.object(q.resource,'getrusage',side_effect=AssertionError('must reject before resource call')),patch.object(q.sys,'platform','darwin'):
    reject('non_Linux_RSS_semantics_fail_closed',real_rss,'Linux')

@dataclass
class TinyBank:
    tensor:object
    meta:object
tiny=TinyBank(torch.tensor([1.],dtype=torch.float32),{'kind':'observed-only','version':1})
class Clock:
    def __init__(self):self.now=0.
    def read(self):return self.now
    def advance(self,seconds):self.now+=seconds
class FakeCache:
    def __init__(self,clock,change=None,fail_after=None):
        self.clock=clock;self.change=change;self.fail_after=fail_after;self.snapshots={};self.cpu={};self.gpu={};self.gpu_used=0;self.bindings=0;self.baselines=0
        self.stats={'requests':0,'snapshot_reads':0,'cold_snapshot_decodes':0,'CPU_hits':0,'CPU_evictions':0,'CPU_oversized_bypass':0,'GPU_evictions':0,'GPU_oversized_bypass':0,'GPU_hits':0,'snapshot_peak_bytes':64,'CPU_peak_resident_bytes':128,'CPU_decode_peak_upper_bytes':256}
    def _bindings(self):
        self.bindings+=1
        if self.fail_after is not None and self.stats['requests']>=self.fail_after:raise ValueError('mock active bindings revoked')
    def __call__(self,tile,cfg,parent,device):
        assert device=='cpu'
        identity=(parent['parent_id'],tile['tile_id']);self.stats['requests']+=1
        if identity in self.cpu:
            self.stats['CPU_hits']+=1;self.clock.advance(1);return self.cpu[identity]
        self.snapshots[identity]=b'mock';self.stats['snapshot_reads']+=1;self.clock.advance(2)
        result=q.m.decode_bank_snapshot_v2(b'mock',tile,cfg,parent,device,999,self.stats)
        self.clock.advance(3);self.cpu[identity]=result;return result
    def report(self):
        report={'all_working_set_retained':len(self.cpu)==32,'retained_CPU_entries':len(self.cpu),'retained_snapshot_entries':len(self.snapshots),'stats':dict(self.stats)}
        if self.change:self.change(report)
        return report

LIMITS={'RSS_ceiling_bytes':100,'minimum_headroom_bytes':90,'baseline_comparison_headroom_bytes':9}
DECODE_CALLS=[]
def run(change=None,fail_after=None,limits=None,baseline_size=4,bad_baseline=False,wrong_decode_id=False,rss=None,cuda=False):
    clock=Clock();cache=FakeCache(clock,change,fail_after);result={};baseline_calls=[]
    def decode(snapshot,tile,cfg,parent,device,budget,stats):
        DECODE_CALLS.append((snapshot,tile,cfg,parent,device,budget,stats))
        stats['cold_snapshot_decodes']+=1;clock.advance(5)
        if wrong_decode_id:tile['tile_id']+=1000
        return deepcopy(tiny)
    def baseline(tile,cfg,parent,device):
        baseline_calls.append((parent['parent_id'],tile['tile_id']));clock.advance(7);result=deepcopy(tiny)
        if bad_baseline:result.meta['version']=2
        return result
    signature=q.field_signature
    def timed_fields(value):clock.advance(11);return signature(value)
    with ExitStack() as stack:
        stack.enter_context(patch.object(q.time,'perf_counter',side_effect=clock.read))
        stack.enter_context(patch.object(q,'rss_peak_bytes',side_effect=rss if rss else lambda:10))
        stack.enter_context(patch.object(q.m,'decode_bank_snapshot_v2',side_effect=decode))
        stack.enter_context(patch.object(q.m,'BASE_LOAD_BANK',side_effect=baseline))
        stack.enter_context(patch.object(q.m,'archive_storage_bytes_v2',return_value=2))
        stack.enter_context(patch.object(q.m,'transfer_upper_bytes_v1',return_value=3))
        stack.enter_context(patch.object(q.m,'resident_bytes_v1',return_value=baseline_size))
        stack.enter_context(patch.object(q.m,'_rng_v1',return_value=('mock_unchanged_RNG',)))
        stack.enter_context(patch.object(q,'field_signature',side_effect=timed_fields))
        stack.enter_context(patch.object(q.m.torch.cuda,'is_initialized',return_value=cuda))
        scoped_decoder=q.m.decode_bank_snapshot_v2
        try:
            answer=q.qualify_working_set(cache,{'mock_only':True},deepcopy(parents),deepcopy(records),limits or LIMITS,result)
            return answer,cache,baseline_calls,clock.now
        finally:
            ck('scoped_decoder_restored_case_'+str(len(CHECKS)),q.m.decode_bank_snapshot_v2 is scoped_decoder)

answer,cache,baselines,total=run()
ck('deterministic_mock_full32_retained_and_fields_equal',answer['all32_verified_snapshots_and_decoded_CPU_banks_retained'] and answer['all32_original_fields_exact'] and len(baselines)==32)
ck('mock_128_requests32_reads32_decodes96_hits',[(cache.stats[k]) for k in ('requests','snapshot_reads','cold_snapshot_decodes','CPU_hits')]==[128,32,32,96])
ck('mock_exact_all128_identity_order',[(x['split'],x['model_identity'],x['parent_id'],x['tile_id']) for x in answer['requests']]==[(s,n,p['parent_id'],t['tile_id']) for s,n,p,t in order])
ck('cold_request_excludes_baseline_and_parity',answer['timing_seconds']['cold_snapshot_requests']['minimum']==answer['timing_seconds']['cold_snapshot_requests']['maximum']==10)
ck('decode_only_timer_contains_exact_delegated_decode',answer['timing_seconds']['cold_decode_only']['minimum']==answer['timing_seconds']['cold_decode_only']['maximum']==5 and len(DECODE_CALLS)==32)
ck('hot_timer_is_cache_only',answer['timing_seconds']['hot_requests']['minimum']==answer['timing_seconds']['hot_requests']['maximum']==1)
# Signature wrapper is recursive: three top/nested calls plus leaf primitive calls, separately accounted.
parity_values=[x['field_comparison_seconds'] for x in answer['bank_parity']]
ck('baseline_loader_timed_separately_exact7',answer['timing_seconds']['original_baseline_loads']['minimum']==answer['timing_seconds']['original_baseline_loads']['maximum']==7)
ck('parity_timed_separately_outside_cache',len(set(parity_values))==1 and parity_values[0]>22 and total==32*(10+7+parity_values[0])+96)
ck('RSS_exact_boundary_and_remaining_headroom_reported',answer['ru_maxrss_at_start_bytes']==answer['ru_maxrss_peak_bytes']==10 and answer['remaining_root_RSS_headroom_bytes']==90)
ck('snapshot_CPU_decode_and_baseline_bounds_reported_separately',answer['bounds']=={'retained_snapshot_peak_bytes':64,'retained_decoded_CPU_tensor_peak_bytes':128,'cold_decode_tensor_stream_upper_bytes':256,'root_baseline_comparison_headroom_bytes':9,'minimum_root_noncache_headroom_bytes':90})
ck('caller_leaves_final_actual_memory_qualification_false',answer['actual_complete_working_set_RSS_and_cold_decode_headroom_qualified'] is False)
ck('mock_complete_has_no_eviction_bypass_or_GPU',all(cache.stats[k]==0 for k in ('CPU_evictions','CPU_oversized_bypass','GPU_evictions','GPU_oversized_bypass','GPU_hits')) and cache.gpu_used==0 and cache.gpu=={})
ck('bindings_are_guarded_before_and_after_all_requests',cache.bindings>=3*128)

for key,value in [('requests',127),('snapshot_reads',31),('cold_snapshot_decodes',31),('CPU_hits',95),('CPU_evictions',1),('CPU_oversized_bypass',1),('GPU_evictions',1),('GPU_oversized_bypass',1),('GPU_hits',1)]:
    reject('mock_final_'+key+'_fails_closed',lambda key=key,value=value:run(change=lambda report:report['stats'].__setitem__(key,value)))
for key,value in [('all_working_set_retained',False),('retained_CPU_entries',31),('retained_snapshot_entries',31)]:
    reject('mock_reduced_'+key+'_fails_closed',lambda key=key,value=value:run(change=lambda report:report.__setitem__(key,value)),'All32')
reject('mock_active_guard_revocation_fails',lambda:run(fail_after=1),'revoked')
reject('mock_RSS_shortage_fails_before_first_request',lambda:run(rss=lambda:11),'RSS')
reject('mock_baseline_upper_shortage_fails_before_loader',lambda:run(limits={**LIMITS,'baseline_comparison_headroom_bytes':8}),'headroom')
reject('mock_baseline_resident_shortage_fails_before_fields',lambda:run(baseline_size=10),'headroom')
reject('mock_field_difference_fails_closed',lambda:run(bad_baseline=True),'fields')
reject('mock_CUDA_initialized_flag_fails_closed',lambda:run(cuda=True),'CUDA')
# Failure on the delegated decoder still records timing and restores its prior alias.
original_decoder=q.m.decode_bank_snapshot_v2
decodes=[]
with patch.object(q.m,'decode_bank_snapshot_v2',side_effect=ValueError('mock decode failed')) as prior,patch.object(q.time,'perf_counter',side_effect=[10.,13.]):
    try:
        with q.measured_snapshot_decode(decodes):q.m.decode_bank_snapshot_v2(b'x',{'tile_id':5},{},{'parent_id':'mock'},'cpu',7,{})
    except ValueError as error:ck('delegated_decode_error_propagates',str(error)=='mock decode failed')
    ck('failing_decode_wrapper_restores_alias',q.m.decode_bank_snapshot_v2 is prior)
ck('failing_decode_records_identity_and_only_decode_time',decodes==[{'parent_id':'mock','tile_id':5,'seconds':3.}])
ck('outer_decoder_restored_after_failing_wrapper',q.m.decode_bank_snapshot_v2 is original_decoder)

now=datetime(2026,10,11,tzinfo=timezone.utc);cref={'path':'mock','sha256':'b'*64}
admission={'schema':'biological_bank_snapshot_cache_working_set_admission_v1','status':'active','root_authorizer':'root_agent','created_at_utc':now.isoformat(),'expires_at_utc':(now+timedelta(hours=1)).isoformat(),'caller_ref':q.source_ref(),'cache_admission_ref':cref,'source_registration_ref':q.REGISTRATION_REF,'device':'cpu','observed_CPU_profile_authorized':True,'models_authorized':False,'scientific_fit_authorized':False,'target_access_authorized':False,'GPU_authorized':False,'external_RSS_watchdog_started':True,'row_resource_admission_ref':{'mock':True},'job_id':'mock','output_directory':'mock','limits':LIMITS}
ck('exact_source_mock_root_gate_accepts',q.validate_root_admission(admission,cref,now)==LIMITS)
for name,changes in [('wrong_cache_phase',{'cache_admission_ref':{'path':'wrong','sha256':'c'*64}}),('registration_pin',{'source_registration_ref':{'path':'wrong','sha256':'c'*64}}),('future_created',{'created_at_utc':(now+timedelta(minutes=1)).isoformat()}),('over24h',{'expires_at_utc':(now+timedelta(hours=25)).isoformat()}),('wrong_root',{'root_authorizer':'author_agent'}),('missing_row',{'row_resource_admission_ref':None}),('missing_job',{'job_id':''}),('missing_output',{'output_directory':''}),('bool_RSS_bound',{'limits':{**LIMITS,'RSS_ceiling_bytes':True}}),('nonpositive_comparison',{'limits':{**LIMITS,'baseline_comparison_headroom_bytes':0}}),('headroom_not_below_ceiling',{'limits':{**LIMITS,'minimum_headroom_bytes':100}})]:
    reject('independent_root_gate_'+name,lambda changes=changes:q.validate_root_admission({**admission,**changes},cref,now))
ck('no_CUDA_context_created',not torch.cuda.is_initialized())
ck('only_blocked_library_proc_probe_attempt',all(x=={'event':'open','path':'/proc/self/maps'} for x in BLOCKED))
for path,value in pins.items():ck('sealed_subject_unchanged_after_mock_checks '+str(path.relative_to(ROOT)),ref(path)['sha256']==value)
result={'schema':'biological_bank_snapshot_cache_complete32_working_set_independent_focused_checks_v1','verdict':'PASS','scope':'source_and_tiny_tensor_and_deterministic_mock_only','actual_admission':False,'review_role':'independent_reviewer','caller_ref':ref(AUTHOR/'caller.py'),'checks_count':len(CHECKS),'checks':CHECKS,'verified_references':list(HASHED.values()),'reference_hashes_verified':len(HASHED),'blocked_library_probe_attempts':BLOCKED,'resource_getrusage_called':False,'real_CPU_GPU_profile_models_targets_original_data_launch_resources_live_edit_or_Git':False,'deterministic_timing':answer['timing_seconds'],'mock_RSS_bytes':10}
with (OUT/'focused_checks.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write(chr(10))
print(json.dumps({'verdict':'PASS','checks_count':len(CHECKS),'reference_hashes_verified':len(HASHED),'actual_admission':False,'resource_profile':False,'all128_order_32_cold96_hot':True},sort_keys=True))
