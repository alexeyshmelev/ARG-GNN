"""Finite source-control mocks only: no Popen, /proc, budgets, arrays or models."""
from pathlib import Path
import ast, copy, datetime, hashlib, json, os, signal, subprocess, sys, types
from contextlib import nullcontext

ROOT = Path("/workspace-SR003.nfs2/ARG-GNN")
OWN = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_execution_independent"
SOURCE = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_root/run_matrix_draft_v1.py"
SOURCE_SHA = "112ecd4fc838d37fdb50e01214a077666948b24e98e6f321a4c7b5cd2f5c6a99"
PLAN_PATH = ROOT/"research/reviews/anchor_parent_cpu_profile_v2_root/execution_plan.json"
PLAN_SHA = "52344e2a26b58fe2abfdcdd9ce5c9d9efff354d7440ccf7df727d86385b6dea3"
source = SOURCE.read_bytes()
plan_bytes = PLAN_PATH.read_bytes()
assert hashlib.sha256(source).hexdigest() == SOURCE_SHA
assert hashlib.sha256(plan_bytes).hexdigest() == PLAN_SHA
plan = json.loads(plan_bytes)
cfg = json.loads((ROOT/plan["config"]["path"]).read_text())
metadata = {str(PLAN_PATH.relative_to(ROOT)): plan}
for field in ("registration","config","review","external_initial_states","admission_template"):
    ref = plan[field]
    raw = (ROOT/ref["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ref["sha256"]
    metadata[ref["path"]] = json.loads(raw)
# Use the actual accepted metadata-only validator, without importing production modules.
child_source = (ROOT/plan["source"]["path"]).read_bytes()
assert hashlib.sha256(child_source).hexdigest() == plan["source"]["sha256"]
tree = ast.parse(child_source)
selected = [n for n in tree.body if getattr(n,"name",None) in
            {"require","utc","validate_admission_metadata_v1"}]
validator = {"datetime":datetime.datetime,"timezone":datetime.timezone,"CONFIG_PATH":plan["config"]["path"],"CONFIG_SHA256":plan["config"]["sha256"]}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(ROOT/plan["source"]["path"]),"exec"),validator)
assert plan["matrix"] == cfg["matrix"] and len(plan["matrix"]) == 16
assert len({c["id"] for c in plan["matrix"]}) == 16
seen = set()
for cell in plan["matrix"]:
    assert set(cell["reference_cells"]) <= seen
    seen.add(cell["id"])

def encoded(x):
    return (json.dumps(x,sort_keys=True,allow_nan=False)+"\n").encode()

def case(name, *, failure_index=0):
    case_root = OWN/"mock_cases"/"draft_r003"/name
    (case_root/"cells").mkdir(parents=True,exist_ok=False)
    ns = {"__file__":str(SOURCE),"__name__":"_supervisor_mock"}
    exec(compile(source,str(SOURCE),"exec"),ns)
    files = {}
    writes = []
    launched = []
    objects = []
    checks = []
    views = []
    clock = [0.]
    active = [0]
    max_active = [0]
    plan_case = copy.deepcopy(plan)
    if name == "matrix_order_change":
        plan_case["matrix"][0],plan_case["matrix"][1] = plan_case["matrix"][1],plan_case["matrix"][0]
    if name == "inactive_plan":
        plan_case["active"] = False
    def relative(path):
        return str(Path(path).relative_to(ROOT))
    def ref(path):
        key = relative(path)
        return {"path":key,"sha256":hashlib.sha256(files[key]).hexdigest()}
    def write(path,value):
        key = relative(path)
        assert key.startswith(str(OWN.relative_to(ROOT))+"/")
        if key in files: raise FileExistsError(key)
        files[key] = encoded(value)
        writes.append((key,copy.deepcopy(value)))
        return ref(path)
    def verified(r):
        if r["path"] == str(PLAN_PATH.relative_to(ROOT)):
            return copy.deepcopy(plan_case)
        if r["path"] in metadata:
            return copy.deepcopy(metadata[r["path"]])
        assert hashlib.sha256(files[r["path"]]).hexdigest() == r["sha256"]
        return json.loads(files[r["path"]])
    def digest(path):
        if Path(path) == SOURCE: return SOURCE_SHA
        if Path(path) == ROOT/plan["source"]["path"]:
            return "0"*64 if name == "profile_source_drift" else plan["source"]["sha256"]
        raise AssertionError("Unexpected content read")
    def identity(pid):
        if pid == 424242: return {"pid":pid,"start_ticks":10,"uid":123}
        return {"pid":pid,"start_ticks":pid+100,"uid":123}
    def current(*args):
        view = {"legacy_ledger_sha256":f"legacy_{len(views)}",
                "supplemental_ledger_sha256":f"fresh_{len(views)}"}
        views.append(view)
        return {},{},view
    def reservation(*args,**kwargs):
        assert args[1] == plan["reservation"]
        assert kwargs["expected_source_sha256"] == cfg["budget_source_ref"]["sha256"]
        assert kwargs["expected_config_sha256"] == cfg["budget_config_ref"]["sha256"]
        assert kwargs["initial_ledger_pins"] == views[-1]
        assert kwargs["boundary"] is True
        checks.append(copy.deepcopy(kwargs))
        return {}
    def finish(child,rc):
        if child.returncode is not None: return
        child.returncode = rc
        active[0] -= 1
        a_ref = child.admission
        a = verified(a_ref)
        cell = next(c for c in cfg["matrix"] if c["id"] == a["cell_id"])
        methods = {}
        for method in ("manual_original","matched_parent_v3"):
            path = ROOT/a["output_directory"]/(method+".pt")
            files[relative(path)] = ("tiny mocked "+method+" "+cell["id"]).encode()
            method_ref = ref(path)
            if name == "bad_artifact" and child.index == failure_index and method == "manual_original":
                method_ref["sha256"] = "0"*64
            methods[method] = {"artifact":method_ref}
        evidence = {"status":"completed_full_support_observed_only_CPU_synthetic_numerical_cell",
                    "cell":copy.deepcopy(cell),"admission_ref":a_ref,"methods":methods}
        if name == "wrong_evidence_cell" and child.index == failure_index:
            evidence["cell"] = copy.deepcopy(cfg["matrix"][(child.index+1)%16])
        files[relative(ROOT/a["output_directory"]/"evidence.json")] = encoded(evidence)
    class Child:
        def __init__(self,command,**kwargs):
            assert active[0] == 0, "Overlapping child"
            self.index = len(launched)
            self.pid = 600000+self.index
            self.returncode = None
            self.polls = 0
            path = command[command.index("--admission")+1]
            self.admission = {"path":path,"sha256":command[-1]}
            a = verified(self.admission)
            assert a["initial_state_sha256"] == metadata[plan["external_initial_states"]["path"]]["states"][
                next(c for c in cfg["matrix"] if c["id"]==a["cell_id"])["geometry"]+"_"+
                next(c for c in cfg["matrix"] if c["id"]==a["cell_id"])["dtype"]]["state_sha256"]
            assert set(a["comparison_refs"]) == set(next(c for c in cfg["matrix"] if c["id"]==a["cell_id"])["reference_cells"])
            for prior, refs in a["comparison_refs"].items():
                assert set(refs) == {"evidence","terminal","manual_original","matched_parent_v3"}
                assert any(k.endswith(prior+".exit_observed.json") and v["returncode"]==0 for k,v in writes)
            launched.append(a["cell_id"])
            objects.append(self)
            active[0] += 1
            max_active[0] = max(max_active[0],active[0])
        def poll(self):
            self.polls += 1
            if self.returncode is not None: return self.returncode
            if name in {"RSS_boundary","cell_timeout","matrix_timeout"} and self.index == failure_index: return None
            if self.polls == 1: return None
            finish(self,3 if name=="nonzero_exit" and self.index==failure_index else 0)
            return self.returncode
        def wait(self,timeout=None):
            if self.returncode is None: finish(self,0)
            return self.returncode
    class Proc:
        def __init__(self,text): self.text = text
        def __truediv__(self,key): return Proc(self.text+"/"+str(key))
        def read_text(self):
            child = objects[-1]
            assert self.text == "/proc/"+str(child.pid)+"/status"
            if name == "exit0_zombie_no_RSS" and child.index==failure_index:
                finish(child,0)
                return "State:\tZ (zombie)\n"
            if name == "exit0_missing_proc" and child.index==failure_index:
                finish(child,0)
                raise FileNotFoundError(self.text)
            if name == "cell_timeout" and child.index==failure_index:
                clock[0] = plan["cell_max_seconds"]+1
            if name == "matrix_timeout" and child.index==failure_index:
                clock[0] = plan["matrix_max_seconds"]+1
            rss = 128000000001 if name=="RSS_boundary" and child.index==failure_index else 1024*1024
            return "State:\tR\nVmRSS:\t"+str((rss+1023)//1024)+" kB\n"
    def path(value):
        return Proc(str(value)) if str(value).startswith("/proc") else Path(value)
    stopped = []
    def stop(child,saved):
        assert identity(child.pid) == saved
        stopped.append(saved)
        if child.returncode is None: finish(child,-15)
    budget = types.ModuleType("arggnn.project_budget_v4")
    budget.policy = lambda *a: ({},{})
    budget.mutex = lambda *a: nullcontext()
    budget.current = current
    budget.check_reservation = reservation
    profile = types.ModuleType("arggnn.anchor_parent_cpu_profile_v2")
    profile.load_config_v1 = lambda: copy.deepcopy(cfg)
    profile.validate_admission_metadata_v1 = validator["validate_admission_metadata_v1"]
    package = types.ModuleType("arggnn")
    package.project_budget_v4 = budget
    previous = {k:sys.modules.get(k) for k in ("arggnn","arggnn.project_budget_v4","arggnn.anchor_parent_cpu_profile_v2")}
    sys.modules.update({"arggnn":package,"arggnn.project_budget_v4":budget,"arggnn.anchor_parent_cpu_profile_v2":profile})
    ns.update(BASE=case_root,verified=verified,digest=digest,reference=ref,write=write,
              identity=identity,stop_child=stop,Path=path,
              os=types.SimpleNamespace(environ={"CUDA_VISIBLE_DEVICES":"","PYTHONDONTWRITEBYTECODE":"1"},getpid=lambda:424242),
              subprocess=types.SimpleNamespace(Popen=Child),
              time=types.SimpleNamespace(monotonic=lambda:clock[0],sleep=lambda n:clock.__setitem__(0,clock[0]+n)))
    error = None
    try:
        ns["run"]({"path":str(PLAN_PATH.relative_to(ROOT)),"sha256":PLAN_SHA},SOURCE_SHA)
    except BaseException as exc:
        error = {"type":type(exc).__name__,"message":str(exc)}
    finally:
        for key,prior in previous.items():
            if prior is None:sys.modules.pop(key,None)
            else:sys.modules[key] = prior
    terminal = [(k,v) for k,v in writes if k.endswith(".terminal.json")]
    failures = [v for k,v in writes if k.endswith("matrix_failure.json")]
    exits = [v for k,v in writes if k.endswith(".exit_observed.json")]
    final = [v for k,v in writes if k.endswith("matrix_terminal.json")]
    result = {"case":name,"error":error,"launched":launched,"max_concurrent_children":max_active[0],
              "fresh_ledger_snapshots":len(views),"reservation_checks":len(checks),
              "stops":len(stopped),"observed_exits":exits,"cell_terminals":len(terminal),
              "matrix_complete":bool(final),"failure_recorded":bool(failures)}
    if name=="all16_success":
        assert error is None and launched==[c["id"] for c in cfg["matrix"]], str(result)
        assert max_active[0]==1 and len(views)==len(checks)==len(terminal)==16 and final
    elif name in {"matrix_order_change","inactive_plan"}:
        assert error and not launched and not terminal
    elif name=="profile_source_drift":
        assert error and not launched and failures
    elif name=="bad_artifact":
        assert error["message"]=="Actual numerical artifact changed"
        assert len(launched)==failure_index+1 and failures
        result["premature_complete_terminal"] = terminal[-1][1]
        result["failure_completed_current_keys"] = list(failures[-1]["completed"][launched[-1]])
        assert terminal[-1][1]["status"]=="complete"
        assert result["failure_completed_current_keys"]==["evidence","terminal"]
    elif name=="exit0_zombie_no_RSS":
        assert error["type"]=="StopIteration" and failures and not exits
        result["actual_mock_child_exit"] = objects[-1].returncode
        assert objects[-1].returncode==0 and not terminal
    elif name=="exit0_missing_proc":
        assert error is None and final and len(launched)==16
    elif name in {"RSS_boundary","cell_timeout","matrix_timeout"}:
        assert error and len(launched)==failure_index+1 and stopped and exits[-1]["watchdog_reason"]
        assert not final
    else:
        assert error and len(launched)==failure_index+1 and not final
    return result

cases = [case("all16_success"),case("matrix_order_change"),case("inactive_plan"),
         case("profile_source_drift"),case("nonzero_exit",failure_index=2),
         case("wrong_evidence_cell"),case("bad_artifact"),
         case("RSS_boundary"),case("cell_timeout"),case("matrix_timeout"),
         case("exit0_missing_proc"),case("exit0_zombie_no_RSS")]
# Direct mocked pidfd stopper exercises the original function without real signals.
ns = {"__file__":str(SOURCE),"__name__":"_stop_mock"}
exec(compile(source,str(SOURCE),"exec"),ns)
signals = []; closed = []; waits = []
saved = {"pid":777,"start_ticks":888,"uid":123}
class StopChild:
    pid = 777
    def poll(self):return None
    def wait(self,timeout):
        waits.append(timeout)
        if len(waits)==1:raise subprocess.TimeoutExpired(["mock"],timeout)
        return -9
ns.update(os=types.SimpleNamespace(pidfd_open=lambda pid:999,close=lambda fd:closed.append(fd)),
          identity=lambda pid:dict(saved),signal=types.SimpleNamespace(
              SIGTERM=signal.SIGTERM,SIGKILL=signal.SIGKILL,
              pidfd_send_signal=lambda fd,sig:signals.append([fd,int(sig)])))
ns["stop_child"](StopChild(),saved)
assert signals==[[999,int(signal.SIGTERM)],[999,int(signal.SIGKILL)]] and closed==[999] and waits==[10,10]
signals.clear();closed.clear()
ns["identity"] = lambda pid:{**saved,"start_ticks":889}
try:ns["stop_child"](StopChild(),saved)
except ValueError as exc:assert str(exc)=="Child identity drift"
else:raise AssertionError("Identity drift not rejected")
assert not signals and closed==[999]
result = {"kind":"bounded_independent_supervisor_control_mocks","source_sha256":SOURCE_SHA,
          "plan_sha256":PLAN_SHA,"cases":cases,"direct_pidfd_mock_checks":
          ["exact-child TERM then KILL after10seconds","pidfd always closed","identity drift sends no signal"],
          "actual_children_proc_queries_budget_calls_arrays_models_GPU":False,
          "source_mock_findings":["exit0 zombie missing VmRSS falsely fails",
                                  "complete terminal precedes numerical artifact hash check"]}
with (OWN/"mock_results.json").open("x") as f:json.dump(result,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps({"mock_cases":len(cases),"findings":result["source_mock_findings"],
                  "full16_success":cases[0]["matrix_complete"],"actual_execution":False},sort_keys=True))
