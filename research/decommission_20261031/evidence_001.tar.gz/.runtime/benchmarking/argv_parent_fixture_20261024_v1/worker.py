"""Small CPU fixture: the scheduler creates only the argv output parent."""
import argparse
import json
from pathlib import Path
import setproctitle
setproctitle.setproctitle("AI Auto Research Pipeline Test")
parser = argparse.ArgumentParser()
parser.add_argument("--output", required=True)
args = parser.parse_args()
output = Path(args.output)
assert output.parent.is_dir() and not output.exists()
output.mkdir()
(output / "completed.json").write_text(json.dumps(dict(
    schema="argv_parent_fixture_v1", parent_existed_before_worker=True,
    output_leaf_was_fresh=True, scientific_data_opened=False)) + "\n")
