# TreeLoom narrative draft

Draft: `manuscript.tex`. Based on `paper/current_full_panel_working.tex` SHA256 `6bb707e24e02de0bf3121b802c94f652382f5398d6588148234476a22adb9b38`.

The new main text begins with admixture, ancestry tracts and the biological role of genealogies. It explains why sampled haplotypes provide a reliable identity across local trees, then develops complete tree message passing, structural conditioning, haplotype memory and the final genomic GRU. The equations retain the current model. Their computational flow was checked against the H050 direct model, its reused memory implementation and the underlying complete tree traversal code.

The results emphasize the selected TreeLoom model against completed AncestralPaths and ARGMix pipelines, followed by modern and ancient cohorts. These are the main text's two tables. The detailed matched NoMem table moves to the supplement. Its main result remains explicit: memory adds only 0.0778 percentage points of accuracy and lowers boundary F1 by approximately 0.67 points. This is a tradeoff, not evidence of improved ancestry tracts.

Material comparator differences remain together in Evaluation: derived four source AncestralPaths endpoint, released dense versus published convolutional architecture, the BAA sampling deficit, ARGMix's 15 references and zero ancestors versus the preprint configuration, and unequal input and training conditions. Reused validation, one optimizer seed and unfinished independent tests remain explicit. No overall LAI ranking or exact publication reproduction is claimed.

All eight original tables retain every numerical token and bold choice. All original numerical values remain somewhere in the draft. The only added numerical value is the requested 0.0778, rounding the completed report's measured paired difference. Simulation assumptions, training lineage, unsuccessful context and memory comparisons, empirical counterevidence, incomplete American comparisons and material scientific TODOs remain in the supplement or limitations.

Internal vocabulary such as episodes, sweeps and eligible nodes is replaced with direct descriptions. Figure 1 has a short provisional conceptual caption and a visible reconciliation TODO. The figure file was not changed. Its panel lettering, arrows, symbols and removal of internal titles remain with the separate figure author.

Static checks passed for table values and bolding, labels and references, balanced LaTeX environments, and removal of semicolons and the targeted jargon. The source contains approximately 2,761 main text words and 5,599 total words under a simple token count. No TeX compiler is available on the remote PATH, so compilation and the 20 page ceiling are not verified here. Build from `paper/` to resolve the existing AAAI style, bibliography and figure paths.

No live paper, figure, measurement, experiment, resource or Git change was made. ROOT has the draft and will refine the abstract, compile it and reconcile the final figure.
