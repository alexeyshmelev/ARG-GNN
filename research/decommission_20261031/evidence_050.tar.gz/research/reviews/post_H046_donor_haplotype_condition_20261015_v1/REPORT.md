# One next condition: reference haplotype continuity beyond source frequencies

**Retain one utility hypothesis for future registration: does persistent identity of an observed reference haplotype across SNPs improve tract boundaries beyond remixing references within their source class at every SNP?** Use a frozen H045 own-state predictor as the common graph prior, and fit only a small copying-HMM head in two arms. This is established Li–Stephens/FLARE-family machinery, not a new general operator or an established contribution. No implementation, run, resource request or hypothesis registration is made here.

The information route differs from another anonymous-clade exchange: its persistent objects are observed phased reference chromosomes, with their actual alleles. Their identity is a statistical copying template, not a claim that a sampled reference is the query's true ancestor.

## Why this condition remains open

All48 recorded decisions were consulted, together with the relevant novelty records and the completed H046 report. H043, H045 and H046 do not establish useful foreign-clade content. H046 gains only .011573 pp Present accuracy and .149225 pp boundary F1 over its own-state arm, below its registered utility threshold. H044 localization gains .005260 pp accuracy while lowering boundary F1 by3.137563 pp. Better span accuracy and another context adapter have not solved tract boundaries.

There is a concrete remaining representational question. The explicit SNP route builds per-site source-frequency/callability tuples and pools sites by mean/max or physical bins. H044's local boxes and H048's disjoint-bin emissions also use source-frequency evidence. They do not explicitly retain which reference chromosome carried a sequence of alleles. The whole-tree/support route can encode LD indirectly, so this is **not** a theorem that the complete GNN has no haplotype information. It is a test of an additional, precisely controlled identity-preserving SNP route.

A hand-derived information witness: source A has reference haplotypes00 and11; source B has01 and10. Both sources have allele0 frequency1/2 at each of two sites. A query00 is therefore uninformative under the per-site source-frequency product, while a no-switch, zero-mismatch copying model assigns it to A. This is a conditional example with the graph prior held fixed, not evidence that current C4 errors exhibit that pattern.

H028/H031 tested fixed source-frequency composites and found weak conditional signal; they did not test reference-haplotype copying. H032's donor Gram concerns static tree-supported dependence, not persistence of a donor's actual allele sequence. H048 has four ancestry states and frequency-based emissions, not266 donor states; its pending result is not assumed. The previous compressed-HMM assessment warned against donor-belief lumping. The construction below keeps all donors explicitly and makes no exact-compression claim.

## Precise two-arm head

Retain all R=266 labelled pure-source reference haplotypes, Q=686 unknown queries, every original observed SNP, the original physical coverage, and the100bp scoring support. Let c(r) be a donor's observed C4 class and R_c its count (50,28,102,86). Source metadata and sample dates remain exactly as in C4. No new reference cohort, query label or hidden ancestry input enters the head.

Freeze the selected H045 own-state backbone and define pi_q,c(x) as its ordinary four-class probability output, piecewise constant on its original scoring bins. Both arms use identical pi and original alleles. This is a discriminative observed-data-conditioned prior; the same observations influence pi and SNP emissions, so do not call their combination an independent-evidence biological likelihood.

At an original SNP s with k_s observed alleles, query allele a_qs and donor allele b_rs, use

    e_qsr = (1-epsilon) 1[a_qs=b_rs] + epsilon/k_s.

A missing query call gives e=1; a missing donor allele is marginalized uniformly, e=1/k_s. Equal treatment of allele categories preserves allele-index invariance; there is no ancestral polarization. These missingness rules are part of a future frozen contract, not a claim about current missing-data results.

Use genetic distance d from the existing observed map in Morgans and

    rho(d) = exp(-kappa*d),
    w_qr(x) = pi_q,c(r)(x)/R_c(r).

For normalized forward donor probabilities f(r), the **identity-preserving** propagation is

    f_minus(r) = rho f(r) + (1-rho) w_qr.

It is the usual keep-or-reset copying transition. Multiply by the SNP emission and normalize. Backward messages give donor posteriors; sum them by c(r) to get ancestry probabilities. The initial donor distribution is w at the left coverage endpoint.

The **within-source remix** arm applies, immediately before each original SNP emission,

    f_minus_remix(r) =
        [rho F(c(r)) + (1-rho) pi_q,c(r)] / R_c(r),
    F(c) = sum_(r:c(r)=c) f(r).

It retains the same ancestry persistence, allele observations, source counts, graph prior and emission parameters, while discarding individual donor continuity between observations. Its class update collapses exactly to

    F_new(c) proportional to
        [rho F(c)+(1-rho)pi_qc] mean_(r:c(r)=c) e_qsr.

Thus the control is a source-frequency HMM under the same mismatch convention. That exact collapse applies to the control; it must not be imposed on the identity arm, whose donor-specific emissions make the within-class posterior history-dependent. This distinction is the experiment.

Propagate exactly through changes of the fixed pi field and requested100bp centers; apply emissions once at actual SNPs. Remixing occurs only at those observation events, never at arbitrary storage subdivisions. No artificial tile reset, detached carry, reference top-k or SNP thinning is allowed. Forward/backward smoothing uses both genomic directions, with the same fixed prior field; no causal-time or ancient-admixture-date interpretation is asserted.

Both arms output

    p_out(x) = (1-lambda) pi(x) + lambda p_copying(x).

Fit exactly three scalars per arm: kappa>0, epsilon in[1e-6,.5], lambda in[0,1]. Proposed shared starts are kappa100 perMorgan, epsilon.01, lambda.1, fixed before new scores; kappa is a statistical copying intensity, not an estimate of generations since admixture. No window/rate/radius sweep, additional neural encoder, new backbone optimization or per-query fitted parameter is included. Equal active parameter count does not mean identical hypothesis classes: the retained latent history is the intentional difference.

## One falsifiable experiment, if root elects to register it

Reuse the completed selected H045 own-state predictor without refitting it. Fit only the two heads on the original32 TRAIN parents, original all686 exact-span C4 risk, one seed101,30 passes/960 complete-parent head updates, checkpoints5/10/15/20/25/30. All query blocks accumulate the same full-parent gradient before one optimizer update; each block spans the full chromosome. Fix original accuracy selection and earlier exact ties for both heads, then evaluate the boundary criterion without reselection.

A proposed practical gate is **at least+1.00 pp Present182 boundary F1 over both the remix head and frozen baseline, with Present accuracy no more than .05 pp below the frozen baseline**. Keep1kb boundary tolerance, exact common physical integration, raw NLL, all seven scoring rows and paired per-parent effects. These margins are proposed and unregistered. Eight repeatedly used VAL parents and one optimizer seed remain development evidence, not independent confirmation or significance.

A tie, blend collapsing to the original predictor, or a boundary improvement bought by more than the allowed accuracy loss fails this condition at the declared budget. A positive result supports donor identity continuity beyond class frequencies in this setting. It would not establish a new HMM, useful anonymous-ancestor exchange, calibrated copying genealogies or superiority to native genotype specialists.

C4-native FLARE has no completed same-panel score in the inspected records; ongoing C3 FLARE does not answer that comparison. Any later competitiveness claim needs a faithfully executed C4 specialist on the same panel. This head is not an imitation substituted for that baseline.

## Cost bound and the genuine engineering limit

For E events, direct forward/backward arithmetic is O(Q R E), not O(Q C E). A reference-class reduction is exact only for the remix control. Generic balanced composition of266×266 matrices would destroy the desired cost; the four-state H048 scan cannot simply be enlarged and advertised as cheap. No efficient exact parallel donor scan is supplied here.

The event union includes observed SNPs, fixed100bp prior-bin boundaries and scoring centers. E is at most S+2M+2, with M<=20,000 bins. A single stored FP32 forward table for all queries uses4 Q R E bytes: **7.299 GB per10,000 events**, before backward tables, emissions and autograd. Around40,000 events already means29.20 GB for that one table. Full-model memory evidence cannot certify this head.

Processing16 queries at a time changes a forward table to4*16*266*E bytes: .681 GB at40,000 events, but backward/autograd work and recomputation add substantially. The fixed graph prior can be computed once, but the donor scan remains sequential in event order in the straightforward O(R) recurrence. GPU launch overhead and three-scalar gradient computation may dominate. These are arithmetic/storage bounds, not measured fit, time or GPU reservations.

This is a concrete candidate, not execution-ready source. Root would need a separately scoped implementation and a real scheduled-step feasibility decision under its current policies before authorizing an efficacy fit. An infeasible full-state scan is a reason to hold this condition, not permission to silently collapse donors, drop sites or truncate genomic carry.

## Closest prior art and possible contribution

1. **Li and Stephens (2003), Modeling linkage disequilibrium and identifying recombination hotspots using SNP data**, DOI10.1093/genetics/165.4.2213. The original primary record establishes the chromosome-wide LD/copying model. Its PMC HTML exposes abstract/references, not the scanned article's equations; no full-equation read is claimed.
2. **Browning, Waples and Browning (2023), Fast, accurate local ancestry inference with FLARE**, DOI[10.1016/j.ajhg.2022.12.010](https://doi.org/10.1016/j.ajhg.2022.12.010). Full primary Methods read. Its state is(ancestry i, donor h), it separates post-admixture ancestry changes from within-ancestry donor switches, and uses donor-allele mismatch emissions. It explicitly traces its ancestry-copying approach to HAPMIX and MOSAIC. Its more expressive ancestry×donor model already contains the essential biological idea.
3. Pinned FLARE author source d6a6c8fd4479ebdb68529824acd11d2b6bbac4a1, AdmixHmmUpdater.java:114–131 and163–180, uses an emission times a retained forward value plus shift, then normalization and ancestry sums. PanelHmm.java:179–196 implements the elementary keep/reset donor recurrence. Copies and retrieval hashes are retained here. No FLARE code was executed.
4. Neural/conditional chain potentials are established and already used in H039/H048. Replacing a constant class prior with a frozen GNN field and training three scalars is not a new general neural-graph principle.

Our restricted state r fixes ancestry to c(r), while FLARE permits an ancestry and copied reference-panel identity to differ and has separate within-ancestry switching. This simpler head must not be described as an exact FLARE reproduction or automatically better model. Heterochronous ancient reference copying is a statistical approximation, and failure could reflect that approximation as well as weak incremental LD information.

The plausible contribution is **a controlled biological finding about donor-haplotype continuity relative to source-frequency summaries conditional on a strong genealogical predictor**, if measured and independently confirmed. No publication priority, architectural novelty or likely performance gain is established by this source assessment. Do not create additional conditions merely to force one.

Only this owned folder was written. Primary literature/source and existing decision/metric metadata were read; no model, tree/genotype/probability/checkpoint payload, test, fit, prediction, GPU/process/resource/guard/accounting, installation or Git action occurred.
