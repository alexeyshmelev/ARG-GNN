import ast,copy,datetime,hashlib,json,sys,types
from pathlib import Path
R=Path('/workspace-SR003.nfs2/ARG-GNN');D=R/'research/reviews/parallel_profiles_v1_root';O=R/'research/reviews/parallel_profiles_v1_independent'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'src'))
from arggnn import budgeted_shared_pool_v3 as m,project_budget_v4 as b
C=[];P={}
def ck(n,v):
 if not v:raise AssertionError(n)
 C.append(n)
def ref(p):return {'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def rd(x):
 ck('pin_'+x['path'],ref(R/x['path'])==x);P[x['path']]=x['sha256'];return json.loads((R/x['path']).read_text()) if x['path'].endswith('.json') else None
a=json.loads((D/'pool_admission.json').read_text());p=a['plan'];ar=ref(D/'pool_admission.json');h=m.digest(p)
ck('final_exact_plan_digest',h=='56f987d74844c9a685a39487e63dfaae14a8fe84aff7e3d8880f9e9bad23f50c');ck('authority_inactive',a['active'] is False)
for k in ('implementation','config','legacy_pool_source','budget_source','budget_config','human_authorization'):rd(a[k])
for x in p['runtime_bindings']:rd(x)
sup=ref(D/'supervisor.py');ck('exact_supervisor',sup['sha256']=='7937dfaf2d5aa4f275bfdfc917b629dcba33a345a163f327268d0da645ffde1d');s=(D/'supervisor.py').read_text();t=ast.parse(s);compile(t,'supervisor','exec')
ck('GPU3_two_named_profiles_48_16_8GiB',p['pool']['physical_gpu']==3 and [x['spec']['job'] for x in p['jobs']]==['bank-cache-profile-v1','census-device-profile-v1'] and [x['spec']['peak_mib'] for x in p['jobs']]==[49152,16384] and p['pool']['headroom_mib']==8192)
for item in p['jobs']:
 spec=item['spec'];args=spec['args'];bank=spec['job'].startswith('bank');rd(item['module_source'])
 ck('exact_argv_and_seed41_'+spec['job'],item['argv_sha256']==m.digest([p['pool']['python'],'-m',spec['module'],*args]) and spec['seed']==41)
 for x in item['worker_bindings']:rd(x)
 ad=rd({'path':args[args.index('--cache-admission' if bank else '--admission')+1],'sha256':args[args.index('--expected-cache-admission-sha256' if bank else '--expected-admission-sha256')+1]})
 now=datetime.datetime.now(datetime.timezone.utc)
 ck('worker_active_own_job_output_'+spec['job'],ad['status']=='active' and ad['device']=='cuda' and ad['job_id']==spec['job'] and str(R/ad['output_directory'])==spec['output'] and datetime.datetime.fromisoformat(ad['created_at_utc'])<=now<datetime.datetime.fromisoformat(ad['expires_at_utc']))
 z={k:rd(x) for k,x in ad['refs'].items()};cfg=z['cache_config' if bank else 'config'];wanted=dict(cfg['source_sha256']);wanted[item['module_source']['path']]=item['module_source']['sha256'];ck('complete_source_closure_'+spec['job'],ad['source_sha256']==wanted)
 for q,hh in wanted.items():rd({'path':q,'sha256':hh})
 rv=z['review'];cr=ad['refs']['cache_config' if bank else 'config'];ck('source_config_independent_review_'+spec['job'],rv['status'].startswith('qualified') and rv['actual_admission'] is False and rv.get('fixture_mode') is not True and rv['artifact_sha256'][item['module_source']['path']]==item['module_source']['sha256'] and rv['artifact_sha256'][cr['path']]==cr['sha256'])
 mem=z['memory_reservation' if bank else 'memory'];ck('active_memory_watchdog_'+spec['job'],mem['status']=='active' and mem['job_id']==spec['job'] and mem['GPU_total_reservation_mib']==spec['peak_mib'] and mem['external_watchdog'] is True and datetime.datetime.fromisoformat(mem['created_at_utc'])<=now<datetime.datetime.fromisoformat(mem['expires_at_utc']))
 ck('five_memory_components_exact_'+spec['job'],set(item['memory_components_mib'])==set(m.FIXED_POLICY['memory_components_mib']) and sum(item['memory_components_mib'].values())==spec['peak_mib'])
 if bank:
  ck('cache_CLI_caps_and_seed',args[0]=='--cache-profile-only' and ad['phase']=='profile' and mem['CPU_cache_bytes']==cfg['CPU_budget_bytes'] and mem['GPU_cache_bytes']==cfg['GPU_budget_bytes'] and mem['CPU_total_reservation_bytes']==128000000000 and mem['original_model_optimizer_runtime_headroom_preserved'] is True and item['memory_components_mib']['cached_bank']>=(cfg['GPU_budget_bytes']+1048575)//1048576 and 'torch.manual_seed(41)' in (R/item['module_source']['path']).read_text())
  ck('cache_max132_TRAIN_cell',ad['profile_cell']=={'parent_id':'bio_paths_pilot_train_000','tile_id':1})
 else:
  ck('Census_CLI_final_source_memory_reservation',args[0]=='--execute' and item['module_source']['sha256']=='f8915b311b0c1fbb219ff7265a37c46b037e1c49a95d2be85bd754623fd3d69f' and z['reservation']==item['reservation'] and mem['GPU_total_reservation_mib']==cfg['GPU_total_reservation_mib'] and mem['CPU_total_reservation_bytes']==cfg['CPU_total_reservation_bytes']==64000000000)
  st=ast.parse((R/'src/arggnn/census_biological_fit_v1.py').read_text());body=[n for n in st.body if (isinstance(n,ast.FunctionDef) and n.name=='require_terminal_numerical_v1') or (isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id in ('PARENTS','CONTROLS') for v in n.targets))];ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),'exact_JSON_gate','exec'),ns)
  native=ns['require_terminal_numerical_v1'](*[z[k] for k in ('numerical_evidence','numerical_admission','inspection_evidence','inspection_freeze','numerical_terminal')],ad['refs']);ck('actual32_terminal_JSON_gate',native['job_id']==z['numerical_terminal']['job_id'])
  qc=rd(native['refs']['runner_config']);nr=rd(native['refs']['runtime']);rt=z['runtime'];ck('actual_seed41_original_model_tolerance_runtime_closure',qc['seed']==41 and cfg['model']==qc['model'] and cfg['tolerances']==qc['tolerances']['float32'] and rt['python']==str(R/'.runtime/env/bin/python') and rt['numerical_identity']==nr['identity'] and rt['runtime_file_sha256']==nr['runtime_file_sha256'])
  counts=[(v['num_trees'],v['parent_id'],v['tile_id']) for v in z['inspection_evidence']['cells'] if v['split']=='train'];selected=[min(v for v in counts if v[0]==e) for e in (min(v[0] for v in counts),max(v[0] for v in counts))]
  ck('frozen_actual95_132_cells',selected==[(95,'bio_paths_pilot_train_001',7),(132,'bio_paths_pilot_train_000',1)] and ad['selected_cells']==[{'parent_id':v[1],'tile_id':v[2],'original_tree_count':v[0]} for v in selected])
br=rd(ref(D/'budget_receipt.json'));ck('static_applied_v4_pins_projected502GB_below950GB',br['projected_bytes']==502469270272 and br['limit_bytes']==950000000000 and br['hard_limit_bytes']==1000000000000 and br['legacy_ledger_mutated'] is False and br['legacy_ledger_sha256']==p['initial_ledger_pins']['legacy_ledger_sha256'] and br['supplemental_ledger_sha256']==p['initial_ledger_pins']['supplemental_ledger_sha256'])
for v in [p['pool']['controller_reservation'],*[v['reservation'] for v in p['jobs']]]:ck('applied_exact_reservation_'+v['key'],br['admitted_reservations'][v['key']]==v)
review={'kind':'budgeted_shared_pool_v3_independent_review','review_role':'independent_reviewer','verdict':'PASS',**{k:a[k] for k in ('implementation','config','legacy_pool_source','budget_source','budget_config','human_authorization')},'reviewed_plan_sha256':h,'actual_live_lock_or_gpu_execution_performed':False,'original_sources_unchanged':True}
aa=copy.deepcopy(a);aa['active']=True;old=b.bound

def overlay(root,record,*args,**kwargs):
 if record==ar:return copy.deepcopy(aa)
 if record==a['independent_review']:return copy.deepcopy(review)
 return old(root,record,*args,**kwargs)
api=types.SimpleNamespace(bound=overlay,scope_spec=b.scope_spec,paths_overlap=b.paths_overlap,FIXED_POLICY=b.FIXED_POLICY)
v=m.ReviewedPlan(R,m.FIXED_POLICY,a['implementation'],a['config'],ar,api=api);ck('production_ReviewedPlan_accepts_exact_schema_in_memory_only',v.plan==p);ck('authority_bytes_not_changed',ref(D/'pool_admission.json')==ar)
limits=next(n for n in ast.walk(t) if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='limits' for v in n.targets));ck('supervisor_exact_GPU_CPU_limits',ast.literal_eval(limits.value)=={'bank-cache-profile-v1':(49152,128000000000),'census-device-profile-v1':(16384,64000000000)})
ck('supervisor_list_job_schema_API',"for v in status['jobs']" in s and "for job in status['jobs']" in s and 'jobs=list(self.jobs.values())' in (R/'src/arggnn/gpu_pool_v1.py').read_text())
ck('supervisor_old_wait_fresh_acquisition_and_deadlines',all(v in s for v in ('while any(live(x) for x in saved)','+ 14400','+ 21600','time.sleep(15)',"command('--start', args.authority_sha256)","gpu.checked_inventory(gpu.real_inventory)")))
ck('supervisor_registered_UID_ticks_pidfd_only_signals',all(v in s for v in ('for worker in verified:',"gpu.open_pidfd(worker['pid'])","(current['start_ticks'], current['uid']) == (worker['start_ticks'], worker['uid'])","gpu.send_pidfd(fd, signal.SIGTERM)",'os.close(fd)')))
ck('supervisor_bound_in_runtime_plan',sup in p['runtime_bindings']);ck('no_scientific_imports','torch' not in sys.modules and 'numpy' not in sys.modules)
report={'status':'PASS','check_count':len(C),'checks':C,'reviewed_plan_sha256':h,'supervisor':sup,'preactivation_pool_admission':ar,'verified_metadata_source_refs':P,'runtime_binary_bytes_compared_as_qualified_metadata_execution_rehashes_bytes':True,'actual_arrays_models_GPU_live_ledgers_locks_or_authority_activation':False,'issues':[]}
with (O/'checks.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'status':'PASS','check_count':len(C),'reviewed_plan_sha256':h},indent=2))
