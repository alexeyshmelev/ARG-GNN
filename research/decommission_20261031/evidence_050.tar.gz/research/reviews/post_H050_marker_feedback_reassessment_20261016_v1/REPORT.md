# H050-conditional architecture recommendation after H057

**Retain one controlled marker-to-tree feedback experiment as a biological utility test. H057 does not justify making finer readout the explanation for most remaining error or calling this a new general graph operator.** The existing design can proceed without another resolution audit after the H050 result determines whether its condition is met.

H057's completed TRAIN oracle gap is only +0.104443 ± 0.009838 percentage points for Present182, just above the frozen +0.10 pp gate. The native-hold oracle itself is 99.892032 ± 0.009986%. These are representability ceilings on TRAIN, not achievable gains or a bound on H045's different VAL simulations. In particular, do not divide this gap by H045's VAL error to estimate a fraction of explained errors. The stronger reason for a marker-learning experiment is H045's weak biological transition recovery: boundary F1 18.1558%, recall 22.5890%, 905 matched, 3,103 missed and 5,063 extra calls across eight reused VAL parents. That supports testing tract discrimination, without yet identifying its cause.

## Concrete decision after H050

If H050 meets its registered accuracy criterion against every memory/control arm, preserve that useful result and pursue its already planned independent confirmation. Marker feedback then remains an orthogonal later utility hypothesis, not a replacement selected because the new memory model happened to win one metric.

If H050 meets only its registered boundary criterion, report that narrower gain and compare the new boundary hypothesis against that stronger practical context in the final paper. Do not describe boundary improvement as an ancestry-accuracy win.

If H050 fails both criteria, the existing marker-feedback design is a reasonable next full training comparison. It tests a condition absent from H044's fixed box readout and H033's frozen-emitter solver: learned ordered observed-marker features enter a complete trainable tree sweep before the next genomic representation is decoded. Do not rerun the failed memory or reset-chain conditions.

Keep the already specified H045 own_state pass30 as the common initializer in every new arm, regardless of H050's outcome. That avoids changing both initialization and the intervention after looking at H050. A successful H050 checkpoint should not silently replace this initializer.

## One useful experiment, with honest controls

Retain the proposed rank-8 marker sequence module and its four fixed depthwise Conv1d dilations 1/8/64/512, shared across the same 952 observed haplotypes. Observed SNP embeddings and complete first-sweep sampled-leaf context supply its inputs. Span-average the ordered features back into native holds, project8-to32 with a zero-initialized residual, and inject only at the actual sampled nodes before the complete second PyG tree sweep. Keep the full genomic BiGRU. A shared zero-initialized8-to4 marker head permits original100bp-grid predictions within a hold. This is the previously proposed 1,240-parameter addition, not an implemented-model count or speed result.

The same four prospective arms are sufficient:

| Arm | Purpose |
|---|---|
| Ordered marker feedback before the second whole-tree sweep | Proposed early graph-routing intervention |
| Same ordered marker computation and extra parameters, injected at sampled-leaf output after the second sweep | Matched available information, capacity and continued training, with later routing |
| Same early routing with marker inputs averaged within each native hold | Separates marker localization from the same early routing, as an information ablation |
| Exact unmodified H045 own_state continuation | Separates architectural utility from another 30 training passes |

The first contrast tests **early tree-mediated versus late leaf-level routing**. It is not a pure causal isolation of foreign-haplotype exchange: injection before a nonlinear tree sweep also changes how the same leaf's signal is transformed. Both arms must retain the same complete second tree computation and final marker head. Do not claim that this contrast alone proves that information from another haplotype caused a gain. Likewise, the hold-mean arm changes information and must not be called equal-information.

No extra random-permutation or generic smoothing arm is necessary for the first full comparison. An exact own-leaf-only counterfactual through a nonlinear whole-tree encoder would otherwise require a different operator or repeated per-query graph runs. Do not quietly substitute that expensive different model for the stated control.

## Biological endpoint and full budget

The primary question is whether the learned route distinguishes real C4 ancestry switches from false calls while preserving span accuracy. C4 means source population at 350 generations BP. A topology change is neither a true ancestry switch nor proof of a shared historical recombination event. Align the same observed sampled haplotypes across loci. Do not invent persistent internal-ancestor identities from Relate node numbers.

Retain 32 TRAIN/eight VAL, all 952 observed haplotypes/all 686 queries, original exact-span objective and scoring support, FP32, seed 101, independent fresh AdamW,30 full passes/960 whole-parent updates per arm, six scheduled checkpoints and all 192 validation prediction products sealed before truth. Select by the original accuracy/NLL rule, without boundary-based checkpoint hunting. The first scheduled complete-parent optimizer update supplies implementation feasibility evidence. Do not create a separate discarded update campaign or rerun H057.

Keep the existing proposed practical boundary gate: at least +1.00 pp Present182 boundary F1 at 1 kb over each control, with at most 0.05 pp span-accuracy loss against each. This would support boundary utility only. Separately report whether the model meets a +0.10 pp span-accuracy gain against each control, without F1 or NLL regression. Neither gate establishes independent confirmation on reused development VAL.

Report per-parent precision, recall, F1, matched/missed/extra calls, span accuracy, NLL, Brier/ECE and all seven cohort rows. Before evaluation, freeze common tract-length strata and chromosome-edge censoring rules. Compare true short tracts recovered and false short predicted tracts. H038's historical fragmentation numbers must not be relabelled as measured H045 residual tract profiles. Avoid a global smoothness prior justified by one cohort's median tract length, because sampling ages, mixture times and source support differ across cohorts. No validation-selected smoothing or marker-density threshold is added.

## Novelty and efficiency limits

The present audits already rule out generic novelty in GNN-plus-sequence processing, graph-context feedback, conditional means, higher-order memory and reset-family smoothing. GST interleaves local graph computation, collection pooling/attention and return to nodes. Graph Matching Networks exchange cross-graph latent context. Whitehouse et al. combine whole marginal trees with node/tree-sequence recurrence. RFMix and FLARE already exploit marker order and ancestry continuity. The new experiment can establish whether this particular observed-leaf/marker/tree routing is useful under controlled genealogical inputs. It does not establish a new kernel merely by combining those ingredients.

A positive routing result would motivate a focused exact-mechanism literature check and an independent held-out/seed confirmation, not a generic priority claim. If ordered late routing ties early graph routing, retain the simpler useful predictor if appropriate and reject the claim that a distinct tree-feedback mechanism was demonstrated. If finer readout increases false calls or fails the boundary gate, stop this condition and preserve its result.

Implement the marker path with Torch Conv1d and the existing complete-tree PyG sweep, not a graph pass per SNP. All original observations remain available. Exact haplotype blocking and halos may reduce peak storage without truncated gradients. The stated 609,280,000-byte rank-8 activation tensor is not a measured full training-memory estimate. Actual first scheduled training will decide feasibility. No operational guard, admission, model code, numerical test or training was added by this reassessment.
