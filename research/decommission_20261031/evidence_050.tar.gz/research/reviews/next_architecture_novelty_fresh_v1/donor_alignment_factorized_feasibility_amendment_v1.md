# Amendment: donor-alignment sham feasibility remains unqualified

This corrects the scientific planning interpretation of the deferred donor-alignment sham. No prototype, test, data read, fit, job or registration was performed.

The maximal N=449,840, R=84 FP32 tensor with shape N×R×R contains 3,174,071,040 entries, approximately 12.70 GB. This is the cost of **materializing every donor pair for every node**, not a necessary memory requirement for exact support-Gram contraction. That allocation may violate the intended working set, but its size does not establish that the sham itself is infeasible.

Let U[n,r]=pi[n,r] be normalized actual donor-affinity weights for the chosen full/subtree/outside subset, including H030's 1/n[family,class] source weights and explicit empty-support masks. Let U_a be U with donors outside observed class a set to zero, and let K'=P K Pᵀ be the symmetric permuted donor-dependence matrix. Then exactly

C_ab[n] = Σ_r U_a[n,r] (U_b K')[n,r].

Thus a class-masked matrix multiplication followed by rowwise products/sums computes the same Gram without an N×R×R tensor. Processing class blocks or chunks can retain O(NR) working memory, plus O(R²) for K' and O(N×4²) output. One unmasked FP32 N×R array is approximately 151 MB at the cited maximum; additional fields, masks, gradients and saved activations must still be counted. There is no need to allocate all four masked copies simultaneously.

Arithmetic remains O(NR²) in the straightforward contraction, with a small fixed number of class blocks. At R=84 the required contractions are on the scale of tens of GFLOPs per maximal full-tile field, and ordinary GPU GEMMs could make that inexpensive. Neither asymptotic notation nor this operation estimate establishes actual runtime or failure. The original tree-reroot factorization is broken by donor permutation, but a different exact matrix contraction remains available.

Unresolved costs may instead lie in constructing stable donor-level path/affinity fields, representing the correct subtree/outside exclusions, retaining gradients through learned age costs and K', normalization/empty-support conditioning, and autograd/allocator memory alongside the existing whole-tree GNN. Restricted-permutation moved fraction also remains unmeasured. These require qualification before any runtime, numerical-parity or meaningful-alignment claim.

Accordingly, the sham is **unqualified and omitted from the present protocol**, rather than prohibited by its arithmetic count. Existing H032 definitions and final source reviews are not modified by this amendment. No scheduling or implementation instruction follows.
