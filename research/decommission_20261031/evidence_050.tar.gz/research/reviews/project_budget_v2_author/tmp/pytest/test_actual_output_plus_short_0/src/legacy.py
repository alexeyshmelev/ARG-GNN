handmade legacy source
