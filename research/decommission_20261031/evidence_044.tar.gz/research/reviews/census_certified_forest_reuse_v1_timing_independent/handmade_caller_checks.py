"""Independent finite fake-API review. No genuine arrays/models/runtime are used."""
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone,timedelta
from types import ModuleType,SimpleNamespace
from unittest.mock import patch
from contextlib import redirect_stdout,redirect_stderr
import ast,hashlib,json,io,sys,os,argparse,time,__future__,locale,gettext,shutil
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
AUTHOR=ROOT/"research/reviews/census_certified_forest_reuse_v1_timing_author"
OUT=ROOT/"research/reviews/census_certified_forest_reuse_v1_timing_independent"
RECIPE=AUTHOR/"root_cpu_timing_recipe.py"
RAW=RECIPE.read_bytes();TEXT=RAW.decode();PINS=json.loads((AUTHOR/"pins.json").read_text())
BASE=json.loads((AUTHOR/"base_admission.template.json").read_text())
EXPECTED="85cf9aa984429a460a15b5be94bb3366f4bf06e65a17812dc7dfb59af3403bf5"
CONTROLS=("proposed","eta0","permuted_groups","raw_diagonal","local")
NOW=datetime(2026,10,11,12,tzinfo=timezone.utc)
COUNTS={};CASES=[]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def check(value,category):
 COUNTS[category]=COUNTS.get(category,0)+1
 assert value,category
def artifact(path):return {"path":str(path.relative_to(ROOT)),"sha256":digest(path.read_bytes())}
check(digest(RAW)=="86a2febedd7973a9258b9b9674d388a673187aebbf96e1c32da35489d733be25","exact_recipe_pin")
check(digest((AUTHOR/"pins.json").read_bytes())=="17cbda8e788ef20b0d2bc13d4f52f8cc74fd2295883292cab4158e6c5416c663","exact_pins_pin")
check(digest((AUTHOR/"author_receipt.json").read_bytes())=="6022a0f830fbc477d0b01c73d8bfe7ba18bcb7cc037215460128c8a552d30195","exact_author_receipt_pin")
# Real file access remains source/author-metadata only; dynamic outputs are fake objects.
def audit(event,args):
 if event=="open":
  value=args[0]
  if isinstance(value,(str,bytes,os.PathLike)):
   path=Path(value)
   if path.is_absolute() and str(path).startswith(str(ROOT)):
    allowed=(str(path).startswith(str(AUTHOR)+"/") or str(path).startswith(str(OUT)+"/")
             or str(path).startswith(str(ROOT/"src")+"/") or str(path).startswith(str(ROOT/"configs")+"/")
             or str(path).startswith(str(ROOT/"research/reviews/census_certified_forest_reuse_v1_independent")+"/"))
    if not allowed:raise AssertionError("Forbidden project read/write: "+str(path))
 if event in ("os.mkdir","os.remove","os.rename"):
  value=args[0]
  if isinstance(value,(str,bytes,os.PathLike)) and not str(Path(value)).startswith(str(OUT)):
   raise AssertionError("Forbidden real mutation: "+str(value))
sys.addaudithook(audit)
class Clock:
 @staticmethod
 def now(tz):return NOW
 @staticmethod
 def fromisoformat(value):return datetime.fromisoformat(value)
class Ids(list):
 def __getitem__(self,index):
  if isinstance(index,list):return Ids(v for v,keep in zip(self,index) if keep)
  return super().__getitem__(index)
class Finite:
 def __init__(self,value=True):self.value=value
 def all(self):return self.value
class Param:
 def __init__(self):self.grad=None;self.device=SimpleNamespace(type="cpu")
class FakeModel:
 def __init__(self,fixture):
  self.fixture=fixture;self.params={n:Param() for n in ("weight","exchange","raw_eta","raw_damping")}
  self.encoder=SimpleNamespace();self.state=PINS["initial_state_sha256"]
 def parameters(self):return self.params.values()
 def named_parameters(self):return self.params.items()
 def state_dict(self):return {"handmade_state_sha256":self.state}
 def __deepcopy__(self,memo):
  model=FakeModel(self.fixture);self.fixture.models.append(model);self.fixture.event("copy")
  return model
class Logits:
 def __init__(self,fixture,model,control):
  self.fixture=fixture;self.model=model;self.control=control
  self.shape=(3,2,4) if fixture.fault!="shape" else (3,2,3)
  self.finite=fixture.fault!="logits_nonfinite"
 def square(self):self.fixture.event("square");return self
 def mean(self):self.fixture.event("mean");return self
 def backward(self):
  self.fixture.event("backward")
  if self.fixture.fault=="backward_failure":raise ValueError("handmade backward failure")
  for name,p in self.model.named_parameters():
   inactive=(name.endswith("raw_eta") and self.control in ("eta0","local")) or (name.endswith("raw_damping") and self.control=="local")
   p.grad=None if inactive else SimpleNamespace(finite=self.fixture.fault!="gradient_nonfinite")
   if self.fixture.fault=="gradient_missing" and name=="weight":p.grad=None
   if self.fixture.fault=="inactive_gradient" and inactive:p.grad=SimpleNamespace(finite=True)
  if self.fixture.fault=="state_changed":self.model.state="0"*64
class FakePath:
 def __init__(self,fixture,value):self.fixture=fixture;self.value=value
 def __truediv__(self,value):return FakePath(self.fixture,self.value+"/"+value)
 def mkdir(self):self.fixture.event("fake_tmp_mkdir")
class Fixture:
 def __init__(self):
  self.pins=deepcopy(PINS);self.old=deepcopy(BASE)
  self.current=deepcopy(BASE);self.current.update(status="active",job_id="handmade-new-job",output_directory="handmade/output",
   created_at_utc=(NOW-timedelta(hours=2)).isoformat(),expires_at_utc=(NOW+timedelta(hours=2)).isoformat())
  self.old.update(status="active",job_id="handmade-old-job",output_directory="handmade/old")
  for role in ("storage","launcher"):self.current["refs"][role]={"path":"handmade/"+role+".json","sha256":"7"*64}
  self.qcfg={"seed":41,"model":deepcopy(PINS["model"]),"readout_chunk_size":128,"output_cap_bytes":1_000_000_000,"time_scale":10000.0}
  self.refs={role:{"path":"handmade/"+role+"_admission.json","sha256":str(i)*64}
             for i,role in enumerate(("base","reuse","memory"),1)}
  self.pins_ref={"path":str((AUTHOR/"pins.json").relative_to(ROOT)),"sha256":digest((AUTHOR/"pins.json").read_bytes())}
  self.recipe_ref=artifact(RECIPE)
  self.reuse={key:deepcopy(PINS["reuse_"+key]) for key in ("source_ref","config_ref","review_ref")}
  self.reuse["fit_authorized"]=False
  self.memory={"schema":"census_forest_reuse_CPU_profile_memory_v1","status":"active","root_authorizer":"root_agent",
   "job_id":self.current["job_id"],"created_at_utc":(NOW-timedelta(hours=1)).isoformat(),
   "expires_at_utc":(NOW+timedelta(hours=1)).isoformat(),"CPU_total_reservation_bytes":64_000_000_000,
   "GPU_admitted":False,"external_watchdog":True,"recipe_ref":self.recipe_ref,"pins_ref":self.pins_ref,
   "output_directory":self.current["output_directory"]}
  self.collision={"handmade_events":0};self.lineage={"handmade_lineage":True}
  self.cert=SimpleNamespace(external_hash=EXPECTED,native_trees=list(range(132)),
   bank=SimpleNamespace(query_ids=Ids([11,12,13]),partitions=[SimpleNamespace(scored_query_mask=[True,False,True])]),
   stored_sequence=SimpleNamespace(positions=[1,2,3]))
  self.history={role:{"handmade_role":role} for role in PINS["historical_refs"]}
  self.history["inspection_evidence"]["cells"]=[{"parent_id":"bio_paths_pilot_train_000","tile_id":1,
   "event_collision_counts":deepcopy(self.collision),"decoded_lineage":deepcopy(self.lineage)}]
  self.events=[];self.models=[];self.writes=[];self.attempts=[];self.fault=None;self.deny_from=None;self.calls=0
  self.execute=True;self.cuda="";self.bytecode="1";self.adapter=None;self.extra_args=[];self.reuse_deny_from=None;self.memory_expire_from=None
 def event(self,value):self.events.append(value)
 def reader(self):
  fixture=self
  class Reader:
   def decode_json(self,reference):
    fixture.event("metadata:"+reference["path"])
    if reference==fixture.pins_ref:return deepcopy(fixture.pins)
    if reference==fixture.refs["memory"]:
     memory=deepcopy(fixture.memory)
     if fixture.memory_expire_from is not None and fixture.calls>=fixture.memory_expire_from:memory["expires_at_utc"]=NOW.isoformat()
     return memory
    for role,pin in PINS["historical_refs"].items():
     if reference==pin:return deepcopy(fixture.history[role])
    raise ValueError("handmade verified reader rejected stale/unbound ref")
  return Reader()
 def gate(self,reference,*,phase,reader):
  self.calls+=1;self.event("base_gate:"+str(self.calls))
  check(reference==self.refs["base"] and phase=="numerical","base_phase_and_ref")
  if self.deny_from is not None and self.calls>=self.deny_from:raise ValueError("handmade authority denied")
  return deepcopy(self.current),deepcopy(self.qcfg),reader
 def reuse_gate(self,reference,*,phase,base_admission_ref):
  self.event("reuse_gate")
  check(reference==self.refs["reuse"] and phase=="observed_profile" and base_admission_ref==self.refs["base"],"reuse_phase_and_binding")
  if self.fault=="reuse_denial" or (self.reuse_deny_from is not None and self.calls>=self.reuse_deny_from):raise ValueError("handmade reuse denied")
  return deepcopy(self.reuse)
 def historical_gate(self,*args):
  self.event("historical_gate")
  check(args[-1]==PINS["historical_refs"],"exact_historical_refs")
  check([item["handmade_role"] for item in args[:-1]]==["numerical_evidence","numerical_admission","inspection_evidence","inspection_freeze","numerical_terminal"],"historical_argument_order")
  if self.fault=="history_denial":raise ValueError("handmade historical denial")
  return deepcopy(self.old)
 def manifests(self,*args):
  self.event("observation_closure")
  check(self.calls>=2,"observation_after_gates")
  if self.fault=="manifest_failure":raise ValueError("handmade manifest failure")
  parent={"parent_id":"bio_paths_pilot_train_000"}
  bank={"tiles":[{"tile_id":0,"original_tree_ids":[1]},{"tile_id":1,"original_tree_ids":list(range(132))}]}
  if self.fault=="tree_count":bank["tiles"][1]["original_tree_ids"].pop()
  return [({"parent_id":"unselected-parent"},{"tiles":[]}), (parent,bank)]
 def load(self,*args,**kwargs):
  self.event("load_parent")
  check(self.calls>=3 and args[0]["parent_id"]=="bio_paths_pilot_train_000","load_after_gates_fixed_parent")
  if self.fault=="load_failure":raise ValueError("handmade load failure")
  return {"handmade_loaded":True}
 def prepare(self,*args):
  self.event("prepare_certificate")
  check(args[2]["tile_id"]==1,"fixed_tile_selection")
  if self.fault=="prepare_failure":raise ValueError("handmade preparation failure")
  if self.fault=="certificate":self.cert.external_hash="0"*64
  if self.fault=="native_tree_count":self.cert.native_trees.pop()
  collision={} if self.fault=="collision" else deepcopy(self.collision)
  lineage={} if self.fault=="lineage" else deepcopy(self.lineage)
  return self.cert,collision,lineage
 def validate(self,cert,expected):
  self.event("validate_certificate")
  check(expected==EXPECTED and cert is self.cert,"external_certificate_pin_and_identity")
  if cert.external_hash!=expected:raise ValueError("handmade certificate mismatch")
 def model(self,qcfg,dtype):
  self.event("initial_model")
  check(self.calls>=3 and qcfg["model"]==PINS["model"] and qcfg["seed"]==41 and dtype=="float32","original_model_config_dtype")
  model=FakeModel(self)
  if self.fault=="initial_state":model.state="0"*64
  if self.fault=="initial_gradient":model.params["weight"].grad=SimpleNamespace(finite=True)
  if self.fault=="initial_device":model.params["weight"].device.type="cuda"
  self.models.append(model);return model
 def output_type(self):
  fixture=self
  class Output:
   def __init__(self,value,*,limit_bytes):
    fixture.event("output_constructor")
    check(fixture.calls==1 and value==fixture.current["output_directory"] and limit_bytes==1_000_000_000,"output_after_initial_gates")
    if fixture.fault=="output_constructor":raise ValueError("handmade output denial")
    self.path=FakePath(fixture,value)
   def write(self,name,value):
    fixture.event("evidence_write");fixture.attempts.append(name)
    if fixture.fault=="evidence_write":raise ValueError("handmade capped output refusal")
    fixture.writes.append((name,deepcopy(value)))
  return Output
 def adapter_type(self):
  fixture=self
  class Adapter:
   def __init__(self):
    fixture.event("adapter_construct");fixture.adapter=self;self.n=0
   def __call__(self,model,cert,*,expected_certificate_sha256,control,readout_chunk_size,**kwargs):
    fixture.event("adapter:"+control)
    check(control==CONTROLS[self.n%5] and expected_certificate_sha256==EXPECTED and cert is fixture.cert and readout_chunk_size==128,"exact_adapter_call_math_controls")
    check(kwargs==({"group_permutation":tuple(fixture.current["group_permutation"])} if control=="permuted_groups" else {}),"exact_control_permutation")
    self.n+=1
    if fixture.fault=="adapter_failure":raise ValueError("handmade adapter failure")
    if fixture.fault=="encoder_leak":model.encoder.forward="handmade_leak"
    ids=Ids([11,13]) if fixture.fault!="query_order" else Ids([13,11])
    return SimpleNamespace(scored_query_ids=ids,logits=Logits(fixture,model,control))
   def report(self):
    return {"calls":self.n,"forest_bindings":int(self.n>0),
     "forest_reuses":max(0,self.n-1)+(1 if fixture.fault=="counter_mismatch" else 0),
     "phase_seconds":{"handmade_binding":int(self.n>0),"handmade_retained":self.n}}
  return Adapter
 def run(self):
  modules={}
  parent=ModuleType("arggnn");parent.__path__=[];modules["arggnn"]=parent
  runner=ModuleType("arggnn.census_native_qualification_runner_v1")
  for name,value in {"admit_runner_v1":self.gate,"read_manifests_v1":self.manifests,"load_parent_v1":self.load,
   "prepare_tile_v1":self.prepare,"_model":self.model,"BoundedEvidenceOutputV1":self.output_type(),"VerifiedReaderV1":self.reader}.items():setattr(runner,name,value)
  modules[runner.__name__]=runner
  fit=ModuleType("arggnn.census_biological_fit_v1");fit.require_terminal_numerical_v1=self.historical_gate;modules[fit.__name__]=fit
  reuse=ModuleType("arggnn.census_certified_forest_reuse_v1");reuse.admit_reuse_v1=self.reuse_gate;reuse.CertifiedForestReuseV1=self.adapter_type();modules[reuse.__name__]=reuse
  bank=ModuleType("arggnn.census_biological_bank_v1");bank.validate_census_biological_certificate_v1=self.validate
  bank.fingerprint_sha256_v1=lambda state:state["handmade_state_sha256"];modules[bank.__name__]=bank
  torch=ModuleType("torch");torch.long="handmade-long"
  torch.tensor=lambda data,*,dtype:tuple(data) if dtype==torch.long else (_ for _ in ()).throw(AssertionError("dtype"))
  torch.equal=lambda left,right:left==right
  torch.isfinite=lambda value:Finite(value.finite)
  modules["torch"]=torch
  ns={"__name__":"independent_handmade_caller","__file__":str(RECIPE)}
  exec(compile(TEXT,str(RECIPE),"exec"),ns)
  ns["datetime"]=Clock
  tick=[0]
  def timer():tick[0]+=1;return float(tick[0])
  ns["time"]=SimpleNamespace(perf_counter=timer)
  argv=[str(RECIPE)]+(["--execute"] if self.execute else [])
  for role in ("base","reuse","memory"):
   argv+=["--"+role+"-admission",self.refs[role]["path"],"--expected-"+role+"-admission-sha256",self.refs[role]["sha256"]]
  argv+=["--expected-pins-sha256",self.pins_ref["sha256"]]+self.extra_args
  stdout=io.StringIO();stderr=io.StringIO();error=None
  with patch.dict(sys.modules,modules),patch.object(sys,"argv",argv),patch.dict(os.environ,{"CUDA_VISIBLE_DEVICES":self.cuda,"PYTHONDONTWRITEBYTECODE":self.bytecode}),redirect_stdout(stdout),redirect_stderr(stderr):
   try:ns["main"]()
   except BaseException as caught:error=caught
  return error,stdout.getvalue(),stderr.getvalue()
def reject(f,name,*,before_inputs=False,no_write=False):
 error,stdout,stderr=f.run()
 check(error is not None,"rejected_"+name)
 check(not stdout,"no_success_stdout_"+name)
 if before_inputs:
  check(not any(e in f.events for e in ("observation_closure","load_parent","initial_model")),"before_inputs_"+name)
 if no_write:check(not f.writes and not f.attempts,"no_evidence_attempt_"+name)
 else:
  check(len(f.writes)==1 and f.writes[0][1]["status"]=="failed_partial_preserved","failed_partial_"+name)
 CASES.append({"case":name,"error":type(error).__name__,"model_objects":len(f.models),"adapter_calls":0 if f.adapter is None else f.adapter.n,"evidence_writes":len(f.writes)})
 return error
# Successful fake trace: every call reuses one adapter, copies original state and clears gradients.
f=Fixture();error,stdout,_=f.run()
if error is not None:print(type(error).__name__+": "+str(error)+" events="+repr(f.events),flush=True)
check(error is None,"positive_completion")
check(f.calls==14 and len(f.writes)==1,"positive_authority_rechecks")
result=f.writes[0][1]
check(result["status"]=="completed_observed_only_CPU_timing","positive_status")
check(len(f.models)==11 and all(p.grad is None for m in f.models for p in m.parameters()),"all_copy_gradients_cleared")
check(all(m.state==PINS["initial_state_sha256"] and not m.encoder.__dict__ for m in f.models),"weights_and_encoder_restored")
check(result["forest_reuse_report"]["calls"]==10 and result["forest_reuse_report"]["forest_bindings"]==1 and result["forest_reuse_report"]["forest_reuses"]==9,"ten_calls_one_binding_nine_reuses")
check([r["control"] for r in result["records"]]==list(CONTROLS)*2,"two_rounds_five_fixed_controls")
check([r["active_gradient_tensors"] for r in result["records"]]==[4,3,4,4,2]*2,"control_gradient_expectations")
check(all(r["backward_objective"]=="observed_logits_squared_mean_no_target_no_optimizer" for r in result["records"]),"synthetic_objective_only")
check(all(result[key] is False for key in ("query_truth_accessed","scientific_fit_performed","optimizer_created","speedup_claim","measured_speedup_claimed")) and result["parameter_updates"]==0,"honest_observed_only_flags")
check(f.events.index("base_gate:1")<f.events.index("output_constructor")<f.events.index("base_gate:2")<f.events.index("observation_closure")<f.events.index("base_gate:3")<f.events.index("load_parent")<f.events.index("initial_model"),"initial_gate_order")
check(f.events[-1]=="evidence_write" and f.events[-3]=="reuse_gate","final_gate_before_evidence")
check(f.events.count("square")==10 and f.events.count("mean")==10 and f.events.count("backward")==10,"exact_synthetic_backward_sequence")
positive_summary={"authority_checks":f.calls,"adapter_calls":f.adapter.n,"model_objects":len(f.models),"records":len(result["records"]),"all_times_are_fake":True}
# Initial denials and changed immutable lineage prevent observation/model/output.
for fault in ("execute","cuda","bytecode","history_denial","reuse_denial"):
 f=Fixture()
 if fault=="execute":f.execute=False
 elif fault=="cuda":f.cuda="2"
 elif fault=="bytecode":f.bytecode="0"
 else:f.fault=fault
 reject(f,fault,before_inputs=True,no_write=True)
for key in ("expected_certificate_sha256","controls","rounds","dtype","cell"):
 f=Fixture()
 f.pins[key]="changed" if key not in ("controls","rounds","cell") else (["local"] if key=="controls" else (3 if key=="rounds" else {"tile_id":0}))
 reject(f,"pins_"+key,before_inputs=True,no_write=True)
for key in ("schema","phase","source_sha256","observed_artifact_sha256","expected_certificates","inspection_manifest","initial_state_sha256_by_dtype","group_permutation"):
 f=Fixture();f.current[key]="changed"
 reject(f,"base_immutable_"+key,before_inputs=True,no_write=True)
for key in BASE["refs"]:
 if key in ("storage","launcher"):continue
 f=Fixture();f.current["refs"][key]={"path":"handmade/changed.json","sha256":"0"*64}
 reject(f,"base_ref_"+key,before_inputs=True,no_write=True)
f=Fixture();f.old["expected_certificates"]["bio_paths_pilot_train_000:1"]="0"*64
reject(f,"historical_certificate",before_inputs=True,no_write=True)
for key in ("fit_authorized","source_ref","config_ref","review_ref"):
 f=Fixture();f.reuse[key]=True if key=="fit_authorized" else {"path":"changed","sha256":"0"*64}
 reject(f,"reuse_"+key,before_inputs=True,no_write=True)
for key,value in [("seed",42),("model",{}),("readout_chunk_size",64)]:
 f=Fixture();f.qcfg[key]=value;reject(f,"qcfg_"+key,before_inputs=True,no_write=True)
# Strict memory capability fields, dates, caller/pin identity and authority declarations.
memory_faults={"schema":"wrong","status":"inactive","root_authorizer":"other","job_id":"other",
 "CPU_total_reservation_bytes":63_000_000_000,"GPU_admitted":True,"external_watchdog":False,
 "recipe_ref":{"path":"wrong","sha256":"0"*64},"pins_ref":{"path":"wrong","sha256":"0"*64},
 "output_directory":"wrong","created_at_utc":(NOW+timedelta(minutes=1)).isoformat(),
 "expires_at_utc":NOW.isoformat()}
for key,value in memory_faults.items():
 f=Fixture();f.memory[key]=value;reject(f,"memory_"+key,before_inputs=True,no_write=True)
for fault in ("extra_field","missing_field","naive_date","before_base","after_base"):
 f=Fixture()
 if fault=="extra_field":f.memory["extra"]=True
 elif fault=="missing_field":del f.memory["external_watchdog"]
 elif fault=="naive_date":f.memory["created_at_utc"]="2026-10-11T11:00:00"
 elif fault=="before_base":f.memory["created_at_utc"]=(NOW-timedelta(hours=3)).isoformat()
 else:f.memory["expires_at_utc"]=(NOW+timedelta(hours=3)).isoformat()
 reject(f,"memory_"+fault,before_inputs=True,no_write=True)
# Denial at each authority boundary refuses every evidence write, including the completed final result.
for number in range(1,15):
 f=Fixture();f.deny_from=number
 reject(f,"authority_denied_from_"+str(number),before_inputs=number<=2,no_write=True)
# Reuse revocation or memory expiry at initial, mid-loop and final gates also refuse writes.
for role in ("reuse","memory"):
 for number in (1,4,14):
  f=Fixture()
  if role=="reuse":f.reuse_deny_from=number
  else:f.memory_expire_from=number
  reject(f,role+"_revoked_from_"+str(number),before_inputs=number==1,no_write=True)
for role in ("base","reuse","memory","pins"):
 f=Fixture();f.extra_args=["--expected-"+role+"-admission-sha256" if role!="pins" else "--expected-pins-sha256","0"*64]
 reject(f,"stale_CLI_"+role,before_inputs=True,no_write=True)
for role in PINS["historical_refs"]:
 f=Fixture();f.pins["historical_refs"][role]["sha256"]="0"*64
 reject(f,"stale_historical_"+role,before_inputs=True,no_write=True)
# Positive authority still preserves failed partial evidence without a completed/speedup claim.
for fault in ("manifest_failure","tree_count","load_failure","prepare_failure","certificate","native_tree_count","collision","lineage",
 "initial_state","initial_gradient","initial_device","adapter_failure","query_order","shape","logits_nonfinite","backward_failure",
 "gradient_nonfinite","gradient_missing","inactive_gradient","state_changed","encoder_leak","counter_mismatch"):
 f=Fixture();f.fault=fault;reject(f,fault)
f=Fixture();f.fault="output_constructor";reject(f,"output_constructor",before_inputs=True,no_write=True)
f=Fixture();f.fault="evidence_write";error,stdout,_=f.run()
check(error is not None and not f.writes and f.attempts==["evidence.json"] and not stdout,"bounded_evidence_write_failure_propagates")
# Metadata joins and accepted implementation are unchanged; no historical/input/runtime objects are read.
check(BASE["expected_certificates"]["bio_paths_pilot_train_000:1"]==EXPECTED==PINS["expected_certificate_sha256"],"fixed_external_certificate_metadata_join")
check(BASE["initial_state_sha256_by_dtype"]["float32"]==PINS["initial_state_sha256"],"initial_state_metadata_join")
check(BASE["inspection_manifest"]==PINS["historical_refs"]["inspection_evidence"],"inspection_ref_metadata_join")
check(BASE["refs"]["runtime"]==PINS["qualified_runtime_ref"],"runtime_ref_metadata_join_only")
check(len(BASE["expected_certificates"])==32 and len(BASE["group_permutation"])==184,"original_closure_and_permutation_count")
for pin in PINS["input_refs"].values():check(BASE["observed_artifact_sha256"][pin["path"]]==pin["sha256"],"input_pin_metadata_join_only")
for key in ("reuse_source_ref","reuse_config_ref","reuse_review_ref"):
 pin=PINS[key];check(artifact(ROOT/pin["path"])==pin,"accepted_reuse_bytes_unchanged")
accepted=json.loads((ROOT/PINS["reuse_review_ref"]["path"]).read_text())
check(accepted["status"]=="PASS" and accepted["actual_admission"] is False,"accepted_source_review_only")
tree=ast.parse(TEXT)
torch_attrs={n.attr for n in ast.walk(tree) if isinstance(n,ast.Attribute) and isinstance(n.value,ast.Name) and n.value.id=="torch"}
check(torch_attrs=={"tensor","long","equal","isfinite"},"no_optimizer_CUDA_or_truth_API")
check("step(" not in TEXT and ".cuda(" not in TEXT and "torch.load(" not in TEXT and ".fit(" not in TEXT,"no_fit_optimizer_device_or_direct_input_decode")
check(next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="_model").args[1].value=="float32","original_float32_model_call")
gate_source=(ROOT/"src/arggnn/census_native_qualification_runner_v1.py").read_text()
check("storage['used_project_bytes']+storage['reserved_new_bytes']+storage['concurrent_reserve_bytes']>=450_000_000_000" in gate_source and "storage.get('project_limit_bytes')!=500_000_000_000" in gate_source,"practical_original_storage_incompatibility")
report={"schema":"census_timing_caller_independent_handmade_checks_v1","status":"PASS",
 "assertions":sum(COUNTS.values()),"categories":COUNTS,"cases":CASES,"positive_handmade_summary":positive_summary,
 "exact_recipe_ref":artifact(RECIPE),"exact_pins_ref":artifact(AUTHOR/"pins.json"),
 "real_arrays_models_runtime_GPU_budgets_or_historical_evidence_decoded":False,
 "all_dynamic_imports_of_arggnn_and_torch_replaced_by_fake_APIs":True,
 "source_reuse_6888_checks_repeated":False}
with (OUT/"test_results.json").open("x") as stream:json.dump(report,stream,indent=2,allow_nan=False);stream.write("\n")
print(json.dumps({"status":"PASS","assertions":report["assertions"],"rejection_cases":len(CASES),"positive_handmade_summary":positive_summary},indent=2))
