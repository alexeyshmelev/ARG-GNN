# Root launch recipe: one genuine certified forest, CPU

Source and metadata only. No arrays, models, CUDA, timing, reservations, launch or Git operations were performed by the author.

## Fixed scope and pins

Use TRAIN parent bio_paths_pilot_train_000, tile1, 132 original trees, chosen by the independently frozen TRAIN maximum. External certificate SHA: 85cf9aa984429a460a15b5be94bb3366f4bf06e65a17812dc7dfb59af3403bf5. This comes from frozen original inspection/numerical admissions and evidence, never a newly prepared object. pins.json includes exact reviewed source/config/history, six selected observation-input refs and qualified runtime.

Keep original seed41, hidden32/latent8/classes4/layers2/branches3 FP32 model, time_scale10000, chunk128, original184-entry group permutation. Preserve complete per-call certificate SHA, retained-input validation and unchanged GNN role/date/membership/topology checks. No targets, target NPZ, serialized bank.pt, optimizer, fit loop, step or autograd cache.

## API and original authority

The reuse module has no observed-profile CLI; its CLI invokes the fit. observed_timing_v1 creates a fresh adapter per call, so it measures cold first binding. Repeating that helper does not exercise recurring reuse.

The Python caller separately admits phase observed_profile, holds one CertifiedForestReuseV1 and calls all5 controls in fixed order for2 rounds. Require10 calls,1 binding,9 reuses. Each control uses a fresh copy of the original initialization and synthetic logits.square().mean().backward(), then clears gradients. Preparation and closure-validation times are separate. Adapter phase differences separate cold first binding from recurring retained-input checks. No original-versus-reuse speedup is inferred.

The historical device-profile gate accepts only CUDA and both extrema. Its admission is evidence, not CPU authority. This caller uses unchanged admit_runner_v1 phase numerical as its fresh original CPU gate and unchanged require_terminal_numerical_v1 for historical qualification, without running the32-cell qualification loop. Preserve all32 original observation/source/certificate/state pins in the base admission. Original read_manifests_v1 hashes the entire observation closure and load_parent_v1 hashes8 selected-parent whole-graph files. Only tile1 is decoded/certified/forwarded. Closure hashing is outside the per-call timing loop.

## Root activation

1. Root registers this as H021's new actual CPU reuse condition, linking accepted source review and prior profile evidence. Select a distinct CPU job and fresh exclusive output.
2. Root obtains a complete current storage snapshot and active1GB output reservation plus current concurrency. Original gates require used+reserve+concurrency below450GB and total project limit500GB. Establish the external64GB CPU watcher before declaring it active. This is a planning reservation, not a measured peak.
3. Copy templates into a fresh root-owned authority directory. Replace all placeholders/null dates. Set base/storage/memory/reuse status active and observed_profile_authorized true. Keep fit_authorized false and GPU_admitted false. Set external_watchdog true only after watcher exists. Base lifetime/age max86400s; snapshot age max3600s; memory dates lie within base dates. Job/output must agree.
4. Freeze/hash snapshot then storage+launcher then base then reuse+memory. Reuse binds new exact base path/SHA. Memory pins this caller and pins.json. Keep every other original base config/runtime/review/observation/certificate/inspection/model/permutation field unchanged; caller checks them.
5. Root validates capabilities/watchdog, then sets the6 authority path/SHA variables to literal approved values and launches from the project directory:

    source scripts/project_env.sh
    export CUDA_VISIBLE_DEVICES=''
    export PYTHONDONTWRITEBYTECODE=1
    "$ARGGNN_PYTHON" -B research/reviews/census_certified_forest_reuse_v1_timing_author/root_cpu_timing_recipe.py \
      --execute \
      --base-admission "$CPU_TIMING_BASE_PATH" \
      --expected-base-admission-sha256 "$CPU_TIMING_BASE_SHA" \
      --reuse-admission "$CPU_TIMING_REUSE_PATH" \
      --expected-reuse-admission-sha256 "$CPU_TIMING_REUSE_SHA" \
      --memory-admission "$CPU_TIMING_MEMORY_PATH" \
      --expected-memory-admission-sha256 "$CPU_TIMING_MEMORY_SHA" \
      --expected-pins-sha256 "17cbda8e788ef20b0d2bc13d4f52f8cc74fd2295883292cab4158e6c5416c663"

Original admission sets CPU threads1 and requires main Python3.11.17/Torch2.6.0+cu124/NumPy2.4.6/tskit1.0.3 plus all frozen interpreter/library byte pins.

## Root completion

Require exit0, evidence.json status completed_observed_only_CPU_timing, all5 controls twice, external certificate/model hashes unchanged, no updates and counters10/1/9. Preserve failed partial stderr/evidence. Expired/denied authority refuses further evidence writes. Root owns terminal binding, outcome/ledger, reservation release and Git. This folder is prospective source, not measured results or an independent review of the caller.
