"""Author handmade CPU cases. Never read project biological observations/targets."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import hashlib,io,json,os
from pathlib import Path
import numpy as np
import pytest
import torch
import tskit
import arggnn.census_biological_fit_v1 as fit
from arggnn.biological_candidate import pack_observed_tile
from arggnn.census_biological_bank_v1 import ObservedSampleRoleV1,prepare_census_biological_bank_v1
from arggnn.census_native_qualification_runner_v1 import VerifiedReaderV1

@pytest.fixture(autouse=True)
def cpu_only():
    assert os.environ['CUDA_VISIBLE_DEVICES']==''
    torch.set_num_threads(1)


def native_fixture():
    ages=[0.]*64+[135.]*16+[155.]*8+[200.]*16+[170.]*16+[120.+2*(i//2) for i in range(64)]+[300.+6*((i//2)%12) for i in range(96)]
    tables=tskit.TableCollection(sequence_length=950.)
    for age in ages:tables.nodes.add_row(flags=tskit.NODE_IS_SAMPLE,time=age)
    for left,right,order in ((0.,475.,list(range(280))),(475.,950.,list(range(0,184,2))+list(range(1,184,2))+list(range(184,280)))):
        active=order
        while len(active)>1:
            later=[]
            for start in range(0,len(active),2):
                pair=active[start:start+2]
                if len(pair)==1:later+=pair;continue
                ancestor=tables.nodes.add_row(time=max(tables.nodes[x].time for x in pair)+80.)
                for child in pair:tables.edges.add_row(left,right,ancestor,child)
                later.append(ancestor)
            active=later
    tables.sort();ts=tables.tree_sequence()
    cohorts=['present_day']*64+['Bronze_Age']*16+['BAA']*8+['Neo']*16+['Yam']*16+['Neo']*64+sum(([c]*24 for c in ('Ana','CHG','WHG','EHG')),[])
    rows=[];roster=[]
    for i,(age,cohort) in enumerate(zip(ages,cohorts)):
        role='query' if i<120 else 'mixed_reference_only' if i<184 else 'pure_source_reference';cls=None if i<184 else (i-184)//24
        rows.append({'sample_index':i,'sample_id':f'handmade_subject_{i//2}','haplotype':i%2,'observed_node_id':3000+i,'observed_cohort':cohort,'age_generations':age,'role':role,'observed_reference_class':cls})
        roster.append(ObservedSampleRoleV1(i,i,role,age,cls))
    return ts,rows,roster


def certificate(ts,rows,roster,parent_id,split):
    parent={'observation':{'nodes':np.arange(280),'offset':25.},'dynamics_slots':np.arange(184),'query_slots':np.arange(120),'reference_slots':np.arange(184,280),'samples':rows,'positions':np.arange(50.,2000000.,100.)}
    sequence,indexes,_,_=pack_observed_tile(ts,parent,25.,975.)
    bindings={name:{'path':'handmade/'+name,'sha256':hashlib.sha256(name.encode()).hexdigest()} for name in ('native_observed_ts','serialized_whole_observed','observed_roster','observed_grid','producer_receipt')}
    return prepare_census_biological_bank_v1(ts,{'sequence':sequence.as_dict(),'labels_in_input':False},roster,left_bp=25.,right_bp=975.,offset_bp=25.,positions_bp=torch.tensor(parent['positions'][indexes]),original_grid_indexes=torch.tensor(indexes),source_bindings=bindings,parent_id=parent_id,split=split,tile_id=0)


def bytes_npz(**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);return stream.getvalue()


def targets_bytes(rows):
    intervals=np.array([[0.,75.],[75.,180.],[180.,505.],[505.,700.],[700.,2000000.]])
    labels=(np.arange(120)[None,:]+np.arange(5)[:,None])%4
    return bytes_npz(intervals_bp=intervals,query_raw_node_ids=np.array([r['observed_node_id'] for r in rows[:120]],dtype=np.int32),native_paths_1based=labels.astype(np.uint8)+1,source_classes_0based=labels.astype(np.uint8))


def parent_score(parent_id,split,rows):
    return {'parent_id':parent_id,'split':split,'samples':rows,'query_slots':np.arange(120),'raw_query_nodes':np.array([r['observed_node_id'] for r in rows[:120]]),
        'cohorts':np.array([r['observed_cohort'] for r in rows[:120]]),'positions':np.arange(50.,1000.,100.),'edges':np.r_[25.,np.arange(100.,1000.,100.),975.],
        'retained_indexes':np.arange(10),'coverage_original':[25.,975.],'query_ids':np.arange(120)}


def memory_reader(data):
    return VerifiedReaderV1(read_bytes=lambda path:data[path])


def ref(path,data):return {'path':path,'sha256':hashlib.sha256(data).hexdigest()}


def gate_fixture():
    refs={k:ref('handmade/'+k+'.json',k.encode()) for k in ('numerical_evidence','numerical_admission','inspection_evidence','inspection_freeze')}
    certs={f'{p}:{i}':hashlib.sha256(f'{p}:{i}'.encode()).hexdigest() for p in fit.PARENTS for i in range(8)}
    sources={'handmade_source':'f'*64};objects={'handmade_observation':'e'*64};originalrefs={k:ref('handmade/'+k,k.encode()) for k in ('runner_config','native_manifest','prepared_manifest','feature_lineage')}
    admission={'job_id':'handmade_numerical','phase':'numerical','inspection_manifest':refs['inspection_evidence'],'expected_certificates':certs,'source_sha256':sources,'observed_artifact_sha256':objects,'refs':originalrefs,'initial_state_sha256_by_dtype':{'float64':'a'*64,'float32':'b'*64}}
    original=[];cells=[]
    wanted=[[d,c] for d in ('float64','float32') for c in fit.CONTROLS]
    for identity,sha in certs.items():
        parent,tile=identity.split(':');cell={'parent_id':parent,'tile_id':int(tile),'split':'train' if '_train_' in parent else 'val','num_trees':2,'certificate_sha256':sha,'decoded_lineage':{'handmade':True},'event_collision_counts':{'handmade':0}}
        original.append(dict(cell,status='inspected_pending_root_freeze'))
        checks=[{'dtype':d,'control':c,'initial_state_sha256':admission['initial_state_sha256_by_dtype'][d],'finite_disposable_AdamW':True,'forest_output_VJP_parity':True,'sample_readout_target_column_order':True} for d,c in wanted]
        cells.append(dict(cell,status='numerically_qualified',qualification={'status':'qualified','performed_controls':wanted,'checks':checks}))
    inspection={'schema':'census_native_qualification_evidence_v1','phase':'inspect','status':'inspection_complete_pending_root_freeze','failed_cells':[],'fixture_mode':False,'cells':original,'source_sha256':sources,'observed_artifact_sha256':objects,'refs':originalrefs}
    freeze={'schema':'root_external_census_inspection_freeze_v1','expected_cells':32,'expected_certificates':certs,'inspection_ref':refs['inspection_evidence'],'model_or_label_outcomes_used_for_selection':False,'source_and_original_count_lineage_rechecked':True}
    evidence={'schema':'census_native_qualification_evidence_v1','phase':'numerical','status':'numerical_complete_no_fitting_or_predictive_claim','fixture_mode':False,'expected_cells':32,'biological_targets_opened':False,'fit_performed':False,'GPU_used':False,'geometry_adapted':False,'failed_cells':[],'performed_cell_coverage':list(certs),'cells':cells,'job_id':admission['job_id'],'admission_ref':refs['numerical_admission'],'source_sha256':sources,'observed_artifact_sha256':objects,'refs':originalrefs}
    terminal={'schema':'census_numerical_root_terminal_binding_v1','status':'complete','returncode':0,'evidence_ref':refs['numerical_evidence'],'admission_ref':refs['numerical_admission'],'inspection_ref':refs['inspection_evidence'],'freeze_ref':refs['inspection_freeze'],'job_id':admission['job_id']}
    return evidence,admission,inspection,freeze,terminal,refs


def test_terminal_gate_complete32_exact_bytes_lineage_shape():
    values=gate_fixture();assert fit.require_terminal_numerical_v1(*values)['job_id']=='handmade_numerical'


@pytest.mark.parametrize('bad',['running','nonzero_exit','duplicate','missing','failed','fixture','source','observation','certificate','control','state','VJP','inspection','freeze','target_opened','job'])
def test_terminal_gate_rejects_incomplete_changed_or_unbound_evidence(bad):
    e,a,i,f,t,r=deepcopy(gate_fixture())
    if bad=='running':e['status']='running'
    elif bad=='nonzero_exit':t['returncode']=1
    elif bad=='duplicate':e['performed_cell_coverage'][-1]=e['performed_cell_coverage'][0]
    elif bad=='missing':e['cells'].pop()
    elif bad=='failed':e['failed_cells']=['one']
    elif bad=='fixture':e['fixture_mode']=True
    elif bad=='source':e['source_sha256']={}
    elif bad=='observation':e['observed_artifact_sha256']={}
    elif bad=='certificate':e['cells'][0]['certificate_sha256']='0'*64
    elif bad=='control':e['cells'][0]['qualification']['performed_controls']=[]
    elif bad=='state':e['cells'][0]['qualification']['checks'][0]['initial_state_sha256']='0'*64
    elif bad=='VJP':e['cells'][0]['qualification']['checks'][0]['forest_output_VJP_parity']=False
    elif bad=='inspection':i['cells'][0]['num_trees']=3
    elif bad=='freeze':f['model_or_label_outcomes_used_for_selection']=True
    elif bad=='target_opened':e['biological_targets_opened']=True
    elif bad=='job':t['job_id']='wrong'
    with pytest.raises(ValueError):fit.require_terminal_numerical_v1(e,a,i,f,t,r)


def test_full_default280_two_tree_all_controls_TRAIN_forward_backward_raw_probability():
    ts,rows,roster=native_fixture();cert=certificate(ts,rows,roster,'handmade_train','train');cfg=fit.load_config_v1()
    assert len(cert.inputs)==2 and all(len(x.parent)==559 for x in cert.inputs)
    states=fit.matched_states_v1(cfg,101,torch.device('cpu'));assert len({s['initial_sha256'] for s in states.values()})==1
    targetdata=targets_bytes(rows);record=ref('handmade/TRAIN.npz',targetdata);reader=memory_reader({record['path']:targetdata});parent=parent_score('handmade_train','train',rows)
    target=fit.ExternalTargetV1(parent,{'truth_npz':record},'TRAIN_loss',reader);mass=target.target_mass(parent,fit.metric_helpers_v1())
    assert mass[0,0].sum()==75 and np.count_nonzero(mass[0,0])==2
    permutation=torch.roll(torch.arange(184),1);inventory=None
    for control,state in states.items():
        names=tuple((k,tuple(v.shape)) for k,v in state['model'].state_dict().items());inventory=names if inventory is None else inventory;assert inventory==names
        step=fit.train_step_v1(state,cert,cert.certificate_sha256,mass,control,permutation,cfg,torch.device('cpu'))
        assert np.isfinite(step['loss']) and step['steps']==1
        logits,p,ids=fit.raw_prediction_v1(state,cert,cert.certificate_sha256,control,permutation,cfg)
        assert logits.shape==p.shape==(10,120,4) and np.array_equal(ids,np.arange(120))
        assert max(float((v.detach().cpu()-state['initial'][k]).abs().max()) for k,v in state['model'].state_dict().items() if v.is_floating_point())>0
        for name,param in state['model'].named_parameters():
            inactive=(name.endswith('raw_eta') and control in ('eta0','local')) or (name.endswith('raw_damping') and control=='local')
            assert (param.grad is None)==inactive
            if not inactive:assert torch.isfinite(param.grad).all()


def test_VAL_target_cannot_open_before_prediction_or_enter_TRAIN_step():
    ts,rows,roster=native_fixture();cert=certificate(ts,rows,roster,'handmade_val','val');parent=parent_score('handmade_val','val',rows)
    data=targets_bytes(rows);record=ref('handmade/VAL.npz',data);reads=[]
    reader=VerifiedReaderV1(read_bytes=lambda path:reads.append(path) or data)
    with pytest.raises(ValueError,match='sealed'):fit.ExternalTargetV1(parent,{'truth_npz':record},'VAL_after_sealed_prediction',reader)
    with pytest.raises(ValueError,match='split'):fit.ExternalTargetV1(parent,{'truth_npz':record},'TRAIN_loss',reader)
    assert reads==[]
    cfg=fit.load_config_v1();state=fit.matched_states_v1(cfg,101,torch.device('cpu'))['proposed']
    with pytest.raises(ValueError,match='TRAIN-only'):fit.train_step_v1(state,cert,cert.certificate_sha256,np.zeros((10,120,4)),'proposed',torch.arange(184),cfg,torch.device('cpu'))


def test_exact_span_raw_scores_preserve_infinite_NLL_and_support():
    _,rows,_=native_fixture();parent=parent_score('handmade_val','val',rows);data=targets_bytes(rows);targetref=ref('handmade/VAL.npz',data)
    p=np.full((10,120,4),.25,dtype=np.float32);p[0,0]=[1.,0.,0.,0.]
    prediction=bytes_npz(C4_probabilities=p,positions_bp=parent['positions'],bin_edges_bp=parent['edges'],retained_fixed100bp_indexes=parent['retained_indexes'],query_sample_indexes=parent['query_slots'])
    seal=ref('handmade/sealed.npz',prediction);reader=memory_reader({targetref['path']:data,seal['path']:prediction})
    result=fit.score_sealed_v1(seal,parent,{'truth_npz':targetref},reader,fit.metric_helpers_v1(),fit.load_config_v1())
    score=result['groups']['all_queries_120'];assert score['nll'] is None and score['infinite_nll_query_bp']==25.
    assert score['denominator_query_bp']==950*120 and score['probability_floor_used'] is False
    assert set(result['groups'])=={'primary_present_day_64','secondary_ancient_56','all_queries_120','age_stratum_Bronze_Age','age_stratum_BAA','age_stratum_Neo','age_stratum_Yam'}
    # Independent ARGMix-style raw proper-score equations over class-span masses.
    target=fit.ExternalTargetV1(parent,{'truth_npz':targetref},'VAL_after_sealed_prediction',reader,seal);mass=target.target_mass(parent,fit.metric_helpers_v1())
    total=mass.sum();pred=p.argmax(-1);good=np.take_along_axis(mass,pred[...,None],-1).sum()/total
    brier=(mass.sum(-1)*(np.square(p.astype(float)).sum(-1)+1)-2*(mass*p).sum(-1)).sum()/total
    assert score['accuracy']==pytest.approx(good,abs=1e-14) and score['brier']==pytest.approx(brier,abs=1e-14)


def test_complete_wrapper_handmade_one_epoch_full_default_architecture(monkeypatch,tmp_path):
    ts,rows,roster=native_fixture();cfg=fit.load_config_v1();cfg=deepcopy(cfg)
    cfg['training'].update(epochs=1,TRAIN_tiles_per_epoch=2,optimizer_steps_per_control_seed=2)
    # Only the admission/observation adapters and epoch budget are handmade substitutes.
    # Real file bytes, target decoder, model/backward, prediction sealing, proper scores,
    # selected checkpoints and changed-weight completion all execute normally.
    paired=[];certs={};bindings={'parents':{}};files={};loaded={};expected={}
    reader=VerifiedReaderV1();output_rel=str((tmp_path/'fit_output').relative_to(fit.ROOT))
    for split in ('train','val'):
        for number in range(2):
            pid=f'handmade_{split}_{number}';cert=certificate(ts,rows,roster,pid,split);certs[pid]=cert;expected[pid+':0']=cert.certificate_sha256
            original=json.dumps(rows).encode();sourcefile=tmp_path/(pid+'.roster.json');sourcefile.write_bytes(original);sref=ref(str(sourcefile.relative_to(fit.ROOT)),original)
            targetdata=targets_bytes(rows);targetfile=tmp_path/(pid+'.targets.npz');targetfile.write_bytes(targetdata);tref=ref(str(targetfile.relative_to(fit.ROOT)),targetdata)
            bindings['parents'][pid]={'truth_npz':tref,'split':split,'query_sample_indexes':list(range(120)),'query_raw_node_ids':list(range(3000,3120))}
            parent={'parent_id':pid,'split':split};bank={'tiles':[{'tile_id':0,'position_indexes':list(range(10))}]};paired.append((parent,bank))
            loaded[pid]=(ts,roster,np.arange(50.,2000000.,100.),25.,[25.,975.],{'source':sref},{'handmade':True})
    now=datetime.now(timezone.utc);admission={'job_id':'handmade_fit','created_at_utc':now.isoformat(),'expires_at_utc':(now+timedelta(hours=1)).isoformat(),'seed':101,'device':'cpu','output_directory':output_rel,'expected_certificates':expected,'source_sha256':{},'group_permutation':torch.roll(torch.arange(184),1).tolist(),'refs':{'config':ref('handmade_config',b'config'),'numerical_evidence':ref('handmade_numerical',b'numerical')}}
    adbytes=json.dumps(admission).encode();adfile=tmp_path/'admission.json';adfile.write_bytes(adbytes);adref=ref(str(adfile.relative_to(fit.ROOT)),adbytes)
    monkeypatch.setattr(fit,'admit_fit_v1',lambda _: (admission,cfg,{}, {},bindings,reader,{'reserved_new_bytes':100000000,'expires_at_utc':admission['expires_at_utc']}))
    monkeypatch.setattr(fit,'read_manifests_v1',lambda *_:paired)
    monkeypatch.setattr(fit,'load_parent_v1',lambda parent,*_,**__:loaded[parent['parent_id']])
    monkeypatch.setattr(fit,'prepare_tile_v1',lambda parent,*_,**__:(certs[parent['parent_id']],{},{}))
    import arggnn.biological_candidate as old
    monkeypatch.setattr(old,'configure_fit',lambda *_:(torch.device('cpu'),{'handmade_CPU':True},None))
    result=fit.run_fit_v1(adref)
    assert result['status']=='completed_five_fixed_budget_development_controls_one_seed'
    assert set(result['models'])==set(fit.CONTROLS) and result['TEST_parents']==0
    for cell in result['models'].values():assert cell['optimizer_steps']==2 and cell['selected_weight_max_delta']>0 and cell['selected_epoch']==1
    assert (tmp_path/'fit_output/completed.json').is_file()


def test_no_actual_default_admission_can_be_omitted():
    bad={'schema':'census_biological_fit_admission_v1','status':'active'};data=json.dumps(bad).encode()
    with pytest.raises(ValueError):fit.admit_fit_v1(ref('handmade/missing.json',data))


def admission_fixture(monkeypatch):
    cfg=deepcopy(fit.load_config_v1());mapping={}
    def put(path,obj):
        data=(json.dumps(obj,sort_keys=True)+'\n').encode();mapping[path]=data;return ref(path,data)
    qcfg=json.loads((fit.ROOT/'configs/census_native_qualification_runner_v1.json').read_text())
    source=dict(qcfg['source_sha256'])
    source['src/arggnn/census_native_qualification_runner_v1.py']=hashlib.sha256((fit.ROOT/'src/arggnn/census_native_qualification_runner_v1.py').read_bytes()).hexdigest()
    fitsources=dict(cfg['source_sha256']);fitsources['src/arggnn/census_biological_fit_v1.py']=hashlib.sha256((fit.ROOT/'src/arggnn/census_biological_fit_v1.py').read_bytes()).hexdigest()
    for path in set(source)|set(fitsources):mapping[path]=(fit.ROOT/path).read_bytes()
    e,a,i,f,t,r=gate_fixture();a['source_sha256']=e['source_sha256']=i['source_sha256']=source
    a['group_permutation']=torch.roll(torch.arange(184),1).tolist()
    runtimehashes={path:hashlib.sha256(path.encode()).hexdigest() for path in qcfg['runtime_files']}
    for path in runtimehashes:mapping[path]=path.encode()
    numericalruntime={'runtime_file_sha256':runtimehashes};qref=put('handmade/native_config.json',qcfg);nrref=put('handmade/numerical_runtime.json',numericalruntime)
    a['refs']['runner_config']=e['refs']['runner_config']=i['refs']['runner_config']=qref;a['refs']['runtime']=nrref
    # Publish references in dependency order. Ref values in terminal bind exact bytes.
    r['inspection_evidence']=put('handmade/inspection.json',i);a['inspection_manifest']=r['inspection_evidence'];f['inspection_ref']=r['inspection_evidence']
    r['inspection_freeze']=put('handmade/freeze.json',f);r['numerical_admission']=put('handmade/numerical_admission.json',a);e['admission_ref']=r['numerical_admission']
    r['numerical_evidence']=put('handmade/numerical.json',e)
    t.update(evidence_ref=r['numerical_evidence'],admission_ref=r['numerical_admission'],inspection_ref=r['inspection_evidence'],freeze_ref=r['inspection_freeze'])
    r['numerical_terminal']=put('handmade/terminal.json',t)
    manifest={'replicates':[{'parent_id':pid,'split':'train' if '_train_' in pid else 'val','files':{'truth/full_truth_intervals.npz':{'sha256':hashlib.sha256(pid.encode()).hexdigest()}}} for pid in fit.PARENTS]}
    r['target_manifest']=put('handmade/target_manifest.json',manifest);cfg['external_target_manifest']=r['target_manifest']
    r['config']=put('handmade/fit_config.json',cfg)
    review={'status':'qualified_source_handmade_CPU_only','actual_admission':False,'fixture_mode':False,'artifact_sha256':{'src/arggnn/census_biological_fit_v1.py':fitsources['src/arggnn/census_biological_fit_v1.py'],'configs/census_biological_fit_v1.json':r['config']['sha256']}}
    r['review']=put('handmade/review.json',review)
    now=datetime.now(timezone.utc);future=(now+timedelta(hours=1)).isoformat()
    snapshot={'status':'complete','returncode':0,'project_root':str(fit.ROOT),'used_project_bytes':1000000000,'created_at_utc':now.isoformat()};snapref=put('handmade/snapshot.json',snapshot)
    storage={'schema':'census_biological_fit_storage_v1','status':'active','job_id':'handmade_fit','output_directory':'handmade/new_output','reserved_new_bytes':40000000000,'concurrent_reserve_bytes':50000000000,'effective_project_ceiling_bytes':450000000000,'used_project_bytes':1000000000,'created_at_utc':now.isoformat(),'expires_at_utc':future,'snapshot_ref':snapref}
    r['storage']=put('handmade/storage.json',storage)
    runtime={'schema':'census_biological_fit_runtime_v1','python':str(fit.ROOT/'.runtime/env/bin/python'),'torch':str(torch.__version__),'numpy':str(np.__version__),'runtime_file_sha256':runtimehashes};r['runtime']=put('handmade/runtime.json',runtime)
    launcher={'schema':'census_biological_fit_launcher_v1','job_id':'handmade_fit','device':'cpu','GPU_admitted':False,'python':'.runtime/env/bin/python','external_watchdog':True,'profile_gate_passed':True,'PYTHONDONTWRITEBYTECODE':'1'};r['launcher']=put('handmade/launcher.json',launcher)
    profileref=put('handmade/profile_evidence.json',{'handmade':True})
    profile={'schema':'census_biological_fit_profile_gate_v1','status':'qualified_for_fixed_protocol','fit_config_ref':r['config'],'source_sha256':fitsources,'numerical_ref':r['numerical_evidence'],'device':'cpu','controls':list(fit.CONTROLS),'model':cfg['model'],'full_whole_tree_forward_backward_measured':True,'fresh_root_resource_reservation':True,'profile_evidence_ref':profileref};r['profile']=put('handmade/profile.json',profile)
    bindings={'schema':'census_biological_targets_root_binding_v1','observed_artifact_sha256':a['observed_artifact_sha256'],'manifest_ref':r['target_manifest'],'parents':{}}
    for row in manifest['replicates']:
        pid=row['parent_id'];bindings['parents'][pid]={'split':row['split'],'truth_npz':{'path':f'data/biological_paths_execution_pilot_v1/{pid}/truth/full_truth_intervals.npz','sha256':row['files']['truth/full_truth_intervals.npz']['sha256']},'query_sample_indexes':list(range(120)),'query_raw_node_ids':list(range(3000,3120))}
    r['target_bindings']=put('handmade/target_bindings.json',bindings)
    ad={'schema':'census_biological_fit_admission_v1','status':'active','fit_authorized':True,'job_id':'handmade_fit','created_at_utc':now.isoformat(),'expires_at_utc':future,'refs':r,'source_sha256':fitsources,'seed':101,'device':'cpu','output_directory':'handmade/new_output','expected_certificates':f['expected_certificates'],'observed_artifact_sha256':a['observed_artifact_sha256'],'group_permutation':a['group_permutation']}
    adref=put('handmade/fit_admission.json',ad)
    reads=[];reader=VerifiedReaderV1(read_bytes=lambda path:reads.append(path) or mapping[path])
    monkeypatch.setattr(fit,'VerifiedReaderV1',lambda:reader);monkeypatch.setattr(fit,'load_config_v1',lambda:cfg)
    return adref,ad,mapping,reads,put


def test_full_root_capability_preflight_reads_no_native_arrays_or_target_NPZ(monkeypatch):
    adref,ad,_,reads,_=admission_fixture(monkeypatch);result=fit.admit_fit_v1(adref)
    assert result[0]['job_id']=='handmade_fit'
    assert not any(path.endswith(('.npz','.trees','.pt')) for path in reads)


@pytest.mark.parametrize('bad',['authorization','expired','review_fixture','runtime','storage','watchdog','profile','seed','permutation','source'])
def test_full_root_capability_preflight_rejects_changed_admission(monkeypatch,bad):
    adref,ad,mapping,reads,put=admission_fixture(monkeypatch)
    if bad=='authorization':ad['fit_authorized']=False
    elif bad=='expired':ad['expires_at_utc']=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
    elif bad in ('review_fixture','runtime','storage','watchdog','profile'):
        role={'review_fixture':'review','runtime':'runtime','storage':'storage','watchdog':'launcher','profile':'profile'}[bad]
        value=json.loads(mapping[ad['refs'][role]['path']])
        if bad=='review_fixture':value['fixture_mode']=True
        elif bad=='runtime':value['runtime_file_sha256']={}
        elif bad=='storage':value['reserved_new_bytes']=1
        elif bad=='watchdog':value['external_watchdog']=False
        elif bad=='profile':value['full_whole_tree_forward_backward_measured']=False
        ad['refs'][role]=put('handmade/'+role+'_bad.json',value)
    elif bad=='seed':ad['seed']=999
    elif bad=='permutation':ad['group_permutation']=list(range(184))
    elif bad=='source':ad['source_sha256']['src/arggnn/census_biological_fit_v1.py']='0'*64
    badref=put('handmade/admission_bad.json',ad)
    with pytest.raises(ValueError):fit.admit_fit_v1(badref)
    assert not any(path.endswith(('.npz','.trees','.pt')) for path in reads)


def test_counterfactual_targets_never_change_forward_inputs_or_raw_predictions():
    ts,rows,roster=native_fixture();cert=certificate(ts,rows,roster,'handmade_train','train');cfg=fit.load_config_v1()
    state=fit.matched_states_v1(cfg,101,torch.device('cpu'))['proposed'];perm=torch.roll(torch.arange(184),1)
    before=fit.raw_prediction_v1(state,cert,cert.certificate_sha256,'proposed',perm,cfg)
    parent=parent_score('handmade_train','train',rows);data=targets_bytes(rows)
    record=ref('handmade/counterfactual.npz',data);reader=memory_reader({record['path']:data})
    target=fit.ExternalTargetV1(parent,{'truth_npz':record},'TRAIN_loss',reader);first=target.target_mass(parent,fit.metric_helpers_v1())
    target.c4=(target.c4+1)%4;second=target.target_mass(parent,fit.metric_helpers_v1());assert not np.array_equal(first,second)
    after=fit.raw_prediction_v1(state,cert,cert.certificate_sha256,'proposed',perm,cfg)
    for old,new in zip(before,after):assert np.array_equal(old,new)


def test_writer_reservation_expiry_stops_new_writes(tmp_path):
    reader=VerifiedReaderV1();reservation={'reserved_new_bytes':10000,'expires_at_utc':(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()}
    writer=fit.FitOutputV1(str((tmp_path/'output').relative_to(fit.ROOT)),reservation,reader)
    reservation['expires_at_utc']=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
    with pytest.raises(ValueError,match='expired'):writer.save('cannot_write.json',{'test':True})
    assert list(writer.path.iterdir())==[]


def test_resource_expiry_blocks_active_fit_even_if_admission_remains_current():
    now=datetime.now(timezone.utc);ad={'created_at_utc':now.isoformat(),'expires_at_utc':(now+timedelta(hours=1)).isoformat()}
    with pytest.raises(ValueError,match='storage'):fit._check_resources_v1(ad,{'expires_at_utc':(now-timedelta(seconds=1)).isoformat()},None)
