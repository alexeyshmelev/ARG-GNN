"""Independent source/scalar and handmade target/scoring review; no actual fit."""
from __future__ import annotations
import ast,copy,hashlib,io,json,os,sys,types
from pathlib import Path
import numpy as np
import torch
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN');OUT=ROOT/'research/reviews/census_biological_fit_v1_independent'
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'src'));os.environ['CUDA_VISIBLE_DEVICES']=''
torch.set_num_threads(1)
from arggnn import census_biological_fit_v1 as m
c=m.load_config_v1();checks=[];details={};issues=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha(p)}
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
def reject(n,call):
 try:call()
 except ValueError as e:checks.append(n);return str(e)
 raise AssertionError('unexpected acceptance: '+n)
pins={'src/arggnn/census_biological_fit_v1.py':'84f7f39c94003256cb22c905f610d5ce4a965d1ca733f483e22367f91dbc90ce','configs/census_biological_fit_v1.json':'b6f70c6d76421662713028b23deedaef071fb6f0d82a0ef6a9aedaa43f5fcd9e'}
for path,h in pins.items():check('requested_pin_'+path,sha(ROOT/path)==h)
for path,h in c['source_sha256'].items():check('restored_pinned_dependency_'+path,sha(ROOT/path)==h)
author=json.loads((ROOT/'research/reviews/census_biological_fit_v1_author/author_receipt.json').read_text())
for path,h in author['artifact_sha256'].items():check('sealed_author_artifact_'+path,sha(ROOT/path)==h)
check('H021_Relate_condition_and_development_limits',c['hypothesis_id']=='H021' and c['confirmation']['existing_VAL_is_development_only'] is True and c['confirmation']['independent_biological_parents']==0 and c['confirmation']['original_paper_reproduction'] is False)
check('fixed_equal30epochs480_steps_three_seeds',c['training']['epochs']==30 and c['training']['optimizer_steps_per_control_seed']==480 and c['training']['TRAIN_tiles_per_epoch']==16 and c['seeds']==[101,202,303])
check('TRAIN_query_only_no_reference_or_VAL_calibration_loss',c['training']['supervision']=='actual_query120_exact_class_span_mass_TRAIN_only' and c['training']['mixed_reference_supervision'] is False and c['training']['pure_reference_auxiliary_loss'] is False and c['training']['VAL_calibration_fit'] is False)
check('raw_probabilities_no_floor_renormalization_or_purity',all(c['metrics'][k] is False for k in ('probability_floor','posthoc_renormalization','purity_filter')))
check('prospective_confirmation_and_sensitivities_inactive',c['planned_independent_confirmation']['inactive'] is True and c['planned_independent_confirmation']['prospective_new_version_freeze_before_data_generation_or_TEST_access_required'] is True and c['planned_sensitivities']['inactive_separate_protocol_and_numerical_qualification_required'] is True)
summary=json.loads((ROOT/'experiments/results/census_native_actual32_numerical_v1_summary/summary.json').read_text())
terminal=json.loads((ROOT/'experiments/results/census_native_actual32_numerical_v1_summary/terminal_binding_v2.json').read_text())
check('actual32_summary_target_free_and_no_fit',summary['qualified_cells']==32 and summary['failed_cells']==0 and summary['control_dtype_checks']==320 and summary['biological_target_arrays_accessed'] is False and summary['predictive_fit_performed'] is False and summary['same_tsinfer_model_comparison_qualified'] is False)
mapping={'numerical_evidence':'evidence_ref','numerical_admission':'admission_ref','inspection_evidence':'inspection_ref','inspection_freeze':'freeze_ref'}
refs={k:terminal[v] for k,v in mapping.items()};values={}
for key,r in refs.items():
 check('actual_numerical_metadata_pin_'+key,sha(ROOT/r['path'])==r['sha256'])
 values[key]=json.loads((ROOT/r['path']).read_text())
gate=m.require_terminal_numerical_v1(values['numerical_evidence'],values['numerical_admission'],values['inspection_evidence'],values['inspection_freeze'],terminal,refs)
check('actual_complete_terminal_gate_function_passes',gate['job_id']==terminal['job_id'])
bad=copy.deepcopy(terminal);bad['returncode']=1
reject('actual_terminal_nonzero_rejected',lambda:m.require_terminal_numerical_v1(values['numerical_evidence'],values['numerical_admission'],values['inspection_evidence'],values['inspection_freeze'],bad,refs))
bad=copy.deepcopy(values['numerical_evidence']);bad['cells'].pop()
reject('actual_incomplete32_cell_gate_rejected',lambda:m.require_terminal_numerical_v1(bad,values['numerical_admission'],values['inspection_evidence'],values['inspection_freeze'],terminal,refs))
details['actual_numerical_metadata']={'summary':ref(ROOT/'experiments/results/census_native_actual32_numerical_v1_summary/summary.json'),'terminal':ref(ROOT/'experiments/results/census_native_actual32_numerical_v1_summary/terminal_binding_v2.json'),'refs':refs,'complete_gate_passed':True,'targets_opened':False}

# Exact source conditions, evaluated on scalar metrics, not training/model state.
tree=ast.parse((ROOT/'src/arggnn/census_biological_fit_v1.py').read_text())
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_fit_v1')
selection=next(n for n in ast.walk(run) if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and ast.unparse(n.test)=="nll < state['best']")
guard=next(n for n in ast.walk(run) if isinstance(n,ast.If) and "state['best_epoch'] is None" in ast.unparse(n.test))
condition=compile(ast.Expression(copy.deepcopy(selection.test)),'<exact_frozen_checkpoint_test>','eval')
completion=compile(ast.Expression(copy.deepcopy(guard.test)),'<exact_frozen_completion_test>','eval')
def select(sequence):
 state={'best':float('inf'),'best_epoch':None,'steps':480}
 for epoch,nll in enumerate(sequence,1):
  if eval(condition,{},dict(nll=nll,state=state)):
   state.update(best=nll,best_epoch=epoch)
 return state
check('finite_NLL_earliest_ties_preserved',select([2.,2.,3.])['best_epoch']==1)
check('initial_infinity_then_finite_selects_first_finite',select([float('inf'),2.,2.])['best_epoch']==2)
s=select([float('inf')]*30)
check('counterexample_all_infinite_no_checkpoint',s['best_epoch'] is None)
check('counterexample_all_infinite_fixed_budget_rejected',eval(completion,{},dict(state=s,cfg=c)) is True)
check('configured_minimum_earliest_tie_has_no_declared_abort',c['training']['selection']=='minimum_equal_parent_development_VAL_present64_exact_span_raw_probability_NLL_earliest_tie' and not any('abort' in k or 'finite' in k for k in c['training']))
issues.append({'id':'ALL_INFINITE_NLL_EARLIEST_CHECKPOINT_NOT_SELECTED','priority':2,'source':'src/arggnn/census_biological_fit_v1.py','lines':[417,423],'expected_selected_epoch':1,'actual_selected_epoch':None,'fixed_optimizer_steps':480,'actual_biological_occurrence_observed':False,'conditional_counterexample':True,'observation':'Compiled exact source selection condition never accepts infinity versus initial infinity.30 all-infinite valid raw-NLL epochs retain no checkpoint and exact terminal guard rejects the fixed-budget control. The config promises minimum raw NLL and earliest ties, without a registered all-infinite abort.'})
details['checkpoint_counterexample']={'selection_test':ast.unparse(selection.test),'completion_test':ast.unparse(guard.test),'all_infinite_epochs':30,'all_infinite_state':{'best':'infinity','best_epoch':None,'steps':480},'expected_earliest_epoch':1,'actual_occurrence_unknown':True}
train=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='train_step_v1')
forward=next(n for n in ast.walk(train) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='forward_certified_census_biological_v1')
check('TRAIN_targets_absent_from_forward_arguments','mass' not in ast.unparse(forward) and 'target' not in ast.unparse(forward))
check('VAL_targets_read_only_after_all_model_seals',next(n.lineno for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='score_sealed_v1')>max(n.lineno for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='save' and '.npz' in ast.unparse(n)))
matched=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='matched_states_v1')
check('controls_use_deepcopy_of_same_initial_weights','model = deepcopy(initial)' in ast.unparse(matched))

# Handmade interval targets held in memory. No actual target file or fit is read/run.
class Reader:
 def __init__(self):self.payload={};self.calls=[]
 def read(self,r):
  self.calls.append(r['path']);return self.payload[r['path']]
reader=Reader()
cohorts=['present_day']*64+['Bronze_Age']*16+['BAA']*8+['Neo']*16+['Yam']*16
source=[];roster=[]
for i in range(280):
 role='pure_source_reference' if i<96 else 'mixed_reference_only' if i<160 else 'query'
 source.append({'role':role,'observed_node_id':1000+7*i,'observed_cohort':cohorts[i-160] if i>=160 else 'reference','sample_id':'sample_'+str(i//2)})
 roster.append(types.SimpleNamespace(role=role,actual_id=9000+i))
reader.payload['handmade_source.json']=json.dumps(source).encode()
binding={'query_sample_indexes':list(range(160,280)),'query_raw_node_ids':[1000+7*i for i in range(160,280)]}
loaded=(None,roster,np.arange(50.,2000000.,100.),25.,[25.,125.],{'source':{'path':'handmade_source.json'}},None)
p=m.scoring_parent_v1({'parent_id':'handmade_train','split':'train'},None,loaded,reader,binding)
check('clipped_original_center_support',p['positions'].tolist()==[50.] and p['edges'].tolist()==[25.,100.] and p['retained_indexes'].tolist()==[0])
check('query_identity_and_cohort_counts_preserved',p['raw_query_nodes'].tolist()==binding['query_raw_node_ids'] and len(m.strata_v1(p)['primary_present_day_64'])==64 and len(m.strata_v1(p)['secondary_ancient_56'])==56)
buf=io.BytesIO()
np.savez(buf,intervals_bp=np.array([[0.,50.],[50.,2000000.]],dtype=np.float64),query_raw_node_ids=p['raw_query_nodes'],source_classes_0based=np.vstack([np.zeros(120,dtype=np.int64),np.ones(120,dtype=np.int64)]),native_paths_1based=np.array([{'must_not_decode':True}],dtype=object))
reader.payload['handmade_target.npz']=buf.getvalue();reader.payload['handmade_seal.npz']=b'handmade sealed-record marker'
b={'truth_npz':{'path':'handmade_target.npz'}}
before=list(reader.calls)
val=dict(p,split='val')
reject('TRAIN_purpose_rejects_VAL_before_target_read',lambda:m.ExternalTargetV1(val,b,'TRAIN_loss',reader))
check('wrong_target_purpose_does_not_read_bytes',reader.calls==before)
reject('VAL_targets_require_sealed_record',lambda:m.ExternalTargetV1(val,b,'VAL_after_sealed_prediction',reader))
check('unsealed_VAL_target_bytes_not_read',reader.calls==before)
target=m.ExternalTargetV1(p,b,'TRAIN_loss',reader)
helpers=m.metric_helpers_v1();mass=target.target_mass(p,helpers)
check('six_path_object_payload_never_decoded',mass.shape==(1,120,4))
check('exact_class_span_mass_25_50_no_center_label_approximation',np.array_equal(mass[0,0],[25.,50.,0.,0.]) and np.array_equal(mass.sum(-1),np.full((1,120),75.)))
before=len(reader.calls)
m.ExternalTargetV1(val,b,'VAL_after_sealed_prediction',reader,{'path':'handmade_seal.npz'})
check('seal_read_precedes_VAL_target',reader.calls[before:]==['handmade_seal.npz','handmade_target.npz'])
p4=np.zeros((1,120,4),dtype=np.float32);p4[:,:,0]=1
metric=helpers.full_span_score(p4,p,target,np.arange(64),c['metrics'])
check('raw_zero_probability_positive_mass_is_infinite',metric['nll'] is None and metric['infinite_nll_query_bp']>0 and m._nll_v1(metric)==float('inf') and metric['probability_floor_used'] is False)
p4[:]=.25
metric=helpers.full_span_score(p4,p,target,np.arange(64),c['metrics'])
check('exact_span_denominator_and_uniform_NLL',metric['denominator_query_bp']==75.*64 and np.isclose(metric['nll'],np.log(4)))
details['handmade_targets_and_scoring']={'all_arrays_handmade':True,'actual_target_bytes_read':False,'support':[25.,100.],'exact_mass_per_query':[25.,50.,0.,0.],'six_path_payload_not_decoded':True,'raw_infinity_preserved':True}
for path,h in pins.items():check('final_source_config_pin_'+path,sha(ROOT/path)==h)
check('final_historic_AGENTS_pin',sha(ROOT/'AGENTS.md')==c['source_sha256']['AGENTS.md'])
report={'schema':'census_biological_fit_independent_checks_v1','status':'completed_one_conditional_protocol_mismatch','check_count':len(checks),'checks':checks,'issues':issues,'details':details,'actual_targets_opened':False,'actual_fit_or_model_optimizer_executed':False,'model_instantiated':False,'GPU_context_or_live_resource_access':False,'runtime_capture_or_install_or_Git':False,'actual_numerical_metadata_only_read':True,'AGENTS_transient_drift_observed':False,'root_reported_AGENTS_restoration':True}
(OUT/'handmade_checks.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':report['status'],'check_count':len(checks),'issues':issues},indent=2))
