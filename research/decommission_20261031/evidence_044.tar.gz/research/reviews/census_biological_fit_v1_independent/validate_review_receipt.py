import datetime,hashlib,json,os,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace-SR003.nfs2/ARG-GNN');D=ROOT/'research/reviews/census_biological_fit_v1_independent'
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'src'));os.environ['CUDA_VISIBLE_DEVICES']=''
from arggnn import census_biological_fit_v1 as m
def ref(p):return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
r=json.loads((D/'review_receipt.json').read_text());h=json.loads((D/'handmade_checks.json').read_text());checks=[]
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
check('final_independent_REJECT',r['verdict']=='REJECT' and not r['status'].startswith('qualified') and r['actual_admission'] is False)
for record in r['files']:check('exact_evidence_'+record['path'],ref(ROOT/record['path'])==record)
for k in ('implementation','config','author_receipt'):check('exact_pin_'+k,ref(ROOT/r[k]['path'])==r[k])
check('86_source_handmade_checks',h['check_count']==86 and len(h['issues'])==1)
check('conditional_not_observed_biological_failure',h['issues'][0]['conditional_counterexample'] is True and h['issues'][0]['actual_biological_occurrence_observed'] is False)
cfg=m.load_config_v1();now=datetime.datetime.now(datetime.timezone.utc)
refs={k:{'path':'fixture/'+k+'.json','sha256':'0'*64} for k in m.REFS}
sources=dict(cfg['source_sha256']);sources['src/arggnn/census_biological_fit_v1.py']=r['implementation']['sha256']
a={'schema':'census_biological_fit_admission_v1','status':'active','fit_authorized':True,'job_id':'fixture_only','created_at_utc':(now-datetime.timedelta(minutes=1)).isoformat(),'expires_at_utc':(now+datetime.timedelta(minutes=5)).isoformat(),'refs':refs,'source_sha256':sources,'seed':101,'device':'cpu','output_directory':'fixture_only','expected_certificates':{},'observed_artifact_sha256':{},'group_permutation':[]}
calls=[]
class Reader:
 def decode_json(self,record):
  calls.append(record['path'])
  if record['path']=='fixture/admission.json':return a
  if record==refs['config']:return cfg
  if record==refs['review']:return r
  raise AssertionError('REJECT reached subsequent data/runtime/profile gate')
 def read(self,record):return b'fixture source binding only'
with patch.object(m,'VerifiedReaderV1',Reader):
 try:m.admit_fit_v1({'path':'fixture/admission.json','sha256':'0'*64})
 except ValueError as e:check('consumer_REJECT_before_numerical_profile_or_targets',str(e)=='Fresh independent exact fit source/config review required')
 else:raise AssertionError('REJECT must deny fitting')
result={'schema':'census_biological_fit_independent_review_validator_v1','status':'passed','check_count':len(checks),'checks':checks,'review_receipt':ref(D/'review_receipt.json'),'consumer_REJECT_denied':True,'actual_fit_or_targets_or_GPU_or_live_resources':False}
with (D/'validator_receipt.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2)
print(json.dumps({'status':'passed','check_count':len(checks),'review_receipt':result['review_receipt']},indent=2))
