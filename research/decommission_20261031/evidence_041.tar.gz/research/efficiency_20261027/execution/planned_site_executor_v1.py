"""Opt-in immutable site-index successor; inherited numerical trunk unchanged."""
import math
import torch
from research.scalability_20261024.categorical_site.categorical_site import categorical_site_chunk
from research.efficiency_20261027.execution.explicit_vjp import ExplicitVJPExecution
from research.efficiency_20261027.execution.large_block_executors import LargeExplicitVJPExecution
from .site_index_plan_v1 import SiteIndexPlan, provenance, need


class PlannedSites:
    def __init__(self,model,bundle,metadata,*,site_index_plan,**kwargs):
        need(isinstance(site_index_plan,SiteIndexPlan)
             and site_index_plan.block_holds==kwargs.get('holds_per_block',128),
             'Explicit site plan must match selected immutable block partition')
        super().__init__(model,bundle,metadata,**kwargs)
        self.site_plan=site_index_plan.bind(bundle.bank,provenance=provenance(bundle))

    def _sites(self,a,b):
        """Original global256 chunks, selection, pooling order and projection."""
        bank,m = self.bank,self.model
        h,d = 1600,32
        selections = self.site_plan.selections(bank,a,b)
        hs,ss,mm,cc = [],[],[],[]
        for selection in selections:
            chunk = self.site_plan.plan.chunks[selection.chunk]
            start,end = chunk.start,chunk.end
            args = tuple(x[start:end].to(self.device) for x in (
                bank.genotype,bank.log_donor_allele_frequency,
                bank.donor_call_mask,bank.panel_allele_frequency,bank.site_entropy))
            sums,maxima,count = categorical_site_chunk(
                m,*args,torch.tensor(chunk.inverse,dtype=torch.long,device=self.device),len(chunk.holds))
            ix = torch.tensor(selection.selected,dtype=torch.long,device=self.device)
            hs.append(torch.tensor(selection.local_holds,dtype=torch.long,device=self.device))
            ss.append(sums.index_select(0,ix))
            mm.append(maxima.index_select(0,ix))
            cc.append(count.index_select(0,ix))
        sums = bank.spans.new_zeros((b-a,h,d),device=self.device)
        maxima = bank.spans.new_full((b-a,h,d),-torch.inf,device=self.device)
        counts = bank.spans.new_zeros((b-a,h,1),device=self.device)
        if hs:
            index = torch.cat(hs)
            sums = sums.index_add(0,index,torch.cat(ss))
            counts = counts.index_add(0,index,torch.cat(cc))
            chunk_max,chunk_count = torch.cat(mm),torch.cat(cc)
            chunk_max = torch.where(chunk_count>0,chunk_max,
                                    torch.full_like(chunk_max,-torch.inf))
            maxima = maxima.scatter_reduce(0,
                index[:,None,None].expand_as(chunk_max),chunk_max,
                reduce="amax",include_self=True)
        present = counts>0
        means = sums/counts.clamp_min(1)
        maxima = torch.where(present,maxima,torch.zeros_like(maxima))
        logcount = counts.log1p()/math.log(100001.)
        empty = (~present).to(sums.dtype)
        span = (bank.spans[a:b].to(self.device).log1p()/math.log(2000001.))[:,None,None].expand(b-a,h,1)
        return m.site_pool_projection(torch.cat(
            (means,maxima,logcount,empty,span),-1))


class PlannedExplicitVJPExecution(PlannedSites, ExplicitVJPExecution):
    pass


class PlannedLargeExplicitVJPExecution(PlannedSites, LargeExplicitVJPExecution):
    pass


def build_executor(model,bundle,metadata,*,site_index_plan,holds_per_block,**kwargs):
    need(holds_per_block in (128,512,1024),'Explicit separately qualified partition required')
    cls=PlannedExplicitVJPExecution if holds_per_block==128 else PlannedLargeExplicitVJPExecution
    return cls(model,bundle,metadata,site_index_plan=site_index_plan,holds_per_block=holds_per_block,**kwargs)
