"""Finite immutable CPU plans for unchanged global 256-site chunk selection.

Only integer coordinates are retained. All observed features and learned MLP,
pooling and projection values remain freshly evaluated. No transfer scheduler,
production integration or model/optimizer mutation is provided.
"""
from dataclasses import dataclass
import hashlib
import json
import math
import weakref
import numpy as np
import torch
from research.scalability_20261024.integration.cache import _charge


def need(ok,message):
    if not ok:raise ValueError(message)


def provenance(bundle):
    return json.dumps(dict(parent_id=bundle.parent_id,
        observation_ref=bundle.observation_ref,focal_registry_ref=bundle.focal_registry_ref,
        native_preparation_ref=bundle.native_preparation_ref),sort_keys=True,separators=(',',':'))


def stamp(tensor):
    return (id(tensor),tensor.data_ptr(),tensor._version,tuple(tensor.shape),str(tensor.dtype))


def digest(tensor):
    return hashlib.sha256(memoryview(tensor.numpy()).cast('B')).hexdigest()


def readonly(value):
    result=np.asarray(value,dtype=np.int64).copy()
    result.flags.writeable=False
    return result


@dataclass(frozen=True)
class SiteChunk:
    start:int
    end:int
    holds:np.ndarray
    inverse:np.ndarray


@dataclass(frozen=True)
class SiteSelection:
    chunk:int
    selected:np.ndarray
    local_holds:np.ndarray


@dataclass(frozen=True)
class SiteIndexPlan:
    native_holds:int
    block_holds:int
    sites:int
    provenance:str
    site_hold_sha256:str
    chunks:tuple
    blocks:tuple
    charged_bytes:int

    @classmethod
    def build(cls,site_hold,*,native_holds,holds_per_block,provenance,max_bytes,admit):
        need(site_hold.device.type=='cpu' and site_hold.dtype==torch.long and site_hold.ndim==1
             and site_hold.is_contiguous(),'Original contiguous CPU int64 site-hold vector required')
        need(type(native_holds) is int and native_holds>0 and type(holds_per_block) is int
             and 1<=holds_per_block<=1024 and type(max_bytes) is int and max_bytes>0
             and callable(admit) and type(provenance) is str and bool(provenance),
             'Explicit finite plan budget, partition, provenance and memory admission required')
        values=site_hold.numpy()
        need(len(values)==0 or (values[0]>=0 and values[-1]<native_holds
             and bool(np.all(values[1:]>=values[:-1]))),'Sorted bounded original site holds required')
        chunk_count=math.ceil(len(values)/256)
        block_count=math.ceil(native_holds/holds_per_block)
        reserve=32*len(values)+2048*(chunk_count+block_count)+65536
        need(reserve<=max_bytes,'Conservative immutable site plan reserve exceeds declared budget')
        admit(reserve,'site_index_plan_build')
        chunks=[]
        for start in range(0,len(values),256):
            end=min(start+256,len(values))
            holds,inverse=torch.unique_consecutive(site_hold[start:end],return_inverse=True)
            chunks.append(SiteChunk(start,end,readonly(holds.numpy()),readonly(inverse.numpy())))
        blocks=[]
        for a in range(0,native_holds,holds_per_block):
            b=min(a+holds_per_block,native_holds)
            left,right=map(int,np.searchsorted(values,[a,b]))
            selections=[]
            for start in range((left//256)*256,right,256):
                chunk=start//256
                holds=chunks[chunk].holds
                selected=np.flatnonzero((holds>=a)&(holds<b))
                if len(selected):
                    selections.append(SiteSelection(chunk,readonly(selected),readonly(holds[selected]-a)))
            blocks.append(tuple(selections))
        payload=(native_holds,holds_per_block,len(values),provenance,digest(site_hold),tuple(chunks),tuple(blocks))
        charge=_charge(payload)+1024
        need(charge<=reserve<=max_bytes,'Actual immutable plan charge must fit prior working admission')
        return cls(*payload,charge)

    def bind(self,bank,*,provenance):
        need(provenance==self.provenance and bank.site_hold.device.type=='cpu'
             and bank.site_hold.dtype==torch.long and bank.site_hold.is_contiguous()
             and tuple(bank.site_hold.shape)==(self.sites,)
             and bank.sample_index.shape[0]==self.native_holds,
             'Exact immutable plan parent, shape and source provenance required')
        need(digest(bank.site_hold)==self.site_hold_sha256,'Restored site coordinates must match exact plan content')
        return BoundSiteIndexPlan(self,weakref.ref(bank),stamp(bank.site_hold))


@dataclass(frozen=True)
class BoundSiteIndexPlan:
    plan:SiteIndexPlan
    bank_ref:object
    site_stamp:tuple

    def selections(self,bank,a,b):
        need(self.bank_ref() is bank and stamp(bank.site_hold)==self.site_stamp,
             'Bound site coordinates were replaced or mutated')
        need(0<=a<self.plan.native_holds and a%self.plan.block_holds==0 and b==min(a+self.plan.block_holds,self.plan.native_holds),
             'Exact original block boundaries required')
        return self.plan.blocks[a//self.plan.block_holds]
