printf error\n >&2
exit 7
