(sleep 0.3; printf late_stdout\n; printf late_stderr\n >&2) &
printf leader_done\n
exit 0
