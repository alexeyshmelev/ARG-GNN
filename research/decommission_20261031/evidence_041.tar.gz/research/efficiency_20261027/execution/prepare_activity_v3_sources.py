"""Create readable direct-API successor sources, preserving all earlier versions."""
from pathlib import Path

BASE = Path('research/efficiency_20261027/execution')
old = (BASE/'native_activity_ledger_v2.py').read_text()
header = '''"""Bounded direct Kineto CUDA ledger; explicit user annotations are excluded.

The actual tiny CUDA probe verified these API annotation flags against native
categories. No Chrome exporter, FIFO, subprocess or raw disk trace is used.
"""
from collections import Counter, defaultdict
from decimal import Decimal
import json
from pathlib import Path
from .native_activity_ledger_v2 import ROOT, PHYSICAL, LIMIT, need, native_kind, interval_union


def api_events(profile):
    for event in profile.profiler.kineto_results.events():
        device = str(event.device_type())
        annotated = event.is_user_annotation()
        need(type(annotated) is bool, 'Explicit native API annotation flag required')
        name = event.name()
        if device == 'DeviceType.CUDA':
            if annotated:
                category = 'gpu_user_annotation'
            elif name.startswith('Memcpy '):
                category = 'gpu_memcpy'
            elif name.startswith('Memset '):
                category = 'gpu_memset'
            else:
                category = 'kernel'
                need(not name.startswith(('treeloom/', 'diagnostic_', 'probe_')),
                     'An annotation-like CUDA event must carry its native API flag')
        elif device == 'DeviceType.CPU' and annotated:
            category = 'user_annotation'
        else:
            category = 'excluded_API_non_CUDA'
        yield dict(cat=category, ph='X', name=name,
                   ts=Decimal(event.start_ns())/1000, dur=Decimal(event.duration_ns())/1000,
                   args=dict(device=event.device_index(), stream=event.device_resource_id(),
                             correlation=event.correlation_id(), bytes=0))


'''
body = old[old.index('def consume('):old.index('\ndef export_native(')]
body = body.replace('def consume(stream, ledger_path, summary_path):',
                    'def consume_API(profile, ledger_path, summary_path):')
body = body.replace('native_events(stream)', 'api_events(profile)')
body = body.replace('TreeLoom_native_physical_CUDA_ledger_v2', 'TreeLoom_direct_API_physical_CUDA_ledger_v3')
body = body.replace('TreeLoom_native_activity_summary_v2', 'TreeLoom_direct_API_activity_summary_v3')
body = body.replace("classification='explicit_native_category_allowlist'",
                    "classification='CUDA_API_events_excluding_is_user_annotation_true'")
body = body.replace("'GPU user annotations and every non-allowlisted native category are excluded from physical unions.'",
                    "'Native API is_user_annotation=True events are excluded before classifying CUDA physical activity.',\n            'Copy direction uses native API names; the API exposes no byte metadata, so copy bytes are unavailable.'")
footer = '''
def export_API(profile, prefix):
    prefix = Path(prefix).resolve()
    need(prefix.is_relative_to(ROOT/'research/efficiency_20261027'), 'Contained diagnostic output')
    ledger = prefix.with_name(prefix.name+'_physical_ledger.json')
    summary = prefix.with_name(prefix.name+'_activity_summary.json')
    result = consume_API(profile, ledger, summary)
    result['export'] = dict(native_disk_trace_written=False, subprocesses=0,
                            ledger_path=str(ledger), summary_path=str(summary))
    return result
'''
with (BASE/'direct_activity_ledger_v3.py').open('x') as handle:
    handle.write(header+body+footer)

runner = (BASE/'profile_boundary_activity_v2.py').read_text()
runner = runner.replace('Exactly one profiler-only learned call per qualified executor; no Adam step.',
                        'Exactly one missing fused profiler-only learned call; no baseline rerun or Adam step.')
runner = runner.replace('Corrected attribution uses explicit native activity categories.',
                        'Corrected attribution excludes native API user annotations explicitly.')
runner = runner.replace('from .native_activity_ledger_v2 import export_native',
                        'from .direct_activity_ledger_v3 import export_API')
runner = runner.replace('source_pins_boundary_activity_v2.json', 'source_pins_boundary_activity_v3.json')
runner = runner.replace('analysis=export_native(capture,output/kind)', 'analysis=export_API(capture,output/kind)')
runner = runner.replace('for kind in KINDS:', 'for kind in KINDS[1:]:')
runner = runner.replace('calls=list(KINDS)', 'calls=list(KINDS[1:])')
runner = runner.replace('TreeLoom_boundary_activity_profiler_only_v2', 'TreeLoom_boundary_activity_fused_only_v3')
runner = runner.replace('Exactly one profiled call per executor;', 'Exactly one fused profiled call; baseline is recovered from preserved v2 trace;')
runner = runner.replace('uses native categories and excludes GPU annotations', 'uses native API annotation flags and excludes GPU annotations')
# The successful tiny probe is evidence; the failed v2 worker is a separate mandatory cleanup predecessor.
runner = runner.replace("parser.add_argument('--category-probe-sha256',required=True)",
    "parser.add_argument('--category-probe-sha256',required=True)\n    parser.add_argument('--category-probe-directory',required=True)")
runner = runner.replace("ROOT/args.gpu_predecessor_directory/'data/completed.json'",
                        "ROOT/args.category_probe_directory/'data/completed.json'")
marker = "    output=Path(args.output).resolve()"
recovery = """    recovered=BASE/'recovered_boundary_baseline_v2/RECOVERY.json'
    recovered_data=json.loads(recovered.read_text())
    need(recovered_data['status']=='passed' and recovered_data['complete_native_JSON_validated']
         and recovered_data['learned_calls_executed']==0, 'Complete recovered baseline is mandatory; never rerun it')
"""
runner = runner.replace(marker, recovery+marker)
runner = runner.replace('records=rows,gpu_predecessor_gate=gate',
                        'records=rows,recovered_baseline_ref=ref(recovered),gpu_predecessor_gate=gate')
with (BASE/'profile_boundary_activity_v3.py').open('x') as handle:
    handle.write(runner)

launcher = (BASE/'launch_boundary_activity_v2.py').read_text()
launcher = launcher.replace('profile_boundary_activity_v2', 'profile_boundary_activity_v3')
launcher = launcher.replace('"--category-probe-sha256", args.category_probe_sha256]',
                            '"--category-probe-sha256", args.category_probe_sha256,\n        "--category-probe-directory", args.category_probe_directory]')
launcher = launcher.replace('parser.add_argument("--category-probe-sha256", required=True)',
                            'parser.add_argument("--category-probe-sha256", required=True)\n    parser.add_argument("--category-probe-directory", required=True)')
with (BASE/'launch_boundary_activity_v3.py').open('x') as handle:
    handle.write(launcher)
