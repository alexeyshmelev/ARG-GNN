"""Create separate readable training wiring; never edit the production trainer."""
from pathlib import Path
base=Path('research/efficiency_20261027')
source=base/'integration_candidate/training_v3.py'
s=source.read_text()
s=s.replace('from .memory_v1 import (LayoutAwareParents as PipelinedCompactParents,\n    LayoutMemoryGovernor, GovernedLayoutCache, GovernedLargeLayoutCache, LAYOUT_CACHE_BYTES)',
'''from .memory_v1 import (GovernedLayoutCache, GovernedLargeLayoutCache, LAYOUT_CACHE_BYTES)
from research.efficiency_20261027.execution.adaptive_prefetch_v1 import (
    AdaptiveCompactParents, AdaptiveMemoryGovernor as LayoutMemoryGovernor, EncoderCredits)
from research.efficiency_20261027.execution.adaptive_encoder_hooks_v1 import install_tree
from types import MappingProxyType''')
s=s.replace('source_pins_v3.json','source_pins_adaptive_v1.json')
s=s.replace('explicit_VJP_CPU8_selected_block_dynamic_layout_prefetch_v1',
            'explicit_VJP_CPU8_selected_block_dynamic_layout_adaptive_prefetch_v1')
s=s.replace('CPU_prefetch_workers=1,lookahead_parents=1',
            'CPU_prefetch_workers=2,lookahead_parents=2,maximum_encoder_children=8')
s=s.replace('    check_lock = threading.RLock()', '    check_lock = threading.RLock()\n    pool_guard = [None]')
s=s.replace("        # The outer runtime's resource writer is process-local, not thread-safe.",
'''        # Failure checks do not inspect/wait on futures under any callback lock.
        if pool_guard[0] is not None:
            pool_guard[0].raise_if_failed()
        # The outer runtime's resource writer is process-local, not thread-safe.''')
needle='    selected = spec["execution_configuration"]\n    cache_class'
s=s.replace(needle,'''    child_credits = EncoderCredits(maximum_bytes=spec["memory_envelope"]["max_rss_bytes"])
    # This candidate requires a fresh worker without the old hook installer.
    # Install every process-global hook exactly once, before producer creation.
    preprocessing_bindings = install_tree(child_credits)
    selected = spec["execution_configuration"]
    cache_class''')
start=s.index('        if parent not in plans:')
end=s.index('        _need(bundle.native_holds==plans[parent]', start)
s=s[:start]+'''        _need(parent in plans and parent in seals,
              "Every original plan and seal is frozen before producers; no fallback writes")
'''+s[end:]
needle='    for parent,item in spec["train_inputs"].items():'
s=s.replace(needle,'''    _need(set(plans)==set(seals)==set(registry.ids("train")), "All20 authenticated frozen plans/seals")
    plans = MappingProxyType({parent:MappingProxyType(plan) for parent,plan in plans.items()})
    seals = MappingProxyType({parent:MappingProxyType(seal) for parent,seal in seals.items()})
'''+needle)
start=s.index('    pool = PipelinedCompactParents(')
end=s.index('    cursor = [initial_steps]',start)
s=s[:start]+'''    schedule = [(epoch,parent) for epoch in range(1,31) for parent in registry.epoch_order(epoch)]
    pool = AdaptiveCompactParents(schedule=[parent for _,parent in schedule],start_cursor=initial_steps,
        parent_bounds=parent_bounds,input_refs=inputs,external_arrays=external,
        max_cache_bytes=spec["observation_cache_bytes"],governor=layout_governor,credits=child_credits,
        resource_check=resource_check,event=event,prepare=prepare_parent)
    pool_guard[0] = pool
'''+s[end:]
s=s.replace('            cursor[0]=steps\n            return ref',
'''            pool.durable_checkpoint(parent=schedule[steps-1][1],completed_updates=steps)
            cursor[0]=steps
            return ref''')
s=s.replace('            pool.prefetch_next([later for _,later in schedule[cursor[0]+1:]])\n', '')
s=s.replace('                  compact_pool_receipt=pool_receipt,observation_disk_cache=False,',
'''                  compact_pool_receipt=pool_receipt,observation_disk_cache=False,
                  preprocessing_bindings=preprocessing_bindings,
                  adaptive_two_parent_production_qualification_required=True,''')
with (base/'integration_candidate/training_adaptive_v1.py').open('x') as handle:handle.write(s)
# Reuse the bounded CPU fixture construction as readable standalone source.
f=Path('research/repairs/TreeLoom_lazy_compact_prefetch_20261024_v1/cpu_smoke.py').read_text()
f=f[f.index('def fixture('):f.index('\ndef state_equal(')]
f=f.replace('    return runtime.prepare_observation(state,split="train",resource_check=lambda stage:None,\n        **refs,max_nodes=100000,max_holds=4,max_episode_payload_bytes=16*2**20),refs', '    return state,refs')
with (base/'execution/adaptive_fixture_v1.py').open('x') as handle:
    handle.write('"""Original bounded two-hold CPU fixture; return independent inputs before preparation."""\nimport numpy as np\nimport tskit\nfrom arggnn.benchmarking import contracts as c\nfrom research.efficiency_20261027.integration_candidate import training_v3 as training\n\n'+f)
