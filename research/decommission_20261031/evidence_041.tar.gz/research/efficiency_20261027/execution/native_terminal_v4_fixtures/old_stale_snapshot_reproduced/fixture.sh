printf ready > ready
while [ ! -f release ]; do sleep 0.01; done
printf finished\n
