"""One bounded read-only sample of the currently identified attempt7 worker."""
import hashlib
import json
import os
from pathlib import Path
import time
import psutil

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')
STATE = ROOT/'.runtime/benchmarking/paper_campaign_resume_20261026_v1/state.json'
OUTPUT = ROOT/'research/efficiency_20261027/execution/MONITOR_COST_READONLY_v1.json'


def identity(pid):
    try:
        return (Path('/proc')/str(pid)/'stat').read_text().split(') ',1)[1].split()[19]
    except FileNotFoundError:
        return None


def measured(function):
    started=time.perf_counter()
    value=function()
    return value,time.perf_counter()-started


def main():
    state=json.loads(STATE.read_text())
    task=state['tasks']['paper_american_treeloom_fit']
    pid,ticks=task['pid'],task['process_start_ticks']
    if task['status']!='running' or task['attempt']!=7 or identity(pid)!=ticks:
        raise ValueError('Exact current attempt7 identity required')
    root=psutil.Process(pid)
    cheap,rss_seconds=measured(root.memory_info)
    full,pss_seconds=measured(root.memory_full_info)
    children,enumeration_seconds=measured(lambda:root.children(recursive=True))
    child_rows=[]
    for process in children:
        try:
            start_ticks=identity(process.pid)
            value,seconds=measured(process.memory_full_info)
            child_rows.append(dict(pid=process.pid,start_ticks=start_ticks,
                seconds=seconds,RSS_bytes=value.rss,PSS_or_RSS_bytes=getattr(value,'pss',value.rss)))
        except (psutil.NoSuchProcess,psutil.ZombieProcess):
            pass
    outer=ROOT/'experiments/results/paper_american_20261024/treeloom_fit'
    def scope():
        files=[p for p in outer.rglob('*') if p.is_file()]
        return dict(files=len(files),bytes=sum(p.stat().st_size for p in files))
    storage,storage_seconds=measured(scope)
    if identity(pid)!=ticks:
        raise ValueError('Worker identity changed during read-only sample')
    receipt=dict(schema='TreeLoom_readonly_resource_monitor_cost_v1',observed_unix=time.time(),
        pid=pid,start_ticks=ticks,attempt=7,process_RSS_bytes=cheap.rss,
        process_PSS_or_RSS_bytes=getattr(full,'pss',full.rss),
        cheap_RSS_seconds=rss_seconds,main_full_memory_info_seconds=pss_seconds,
        descendants_enumeration_seconds=enumeration_seconds,children=child_rows,
        scope_scan_seconds=storage_seconds,scope=storage,
        total_sampled_monitor_seconds=pss_seconds+enumeration_seconds+sum(r['seconds'] for r in child_rows)+storage_seconds,
        resource_check_source=dict(path='src/arggnn/benchmarking/paper_campaign/runtime.py',
            sha256=hashlib.sha256((ROOT/'src/arggnn/benchmarking/paper_campaign/runtime.py').read_bytes()).hexdigest()),
        sample_count=1,worker_instrumented=False,signals_sent=0,source_changed=False,
        limitations=['One external read-only sample, not worker callback latency or causal attribution.',
            'Concurrent workload and filesystem caching can change cost.',
            'Existing resource checks remain unchanged; successor emits in-worker callback timings.'])
    with OUTPUT.open('x') as stream:json.dump(receipt,stream,indent=2)
    print(json.dumps(receipt))


if __name__=='__main__':main()
