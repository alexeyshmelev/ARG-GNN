"""Independent tiny lifecycle/timing critique; no real resource scans or jobs."""
import hashlib
import io
import json
from pathlib import Path
import threading
import time
import unittest
from research.efficiency_20261027.root.async_resource_checks.check_v1 import AsyncResourceCheck
from research.efficiency_20261027.root.async_resource_checks import test_v1

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')

def ref(path):
    path=Path(path)
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def main():
    output=io.StringIO()
    results=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test_v1))
    assert results.wasSuccessful() and results.testsRun==11,output.getvalue()
    class Clock:
        value=0.
        def __call__(self):return self.value
    clock=Clock()
    class Slow:
        task={'max_seconds':1000.}
        started=0.
        next_check=0.
        def __call__(self,stage):clock.value+=130.
    slow=AsyncResourceCheck(Slow(),interval_seconds=30.,maximum_scan_age_seconds=120.,clock=clock)
    slow.start()
    slow('model_dispatch_after_130second_initial_scan')
    initial=slow.receipt()
    assert initial['maximum_scan_seconds']==130.
    slow.close()

    original=test_v1.Original()
    original.do_block=True
    blocked=AsyncResourceCheck(original,interval_seconds=.01,maximum_scan_age_seconds=.1)
    blocked.start()
    writer=None
    write_outcome=[]
    entered=threading.Event()
    def write():
        entered.set()
        try:blocked(5);write_outcome.append('accepted')
        except BaseException as error:write_outcome.append(type(error).__name__+': '+str(error))
    try:
        assert original.block.wait(1.)
        writer=threading.Thread(target=write)
        writer.start()
        assert entered.wait(1.)
        time.sleep(.2)
        writer_blocked_after_expired_lease=writer.is_alive() and not write_outcome
        assert writer_blocked_after_expired_lease
        original.release.set()
        writer.join(timeout=1.)
        assert not writer.is_alive() and write_outcome==['accepted'],write_outcome
    finally:
        original.release.set()
        if writer is not None:writer.join(timeout=1.)
        blocked.close()
    report=dict(schema='TreeLoom_async_resource_independent_review_v1',passed=False,
        source_refs=[ref(Path(test_v1.__file__).with_name('check_v1.py')),ref(Path(test_v1.__file__)),ref(Path(__file__))],
        existing_tiny_tests_independently_rerun=11,existing_tests_passed=True,
        additional_reproductions=2,
        observations=dict(initial_130second_scan_accepted_with120second_lease=True,
            writer_remained_blocked_after_100ms_lease_expired=True,
            writer_was_accepted_after_200ms_block_and_freshness_reset=True),
        findings=[dict(priority='required_before_integration',title='Completed slow scan renews lease without bounding scan duration',
            detail='The completion timestamp becomes last_success even when a scan itself exceeds maximum_scan_age_seconds. A130s initial scan is accepted with a120s lease; a long periodic scan can likewise erase a missed stale interval.',
            requested_fix='Record successful scan start and completion separately, bound scan duration, and latch timeout failures before refreshing the successful-scan lease. Initial/final scans must enforce the same finite contract.'),
            dict(priority='required_before_integration',title='Prospective write waits indefinitely for callback lock and can cross freshness deadline',
            detail='The writer checks state only before waiting on an unbounded callback lock. A blocked periodic scan allows its lease to expire; after the scan returns, last_success is reset and the waiting write is accepted.',
            requested_fix='Use bounded lock acquisition with repeated cheap wall/failure/freshness checks, and revalidate after acquiring the lock before running or accepting the prospective-write scan. Do not silently renew a lease already missed while waiting.')],
        source_clarifications=[
            'Periodic scan cadence is30seconds after completion, so a27.3second scan yields about57.3seconds between starts; the receipt discloses this difference.',
            'Numeric caps and source algorithm remain unchanged, but this is still cooperative sampled protection; a stuck callback cannot be safely canceled as a Python thread, so ROOT outer guardian stays authoritative.',
            'Integration must give this wrapper exclusive ownership of the original callback; remaining aliases must not invoke its mutable next_check and status writer concurrently.',
            'Caller must close the wrapper before reporting completion and must propagate close failure; no live installation has been reviewed.'],
        real_processes_started=0,real_processes_signaled=0,scientific_payloads_opened=False,model_or_GPU_calls=0,production_modified=False)
    destination=ROOT/'research/efficiency_20261027/execution/ASYNC_RESOURCE_V1_SOURCE_REVIEW.json'
    with destination.open('x') as stream:json.dump(report,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(dict(review=ref(destination),passed=False,original_tests=11,reproductions=2)))

if __name__=='__main__':main()
