"""CPU semantics of larger-prefix focal selection, scheduling and failure receipts."""
import os
os.environ["CUDA_VISIBLE_DEVICES"]=""
import ast
import importlib
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import torch
from research.efficiency_20261027.execution.compare_large_blocks import (
    KINDS,BLOCK_SIZES,schedule,source_names,run_update,ref,write)
from research.efficiency_20261027.execution.prepare_large_slice import focal_prefix_selection
from research.efficiency_20261027.execution.test_explicit_resident_runner import FakeDevice
from research.efficiency_20261027.execution.large_block_executors import (
    LargeExplicitVJPExecution,LargeExplicitResidentVJPExecution)
from research.efficiency_20261027.execution.explicit_vjp import ExplicitVJPExecution
from research.efficiency_20261027.execution.explicit_resident_vjp import ExplicitResidentVJPExecution


def main():
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    root=Path("research/efficiency_20261027/execution")
    for name in ("compare_large_blocks.py","prepare_large_slice.py","large_block_executors.py",
                 "large_layout_cache.py","large_layout_plan.py"):
        ast.parse((root/name).read_text())
    output=root/"large_block_runner_CPU_test"
    output.mkdir(exist_ok=False)
    assert schedule(0)==[("qualification",0,KINDS)]
    timed=[order for phase,repeat,order in schedule(6) if phase=="timed"]
    assert len(set(timed))==6
    assert all(sum(order[position]==kind for order in timed)==2
        for position in range(3) for kind in KINDS)
    intervals=np.array([[0.,2.],[2.,4.],[4.,7.]])
    positions=np.array([0.,1.9,2.,2.,6.9,7.,8.])
    columns=np.array([3,2,1,1,0,0,1])
    selected,hold,column=focal_prefix_selection(positions,columns,intervals)
    assert selected.tolist()==[True,True,True,True,True,False,False]
    assert hold.tolist()==[0,0,1,1,2] and column.tolist()==[3,2,1,1,0]
    try:
        focal_prefix_selection(positions,columns,intervals+1)
    except ValueError:
        pass
    else:
        raise AssertionError("Nonzero site origin accepted")
    for cls,base in ((LargeExplicitVJPExecution,ExplicitVJPExecution),
                     (LargeExplicitResidentVJPExecution,ExplicitResidentVJPExecution)):
        for method in ("_sites","_first","_forcing","_second","_finite_own_episode","context_forward"):
            assert getattr(cls,method) is getattr(base,method),method
    for name in (
        "research.efficiency_20261027.execution.large_block_executors",
        "research.efficiency_20261027.execution.explicit_vjp",
        "research.benchmark_rebuild_20261024.american.treeloom_speed.decoder_v2",
        "research.repairs.TreeLoom_lazy_compact_prefetch_20261024_v1.training"):
        importlib.import_module(name)
    OOM=torch.cuda.OutOfMemoryError
    receipts=[]
    for kind in KINDS:
        fake=FakeDevice()
        def fail_model():
            raise OOM("Controlled CPU large-runner OOM")
        with patch.object(torch,"cuda",fake):
            try:
                run_update(kind,"injected_failure",0,SimpleNamespace(gpu_memory_gib=16),
                    SimpleNamespace(build_model=fail_model),{},SimpleNamespace(native_holds=1024),
                    {},None,None,None,lambda stage:None,output)
            except OOM:
                pass
            else:
                raise AssertionError("Injected OOM swallowed")
        path=output/("failed_update_"+kind+"_injected_failure_0.json")
        row=json.loads(path.read_text())
        assert row["CUDA_OOM"] and row["holds_per_block"]==BLOCK_SIZES[kind]
        assert not row["retry_attempted"] and row["stages"]["stage_wall_clock"]
        receipts.append(ref(path))
    assert not torch.cuda.is_initialized()
    result=dict(schema="TreeLoom_large_runner_CPU_semantics_v1",status="pass",
        CUDA_initialized=False,source_refs=[ref(name) for name in source_names()]+[ref(__file__)],
        each_arm_has_one_qualification_update=True,six_optional_balanced_orders=True,
        focal_boundary_and_duplicate_identity_preserved=True,nonzero_site_origin_rejected=True,
        exact_inherited_site_and_trunk_methods=True,
        OOM_failure_receipts=receipts,no_automatic_fallback=True,
        scope="CPU focal-selection/schedule/import/failure semantics; no new observations, targets, checkpoint or GPU loaded.")
    write(output/"completed.json",result)
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()

