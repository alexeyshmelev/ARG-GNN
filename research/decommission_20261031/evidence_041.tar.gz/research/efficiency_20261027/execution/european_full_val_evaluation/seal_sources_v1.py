"""Seal the full200Mb evaluator and read-only direct-four readiness inventory."""
from pathlib import Path
import ast
import datetime
import difflib
import json
from . import contracts_v1 as c


def save(name,value):
    path=c.HERE/name
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    return c.io._ref(path)


def main():
    previous=c.ROOT/'research/efficiency_20261027/execution/european_short_val_evaluation'
    inherited=[];dependencies={}
    for path,expected in [(previous/'source_pins_v1.json','4e64991b13ccb1b477551b4fe650ec8a70a8cb1c809bfc5cf642f80341a8ca9d'),
        (c.ROOT/'research/efficiency_20261027/execution/european_full_val_runner/source_pins_v2.json','83107bef8d534b30361339c08de2412d69e9181acb051e2871ebd87e0864e11d')]:
        reference=c.io._ref(path);assert reference['sha256']==expected
        value=c.io._read(reference);inherited.append(reference);dependencies[reference['path']]=reference
        for item in value['source_refs']:
            assert c.io._ref(item['path'])==item,item['path']
            assert item['path'] not in dependencies or dependencies[item['path']]==item
            dependencies[item['path']]=item
    original_review_ref=c.io._ref(c.ROOT/'research/efficiency_20261027/fidelity/EUROPEAN_SHORT_VAL_EVALUATION_V1_SOURCE_REVIEW.json')
    assert original_review_ref['sha256']=='95ca81a4de27bf1a0eb06acd2fb53e12995a5a8b8d2943c88c4b84d815bbc096'
    assert c.io._read(original_review_ref)['passed'] is True
    for p in c.HERE.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
    with (c.HERE/'FULL_VAL_EVALUATION_PLAINTEXT_v1.diff').open('x') as stream:
        for p in sorted(c.HERE.glob('*.py')):
            old=previous/p.name
            if old.exists():stream.writelines(difflib.unified_diff(old.read_text().splitlines(True),p.read_text().splitlines(True),
                fromfile=str(old.relative_to(c.ROOT)),tofile=str(p.relative_to(c.ROOT))))
    direct_plan_ref=c.io._ref('configs/benchmarks/paper_ancestralpaths_four_20261027.json')
    plan=c.io._read(direct_plan_ref)
    direct_sources=[c.io._ref(path) for path in sorted((c.ROOT/'src/arggnn/benchmarking/paper_ancestralpaths_four').glob('*.py'))]
    outputs=[dict(task=task['id'],output_directory=task['output_directory'],
        directory_exists=Path(task['output_directory']).exists(),fit_receipt_exists=(Path(task['output_directory'])/'fit.json').exists())
        for task in plan['tasks']]
    assert plan['plan_only'] is True and plan['admitted'] is False and all(not x['directory_exists'] for x in outputs)
    direct_ref=save('DIRECT_FOUR_CLASS_READINESS_v1.json',dict(schema='AncestralPaths_direct_four_class_readiness_v1',
        observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_plan_ref=direct_plan_ref,
        source_refs=direct_sources,condition=plan['condition'],source_implementation_present=True,
        declared_plan_admitted=False,declared_output_inventory=outputs,completed_fit_receipt_available_in_declared_plan=False,
        checkpoint_ready=False,full200Mb_validation_consumer_ready=False,
        required_model=dict(input_shape=[1,5,8],output_classes=['Ana','CHG','WHG','EHG'],parameters=16900,
            fresh_non_BAA_training_rows=40000,epochs=5,batch_size=30,optimizer_updates=6670,checkpoint_selection='final_epoch5'),
        feature_requirement='Reextract5x8 from original observed trees with BAA excluded before informative-shell selection and normalization. Dropping a cached six-class feature column is insufficient.',
        sampling_requirement='Use8000 non-BAA rows from the frozen10000 fullVAL examples; preserve original indices and all four cohort denominators.',
        current_consumer_scope='Existing plan and workflow target original3TRAIN/5TEST; predict() explicitly loads split=test. No independentVAL consumer is supplied by that package.',
        missing_before_fullVAL_prediction=['Actually completed fresh four-output fit and exact ROOT fixed-checkpoint acceptance.',
            'Separately reviewed independent fullVAL preparation/prediction interface using the existing four-path extractor.',
            'Declare direct-four predictions in an appropriate pre-truth comparison barrier before any dependent validation score.'],
        native6_five_method_evaluation_modified_to_include_direct_four=False,
        derived_C4_mapping_is_not_direct_four_output_model=True,
        no_fit_feature_prediction_scoring_or_TEST_payload_access_performed=True))
    cpu_refs=[c.io._ref(c.HERE/name) for name in ('CONTRACTS_CPU_v1.json','FULL_BINDING_CPU_v1.json')]
    for item in cpu_refs:assert c.io._read(item)['passed'] is True
    extras=[original_review_ref,c.definition_ref(),c.full.PLAN_REF,direct_ref,direct_plan_ref,*direct_sources,*cpu_refs,
        c.io._ref(c.HERE/'FULL_VAL_EVALUATION_PLAINTEXT_v1.diff')]
    extras.extend(c.io._ref(path) for path in sorted(c.HERE.glob('*.py')))
    extras.extend(c.io._ref(c.HERE/name) for name in ('CONTRACTS_CPU_attempt1.log','FULL_BINDING_CPU_attempt1.log'))
    for item in extras:
        assert c.io._ref(item['path'])==item;dependencies[item['path']]=item
    manifest_ref=save('source_pins_v1.json',dict(schema='European_full_VAL_evaluation_sources_v1',
        source_refs=[dependencies[path] for path in sorted(dependencies)],inherited_manifest_refs=inherited,
        original_review_ref=original_review_ref,definition_ref=c.definition_ref(),CPU_evidence_refs=cpu_refs,
        full200Mb_registered_plan_ref=c.full.PLAN_REF,registered_parent_id=c.full.frozen_parent()['parent_id'],
        fixed_observed_scope=str(c.full.SCOPE.relative_to(c.ROOT)),scientific_algorithms_changed=False,
        native_feature_and_truth_join_are_original_imports=True,
        TreeLoom_consumers='Existing original200Mb queue adapter and original200Mb cohort successor, with fixed TRAIN checkpoints.',
        checkpoint_rules_CNN_Dense_inference_prior_math_metrics_prediction_barrier_unchanged=True,
        previous_short_evaluator_sources_preserved=True,real_scientific_payloads_opened=False,
        model_forward_fit_prediction_scoring_executions=0,launch_authorization=False))
    contract=json.loads((previous/'ROOT_EVALUATION_CONTRACT_v1.json').read_text())
    contract['schema']='European_full_VAL_ROOT_evaluation_contract_v1';contract['source_manifest_ref']=manifest_ref
    contract['definition_ref']=c.definition_ref();contract['cpu_evidence_refs']=cpu_refs;contract.pop('cpu_evidence_ref')
    contract['module_prefix']='research.efficiency_20261027.execution.european_full_val_evaluation'
    contract['required_source_review_schema']='European_full_VAL_evaluation_source_review_v1'
    contract['registered_parent_id']=c.full.frozen_parent()['parent_id'];contract['sequence_length_bp']=200000000
    contract['frozen_scope']=str(c.full.SCOPE.relative_to(c.ROOT))
    contract['expected_input_paths']=dict(observed_artifacts=str((c.full.SCOPE/'observed_artifacts.json').relative_to(c.ROOT)),
        sampled_registry=str((c.full.SCOPE/'sampled_registry.json').relative_to(c.ROOT)),
        inference=str((c.full.SCOPE/'native/inference.json').relative_to(c.ROOT)),
        observed_vcf=str((c.full.SCOPE/'generation/observed/genotypes.vcf').relative_to(c.ROOT)),
        post_barrier_generation=str((c.full.SCOPE/'generation/generation.json').relative_to(c.ROOT)),
        post_barrier_target_schema=str((c.full.SCOPE/'generation/truth/target_schema.json').relative_to(c.ROOT)),
        post_barrier_truth=str((c.full.SCOPE/'generation/truth/full_truth_intervals.npz').relative_to(c.ROOT)))
    contract['checkpoint_acceptance_template']['schema']='European_full_VAL_checkpoint_acceptance_v1'
    contract['checkpoint_acceptance_template']['evaluation_source_manifest_ref']=manifest_ref
    contract['prerequisites'][0]='ROOT accepts actual full200Mb generation/native terminal evidence and genuinely reaped guardian/worker family, then seals exact observed-artifact and10000-row registry references.'
    contract['limits']='One independent200Mb diagnostic parent at frozen final checkpoints. No across-parent variance,independent-row uncertainty,checkpoint selection or architectural novelty claim follows automatically.'
    contract['stage_order']=[x.replace('shortVAL','full200MbVAL') for x in contract['stage_order']]
    contract['truth_join']='Direct original european_sampling.native_truth_labels import with unchanged200000000bp guard.'
    contract['direct_four_class_readiness_ref']=direct_ref
    contract['preprocessing_note']='Uses the existing full200Mb consumers. The separately qualified FIT-only preprocessing bridge is not implicitly installed or claimed here.'
    contract['work_performed']='Source preparation plus21 inherited barrier/checkpoint/math and8 full-scope/consumer CPU checks. No real checkpoint,TRAIN label,VAL truth,model forward,prediction or scientific scoring performed.'
    contract_ref=save('ROOT_EVALUATION_CONTRACT_v1.json',contract)
    print(json.dumps(dict(source_manifest_ref=manifest_ref,source_refs=len(dependencies),ROOT_contract_ref=contract_ref,
        direct_four_readiness_ref=direct_ref,CPU_evidence_refs=cpu_refs)))


if __name__=='__main__':main()
