"""Synthetic full-size registry and exact existing-consumer routing checks."""
import argparse
import ast
import copy
import json
from pathlib import Path
from unittest.mock import patch
import numpy as np
from . import contracts_v1 as c, predictions_v1 as predictions, features_v1 as features, evaluation_v1 as evaluation
from research.efficiency_20261027.architecture.european_cohort_candidate.validation_sampling import build_validation_registry


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--receipt',default=str(c.HERE/'FULL_BINDING_CPU_v1.json'))
    args=parser.parse_args();destination=Path(args.receipt);assert destination.is_relative_to(c.HERE)
    frozen=c.full.validate_plan();rows=[]
    for cohort,count in [('present_day',182),('Bronze_Age',162),('BAA',14),('Neo',302),('Yam',26),('WHG',102),('EHG',86),('Ana',50),('CHG',28)]:
        for _ in range(count):
            i=len(rows);rows.append(dict(sample_index=i,observed_node_id=i,sample_id='synthetic_'+str(i//2),
                haplotype=i%2,role='query' if cohort in c.COHORTS else 'pure_source_reference',observed_cohort=cohort))
    inferred=dict(sample_index_to_inferred_tree_node_id=[dict(sample_index=i,inferred_tree_node_id=i) for i in range(952)],
        coverage_original_bp0=[0,200000000],local_to_original_offset_bp=0,
        site_join=[dict(native_site_id=i,local_position_0based=1000+100000*i,original_position_0based=1000+100000*i) for i in range(1000)])
    registry_ref=dict(path=str((c.full.SCOPE/'sampled_registry.json').relative_to(c.ROOT)),sha256='0'*64)
    inference_ref=dict(path=str((c.full.SCOPE/'native/inference.json').relative_to(c.ROOT)),sha256='1'*64)
    registry=build_validation_registry(frozen['sampling_plan'],frozen['parent']['parent_id'],rows,inferred,observation_ref=inference_ref)
    checks=[]
    with patch.object(c.io,'_read',return_value=registry):
        actual,canonical=c.registry(registry_ref,inference_ref)
        assert actual is registry and len(canonical)==10000 and all(sum(r['cohort']==cohort for r in canonical)==2000 for cohort in c.COHORTS)
        checks.append('original_full_sampler_registry_accepts_all10000_rows_and_all_five_cohorts')
        for name,bad_ref,bad_infer in [('short_scope',dict(registry_ref,path='research/efficiency_20261027/root/runs/european_short_development_val_10mb_v2/sampled_registry.json'),inference_ref),
            ('other_inference_scope',registry_ref,dict(inference_ref,path='research/efficiency_20261027/root/runs/other/native/inference.json'))]:
            try:c.registry(bad_ref,bad_infer)
            except ValueError:checks.append(name+'_rejected')
            else:raise AssertionError(name)
        registry['sequence_length_bp']=10000000
        try:c.registry(registry_ref,inference_ref)
        except ValueError:checks.append('short_length_rejected')
        else:raise AssertionError('Short length accepted')
        registry['sequence_length_bp']=200000000
        registry['labels_present']=True
        try:c.registry(registry_ref,inference_ref)
        except ValueError:checks.append('label_contaminated_registry_rejected')
        else:raise AssertionError('Labels accepted')
        registry['labels_present']=False
    from research.repairs.benchmark_multigpu_20261022.scientific.queue_adapters import european_observations as original
    with patch.object(original,'_bound',return_value=c.full.SCOPE/'sampled_registry.json'),patch.object(original,'_json_ref',return_value=registry):
        records=original.sampled_records(registry_ref,protocol_id=c.TRAIN_PROTOCOL,
            observation_ref=inference_ref,parent_id=frozen['parent']['parent_id'],split='validation')
    assert np.array_equal(records['record_ids'],np.arange(10000)) and records['class_order'].tolist()==list(c.CLASSES)
    checks.append('unchanged_original200Mb_sampled_consumer_accepts_independent_validation_registry')
    import sys
    assert 'tensorflow' not in sys.modules
    source=(c.HERE/'predictions_v1.py').read_text();tree=ast.parse(source)
    imported={node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)}
    assert 'research.efficiency_20261027.architecture.european_cohort_candidate.execution' in imported
    assert 'research.repairs.benchmark_multigpu_20261022.scientific.queue_adapters.european_execution' in imported
    assert not any('short_development' in (name or '') for name in imported)
    checks.append('prediction_bindings_use_existing_full200Mb_original_and_cohort_consumers')
    from arggnn.benchmarking.european_execution import iter_native_sampled_features
    assert features.iter_native_sampled_features is iter_native_sampled_features
    assert evaluation.native_truth_labels is c.sampling.native_truth_labels
    checks.append('original_feature_and_truth_functions_reused_directly')
    report=dict(schema='European_full_VAL_binding_CPU_v1',passed=True,checks=checks,check_count=len(checks),
        source_refs=[c.io._ref(c.HERE/name) for name in ('full_plan_v1.py','contracts_v1.py','features_v1.py','predictions_v1.py','evaluation_v1.py','test_full_binding_v1.py')],
        definition_ref=c.definition_ref(),synthetic_registry_rows=10000,synthetic_haplotypes=952,
        real_checkpoint_TRAIN_labels_VAL_truth_opened=False,model_forward_fit_prediction_scoring_executions=0,
        GPU_calls=0,tensorflow_imported=False,torch_imported_for_existing_consumer_definitions_only=True)
    with destination.open('x') as stream:json.dump(report,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(dict(passed=True,checks=len(checks),receipt=c.io._ref(destination))))


if __name__=='__main__':main()
