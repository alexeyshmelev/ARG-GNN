"""Frozen original full200Mb registration and ROOT observed-output namespace."""
from research.efficiency_20261027.execution.european_full_val_runner.contracts_v1 import ROOT,PLAN_REF,validate_plan,need
LENGTH=200000000
SCOPE=ROOT/'research/efficiency_20261027/root/runs/european_independent_validation_200mb_v1'


def frozen_parent():return validate_plan()['parent']


def validate_recipe(recipe):
    need(recipe==validate_plan()['recipe'],'Exact original200Mb European recipe')
    return recipe
