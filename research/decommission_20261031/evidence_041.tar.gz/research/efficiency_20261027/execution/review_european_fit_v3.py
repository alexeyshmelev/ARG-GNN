"""Independent bounded source/CPU review of the European FIT preprocessing bridge."""
import ast
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
OUT=ROOT/'research/efficiency_20261027/execution'
WRAPPER='research/efficiency_20261027/execution/european_cohort_fit/fit_cli_pins_v3.json'
BRIDGE='research/efficiency_20261027/fidelity/european_fit_preprocessing_v1/source_pins_v1.json'

def ref(path):
    path=Path(path)
    if not path.is_absolute():path=ROOT/path
    assert path.is_relative_to(ROOT) and path.resolve()==path and path.stat().st_size<=8*2**20
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def read(path):return json.loads((ROOT/path).read_text())
def ast_same(left,right):return ast.dump(left,include_attributes=False)==ast.dump(right,include_attributes=False)
def function(path,name):return next(node for node in ast.parse((ROOT/path).read_text()).body if isinstance(node,ast.FunctionDef) and node.name==name)
def assignment(node,names):
    if not isinstance(node,ast.Assign):return False
    target=node.targets[0]
    actual=[target.id] if isinstance(target,ast.Name) else [part.id for part in target.elts] if isinstance(target,ast.Tuple) else []
    return actual==names

def main():
    assert ref(WRAPPER)['sha256']=='990eda6fcca1894a1dede1f9d547bc38c6c2bfa4484e0f58e30d4919eacb3f22'
    assert ref(BRIDGE)['sha256']=='f2bc8735f3de79f7926735db5456448ef82ccb3bf594b20a873071df2ec7461a'
    wrapper,bridge=read(WRAPPER),read(BRIDGE)
    refs=wrapper['source_refs'];assert len(refs)==323 and len({row['path'] for row in refs})==323
    for row in refs:
        assert Path(row['path']).suffix not in ('.pt','.npz','.npy','.trees'),row['path']
        assert ref(row['path'])==row,row['path']
    for row in bridge['source_refs']:assert row in refs
    inherited=read(wrapper['inherited_wrapper_manifest_ref']['path'])
    assert ref(wrapper['inherited_wrapper_manifest_ref']['path'])==wrapper['inherited_wrapper_manifest_ref']
    for row in inherited['source_refs']:assert row in refs
    old_path='research/repairs/benchmark_multigpu_20261022/scientific/queue_adapters/european_observations.py'
    new_path='research/efficiency_20261027/fidelity/european_fit_preprocessing_v1/observed_adapter_v1.py'
    old=function(old_path,'load_relate_observation');new=function(new_path,'load_relate_observation')
    assert ast_same(old.args,new.args)
    old_first=next(i for i,n in enumerate(old.body) if assignment(n,['h']))
    new_first=next(i for i,n in enumerate(new.body) if assignment(n,['genotype','allele_count']))
    assert len(old.body[:old_first])==len(new.body[:new_first])
    assert all(ast_same(a,b) for a,b in zip(old.body[:old_first],new.body[:new_first]))
    old_last=next(i for i,n in enumerate(old.body) if assignment(n,['labels','queries','ages']))
    new_last=next(i for i,n in enumerate(new.body) if assignment(n,['labels','queries','ages']))
    assert len(old.body[old_last:])==len(new.body[new_last:])
    assert all(ast_same(a,b) for a,b in zip(old.body[old_last:],new.body[new_last:]))
    assert new_last==new_first+1 and ast.unparse(new.body[new_first])=='genotype, allele_count = read_observed_calls(vcf_path, rows, wanted, ts.num_sites, resource_check=resource_check)'
    prior_path='research/efficiency_20261027/fidelity/EUROPEAN_COHORT8_FIT_CLI_V2_SOURCE_REVIEW.json'
    prior=read(prior_path)
    assert prior['passed'] and prior['resume_restore_CPU_equivalence_passed']
    assert prior['resume_driver_source_manifest_ref']==wrapper['resume_driver_source_manifest_ref']
    for row in prior['evidence_refs']:assert ref(row['path'])==row
    original_driver='research/efficiency_20261027/architecture/european_cohort_train/driver_v3.py'
    assert ref(original_driver)['sha256']=='8de0ba11d71bf7b2eee518ad8274ffc2e22b10bdd7937613e29501e470d7fcff'
    from research.efficiency_20261027.fidelity.european_fit_preprocessing_v1 import test_contracts_v1 as bridge_test
    from research.efficiency_20261027.execution.european_cohort_fit import test_contracts_v3 as cli_test
    original_open=Path.open
    redirected={bridge_test.HERE/'CPU_TEST_RESULTS_v1.json':OUT/'EUROPEAN_FIT_BRIDGE_INDEPENDENT_CPU_v1.json',cli_test.HERE/'CONTRACTS_CPU_v3.json':OUT/'EUROPEAN_FIT_CLI_V3_INDEPENDENT_CPU_v1.json'}
    def output_open(path,mode='r',*args,**kwargs):
        if path in redirected and mode=='x':path=redirected[path]
        return original_open(path,mode,*args,**kwargs)
    with patch.object(Path,'open',output_open):
        bridge_test.main()
        cli_test.main()
    bridge_evidence=json.loads(redirected[bridge_test.HERE/'CPU_TEST_RESULTS_v1.json'].read_text())
    cli_evidence=json.loads(redirected[cli_test.HERE/'CONTRACTS_CPU_v3.json'].read_text())
    assert bridge_evidence['passed'] and bridge_evidence['check_count']==22
    assert cli_evidence['passed'] and cli_evidence['check_count']==28
    # Verify no source/evidence was changed by the independently repeated tests.
    for row in refs:assert ref(row['path'])==row
    review=dict(schema='European_cohort8_FIT_CLI_review_v3',passed=True,
        wrapper_manifest_ref=ref(WRAPPER),preprocessing_source_manifest_ref=ref(BRIDGE),
        resume_driver_source_manifest_ref=wrapper['resume_driver_source_manifest_ref'],
        resume_restore_CPU_equivalence_passed=True,
        preprocessing_actual_route_CPU_equivalence_passed=True,original_numerical_driver_unchanged=True,
        reviewer='treeloom_execution_oct27',independent_CPU_tests_rerun=50,
        independent_CPU_evidence_refs=[ref(path) for path in redirected.values()],
        source_refs_independently_rehashed=len(refs),predecessor_source_refs_preserved=len(inherited['source_refs']),
        reviewer_program_ref=ref(Path(__file__)),prior_resume_review_ref=ref(prior_path),
        resume_restore_test_repeated=False,prior_resume_evidence_authenticated=True,
        source_findings=[
          'Exact four live owners: queue VCF loader, recovery encoder, recovery episodes, recovery cut plan. Queue helper objects remain identical.',
          'All adapter statements before and after the VCF parsing region are AST-identical; the sole region replacement calls the already qualified exact parser.',
          'Authentication verifies original release proofs, original TRAIN000 parser input refs, unchanged TRAIN input dictionary and original512GiB envelope before assignment.',
          'Qualified process4 encoder retains8GiB child reserve, bounded128-tree/64MiB chunks, original resource callback and complete original dimensions.',
          'Installation validates every owner before mutation and rolls back its own assignments on failed verification.',
          'Binding receipt is written before unchanged driver_v3.run_fit, then reverified before lateGPU acquisition and completion.',
          'Qualification, guardian command/resources/PID validation, progress and runtime guards retain unchanged AST; resume gate only adds the exact v3 module.',
          'Independent actual-route fixture enters all four replacements through the actual driver and preserves all tensor bytes, metadata,952x8 cohort features, four holds and repeated focal draws.'],
        limitations=[
          'Tiny synthetic actual-route parity and source review; no real European parent preprocessing or training was repeated.',
          'Historical full parser proof is European TRAIN000; historical full tree proof is American TRAIN000. Full European tree equivalence is not claimed.',
          'Resume equivalence evidence is inherited from authenticated unchanged driver/predecessor review; this review repeated only bridge and CLI contracts.',
          'This review is not launch authorization. ROOT current resources, exact successful numerical qualification, lateGPU lease and actual final wait/family absence remain required.'],
        scientific_payloads_opened=False,native_tools_launched=0,training_launched=False,CUDA_initialized=False,production_modified=False,launch_authorization=False)
    destination=OUT/'EUROPEAN_COHORT8_FIT_CLI_V3_SOURCE_REVIEW.json'
    with destination.open('x') as stream:json.dump(review,stream,indent=2,sort_keys=True);stream.write('\n')
    from research.efficiency_20261027.execution.european_cohort_fit import fit_cli_v3
    fit_cli_v3.verify_wrapper(ref(WRAPPER)['sha256'],str(destination.relative_to(ROOT)),ref(destination)['sha256'])
    print(json.dumps(dict(review=ref(destination),checks=50,source_refs=len(refs),actual_wrapper_gate_passed=True)))

if __name__=='__main__':main()
