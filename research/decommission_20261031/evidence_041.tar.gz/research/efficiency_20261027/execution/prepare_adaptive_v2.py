"""Preserve v1 and create joint family/phase/child-credit admission successor."""
from pathlib import Path
base=Path('research/efficiency_20261027')
p=base/'execution/adaptive_prefetch_v1.py'
s=p.read_text().replace('from contextlib import contextmanager','from contextlib import contextmanager, nullcontext')
s=s.replace('        self.encoder_calls = 0','        self.encoder_calls = 0\n        self.governor = None')
s=s.replace('    def acquire(self, parent):\n        with self.lock:', '''    def acquire(self, parent, *, phase_amount=0):
        condition = self.governor.condition if self.governor is not None else nullcontext()
        with condition, self.lock:''')
s=s.replace("            if measured['bytes'] + (len(self.active)+1)*self.allowance > self.maximum:\n                return None", """            live = measured['bytes']
            phases = phase_amount
            if self.governor is not None:
                live = max(live, self.governor.rss())
                phases += sum(self.governor.active.values())
            if live + phases + (len(self.active)+1)*self.allowance > self.maximum:
                return None""")
s=s.replace('    def before_encoder(self):\n        with self.lock:', '''    def before_encoder(self):
        condition = self.governor.condition if self.governor is not None else nullcontext()
        with condition, self.lock:''')
s=s.replace("            need(measured['bytes'] + len(self.active)*self.allowance <= self.maximum,\n                 'Live family plus every outstanding child allowance exceeds task limit')", """            live = measured['bytes']
            phases = 0
            if self.governor is not None:
                live = max(live, self.governor.rss())
                phases = sum(self.governor.active.values())
            need(live + phases + len(self.active)*self.allowance <= self.maximum,
                 'Joint live family, main RSS, phase reserves and child allowances exceed task limit')""")
s=s.replace('        self.labels = {}', '        self.labels = {}\n        self.credits = None')
s=s.replace('    def _available(self, amount, *, evict):', '''    def bind_credits(self, credits):
        with self.condition, credits.lock:
            need(self.credits is None and credits.governor is None
                 and not self.active and not credits.active, 'Bind one ledger before any phase or producer')
            need(self.maximum == credits.maximum, 'One joint family admission cap')
            self.credits = credits
            credits.governor = self

    def _required_total(self, amount, added_credit):
        live = self.rss()
        credit_bytes = added_credit
        if self.credits is not None:
            with self.credits.lock:
                live = max(live, self.credits._measure()['bytes'])
                credit_bytes += len(self.credits.active)*self.credits.allowance
        return live + amount + sum(self.active.values()) + credit_bytes

    def _available(self, amount, *, evict, added_credit=0):''')
s=s.replace('self.rss() + amount + sum(self.active.values()) <= self.maximum',
            'self._required_total(amount, added_credit) <= self.maximum')
s=s.replace('self._available(amount, evict=not optional)',
            'self._available(amount, evict=not optional, added_credit=0 if credits is None else credits.allowance)')
s=s.replace('credit = credits.acquire(parent)', 'credit = credits.acquire(parent, phase_amount=amount)')
s=s.replace('        self.credits = credits\n        self.check = resource_check',
            '        self.credits = credits\n        governor.bind_credits(credits)\n        self.check = resource_check')
s=s.replace("TreeLoom_adaptive_two_parent_candidate_v1", "TreeLoom_adaptive_two_parent_candidate_v2")
s=s.replace('optional_admission_never_waits=True)',
            'optional_admission_never_waits=True, joint_phase_and_child_family_admission=True)')
with (base/'execution/adaptive_prefetch_v2.py').open('x') as handle:handle.write(s)
for old,new in (('adaptive_encoder_hooks_v1.py','adaptive_encoder_hooks_v2.py'),
                ('test_adaptive_prefetch_v2.py','test_adaptive_prefetch_v3.py'),
                ('test_adaptive_training_v1.py','test_adaptive_training_v2.py')):
    s=(base/'execution'/old).read_text().replace('from .adaptive_prefetch_v1','from .adaptive_prefetch_v2')
    s=s.replace('training_adaptive_v1','training_adaptive_v2')
    if old.startswith('test_adaptive_prefetch'):
        s=s.replace('rss=[200]','rss=[190]').replace('adaptive_prefetch_CPU_v2','adaptive_prefetch_CPU_v3').replace('ADAPTIVE_PREFETCH_CPU_v2','ADAPTIVE_PREFETCH_CPU_v3')
    if old.startswith('test_adaptive_training'):
        s=s.replace('ADAPTIVE_TRAINING_CPU_v1','ADAPTIVE_TRAINING_CPU_v2')
    with (base/'execution'/new).open('x') as handle:handle.write(s)
s=(base/'integration_candidate/training_adaptive_v1.py').read_text()
s=s.replace('execution.adaptive_prefetch_v1','execution.adaptive_prefetch_v2')
s=s.replace('execution.adaptive_encoder_hooks_v1','execution.adaptive_encoder_hooks_v2')
s=s.replace('source_pins_adaptive_v1.json','source_pins_adaptive_v2.json')
with (base/'integration_candidate/training_adaptive_v2.py').open('x') as handle:handle.write(s)
