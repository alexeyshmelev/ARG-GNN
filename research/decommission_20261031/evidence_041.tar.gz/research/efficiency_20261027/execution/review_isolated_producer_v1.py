"""Independent tiny producer handoff-failure tests and source review evidence."""
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import tempfile
import time
from unittest.mock import patch
from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1 import backend, codec, wire
from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.test_cpu import BOUND, TinyWholeParent, spec_file

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')
HERE = ROOT/'research/efficiency_20261027/execution'
PACKAGE = ROOT/'research/efficiency_20261027/independent_efficiency_challenge/producer_isolation_v1'


def ref(path):
    return dict(path=str(path.relative_to(ROOT)), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def actual_handoff_failure(mode):
    with tempfile.TemporaryDirectory(prefix='CPU_handoff_', dir=HERE) as directory:
        specification, inputs = spec_file(directory)
        producer = backend.CPUProducerBackend(specs={'fresh_train_000':specification},
            bundle_type=TinyWholeParent, module=backend.TINY_WORKER, maximum_seconds=60)
        original_receive = codec.receive_record
        original_send = wire.send
        owners = []
        descriptors = set(os.listdir('/proc/self/fd'))
        def capture(*args, **kwargs):
            record = original_receive(*args, **kwargs)
            owners.append(record['mapping_owner'])
            return record
        def fail_ACK(control, value, **kwargs):
            assert value['status'] == 'ack'
            if mode == 'cancel_after_map':
                raise RuntimeError('Independent cancellation after complete mapped-record validation')
            wrong = dict(value, hashes={key:'0'*64 for key in value['hashes']})
            return original_send(control, wrong, **kwargs)
        with patch.object(codec, 'receive_record', side_effect=capture), patch.object(wire, 'send', side_effect=fail_ACK):
            try:
                producer('fresh_train_000', input_refs=inputs, external_arrays={}, bound=BOUND,
                    resource_check=lambda stage:None)
            except (RuntimeError, ValueError) as error:
                if mode == 'cancel_after_map':
                    assert 'Independent cancellation' in str(error)
                else:
                    assert 'Actual CPU producer exit zero' in str(error)
            else:
                raise AssertionError('Failed handoff published a record')
        assert len(owners) == 1 and owners[0].closed
        assert set(os.listdir('/proc/self/fd')) == descriptors
        receipt = producer.receipts['fresh_train_000']
        assert receipt['actual_wait'] is True and receipt['published_ready'] is False
        assert receipt['whole_task_failure_requires_outer_session_cleanup'] is True
        if mode == 'incorrect_ACK':
            assert receipt['returncode'] != 0
        return dict(name=mode, passed=True, mapping_closed=True, descriptors_unchanged=True,
            actual_wait=True, published_ready=False, returncode=receipt['returncode'])


def malformed_control_closes_received_fd():
    first, second = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
    descriptor = codec.create_memfd('independent_tiny_control')
    import array
    descriptors = set(os.listdir('/proc/self/fd'))
    try:
        first.sendmsg([b'F'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', [descriptor]))])
        first.sendall(struct.pack('!Q', 1) + b'{')
        try:
            wire.receive(second, check=lambda stage:None, deadline=time.monotonic()+2)
        except json.JSONDecodeError:
            pass
        else:
            raise AssertionError('Malformed JSON accepted')
        assert set(os.listdir('/proc/self/fd')) == descriptors
    finally:
        os.close(descriptor)
        first.close()
        second.close()
    return dict(name='malformed_JSON_after_SCM_RIGHTS_closes_received_descriptor', passed=True)


def main():
    checks = [actual_handoff_failure('cancel_after_map'), actual_handoff_failure('incorrect_ACK'),
              malformed_control_closes_received_fd()]
    manifest_ref = ref(PACKAGE/'source_pins_v1.json')
    assert manifest_ref['sha256'] == 'cb75e3433152aabe583f3aed91e0a37fcc939c88e9f825ed0551cf4d01d63c25'
    manifest = json.loads((PACKAGE/'source_pins_v1.json').read_text())
    assert len(manifest['source_refs']) == len({item['path'] for item in manifest['source_refs']}) == 314
    for item in manifest['source_refs']:
        assert ref(ROOT/item['path']) == item
    log = HERE/'ISOLATED_PRODUCER_V1_INDEPENDENT_CPU.log'
    text = log.read_text()
    assert 'Ran 15 tests' in text and text.rstrip().endswith('OK')
    report = dict(schema='TreeLoom_isolated_producer_independent_source_review_v1', passed=True,
        source_manifest_ref=manifest_ref, authenticated_source_refs=314,
        original_tiny_test_count=15, independent_test_log_ref=ref(log),
        additional_actual_tiny_checks=checks, review_source_ref=ref(Path(__file__)),
        total_independent_checks=18, original_codec_plans_dtypes_hashes_and_restore_preserved=True,
        coordinator_cursor_futures_admission_and_prepare_once_methods_inherited=True,
        phase_and_encoder_credits_held_through_map_ACK_actual_wait_and_commit=True,
        sealed_readonly_memfd_all_array_hashes_before_ACK=True,
        no_expanded_payload_IPC_or_duplicate_cache=True,
        local_failure_cleanup_excludes_same_session_siblings=True,
        production_qualified=False, live_integration_reviewed=False,
        integration_requirements=[
            'Retain unchanged outer session guardian for whole-task cleanup, including unobserved orphan descendants.',
            'Caller must authenticate exact source manifest and registered observed refs, plan, seal and external genotype; build specs in the actual coordinator.',
            'Use the reviewed async wrapper with exclusive original callback ownership for the entire training lifecycle; retain trainer own-RSS and phase checks.',
            'On shutdown join pool, release compact records after users finish, then close the async wrapper and propagate failures before success receipts.',
            'Separately admit full-parent process qualification: exact archived complete signature, external genotype restore, family peak memory, four encoder children, ACK/FD lifetime and actual wait.',
            'Review and pin the actual isolated integration entrypoint before any training continuation; preserve current warm live training state.'
        ],
        limitations=[
            'Tiny synthetic transport/process checks do not qualify full-parent throughput or memory.',
            'Known family absence after exit is local evidence; outer session supervision remains mandatory.',
            'There is no measured GPU-utilization improvement or80-percent GPU-utilization claim.'
        ],
        scientific_payloads_opened=False, scientific_native_model_GPU_executions=0,
        existing_jobs_modified=False, heavy_launch_performed=False)
    destination = HERE/'ISOLATED_PRODUCER_V1_SOURCE_REVIEW.json'
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(passed=True, checks=18, review=ref(destination))))

if __name__ == '__main__':
    main()
