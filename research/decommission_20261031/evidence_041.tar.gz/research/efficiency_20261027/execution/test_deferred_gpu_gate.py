"""CPU-only tests of the exact predecessor exit gate."""
import os
os.environ["CUDA_VISIBLE_DEVICES"]=""
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import torch
from research.efficiency_20261027.execution import deferred_gpu_gate as gate
from research.efficiency_20261027.root.compare_host_parallelism import ref,write,GIB


def main():
    output=Path("research/efficiency_20261027/execution/deferred_gate_CPU_test")
    output.mkdir(exist_ok=False)
    launch=dict(pid=4242,process_start_ticks="123456",actual_argv=["python","visible.py"])
    wait=dict(actual_wait=True,owned_group_absent=True,actual_returncode=0,
        pid=4242,process_start_ticks="123456")
    gate.validate_completion(launch,wait,None,[])
    gate.validate_completion(launch,wait,"999999",[])
    cases=[
        (dict(wait,actual_wait=False),None,[]),
        (dict(wait,owned_group_absent=False),None,[]),
        (dict(wait,actual_returncode=1),None,[]),
        (dict(wait,pid=4243),None,[]),
        (dict(wait,process_start_ticks="wrong"),None,[]),
        (wait,"123456",[]),
        (wait,None,[4242])]
    for candidate,current,members in cases:
        try:
            gate.validate_completion(launch,candidate,current,members)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid predecessor completion accepted")
    fixture=(output/"fixture").resolve()
    directory=fixture/"research/efficiency_20261027/root/runs/predecessor"
    directory.mkdir(parents=True)
    (directory/"launch.json").write_text(json.dumps(launch))
    (directory/"request.json").write_text(json.dumps(dict(command=launch["actual_argv"])))
    events=[]
    fake_torch=SimpleNamespace(cuda=SimpleNamespace(is_initialized=lambda:False))
    def finish_on_wait(seconds):
        events.append("wait")
        (directory/"actual_wait.json").write_text(json.dumps(wait))
    def free(index):
        assert (directory/"actual_wait.json").exists()
        events.append("GPU_free_read_after_exit")
        return 18*GIB
    with patch.object(gate,"ROOT",fixture),patch.object(gate,"identity",lambda pid:None), \
         patch.object(gate,"owned_group_members",lambda pid:[]),patch.object(gate,"gpu_free",free), \
         patch.object(gate.time,"sleep",finish_on_wait):
        result=gate.wait_before_cuda(fake_torch,lambda stage:None,
            predecessor_directory="research/efficiency_20261027/root/runs/predecessor",
            output=output,gpu_index=5,gpu_budget_bytes=16*GIB,timeout_seconds=30,poll_seconds=1)
    assert events==["wait","GPU_free_read_after_exit"]
    assert result["status"]=="ready" and result["CUDA_initialized"] is False
    assert result["predecessor_actual_wait_ref"] is not None
    memory_output=output/"insufficient_memory"
    memory_output.mkdir()
    reads=[]
    def memory_free(index):
        reads.append(index)
        return (17 if len(reads)==1 else 18)*GIB
    with patch.object(gate,"gpu_free",memory_free),patch.object(gate.time,"sleep",lambda seconds:None):
        memory_result=gate.wait_before_cuda(fake_torch,lambda stage:None,
            predecessor_directory=None,output=memory_output,gpu_index=5,
            gpu_budget_bytes=16*GIB,timeout_seconds=30,poll_seconds=1)
    assert len(reads)==2 and memory_result["required_free_GPU_bytes"]==18*GIB
    assert not torch.cuda.is_initialized()
    result=dict(schema="TreeLoom_deferred_GPU_gate_CPU_v1",status="pass",CUDA_initialized=False,
        invalid_completion_cases_rejected=len(cases),PID_reuse_without_old_group_allowed=True,
        original_PID_start_identity_alive_rejected=True,remaining_group_rejected=True,
        actual_wait_required_before_free_GPU_query=True,
        current_GPU_budget_plus_two_GiB_margin_rechecked=True,owned_processes_signaled=False,
        source_refs=[ref("research/efficiency_20261027/execution/deferred_gpu_gate.py"),
            ref("research/efficiency_20261027/execution/compare_large_blocks_deferred.py"),ref(__file__)],
        scope="Synthetic files under owned execution test output and injected read-only probes; no actual GPU queried or initialized and no process signaled.")
    write(output/"completed.json",result)
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()

