"""Exact full observed coordinate plan and CPU learned-site output/gradient tests."""
import copy
import hashlib
import json
from pathlib import Path
import statistics
import time
from types import SimpleNamespace
import numpy as np
import torch
import tskit
from research.scalability_20261024.integration.executors import IntegratedStagedExecution
from research.benchmark_rebuild_20261024.american.treeloom_speed import static_model_v2 as frozen
from .site_index_plan_v1 import SiteIndexPlan
from .planned_site_executor_v1 import PlannedSites
from research.efficiency_20261027.root.compare_host_parallelism import ROOT,CHECKPOINT,ref,write

BASE=ROOT/'research/efficiency_20261027/execution'


class Bank:
    pass


def need(ok,message):
    if not ok:raise AssertionError(message)


def rejects(call):
    try:call()
    except ValueError:return
    raise AssertionError('Expected rejection')


def baseline_indices(bank,a,b):
    values=bank.site_hold.numpy()
    left,right=map(int,np.searchsorted(values,[a,b]))
    result=[]
    for start in range((left//256)*256,right,256):
        end=min(start+256,len(values))
        holds,inverse=torch.unique_consecutive(bank.site_hold[start:end],return_inverse=True)
        selected=torch.nonzero((holds>=a)&(holds<b),as_tuple=False).flatten()
        if len(selected):result.append((start,end,holds,inverse,selected,holds[selected]-a))
    return result


def full_coordinate_check():
    packet=json.loads((ROOT/'research/scalability_20261024/execution/representative_slice.json').read_text())
    metadata=json.loads((ROOT/'research/preprocessing_optimization_20261026/integration/full_candidate.json').read_text())
    for key in ('tree_ref','positions_ref'):
        need(ref(packet[key]['path'])==packet[key],'Exact original observed file identity')
    ts=tskit.load(ROOT/packet['tree_ref']['path'])
    positions=np.load(ROOT/packet['positions_ref']['path'],mmap_mode='r',allow_pickle=False)
    values=np.searchsorted(ts.breakpoints(as_array=True)[1:],positions,side='right').astype(np.int64)
    need(hashlib.sha256(values.tobytes()).hexdigest()==metadata['bundle']['bank']['site_hold']['sha256'],
         'Reconstructed full observed site coordinates must match authenticated prepared bank byte for byte')
    bank=Bank()
    bank.site_hold=torch.from_numpy(values)
    bank.sample_index=SimpleNamespace(shape=(77472,1600))
    admissions=[]
    tick=time.perf_counter()
    plan=SiteIndexPlan.build(bank.site_hold,native_holds=77472,holds_per_block=512,
        provenance='authenticated TRAIN000 site coordinates',max_bytes=16*2**20,
        admit=lambda amount,stage:admissions.append(dict(bytes=amount,stage=stage)))
    build_seconds=time.perf_counter()-tick
    bound=plan.bind(bank,provenance=plan.provenance)
    comparisons=0
    for a in range(0,77472,512):
        b=min(a+512,77472)
        expected=baseline_indices(bank,a,b)
        actual=bound.selections(bank,a,b)
        need(len(expected)==len(actual),'Every original global chunk selection retained')
        for old,selected in zip(expected,actual):
            chunk=plan.chunks[selected.chunk]
            need((chunk.start,chunk.end)==old[:2],'Exact original global256 chunk support')
            for got,want in ((chunk.holds,old[2]),(chunk.inverse,old[3]),
                             (selected.selected,old[4]),(selected.local_holds,old[5])):
                need(np.array_equal(got,want.numpy()),'Exact integer values and order')
                need(not got.flags.writeable,'Immutable retained integer arrays')
            comparisons+=1
    def cold_iteration():
        count=0
        for _ in range(4):
            for a in range(0,77472,512):
                count+=sum(len(row[4]) for row in baseline_indices(bank,a,min(a+512,77472)))
        return count
    def warm_iteration():
        count=0
        for _ in range(4):
            for a in range(0,77472,512):
                count+=sum(len(row.selected) for row in bound.selections(bank,a,min(a+512,77472)))
        return count
    timings={'original_index_setup':[],'planned_index_lookup':[]}
    for repeat in range(6):
        order=(('original_index_setup',cold_iteration),('planned_index_lookup',warm_iteration))
        if repeat%2:order=tuple(reversed(order))
        counts=[]
        for name,function in order:
            tick=time.perf_counter()
            counts.append(function())
            timings[name].append(time.perf_counter()-tick)
        need(counts[0]==counts[1],'Complete repeated selection coverage')
    restored=Bank()
    restored.site_hold=bank.site_hold.clone()
    restored.sample_index=bank.sample_index
    tick=time.perf_counter()
    rebound=plan.bind(restored,provenance=plan.provenance)
    bind_seconds=time.perf_counter()-tick
    need(rebound.plan is plan,'Restored exact coordinates reuse immutable plan')
    rejects(lambda:plan.bind(restored,provenance='wrong parent'))
    restored.site_hold[0]+=1
    rejects(lambda:rebound.selections(restored,0,512))
    rejects(lambda:plan.bind(restored,provenance=plan.provenance))
    rejects(lambda:bound.selections(bank,-512,0))
    rejects(lambda:bound.selections(bank,0,128))
    rejects(lambda:SiteIndexPlan.build(bank.site_hold,native_holds=77472,holds_per_block=512,
        provenance=plan.provenance,max_bytes=1024,admit=lambda *args:None))
    return dict(native_holds=77472,sites=len(values),haplotypes=1600,block_holds=512,
        blocks=len(plan.blocks),global_chunks=len(plan.chunks),selected_block_chunks=comparisons,
        all_global_chunk_indices_byte_exact=True,plan_charged_bytes=plan.charged_bytes,
        build_admission=admissions,build_seconds=build_seconds,restored_bind_seconds=bind_seconds,
        timings=timings,median_seconds={key:statistics.median(value) for key,value in timings.items()},
        mutation_provenance_partition_and_budget_rejections=True,
        scope='Observed integer coordinate plan only. No complete bank reconstruction, learned execution, GPU or full-parent speedup measurement in this timing.')


def numerical_check():
    torch.manual_seed(901)
    saved=torch.load(ROOT/CHECKPOINT,map_location='cpu',weights_only=True,mmap=True)
    model=frozen.AmericanTreeLoomC3FullV1()
    model.load_state_dict(saved['model_state'],strict=True)
    bank=Bank()
    t,h,s=67,1600,263
    bank.site_hold=torch.linspace(1,65,s).long()
    bank.sample_index=SimpleNamespace(shape=(t,h))
    bank.genotype=torch.randint(-1,3,(s,h),dtype=torch.int8)
    bank.log_donor_allele_frequency=-torch.rand(s,3,6)
    bank.donor_call_mask=torch.rand(s,6)>.15
    bank.panel_allele_frequency=torch.full((s,3),1/3)
    bank.site_entropy=torch.rand(s)
    bank.spans=torch.linspace(1.,1000.,t)
    # An entirely uncalled global chunk exercises the original empty-site path.
    bank.genotype[:256]=-1
    plan=SiteIndexPlan.build(bank.site_hold,native_holds=t,holds_per_block=32,
        provenance='synthetic missingness and ragged support',max_bytes=2**20,admit=lambda *args:None)
    bound=plan.bind(bank,provenance=plan.provenance)
    def run(cls):
        selected=copy.deepcopy(model)
        executor=object.__new__(cls)
        executor.bank,executor.model,executor.device=bank,selected,torch.device('cpu')
        if cls is PlannedSites:executor.site_plan=bound
        output=torch.cat([executor._sites(a,min(a+32,t)) for a in range(0,t,32)])
        coefficients=torch.linspace(.1,1.,32)
        loss=(output.square()*coefficients).mean()+.01*output.mean()
        loss.backward()
        gradients={name:None if p.grad is None else p.grad.clone() for name,p in selected.named_parameters()}
        return output.detach(),loss.detach(),gradients
    before=torch.get_rng_state().clone()
    original=run(IntegratedStagedExecution)
    planned=run(PlannedSites)
    need(torch.equal(before,torch.get_rng_state()),'Plan use must not consume RNG')
    need(torch.equal(original[0],planned[0]) and torch.equal(original[1],planned[1]),'Bit-exact CPUsite outputs/loss')
    connected=0
    for name,value in original[2].items():
        need((value is None)==(planned[2][name] is None),'Original gradient connectivity')
        if value is not None:
            connected+=1
            need(torch.equal(value,planned[2][name]),'Bit-exact current-parameter site gradient '+name)
    return dict(status='pass',native_holds=t,haplotypes=h,sites=s,block_holds=32,blocks=3,
        outputs_and_loss_bit_exact=True,connected_parameter_gradients_bit_exact=connected,
        missing_entire_global_chunk=True,ragged_final_block=True,empty_first_and_last_holds=True,RNG_unchanged=True)


def main():
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    need(not torch.cuda.is_initialized(),'CPU-only qualification')
    result=dict(schema='TreeLoom_site_index_plan_CPU_qualification_v1',status='pass',CPU_threads=8,
        full_coordinates=full_coordinate_check(),numerical=numerical_check(),
        source_refs=[ref(BASE/name) for name in ('site_index_plan_v1.py','planned_site_executor_v1.py','test_site_index_plan_v1.py')],
        CUDA_initialized=torch.cuda.is_initialized(),production_modified=False,
        full_parent_numerical_qualification=False)
    write(BASE/'site_index_plan_CPU_v1.json',result)
    print(json.dumps(result,indent=2,allow_nan=False))


if __name__=='__main__':main()
