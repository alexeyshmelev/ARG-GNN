printf immediate\n
