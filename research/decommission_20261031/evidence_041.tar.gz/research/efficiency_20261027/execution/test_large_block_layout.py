"""CPU invariance of larger immutable layouts on a ragged synthetic forest."""
import os
os.environ["CUDA_VISIBLE_DEVICES"]=""
import ast
import copy
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from research.efficiency_20261027.execution.large_layout_plan import LargeLayoutPlan
from research.efficiency_20261027.execution.large_layout_cache import LargeBlockLayoutCache
from research.scalability_20261024.execution.measure_representative import baseline_layout, assert_same
from research.benchmark_rebuild_20261024.american.treeloom_speed import static_model_v2
from research.efficiency_20261027.root.compare_host_parallelism import ref, write


class Bank(SimpleNamespace):
    pass


def main():
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    counts=[];parent=[];samples=[];height=[];depth=[]
    for hold in range(1091):
        offset=len(parent)
        unary=hold%3==0
        local=[-1,0,1,1] if unary else [-1,0,0]
        counts.append(len(local))
        parent.extend([p+offset if p>=0 else -1 for p in local])
        samples.append([offset+2,offset+3] if unary else [offset+1,offset+2])
        height.extend([2,1,0,0] if unary else [1,0,0])
        depth.extend([0,1,2,2] if unary else [0,1,1])
    height=np.asarray(height);depth=np.asarray(depth)
    bank=Bank(parent=torch.tensor(parent),sample_index=torch.tensor(samples),
        upward_levels=tuple(torch.from_numpy(np.flatnonzero(height==level)) for level in range(3)),
        downward_levels=tuple(torch.from_numpy(np.flatnonzero(depth==level)) for level in (1,2)))
    members=torch.arange(1091).repeat_interleave(2)
    layouts={}
    for block in (128,256,512,1024):
        plan=LargeLayoutPlan.build(bank,counts,members,holds_per_block=block)
        layouts[block]=plan.executor_layout()
        assert_same(baseline_layout(bank,counts,members,holds_per_block=block),layouts[block])
        assert layouts[block][-1][1]-layouts[block][-1][0] == 1091%block
        for z in plan.blocks:
            assert not z.parent.flags.writeable
        bound=plan.bind(bank,counts,members)
        assert_same(layouts[block],bound.assert_binding(bank,counts,members))
    try:
        LargeLayoutPlan.build(bank,counts,members,holds_per_block=1025)
    except ValueError:
        pass
    else:
        raise AssertionError("Unadmitted partition accepted")
    bundle=SimpleNamespace(bank=bank,episodes=SimpleNamespace(member_hold=members),
        parent_id="synthetic-layout-only",native_holds=1091,observation_ref=dict(path="synthetic"))
    metadata=dict(episode_metadata=dict(native_nodes_per_tree=counts),layout_cache_scope="CPU synthetic only")
    cache=LargeBlockLayoutCache(max_bytes=16*2**20)
    lease=cache.acquire(bundle,metadata,holds_per_block=1024)
    second=cache.acquire(bundle,metadata,holds_per_block=1024)
    assert cache.snapshot()["builds"] == cache.snapshot()["fast_hits"] == 1
    try:
        cache.clear()
    except RuntimeError:
        pass
    else:
        raise AssertionError("Active lease evicted")
    lease.release();second.release();cache.clear()
    plan=LargeLayoutPlan.build(bank,counts,members,holds_per_block=1024)
    bound=plan.bind(bank,counts,members)
    bank.parent.add_(0)
    try:
        bound.assert_binding(bank,counts,members)
    except ValueError:
        pass
    else:
        raise AssertionError("Tensor version mutation accepted")
    generator=torch.Generator().manual_seed(927)
    raw=(torch.randn(len(parent),32,generator=generator),
        torch.rand(len(parent),32,generator=generator),
        torch.rand(len(parent),32,generator=generator))
    weights=torch.randn(len(parent),32,generator=generator)/len(parent)
    torch.manual_seed(928)
    prototype=static_model_v2.AmericanTreeLoomC3FullV1()
    def run(block):
        model=copy.deepcopy(prototype)
        outputs=[];input_grads=[[],[],[]]
        for z in layouts[block]:
            lo,hi=z[2:4]
            local=SimpleNamespace(parent=torch.tensor(z[4],dtype=torch.long),
                upward_levels=tuple(torch.tensor(x,dtype=torch.long) for x in z[5]),
                upward_children=tuple(torch.tensor(x,dtype=torch.long) for x in z[6]),
                upward_parent_rank=tuple(torch.tensor(x,dtype=torch.long) for x in z[7]),
                downward_levels=tuple(torch.tensor(x,dtype=torch.long) for x in z[8]))
            values=[x[lo:hi].clone().requires_grad_(True) for x in raw]
            degree=torch.bincount(local.parent[local.parent>=0],minlength=hi-lo).float().clamp_min(1)
            up,out=model.sweep_tree_state_v1(local,*values,degree)
            ((up*weights[lo:hi]).sum()+(out*weights[lo:hi].flip(1)).sum()).backward()
            outputs.append(torch.stack((up.detach(),out.detach())))
            for index,x in enumerate(values):
                input_grads[index].append(x.grad.detach())
        return torch.cat(outputs,dim=1),[torch.cat(x) for x in input_grads],{
            name:None if p.grad is None else p.grad.detach().clone() for name,p in model.named_parameters()}
    reference=run(128)
    results=[]
    for block in (512,1024):
        result=run(block)
        torch.testing.assert_close(result[0],reference[0],atol=1e-6,rtol=1e-5)
        for a,b in zip(result[1],reference[1]):
            torch.testing.assert_close(a,b,atol=1e-6,rtol=1e-4)
        errors={}
        for name,a in reference[2].items():
            b=result[2][name]
            assert (a is None)==(b is None)
            if a is not None:
                torch.testing.assert_close(a,b,atol=1e-6,rtol=1e-4,msg=name)
                errors[name]=float((a-b).abs().max())
        results.append(dict(holds_per_block=block,blocks=len(layouts[block]),
            last_block_holds=1091%block,output_max_abs_error=float((result[0]-reference[0]).abs().max()),
            input_gradient_max_abs_error=max(float((a-b).abs().max()) for a,b in zip(result[1],reference[1])),
            connected_parameter_gradients=len(errors),parameter_gradient_max_abs_error=max(errors.values())))
    assert not torch.cuda.is_initialized()
    output=Path("research/efficiency_20261027/execution")
    receipt=dict(schema="TreeLoom_large_layout_CPU_v1",status="pass",CUDA_initialized=False,
        native_holds=1091,native_nodes=len(parent),layouts_exact=True,
        immutable_bindings_and_finite_cache=True,active_leases_protected=True,
        version_mutation_rejected=True,unadmitted_1025_partition_rejected=True,
        baseline_holds_per_block=128,results=results,
        scope="Synthetic unary/binary two-leaf forest, exact frozen sweep and parameter/input gradients. Not an observed bank or full learned-context/decoder qualification.",
        source_refs=[ref(output/name) for name in ("large_layout_plan.py","large_layout_cache.py","large_block_executors.py","test_large_block_layout.py")])
    write(output/"large_block_layout_CPU_results.json",receipt)
    print(json.dumps(receipt,indent=2))


if __name__=="__main__":
    main()

