"""Metadata-only hot block pack resource closure and bounded qualification proposal."""
import json
from pathlib import Path
from arggnn.benchmarking import contracts as c

BASE=Path('research/efficiency_20261027/execution')
GIB=2**30


def main():
    cpu_ref=c.file_ref(BASE/'hot_block_pack_CPU_v3.json')
    cpu=c.read_json(cpu_ref['path'])
    assert cpu['status']=='pass' and cpu['CUDA_initialized'] is False
    for reference in cpu['source_refs']:
        assert c.file_ref(reference['path'])==reference
    full_path=Path('research/efficiency_20261027/root/runs/selected_full_gpu5_v1/data/completed.json')
    full=c.read_json(full_path)
    assert full['status']=='completed'
    row=next(row for row in full['records'] if row['kind']=='explicit_cpu_vjp')
    assert row['CPU_threads']==8 and row['holds_per_block']==512 and row['comparison']['passed']
    inventory=c.read_json(BASE/'static_input_inventory_v1.json')
    metadata_path=Path('research/preprocessing_optimization_20261026/integration/full_candidate.json')
    metadata=c.read_json(metadata_path)
    counts=metadata['metadata']['episode_metadata']['native_nodes_per_tree']
    blocks=(len(counts)+511)//512
    assert blocks==inventory['selected512_blocks']==152
    shared=inventory['shared_reference_age_bytes']*blocks
    payload=inventory['one_full_pass_block_payload_bytes']+shared
    source_refs={reference['path']:reference for reference in full['source_refs']}
    for path in (BASE/'hot_block_pack_v2.py',BASE/'hot_block_executor_v2.py'):
        reference=c.file_ref(path)
        source_refs[reference['path']]=reference
    manifest=dict(schema='TreeLoom_hot_block_pack_source_pins_v2',
        source_refs=[source_refs[name] for name in sorted(source_refs)])
    for reference in manifest['source_refs']:
        assert c.file_ref(reference['path'])==reference
    pins=BASE/'source_pins_hot_block_v2.json'
    with pins.open('x') as stream:
        json.dump(manifest,stream,sort_keys=True,indent=2)
        stream.write('\n')
    report=dict(schema='TreeLoom_hot_block_pack_assessment_v2',status='CPU_exact_candidate_no_GPU_qualification',
        source_pins_ref=c.file_ref(pins),CPU_qualification_ref=cpu_ref,
        full_baseline_ref=c.file_ref(full_path),actual_observed_metadata_ref=c.file_ref(metadata_path),
        audit_source_ref=c.file_ref(Path(__file__).resolve()),
        implementation=dict(module='research.efficiency_20261027.execution.hot_block_executor_v2',
            factory='build_executor',required_options=['hot_pack_max_payload_bytes','hot_pack_soft_budget_bytes','hot_pack_scratch_reserve_bytes'],
            variant='CPU-context explicit VJP,512holds,64GRUhaps,1024history in future qualification',
            overridden_behavior='Only immutable _block input copies and one-update cache lifetime. Original first/second/base/sites/forcing/finite-episode/history/explicit backward equations remain inherited.',
            original_cpu_bank_retained=True,complete_context_stays_CPU=True,
            learned_or_optimizer_state_cached=False,per_parent_pack=True,
            cross_update_or_restored_bank_reuse=False,Lru_or_background_prefetch=False,
            cold_pack_rebuilt_each_complete_parent_update=True),
        full_TRAIN000_payload=dict(native_holds=len(counts),native_nodes=sum(counts),blocks=blocks,
            maximum512block_nodes=max(sum(counts[a:a+512]) for a in range(0,len(counts),512)),
            unique_per_block_fields_bytes=inventory['one_full_pass_block_payload_bytes'],
            repeated_shared_reference_age_bytes=shared,
            exact_pack_payload_bytes=payload,original_four_pass_payload_bytes=4*payload,
            avoided_repeated_H2D_payload_bytes=3*payload,copy_count_reduction_fraction=.75,
            index_width='Original torch.long on device; no int32 kernel change',
            note='Reference labels and sample ages remain duplicated exactly as each original block namespace, totaling2.918MB. This dominant block-only pack excludes site features and second-stage flags/member/cut indices.'),
        resource_closure=dict(baseline_allocated_peak_bytes=row['torch_peak_allocated_bytes'],
            baseline_reserved_peak_bytes=row['torch_peak_reserved_bytes'],
            nominal_payload_plus_allocated_peak_bytes=payload+row['torch_peak_allocated_bytes'],
            nominal_payload_plus_reserved_peak_bytes=payload+row['torch_peak_reserved_bytes'],
            nominal_arithmetic_is_not_admission=True,
            example_full_TRAIN000_payload_cap_bytes=18*GIB,
            example_soft_budget_bytes=48*GIB,required_scratch_reserve_bytes=16*GIB,
            initial_admission_required_payload_plus_scratch_bytes=payload+16*GIB,
            admission='Before first allocation and each cold block: actual CUDA reserved+remaining entire pack+16GiB complete scratch <= explicit soft cap; physical free >= remaining pack+16GiB. Caller existing resource check also runs. No allocator empty_cache or silent fallback.',
            allocator_reuse_or_physical_release_inferred_from_accounting=False,
            synchronous_transfers_and_same_stream_only=True,
            extra_host_working_storage='Existing layout arrays reused. Relative sample indices allocate one block-local CPU tensor (at most6,553,600bytes for512x1600 int64) and PyTorch conversion/staging uses original transfer path. No full host clone or pinned-memory pool is introduced.',
            CPU_metadata='Finite per-block namespaces/tensor stamps and source/immutable-layout stamps; host caller retains original preparation/training headroom.',
            largest_new_pack_fraction='All blocks remain resident; original measured single-block activation, context-copy, decoder and backward workspace must still fit. The nominal addition double counts some original current-block inputs but cannot bound allocator fragmentation or a different peak.',
            all20_parent_peak_guarantee=False,training_original_RSS_cap_changed=False),
        lifetime_and_invalidation=dict(lease='Original custom-trunk autograd node post-hook marks successful complete backward. close before that fails. Any failed candidate call must abort_hot_pack before releasing the executor.',
            binding='Exact live CPU bank identity, source tensor identity/pointer/version/shape/stride/dtype, byte-backed immutable original layout tuples, explicit provenance, and original CUDA stream.',
            source_mutation='Torch in-place changes and tensor replacement are rejected. Raw-storage/NumPy writes bypassing Torch version tracking remain forbidden by the existing immutable-bank contract; this candidate does not claim to detect such unsupported external writes.',
            thread_handling='RLock serializes cache state; CUDA autograd engine thread continuation is allowed. v1 thread-affinity guard was superseded before anyGPU test.',
            device_inputs='Cached tensors must stay non-grad and their identity/pointer/version/shape/dtype stamps match on reuse.',
            error='No shortened parent, dtype fallback, alternate block size, retry launcher or partial-gradient success. Failures propagate; explicit abort invalidates later graph reuse.',
            release='Clears all strong device entries and held CPU layout references. Existing layout lease releases only afterward. Actual CUDA allocation/free state must be reread; dropping references is not proof of physical release.'),
        CPU_proof=dict(actual_observed_holds=128,haplotypes=1600,block_holds=65,ragged_final_block=63,
            complete_restricted_history_window=17,all_input_values_dtypes_order_bit_exact=True,
            context_and_loss_bit_exact=True,connected_trunk_gradient_tensors=37,
            preexisting_decoder_gradient_tensors_preserved=12,gradient_max_abs_difference=0.,
            original_numerical_methods_inherited_identically=True,full_original_backward_on_different_python_thread=True,
            copies=2,hits=6,RNG_unchanged=True,
            CPU_payload_bytes=cpu['exact_inputs_and_lifecycle']['snapshot']['total_payload_bytes'],
            CPU_copy_validation_seconds=cpu['exact_inputs_and_lifecycle']['CPU_copy_plus_validation_seconds'],
            CPU_three_pass_lookup_seconds=cpu['exact_inputs_and_lifecycle']['three_pass_lookup_seconds'],
            CPU_timings_not_GPU_performance=True,full_parent_GPU_optimizer_qualification=False,
            test_history='Initial testv1 attempted ordinary assignment to an already-frozen bank dataclass. Version2 tests deliberate hostile replacement via object.__setattr__; version3 also validates cross-thread backward. Earlier tests and artifacts are retained.'),
        benefit_assessment=dict(baseline_full_update_seconds=row['update_seconds'],
            evidence='75percent fewer _block H2D bytes and copies; every update still pays one complete pack. No transfer bandwidth or end-to-end GPU speedup has been measured.',
            illustrative_saved_transfer_seconds_at_10_20_30_decimal_GB_per_second=[3*payload/(rate*10**9) for rate in (10,20,30)],
            illustrative_rates_are_assumptions_not_measurements=True,
            unmeasured_costs=['Persistent input fragmentation','Per-parent pack fill and finite binding checks',
                'Allocator pressure from17.422GB extra resident inputs','Reduced GPU sharing headroom'],
            priority='A short bounded transfer measurement is justified by the52.267GB avoided payload and unchanged math. A full-parent benchmark or another production restart is not yet justified by byte counts alone.'),
        bounded_GPU_proposal=dict(status='proposal_only_no_launch',
            first_stage='ROOT-owned fresh visible512-block,1153-hold authenticated observed prefix; original H2D copies versus one packed copy plus3hits. Alternate6rounds after one warmup, synchronize only whole measured phases, compare all copied values exactly outside timing. No TRAIN truth or optimizer required for this transfer measurement.',
            first_stage_caps=dict(native_holds=1153,holds_per_block=512,blocks=3,
                maximum_payload_bytes=512*2**20,soft_GPU_budget_bytes=24*GIB,
                complete_scratch_reserve_bytes=16*GIB,CPU_threads=8,max_wall_seconds=600),
            first_stage_go_no_go='Report cold-pack-inclusive total4pass time, lookup cost, source-validation cost, allocated/reserved peaks and transfer bytes. Do not use cached-hit-only timing as update speed. Advance only if a repeatable useful absolute saving survives all costs and preserved GPU headroom.',
            second_stage='Only after useful transfer evidence: original CPU-context explicit512 versus packed candidate on the same1153-hold restricted slice, same checkpoint/targets/RNG/AdamW, all49gradients and optimizer states, strict logits/loss/argmax comparison,6balanced timing rounds, full allocation telemetry and actual wait. CPU proof does not replace this.',
            final_stage='Only after independent bounded correctness/performance approval: one full TRAIN000/all10000targets comparison with payload cap18GiB,soft48GiB,scratch16GiB or stricter independently measured admission. No inference that other19parents fit.',
            production='Keep integrationv3/current worker unchanged. Any future migration needs separate release and warm-pool amortization; schedule qualification on an independently admitted spare lane. No combined first/forcing fusion claim.'),
        production_modified=False,GPU_launches=0,full_GPU_allocation_attempted=False)
    path=BASE/'HOT_BLOCK_PACK_ASSESSMENT_v2.json'
    with path.open('x') as stream:
        json.dump(report,stream,sort_keys=True,indent=2,allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(report_ref=c.file_ref(path),source_pins_ref=c.file_ref(pins),
        source_count=len(manifest['source_refs']),payload_bytes=payload,
        avoided_bytes=3*payload,nominal_allocated=payload+row['torch_peak_allocated_bytes'],
        nominal_reserved=payload+row['torch_peak_reserved_bytes'])))


if __name__=='__main__':main()
