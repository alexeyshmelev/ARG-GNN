"""Bounded mocked guardian review; never invokes Popen or a real process signal."""
import copy
import hashlib
import json
from pathlib import Path
from unittest.mock import Mock, patch
from research.efficiency_20261027.root import run_structural_comparison_v1 as g
from arggnn.benchmarking.paper_campaign import processes

ROOT = g.ROOT
OUT = ROOT / 'research/efficiency_20261027/execution/STRUCTURAL_GUARDIAN_V2_REVIEW.json'
checks = []

def check(name, function):
    function()
    checks.append(name)

def reject(function):
    try:
        function()
    except (ValueError, RuntimeError):
        return
    raise AssertionError('Expected rejection')

def admission_case(available, own=0, reserved=0, peer_error=False):
    with patch.object(g, 'campaign_growth', return_value=({'project_reserved_bytes':reserved}, 3*g.GIB, [])), patch.object(g, 'peer_growth', side_effect=RuntimeError('Unverified peer') if peer_error else None, return_value=(2*g.GIB, {'peer':'synthetic'})), patch.object(g, 'current_memory', return_value=available):
        return g.admission(['synthetic'], own)

def equal(a, b):
    assert a == b, (a, b)

required = (32+64+3+2)*g.GIB
check('exact_host_growth_boundary_accepted', lambda: equal(admission_case(required)['required_host_bytes'], required))
check('one_byte_host_deficit_rejected', lambda: reject(lambda: admission_case(required-1)))
check('owned_RSS_credited_only_at_resampling', lambda: equal(admission_case(required-7*g.GIB, 7*g.GIB)['required_host_bytes'], required))
check('project_ceiling_exact_accepted', lambda: equal(admission_case(required, reserved=995_000_000_000-g.OTHER_COMMITMENTS)['total_committed_storage_bytes'], 995_000_000_000))
check('project_ceiling_one_byte_excess_rejected', lambda: reject(lambda: admission_case(required, reserved=995_000_000_001-g.OTHER_COMMITMENTS)))
check('unverified_peer_rejected', lambda: reject(lambda: admission_case(required, peer_error=True)))

review_path = 'research/efficiency_20261027/independent_efficiency_challenge/STRUCTURAL_EPISODE_COMPARATOR_V1_SOURCE_REVIEW.json'
review = json.loads((ROOT/review_path).read_text())
manifest = review['source_manifest_ref']
contract_ref = g.file_ref(g.CONTRACT)
assert g.file_ref(Path(g.__file__))['sha256'] == '90b5c8432f3ee9163694599d03d136ae678a920e9fed2ac9cc3b7de78dbd1b39'
digest = g.file_ref(review_path)['sha256']
check('exact_independent_review_accepted', lambda: equal(g.verify_review(review_path,digest,manifest,contract_ref), g.file_ref(review_path)))
check('wrong_independent_review_hash_rejected', lambda: reject(lambda:g.verify_review(review_path,'0'*64,manifest,contract_ref)))
check('wrong_manifest_rejected', lambda: reject(lambda:g.verify_review(review_path,digest,dict(manifest,sha256='0'*64),contract_ref)))
changed = copy.deepcopy(review)
changed['launch_contract_ref']['sha256'] = '0'*64
with patch.object(Path, 'read_text', return_value=json.dumps(changed)):
    check('changed_launch_contract_rejected', lambda: reject(lambda:g.verify_review(review_path,digest,manifest,contract_ref)))
with patch.object(processes,'session_members',return_value=[]):
    child = Mock(pid=123, poll=Mock(return_value=0))
    check('empty_owned_session_drain_true', lambda: equal(processes.drain(child,terminate=True),True))
with patch.object(processes,'session_members',return_value=[{'pid':123}]):
    check('nonterminating_drain_with_members_false', lambda: equal(processes.drain(Mock(pid=123),terminate=False),False))

refs = [g.file_ref(path) for path in [Path(g.__file__),ROOT/'research/efficiency_20261027/root/run_guarded_profile_with_peer.py',Path(processes.__file__),ROOT/'src/arggnn/benchmarking/paper_campaign/runtime.py',g.CONTRACT,ROOT/review_path]]
report = dict(schema='TreeLoom_structural_guardian_independent_review_v2',passed=True,source_refs=refs,checks=checks,checks_passed=len(checks),heavy_run_launched=False,real_processes_started=0,real_processes_signaled=0,findings=[],closed_findings=['Exact contract is now captured as one byte string, bound to reviewed launch_contract_ref and rechecked immediately before Popen'],clarifications=['drain(terminate=True) returns True or raises; ignored return does not attest failure as success','Project 16MiB diagnostic output stays inside existing512MiB efficiency allowance; existing16GiB shortVAL and2GiB cohort commitments remain charged','A child-exit race during identity/psutil reads can cause conservative diagnostic failure; it cannot produce scientific success'])
with OUT.open('x') as stream:
    json.dump(report,stream,indent=2,sort_keys=True)
    stream.write('\n')
print(json.dumps(dict(path=str(OUT.relative_to(ROOT)),sha256=hashlib.sha256(OUT.read_bytes()).hexdigest(),passed=report['passed'],checks_passed=len(checks))))
