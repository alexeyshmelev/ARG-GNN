"""CPU-only composition runner qualification, including controlled failure injection."""
import os
os.environ["CUDA_VISIBLE_DEVICES"] = ""
import ast
import importlib
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import torch
from research.efficiency_20261027.execution.compare_explicit_resident_vjp import (
    KINDS, GIB, MemoryProfile, compare_state, resident_admission, slice_schedule,
    failure_record, run_update, ref, write)
from research.efficiency_20261027.execution.test_full_context_runner import FakeCUDA


class FakeDevice(FakeCUDA):
    fail_sync = False
    def mem_get_info(self):
        return 80*GIB-self.reserved, 80*GIB
    def synchronize(self):
        if self.fail_sync:
            raise RuntimeError("Injected telemetry synchronization failure")
    def empty_cache(self):
        pass


def main():
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    folder = Path("research/efficiency_20261027/execution")
    runner = folder/"compare_explicit_resident_vjp.py"
    ast.parse(runner.read_text())
    ast.parse(Path(__file__).read_text())
    output = folder/"explicit_resident_runner_CPU_test"
    output.mkdir(exist_ok=False)
    schedule = slice_schedule(6)
    assert len(schedule) == 8
    timed = [order for phase, repeat, order in schedule if phase == "slice_timed"]
    assert len(set(timed)) == 6
    assert all(sum(order[position] == kind for order in timed) == 2
        for position in range(3) for kind in KINDS)
    assert len(slice_schedule(12)) == 14
    for repeats in (5, 8, 10):
        try:
            slice_schedule(repeats)
        except ValueError:
            pass
        else:
            raise AssertionError("Unbalanced schedule accepted")
    admission = resident_admission(77472, 80*GIB, 64*GIB, 8)
    assert admission["two_context_buffers_bytes"] == 31732531200
    assert admission["rounded_context_budget_bytes"] == 32*GIB
    assert admission["required_free_and_soft_budget_bytes"] == 40*GIB
    rejected = []
    for free, budget, reserve in ((80,39,8), (39,64,8), (80,64,7)):
        try:
            resident_admission(77472, free*GIB, budget*GIB, reserve)
        except ValueError:
            rejected.append((free,budget,reserve))
        else:
            raise AssertionError("Insufficient full residency admission accepted")
    assert len(rejected) == 3
    assert resident_admission(128, 8*GIB, 8*GIB, 1)["context_bytes"] == 26214400
    probe = dict(logits=torch.tensor([[.1,.2,.3]]), loss=torch.tensor(.7),
        gradients={str(i):torch.tensor([.1]) for i in range(49)},
        parameters={str(i):torch.tensor([.2]) for i in range(49)},
        moments={str(i):dict(step=torch.tensor(242.), exp_avg=torch.tensor([.01]),
            exp_avg_sq=torch.tensor([.001])) for i in range(49)})
    same = compare_state(probe, probe)
    assert same["passed"]
    assert same["categories"]["gradients"]["tensors"] == 49
    assert same["categories"]["moments"]["tensors"] == 147
    wrong = dict(probe, gradients=dict(probe["gradients"], **{"0":torch.tensor([.1002])}))
    assert not compare_state(probe, wrong)["passed"]
    tie = dict(probe, logits=torch.tensor([[.1,.2,.2]]))
    changed = dict(tie, logits=torch.tensor([[.1,.2,.2000001]]))
    mismatch = compare_state(tie, changed)
    assert mismatch["categories"]["logits"]["passed"] and not mismatch["passed"]
    fake = FakeDevice()
    profile = MemoryProfile(SimpleNamespace(cuda=fake), lambda stage:None,
        journal=output/"stage_memory.jsonl", identity=dict(test="allocator"),
        GPU_budget_bytes=1024)
    with profile.stage("profile_context_forward"):
        fake.set_usage(100,200)
        with profile.stage("_second"):
            fake.set_usage(250,400)
        fake.set_usage(80,150)
    with profile.stage("profile_decoder_forward_backward"):
        fake.set_usage(200,300)
        fake.set_usage(180,250)
    assert fake.resets == 2 and profile.run_reserved_peak == 400
    try:
        with profile.stage("profile_transient_budget"):
            fake.set_usage(500,1200)
            fake.set_usage(100,200)
    except ValueError:
        pass
    else:
        raise AssertionError("Transient reserved peak was accepted")
    assert not profile.top_active and profile.run_reserved_peak == 1200
    OOM = torch.cuda.OutOfMemoryError
    injected = OOM("Injected controlled CPU test OOM")
    try:
        with profile.stage("profile_injected_OOM"):
            raise injected
    except OOM as error:
        assert error is injected
    else:
        raise AssertionError("OOM swallowed")
    assert profile.memory_stages[-1]["error"]["CUDA_OOM"]
    assert not profile.memory_stages[-1]["completed"]
    try:
        with profile.stage("profile_OOM_and_failed_telemetry"):
            fake.fail_sync = True
            raise injected
    except OOM as error:
        assert error is injected
    else:
        raise AssertionError("Primary OOM replaced or swallowed")
    fake.fail_sync = False
    assert profile.memory_stages[-1]["after"] is None
    assert "Injected telemetry" in profile.memory_stages[-1]["telemetry_error"]
    assert len(profile.wall_stages) == 5 and not profile.top_active
    assert len((output/"stage_clock.jsonl").read_text().splitlines()) == 5
    for name in (
        "research.scalability_20261024.integration.executors",
        "research.efficiency_20261027.execution.explicit_resident_vjp",
        "research.efficiency_20261027.root.context_residency",
        "research.benchmark_rebuild_20261024.american.treeloom_speed.decoder_v2",
        "research.repairs.TreeLoom_lazy_compact_prefetch_20261024_v1.training"):
        importlib.import_module(name)
    fake2 = FakeDevice()
    def fail_model():
        fake2.set_usage(128,256)
        raise OOM("Injected model construction OOM")
    args = SimpleNamespace(gpu_memory_gib=8, minimum_free_reserve_gib=1)
    assert not torch.cuda.is_initialized()
    with patch.object(torch, "cuda", fake2):
        try:
            run_update("explicit_resident_vjp", "injected_failure", 0, args,
                SimpleNamespace(build_model=fail_model), {},
                SimpleNamespace(native_holds=128), {}, None, None, None,
                lambda stage:None, output)
        except OOM:
            pass
        else:
            raise AssertionError("run_update swallowed injected OOM")
    assert not torch.cuda.is_initialized()
    receipt_path=output/"failed_update_explicit_resident_vjp_injected_failure_0.json"
    failure=json.loads(receipt_path.read_text())
    assert failure["CUDA_OOM"] and failure["partial_receipts_preserved"]
    assert not failure["retry_attempted"]
    assert failure["identity"]["kind"] == "explicit_resident_vjp"
    assert len(failure["stages"]["stage_wall_clock"]) == 2
    result = dict(schema="TreeLoom_explicit_resident_runner_CPU_qualification_v1", status="pass",
        CUDA_initialized=False, source_refs=[ref(runner),ref(__file__)],
        strict_49_gradient_and_147_moment_comparator=True,
        gradient_and_within_tolerance_argmax_mismatches_rejected=True,
        six_permutations_each_position_twice=True,
        full_minimum_context_budget_bytes=32*GIB, full_minimum_scratch_bytes=8*GIB,
        full_minimum_total_bytes=40*GIB, full_insufficient_memory_rejections=len(rejected),
        stage_peaks_and_clocks=True, transient_reserved_peak_rejected=True,
        primary_OOM_preserved_on_telemetry_failure=True,
        injected_update_OOM_failure_receipt_ref=ref(receipt_path),
        no_automatic_retry=True,
        scope="CPU fake allocator, controlled OOM exceptions and strict comparator only. No actual GPU allocation, observations, targets, checkpoint or training update.")
    write(output/"completed.json",result)
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()

