"""Metadata-only actual TRAIN000 inventory; no tensor/model/GPU allocation."""
from pathlib import Path
import hashlib
import json
import math

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
BASE=ROOT/'research/efficiency_20261027/execution'
META=ROOT/'research/preprocessing_optimization_20261026/integration/full_candidate.json'
WIDTHS=dict(int64=8,int32=4,float32=4,uint8=1,int8=1,bool=1,float64=8)


def ref(path):
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def entries(value,prefix):
    if isinstance(value,dict) and 'shape' in value and 'dtype' in value:
        return [dict(path=prefix,dtype=value['dtype'],shape=value['shape'],
            bytes=math.prod(value['shape'])*WIDTHS[value['dtype']],tensor_sha256=value['sha256'])]
    if isinstance(value,list):
        return [row for i,item in enumerate(value) for row in entries(item,prefix+'.'+str(i))]
    if isinstance(value,dict):
        return [row for key,item in value.items() for row in entries(item,prefix+'.'+key)]
    return []


def main():
    metadata=json.loads(META.read_text())
    bundle=metadata['bundle']
    rows=entries(bundle,'bundle')
    bank=bundle['bank']
    n=bank['parent']['shape'][0]
    holds,haplotypes=bank['sample_index']['shape']
    sites=bank['genotype']['shape'][0]
    size=lambda name:sum(row['bytes'] for row in entries(bank[name],name))
    block_fields=('parent','node_time','sample_index','upward_levels','upward_children',
        'upward_parent_rank','downward_levels','edge_geometry','branch_support_true','spans')
    shared_fields=('reference_class','sample_age')
    site_fields=('genotype','log_donor_allele_frequency','donor_call_mask','panel_allele_frequency','site_entropy')
    topology=('parent','sample_index','upward_levels','upward_children','upward_parent_rank','downward_levels')
    block_bytes=sum(size(name) for name in block_fields)
    site_bytes=sum(size(name) for name in site_fields)
    shared_bytes=sum(size(name) for name in shared_fields)
    member_count=bundle['episodes']['member_node']['shape'][0]
    reps=bundle['cut']['representatives']['shape'][0]
    second_static_float_flags=8*n+8*member_count+8*reps
    fullhot=block_bytes+site_bytes+shared_bytes+second_static_float_flags
    context=holds*haplotypes*32*4
    group_totals={name:sum(row['bytes'] for row in entries(bundle[name],name)) for name in ('bank','episodes','cut')}
    source=ROOT/'research/efficiency_20261027/root/runs/explicit_full_gpu5_v1/data/completed.json'
    full=json.loads(source.read_text())
    explicit=next(row for row in full['records'] if row['kind']=='explicit_vjp')
    result=dict(schema='TreeLoom_actual_TRAIN000_static_input_inventory_v1',status='metadata_inventory_complete_no_residency_admission',
        source_refs=[ref(META),ref(source),ref(Path(__file__).resolve()),ref(ROOT/'research/efficiency_20261027/fidelity/HOTPATH_TRANSFER_SYNCHRONIZATION_REVIEW.json')],
        actual_dimensions=dict(native_nodes=n,native_holds=holds,haplotypes=haplotypes,sites=sites,members=member_count,cut_groups=reps),
        tensor_byte_rows=rows,original_tensor_totals=group_totals,total_original_bank_episode_cut_bytes=sum(group_totals.values()),
        hot_block_fields={name:size(name) for name in block_fields},shared_fields={name:size(name) for name in shared_fields},site_fields={name:size(name) for name in site_fields},
        one_full_pass_block_payload_bytes=block_bytes,
        four_pass_block_H2D_payload_lower_bound_bytes=4*block_bytes,
        four_pass_site_H2D_payload_lower_bound_bytes=4*site_bytes,
        shared_reference_age_bytes=shared_bytes,
        selected512_blocks=math.ceil(holds/512),selected512_repeated_block_site_base_calls=4*math.ceil(holds/512),
        exact_width_resident_hot_pack_bytes=fullhot,
        exact_width_resident_second_fields=dict(node_flags_FP32=8*n,relative_member_nodes_int64=8*member_count,relative_cut_representatives_int64=8*reps),
        unused_sham_branch_bytes=size('branch_support_sham'),
        theoretical_int32_topology_storage_bytes=sum(size(name)//2 for name in topology),
        theoretical_int32_note='Not a qualified compute representation: current kernels/guards consume int64. Compact host transfer plus device conversion needs its own transient budget and qualification.',
        optional_static_degree_FP32_bytes=4*n,optional_node_feature_FP32_3_bytes=12*n,
        optional_categorical_chosen_int64_bytes=8*sites*haplotypes,
        optional_categorical_called_bool_bytes=sites*haplotypes,
        GPU64GiB_budget_bytes=64*2**30,one_complete_context_bytes=context,two_context_bytes=2*context,
        original_all_input_tensors_plus_two_context_bytes=sum(group_totals.values())+2*context,
        hot_pack_plus_two_context_bytes=fullhot+2*context,
        headroom_after_hot_pack_and_two_context_bytes=64*2**30-fullhot-2*context,
        illustrative_hotpack_two_context_plus_measured128_CPU_context_peak_bytes=fullhot+2*context+explicit['torch_peak_allocated_bytes'],
        illustrative_unallocated_margin_bytes=64*2**30-fullhot-2*context-explicit['torch_peak_allocated_bytes'],
        measured128_peak_ref=ref(source),measured128_peak_allocated_bytes=explicit['torch_peak_allocated_bytes'],
        selected512_full_peak_available=False,
        limitations=['Byte rows derive from authenticated actual full observed TRAIN000 shape/dtype/hash metadata. Tensor payloads were not regenerated in this audit.',
            'One-pass block bytes sum exact payload widths; repeated shared arrays, site chunks straddling block boundaries, transfer staging, allocator padding, PyG edge_index creation and temporary conversions add bytes.',
            'A cache of every original input is unnecessarily large; staged execution uses neither sham branch support nor most legacy cut recipes.',
            'Adding separate measured peaks overcounts some overlapping block tensors but does not bound a new execution schedule. Full resident/512 allocated+reserved measurements and scratch admission are still required.',
            'No whole-parent device pack is admitted by nominal arithmetic. The64GiB bound includes learned activations, context/VJP, optimizer, scratch and fragmentation.',
            'Immutable CPU index preparation is low memory risk, but static call counts do not establish a speedup. Four learned base/site/gate computations must remain connected to current parameters.'],
        recommendation='First prepare a small immutable CPU site/index plan and measure setup cost. Stage bounded exact-width block packs unless the measured selected resident peak plus truly incremental static residency and scratch fits64GiB. No level-local sweep rewrite.',
        GPU_launched=False,full_GPU_allocation_attempted=False,model_executed=False,truth_opened=False)
    out=BASE/'static_input_inventory_v1.json'
    with out.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('original_tensor_totals','one_full_pass_block_payload_bytes','four_pass_block_H2D_payload_lower_bound_bytes','exact_width_resident_hot_pack_bytes','hot_pack_plus_two_context_bytes','headroom_after_hot_pack_and_two_context_bytes','illustrative_unallocated_margin_bytes')},indent=2))


if __name__=='__main__':main()
