"""Reviewable pending release and assessment;never submit or deploy a task."""
import copy
import json
from pathlib import Path
from arggnn.benchmarking import contracts as c
from .configuration_combined_v5 import EXPECTED,PINS
from .envelope_combined_v5 import resource_declaration,PREDECESSOR_JOB
from .qualification_combined_v5 import validate_router
HERE=Path(__file__).parent


def put(name,value):
    path=HERE/name
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    return c.file_ref(path)


def main():
    source_ref=c.file_ref(PINS)
    router=dict(source_manifest_ref=c.file_ref('research/efficiency_20261027/architecture/qualified_residency_router/source_pins_v1.json'),
        independent_source_review_ref=c.file_ref('research/efficiency_20261027/fidelity/QUALIFIED_CPU_CONTEXT_ROUTER_V1_SOURCE_REVIEW.json'),
        CPU_contracts_ref=c.file_ref('research/efficiency_20261027/architecture/qualified_residency_router/CPU_RESULTS_v1.json'))
    validate_router(router)
    value=c.read_json(HERE/'COMBINED_RELEASE_TEMPLATE_v4.json')
    value['source_pins_ref']=source_ref;value['configuration']=dict(EXPECTED);value['qualified_router']=router
    value['resource_declaration']=resource_declaration(c.read_json(PREDECESSOR_JOB),c.file_ref(PREDECESSOR_JOB))
    value['acceptance'].update(capacity_route_before_forward_required=True,explicit_CPU512_fallback_qualified=True,no_mid_update_fallback=True)
    value['pending_artifacts']['independent_results_review_required_fields']['candidate_source_pins_ref']=source_ref
    value['status']='pending_actual_preparation_and_independent_combined_review'
    template_ref=put('COMBINED_RELEASE_TEMPLATE_v5.json',value)
    evidence={name:c.file_ref(HERE/name) for name in ('ROUTING_COMBINED_CPU_v5.json','CONTRACTS_COMBINED_CPU_v5.json',
        'SCHEDULER_RESTORE_COMBINED_CPU_v5.json')}
    assessment=dict(schema='TreeLoom_combined_candidate_assessment_v5',source_pins_ref=source_ref,
        status='CPU_passed_pending_independent_combined_source_and_real_preparation_results_review',
        inherited_v4_manifest_ref=c.file_ref(HERE/'source_pins_combined_v4.json'),qualified_router=router,CPU_evidence=evidence,
        pending_release_template_ref=template_ref,configuration=dict(EXPECTED),
        change='Before learned forward,select already qualified upward/direct residentCPU512 when actual nodes and live capacity fit;otherwise already qualified explicitCPU512. Record actual route per complete parent.',
        numerical_body='train_step AST equal after only two capacity kwargs and one receipt field;run_training/build_spec/loop/restore/RNG functions AST equal to v4',
        scientific_protocol='Original model,loss,all20 TRAIN parents,600update schedule,target registry and fixedfinal30 unchanged',
        operational_envelope='768GiB outer/main,CPU8,80GiB layout,352GiB compactpool,128GiB prep+training reserves,2producersx4workers,76GiB scheduler admission unchanged',
        route_limits='74GiB soft allocation screen and16GiB scratch;actual allocator/fragmentation peak is not proven for every parent;existing stage and outer resource guards remain mandatory',
        no_async_monitor_rewrite=True,no_prefetch_sweep=True,no_mid_update_OOM_retry=True,
        current_ROOT_peers_and_then_latest_checkpoint_required=True,exact_preparation_v2_terminal_evidence_required=True,
        one_fixed_order_preparation_pair_limitation_retained=True,production_modified=False,GPU_or_native_launch=False)
    assessment_ref=put('ASSESSMENT_COMBINED_v5.json',assessment)
    print(json.dumps(dict(source_manifest_ref=source_ref,template_ref=template_ref,assessment_ref=assessment_ref,CPU_evidence=evidence)))

if __name__=='__main__':main()
