"""Independent bounded source checks and rerun of the sealed CPU-only contracts."""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from research.efficiency_20261027.execution.european_short_val_runner import test_contracts_cpu_v3 as tests
from research.efficiency_20261027.execution.european_short_val_runner import contracts_v3 as c

root = Path.cwd()
out = root / 'research/efficiency_20261027/independent_efficiency_challenge/shortval_v3_review'
base = root / 'research/efficiency_20261027/execution/european_short_val_runner'
manifest_ref = c.ref(base / 'source_pins_v3.json')
assert manifest_ref['sha256'] == '55d1befb175122ce198a505e11398edc8f422ff8709134216902b819d5bcc36f'
manifest = c.read(manifest_ref)
prior = c.read(manifest['previous_candidate_ref'])
original = c.read(manifest['original_v3_source_manifest_ref'])
original_review = c.read(manifest['original_v3_source_review_ref'])
assert original_review['passed']
assert original_review['source_manifest_ref'] == manifest['original_v3_source_manifest_ref']
key = lambda item: (item['path'], item['sha256'])
current_refs = {key(item) for item in manifest['source_refs']}
assert {key(item) for item in prior['source_refs']} <= current_refs
assert {key(item) for item in original['source_refs']} <= current_refs
verified, inherited_large = [], []
for item in manifest['source_refs']:
    path = root / item['path']
    assert path.is_file() and not path.is_symlink() and path.resolve() == path
    if path.stat().st_size > 8 * 2**20:
        assert key(item) in {key(ref) for ref in original['source_refs']}
        assert path.name == 'inference.json'
        inherited_large.append(dict(item, bytes=path.stat().st_size))
    else:
        assert c.ref(path) == item, item['path']
        verified.append(item)

def stage_ast(path):
    tree = ast.parse(path.read_text())
    return ast.dump(next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'run_stages'))
assert stage_ast(base/'worker_v2.py') == stage_ast(base/'worker_v3.py')
assert c.ROOT_STATUS_MAX_AGE_SECONDS == 120 and c.GROWTH_INTERVAL_SECONDS == 30
fixture = out/'cpu_fixture_v1'
fixture.mkdir()
tests.release_tests()
tests.family_tests()
tests.runtime_gate_tests(fixture)
tests.stage_wiring_tests(fixture)
tests.retained_allowance_tests(fixture)
config, tools, chain = c.native_bindings()
assert len(tools) == 7 and 'torch' not in sys.modules
assert not c.AGGREGATE.exists()
result = dict(schema='independent_shortVAL_v3_review_checks_v1', passed=True,
    created_utc=datetime.now(timezone.utc).isoformat(), source_manifest_ref=manifest_ref,
    checks=tests.RESULTS, check_count=len(tests.RESULTS),
    hash_verified_refs_count=len(verified), inherited_large_refs_not_reread=inherited_large,
    inherited_refs_reason='Unchanged prior independently verified stage metadata; no new scientific-data reread for this narrow orchestration review.',
    all_prior_and_209_stage_refs_preserved=True, run_stages_AST_identical=True,
    retained_attempt_ref=c.ref(c.RETAINED_REF_PATH),
    cpu_source_ref=c.ref(base/'test_contracts_cpu_v3.py'), native_chain_review_ref=chain,
    original_cpu_receipt_ref=c.ref(base/'CONTRACTS_CPU_v3.json'),
    no_torch_import=True, children_launched=False, generation_or_native_execution=False,
    scientific_aggregate_created=False)
with (out/'REVIEW_CHECKS_v1.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(dict(passed=True, checks=len(tests.RESULTS), hash_verified_refs=len(verified),
    inherited_large_refs=len(inherited_large), evidence_ref=c.ref(out/'REVIEW_CHECKS_v1.json')),indent=2))
