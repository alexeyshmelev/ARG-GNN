"""Bounded plain JSON control messages plus one SCM_RIGHTS descriptor; no pickle."""
import array
import json
import os
import socket
import struct
import time

MAX_METADATA = 64*2**20


def need(ok, message):
    if not ok:
        raise ValueError(message)


def send(sock, value, *, fd=None):
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    need(len(raw) <= MAX_METADATA, 'Existing compact metadata allowance')
    ancillary = [] if fd is None else [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', [fd]))]
    need(sock.sendmsg([b'F' if fd is not None else b'J'], ancillary) == 1, 'Control marker delivered')
    sock.sendall(struct.pack('!Q', len(raw)))
    sock.sendall(raw)


def _recv(sock, count, *, check, deadline):
    result = bytearray()
    while len(result) < count:
        check('producer_control_wait')
        need(time.monotonic() < deadline, 'Finite producer control deadline')
        try:
            block = sock.recv(min(count-len(result), 2**20))
        except socket.timeout:
            continue
        need(block, 'Producer control EOF before complete record')
        result.extend(block)
    return bytes(result)


def receive(sock, *, check, deadline):
    sock.settimeout(.2)
    fds = []
    try:
        while True:
            check('producer_control_wait')
            need(time.monotonic() < deadline, 'Finite producer control deadline')
            try:
                marker, ancillary, flags, _ = sock.recvmsg(1, socket.CMSG_SPACE(4))
                break
            except socket.timeout:
                pass
        for level, kind, data in ancillary:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                values = array.array('i')
                values.frombytes(data[:len(data)//values.itemsize*values.itemsize])
                fds.extend(values)
        need(not flags & socket.MSG_CTRUNC and marker in (b'F', b'J')
             and len(fds) == (1 if marker == b'F' else 0), 'Exactly the declared control descriptor')
        size = struct.unpack('!Q', _recv(sock, 8, check=check, deadline=deadline))[0]
        need(size <= MAX_METADATA, 'Bounded plain control metadata')
        value = json.loads(_recv(sock, size, check=check, deadline=deadline))
        if fds:
            os.set_inheritable(fds[0], False)
        return value, fds[0] if fds else None
    except BaseException:
        for fd in fds:
            os.close(fd)
        raise
