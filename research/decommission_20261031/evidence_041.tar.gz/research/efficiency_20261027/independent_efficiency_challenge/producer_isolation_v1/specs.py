"""Small explicit production specifications: immutable observed refs, never truth."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
from .wire import need

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')
INPUTS = {'observation_ref', 'focal_registry_ref', 'native_preparation_ref'}


def reference(value):
    need(type(value) is dict and set(value)=={'path','sha256'}
         and type(value['path']) is str and not Path(value['path']).is_absolute()
         and '..' not in Path(value['path']).parts
         and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None,
         'Explicit project-relative immutable metadata reference')
    return dict(value)


def build(*, parent_id, parent_registry_ref, input_refs, plan_ref, seal,
          external_arrays, compact_bound_bytes, source_manifest_ref, max_seconds=3600):
    need(type(parent_id) is str and re.fullmatch('[A-Za-z0-9_][A-Za-z0-9_.-]*',parent_id) is not None,
         'Registered safe parent identity')
    need(type(input_refs) is dict and set(input_refs)==INPUTS,
         'Exactly three observed references; no truth reference')
    refs={key:reference(value) for key,value in input_refs.items()}
    need(seal['parent_id']==parent_id and all(seal[key]==refs[key] for key in INPUTS)
         and re.fullmatch('[0-9a-f]{64}',seal['focal_identity_sha256']) is not None,
         'Exact frozen observed parent seal')
    need(type(external_arrays) is dict and set(external_arrays)=={'bank.genotype'},
         'Original external genotype binding required')
    external={key:reference(value) for key,value in external_arrays.items()}
    need(type(compact_bound_bytes) is int and 64*2**20 < compact_bound_bytes < 20*2**30
         and type(max_seconds) is int and 0 < max_seconds <= 3600,
         'Existing finite per-parent compact and CPU wall bounds')
    return dict(schema='TreeLoom_CPU_producer_spec_v1',parent_id=parent_id,
        coordinator_pid=os.getpid(),parent_registry_ref=reference(parent_registry_ref),
        input_refs=refs,plan_ref=reference(plan_ref),
        seal={key:copy.deepcopy(seal[key]) for key in ('parent_id','focal_identity_sha256',*sorted(INPUTS))},
        external_arrays=external,compact_bound_bytes=compact_bound_bytes,
        source_manifest_ref=reference(source_manifest_ref),max_seconds=max_seconds,
        phase_bytes=128*2**30,encoder_allowance_bytes=8*2**30,
        preparation_limits=dict(max_nodes=400000000,max_holds=100000,max_episode_payload_bytes=8*2**30))


def write(directory, value):
    """Caller owns an already-charged output directory; do not overwrite evidence."""
    directory=Path(directory)
    need(directory.is_absolute() and directory.resolve()==directory and directory.is_relative_to(ROOT)
         and directory.is_dir(),'Existing ordinary owned project output directory')
    need(re.fullmatch('[A-Za-z0-9_][A-Za-z0-9_.-]*',value['parent_id']) is not None,
         'Safe spec filename')
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    need(len(raw)<=2**20,'At most one MiB of CPU producer specification')
    path=directory/(value['parent_id']+'.CPU_producer.json')
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(raw).hexdigest())
