"""Fresh CPU interpreter backend; current coordinator owns all admission credits."""
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from research.efficiency_20261027.integration_candidate.european_short_development_val.native_supervisor_v3 import (
    process_table, signal_owned)
from . import codec, wire

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')
WORKER = 'research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.worker'
TINY_WORKER = 'research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.tiny_worker'


def producer_family(table, leader, known):
    """Exact generations and descendants only; siblings share our session."""
    result = {pid: table[pid] for pid, old in known.items()
              if pid in table and table[pid]['start'] == old['start']}
    current = table.get(leader['pid'])
    if current is not None and current['start'] == leader['start']:
        result[leader['pid']] = current
    changed = True
    while changed:
        changed = False
        for pid, row in table.items():
            if pid not in result and row['ppid'] in result:
                result[pid] = row
                changed = True
    return result


class CPUProducerBackend:
    """One invocation per already-admitted parent; no private scheduling or cache."""
    def __init__(self, *, specs, bundle_type, module=WORKER, maximum_seconds=3600):
        wire.need(module in (WORKER, TINY_WORKER), 'One fixed reviewed producer module')
        wire.need(type(maximum_seconds) is int and maximum_seconds > 0, 'Finite producer lifetime')
        self.specs, self.bundle_type = dict(specs), bundle_type
        self.module, self.seconds = module, maximum_seconds
        self.receipts = {}

    def __call__(self, parent, *, input_refs, external_arrays, bound, resource_check):
        reference = self.specs[parent]
        command = [sys.executable, '-B', '-m', self.module, '--control-fd']
        ours, theirs = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        command += [str(theirs.fileno()), '--spec', reference['path'], '--spec-sha256', reference['sha256']]
        environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1',
                           PYTHONPATH='src:.', OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='8', MKL_NUM_THREADS='8')
        for key in ('ARGGNN_PHYSICAL_GPU', 'ARGGNN_READABLE_GPU_FD',
                    'ARGGNN_MAX_CUDA_RESERVED_BYTES', 'ARGGNN_GPU_MEMORY_POLICY'):
            environment.pop(key, None)
        process = None
        leader = None
        known = {}
        record = None
        received_fd = None
        committed = False
        deadline = time.monotonic() + self.seconds
        last_family = -float('inf')
        def observe(stage):
            nonlocal last_family
            resource_check(stage)
            wire.need(time.monotonic() < deadline, 'Producer lifetime expired')
            if leader is not None and time.monotonic()-last_family >= 2:
                table = process_table()
                known.update(producer_family(table, leader, known))
                last_family = time.monotonic()
        try:
            resource_check('before_CPU_producer_spawn')
            # Inherit the training session/group so the existing outer session
            # supervisor continues to own every producer and encoder descendant.
            # No fork-with-live-CUDA Python execution or inherited GPU lease FD.
            process = subprocess.Popen(command, cwd=ROOT, env=environment,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                pass_fds=(theirs.fileno(),), close_fds=True, start_new_session=False)
            theirs.close()
            leader = process_table().get(process.pid)
            wire.need(leader is not None and leader['ppid'] == os.getpid(), 'Exact newly spawned CPU child')
            known[process.pid] = leader
            value, received_fd = wire.receive(ours, check=observe, deadline=deadline)
            wire.need(value.get('status') == 'ready' and received_fd is not None,
                      'Producer completed preparation and packing: ' + str(value.get('error')))
            wire.need(value.get('parent_id') == parent and value.get('pid') == process.pid
                      and value.get('CUDA_initialized') is False
                      and value.get('encoder_children_joined') is True,
                      'Exact CPU producer ready identity and completed encoder lifecycle')
            wire.need(value['record']['input_refs'] == input_refs
                      and {key: item['external_ref'] for key, item in value['record']['plan']['arrays'].items()
                           if 'external_ref' in item} == (external_arrays or {}),
                      'Original observed inputs and external genotype bindings')
            # receive_record owns/closes this descriptor even on validation failure.
            fd, received_fd = received_fd, None
            record = codec.receive_record(fd, value['record'], bundle_type=self.bundle_type,
                input_refs=input_refs, max_charge_bytes=bound, resource_check=resource_check)
            wire.send(ours, dict(status='ack', parent_id=parent, hashes=record['hashes']))
            while process.poll() is None:
                observe('CPU_producer_ACK_wait')
                time.sleep(.05)
            code = process.wait()
            table = process_table()
            family = producer_family(table, leader, known)
            wire.need(code == 0 and not family, 'Actual CPU producer exit zero and complete known family absence')
            self.receipts[parent] = dict(pid=process.pid, start_ticks=leader['start'],
                actual_wait=True, returncode=code, known_family_absent=True,
                memfd_sealed=True, ACK_before_exit=True, no_expanded_IPC=True,
                inherited_training_session=True, command=command)
            committed = True
            return record
        finally:
            try:
                theirs.close()
                ours.close()
                if received_fd is not None:
                    os.close(received_fd)
                if process is not None and not committed:
                    if leader is None:
                        process.terminate()
                        process.wait(timeout=10)
                    else:
                        # Reuse existing identity-bound recursive signaling. Never
                        # signal the shared training process group.
                        for signum, grace in ((signal.SIGTERM, 5), (signal.SIGKILL, 5)):
                            until = time.monotonic() + grace
                            while True:
                                table = process_table()
                                family = producer_family(table, leader, known)
                                known.update(family)
                                if not family:
                                    break
                                signal_owned(family, signum)
                                process.poll()
                                if time.monotonic() >= until:
                                    break
                                time.sleep(.05)
                            if not family:
                                break
                        if process.poll() is None:
                            process.wait(timeout=5)
                        # An abrupt unobserved descendant escape is a whole-task
                        # failure handled by the unchanged outer session supervisor;
                        # no failed backend can publish READY or resume training.
                    self.receipts[parent] = dict(pid=process.pid, actual_wait=process.poll() is not None,
                        returncode=process.returncode, published_ready=False, inherited_training_session=True,
                        whole_task_failure_requires_outer_session_cleanup=True)
            finally:
                if record is not None and not committed:
                    codec.close_record(record)
