"""Explicit synthetic-only child entrypoint used by bounded CPU transport tests."""
import argparse
import socket
from . import worker


def tiny_prepare(spec, check):
    from research.reviews.workflow_progress_diagnosis_20261018.treeloom.test_resident_pool_v2 import tiny
    check('tiny_fixture')
    if spec.get('synthetic_failure'):
        raise ValueError('Requested synthetic producer failure')
    return tiny(spec['parent_id'], spec['input_refs'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--control-fd', type=int, required=True)
    parser.add_argument('--spec', required=True)
    parser.add_argument('--spec-sha256', required=True)
    args = parser.parse_args()
    spec = worker.read_spec(args.spec, args.spec_sha256)
    worker.wire.need(spec.get('synthetic_only') is True, 'Explicit synthetic fixture only')
    worker.serve(socket.socket(fileno=args.control_fd), spec, prepare_callable=tiny_prepare)


if __name__ == '__main__':
    main()
