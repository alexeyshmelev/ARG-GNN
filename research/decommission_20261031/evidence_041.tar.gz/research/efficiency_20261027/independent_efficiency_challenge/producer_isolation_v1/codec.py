"""Original lossless compact recipe with one sealed anonymous memfd allocation."""
from dataclasses import fields
import copy
import fcntl
import mmap
import os
from pathlib import Path
import numpy as np
from research.reviews.workflow_progress_diagnosis_20261018.treeloom import resident_pool_v2 as original

codec = original.codec
need = original.need
from .linux_memfd import create as create_memfd, F_ADD_SEALS, F_GET_SEALS, SEALS
ALIGN = 64


def packed_layout(plan):
    need(type(plan['arrays']) is dict and 0 < len(plan['arrays']) <= 1024, 'Finite compact array descriptor map')
    # JSON object ordering must not change physical offsets across IPC.
    entries, offset = {}, 0
    for key, entry in sorted(plan['arrays'].items()):
        if 'alias' in entry or 'external_ref' in entry:
            continue
        need(type(entry['shape']) is list and all(type(n) is int and n >= 0 for n in entry['shape'])
             and not np.dtype(entry['stored_dtype']).hasobject, 'Ordinary numeric compact shape and dtype')
        offset = (offset + ALIGN - 1) // ALIGN * ALIGN
        size = int(np.prod(entry['shape'], dtype=object)) * np.dtype(entry['stored_dtype']).itemsize
        entries[key] = dict(offset=offset, bytes=size)
        offset += size
    return entries, max(1, offset)


def _fill(mapping, offset, source, entry, chunk_bytes, check, key):
    target = np.ndarray(source.shape, dtype=entry['stored_dtype'], buffer=mapping, offset=offset)
    flat = target.reshape(-1)
    for first, block in codec.chunks(source, chunk_bytes):
        check('pack_' + key)
        packed = block.astype(target.dtype, copy=False)
        need(np.array_equal(packed.astype(source.dtype), block),
             'Every compact RAM value must round-trip exactly')
        flat[first:first+len(block)] = packed
    target.flags.writeable = False
    return original.array_hash(target, chunk_bytes)


def pack_memfd_bundle(bundle, metadata, *, input_refs, external_arrays=None,
                      max_charge_bytes, resource_check=lambda stage: None):
    """Only the compact destination allocation differs; no expanded payload crosses IPC."""
    plan = codec.plan_cache(bundle.bank, bundle.episodes, bundle.cut,
        external_arrays=external_arrays, rebuild_indices=True)
    arrays, _ = codec.flatten(bundle.bank, bundle.episodes, bundle.cut)
    codec.integer_recipe(bundle.bank, arrays, {'bank': {}})
    outer = {}
    for field in fields(bundle):
        if field.name in ('bank', 'episodes', 'cut', *original.STAMPS):
            continue
        value = getattr(bundle, field.name)
        if field.name in original.OUTER_TENSORS:
            key = 'outer.' + field.name
            arrays[key] = value.detach().numpy()
            dtype = codec.packed_dtype(key, arrays[key], plan['io_chunk_bytes'])
            plan['arrays'][key] = dict(shape=list(arrays[key].shape), dtype=arrays[key].dtype.str,
                stored_dtype=dtype.str, expanded_bytes=arrays[key].nbytes)
            outer[field.name] = {'array': key}
        else:
            outer[field.name] = {'scalar': codec._plain(value)}
    entries, allocation = packed_layout(plan)
    payload = sum(item['bytes'] for item in entries.values())
    charge = allocation + 64*2**20
    need(type(max_charge_bytes) is int and charge <= max_charge_bytes,
         'One complete memfd compact record must fit its existing parent bound')
    resource_check('before_memfd_allocation')
    fd = create_memfd('TreeLoom_compact_parent')
    mapping = None
    try:
        os.ftruncate(fd, allocation)
        mapping = mmap.mmap(fd, allocation, flags=mmap.MAP_SHARED, prot=mmap.PROT_READ | mmap.PROT_WRITE)
        digests = {}
        for key, item in entries.items():
            resource_check('pack_' + key)
            digests[key] = _fill(mapping, item['offset'], arrays[key], plan['arrays'][key],
                                 plan['io_chunk_bytes'], resource_check, key)
        expanded = plan['expanded_tensor_bytes'] + sum(arrays['outer.'+name].nbytes for name in original.OUTER_TENSORS)
        wire = dict(schema='TreeLoom_memfd_compact_record_v1', plan=plan, entries=entries,
            allocation_bytes=allocation, hashes=digests, outer=outer,
            metadata=codec._plain(metadata), input_refs=copy.deepcopy(input_refs),
            external_stamps={key: list((Path(value['external_ref']['path']).stat().st_dev,
                Path(value['external_ref']['path']).stat().st_ino,
                Path(value['external_ref']['path']).stat().st_size,
                Path(value['external_ref']['path']).stat().st_mtime_ns))
                for key, value in plan['arrays'].items() if 'external_ref' in value},
            charged_bytes=charge, payload_bytes=payload, expanded_tensor_bytes=expanded,
            read_peak_upper_bound_bytes=expanded+256*bundle.bank.parent.numel()+64*2**20)
        # _fill retains no ndarray views. Close the last writable mapping before sealing.
        mapping.close()
        mapping = None
        fcntl.fcntl(fd, F_ADD_SEALS, SEALS)
        need(fcntl.fcntl(fd, F_GET_SEALS) & SEALS == SEALS, 'Kernel-enforced immutable memfd required')
        return fd, wire
    except BaseException:
        if mapping is not None:
            mapping.close()
        os.close(fd)
        raise


class MappingOwner:
    def __init__(self, fd, mapping):
        self.fd, self.mapping = fd, mapping
        self.closed = False

    def close(self):
        if not self.closed:
            self.mapping.close()
            os.close(self.fd)
            self.closed = True


def receive_record(fd, wire, *, bundle_type, input_refs, max_charge_bytes,
                   resource_check=lambda stage: None):
    """Consume one received FD; construct the exact original restore record locally."""
    mapping = None
    stored = {}
    try:
        need(wire.get('schema') == 'TreeLoom_memfd_compact_record_v1' and wire['input_refs'] == input_refs,
             'Exact complete observed input binding')
        entries, allocation = packed_layout(wire['plan'])
        need(entries == wire['entries'] and allocation == wire['allocation_bytes']
             and os.fstat(fd).st_size == allocation, 'Exact whole compact descriptor layout')
        need(wire['charged_bytes'] == allocation + 64*2**20 <= max_charge_bytes
             and wire['payload_bytes'] == sum(item['bytes'] for item in entries.values()),
             'Compact charge remains in the original parent reservation')
        need(fcntl.fcntl(fd, F_GET_SEALS) & SEALS == SEALS,
             'Reject unsealed or writable compact descriptor')
        mapping = mmap.mmap(fd, allocation, flags=mmap.MAP_SHARED, prot=mmap.PROT_READ)
        for key, item in entries.items():
            entry = wire['plan']['arrays'][key]
            resource_check('receive_' + key)
            array = np.ndarray(entry['shape'], dtype=entry['stored_dtype'], buffer=mapping, offset=item['offset'])
            array.flags.writeable = False
            need(original.array_hash(array, wire['plan']['io_chunk_bytes']) == wire['hashes'][key],
                 'Every received compact byte must authenticate: ' + key)
            stored[key] = array
        del array
        owner = MappingOwner(fd, mapping)
        record = {key: wire[key] for key in ('plan', 'hashes', 'outer', 'metadata', 'input_refs',
                  'charged_bytes', 'payload_bytes', 'expanded_tensor_bytes', 'read_peak_upper_bound_bytes')}
        record.update(stored=stored, buffer_ids={key: id(value) for key, value in stored.items()},
            external_stamps={key: tuple(value) for key, value in wire['external_stamps'].items()},
            bundle_type=bundle_type, mapping_owner=owner)
        return record
    except BaseException:
        stored.clear()
        if 'array' in locals():
            del array
        if mapping is not None:
            mapping.close()
        os.close(fd)
        raise


def close_record(record):
    """Call only after pool users have released the compact record."""
    record['stored'].clear()
    record['buffer_ids'].clear()
    record['mapping_owner'].close()
