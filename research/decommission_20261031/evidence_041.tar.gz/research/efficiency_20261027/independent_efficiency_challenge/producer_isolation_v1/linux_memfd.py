"""Linux memfd ABI compatibility for the project Python's limited os module."""
import ctypes
import fcntl
import os
import sys

if sys.platform != 'linux':
    raise RuntimeError('Sealed compact producer records require Linux')

# Linux UAPI: include/uapi/linux/fcntl.h and include/uapi/linux/memfd.h.
# The host headers confirm F_LINUX_SPECIFIC_BASE=1024 and offsets 9 and 10.
F_ADD_SEALS = getattr(fcntl, 'F_ADD_SEALS', 1033)
F_GET_SEALS = getattr(fcntl, 'F_GET_SEALS', 1034)
SEALS = (getattr(fcntl, 'F_SEAL_WRITE', 8) | getattr(fcntl, 'F_SEAL_GROW', 4)
         | getattr(fcntl, 'F_SEAL_SHRINK', 2) | getattr(fcntl, 'F_SEAL_SEAL', 1))
MFD_CLOEXEC = getattr(os, 'MFD_CLOEXEC', 1)
MFD_ALLOW_SEALING = getattr(os, 'MFD_ALLOW_SEALING', 2)


def create(name):
    flags = MFD_CLOEXEC | MFD_ALLOW_SEALING
    if hasattr(os, 'memfd_create'):
        return os.memfd_create(name, flags)
    # Call the named libc entrypoint directly; no executable payload or syscall
    # number guessing. A missing libc symbol is an explicit unsupported host.
    libc = ctypes.CDLL(None, use_errno=True)
    function = libc.memfd_create
    function.argtypes = [ctypes.c_char_p, ctypes.c_uint]
    function.restype = ctypes.c_int
    fd = function(name.encode('ascii'), flags)
    if fd < 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    os.set_inheritable(fd, False)
    return fd
