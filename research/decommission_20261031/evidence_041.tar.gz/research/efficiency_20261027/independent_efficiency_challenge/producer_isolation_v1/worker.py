"""One fresh CPU producer interpreter. No model, optimizer, truth or CUDA call."""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import socket
import time
from . import wire

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')


def read_ref(reference, maximum=64*2**20):
    path = ROOT / reference['path']
    wire.need(path.is_relative_to(ROOT) and path.resolve() == path and path.is_file() and not path.is_symlink()
              and path.stat().st_size <= maximum, 'Bounded immutable ordinary project metadata')
    raw = path.read_bytes()
    wire.need(hashlib.sha256(raw).hexdigest() == reference['sha256'], 'Exact metadata source hash')
    return json.loads(raw)


def read_spec(path, digest):
    spec = read_ref(dict(path=path, sha256=digest), maximum=2**20)
    wire.need(spec.get('schema') == 'TreeLoom_CPU_producer_spec_v1'
              and set(spec['input_refs']) == {'observation_ref', 'focal_registry_ref', 'native_preparation_ref'},
              'Only observed preparation references enter CPU producer')
    return spec


def prepare(spec, check):
    import torch
    from threadpoolctl import threadpool_limits
    from arggnn.american_c3_gnn_dataset_v1 import load_observation
    from research.benchmark_rebuild_20261024.american.treeloom_speed import runtime_v2 as fresh
    from research.efficiency_20261027.execution.adaptive_prefetch_v2 import EncoderCredits, CHILD_ALLOWANCE_BYTES
    from .bindings import install
    wire.need(not torch.cuda.is_initialized(), 'Fresh CPU interpreter has no CUDA state')
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    threads = threadpool_limits(limits=8)
    limits = spec['preparation_limits']
    wire.need(limits == dict(max_nodes=400000000, max_holds=100000, max_episode_payload_bytes=8*2**30)
              and spec['phase_bytes'] == 128*2**30 and spec['encoder_allowance_bytes'] == CHILD_ALLOWANCE_BYTES,
              'Original complete preparation and four-child memory reservations')
    registry = fresh.FreshParentRegistry.from_ref(spec['parent_registry_ref'])
    wire.need(registry.split_for(spec['parent_id']) == 'train', 'Original TRAIN-only producer')
    runtime = fresh.FreshTreeLoom(registry)
    credits = EncoderCredits(maximum_bytes=spec['phase_bytes']+spec['encoder_allowance_bytes'])
    binding_receipt = install(credits)
    credit = credits.acquire(spec['parent_id'])
    wire.need(credit is not None, 'Own CPU worker encoder allowance')
    refs = spec['input_refs']
    config = dict(native_preparation_ref=refs['native_preparation_ref'], class_order=list(fresh.CLASSES),
        expected_haplotypes=1600, reference_counts=[200, 200, 200],
        input_reference_class_mask=None, input_reference_sample_indices=None)
    try:
        with credits.owner(credit):
            state = load_observation(refs['observation_ref'], refs['focal_registry_ref'], config)
            bundle, metadata = runtime.prepare_observation(state, split='train', resource_check=check,
                **refs, **limits)
            del state
        plan = read_ref(spec['plan_ref'])
        seal = spec['seal']
        wire.need(bundle.parent_id == spec['parent_id'] and bundle.sequence_length_bp == 30000000
                  and bundle.bank.parent.device.type == 'cpu'
                  and bundle.native_holds == plan['native_holds']
                  and bundle.original_sites == plan['original_sites']
                  and bundle.focal_identity_sha256 == seal['focal_identity_sha256']
                  and all(getattr(bundle, key) == seal[key] for key in fresh.INPUT_REFS),
                  'Original complete frozen parent plan and observation seal')
        from research.preprocessing_optimization_20261026.integration.hooks import verify_bindings
        verify_bindings(binding_receipt)
        return bundle, metadata
    finally:
        credits.release(credit)


def serve(control, spec, *, prepare_callable=prepare):
    wire.need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and not any(key in os.environ for key in
        ('ARGGNN_PHYSICAL_GPU','ARGGNN_READABLE_GPU_FD','ARGGNN_MAX_CUDA_RESERVED_BYTES','ARGGNN_GPU_MEMORY_POLICY')),
        'CPU-only environment without inherited GPU lease')
    from .codec import pack_memfd_bundle
    import psutil
    import torch
    started = time.monotonic()
    def check(stage):
        wire.need(time.monotonic()-started < spec['max_seconds'], 'Finite CPU producer wall time')
        rss = int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
        wire.need(rss <= spec['phase_bytes'], 'Original producer preparation phase RSS bound')
        wire.need(os.getppid() == spec['coordinator_pid'], 'Actual owning coordinator remains alive')
    fd = None
    try:
        bundle, metadata = prepare_callable(spec, check)
        fd, record = pack_memfd_bundle(bundle, metadata, input_refs=spec['input_refs'],
            external_arrays=spec['external_arrays'], max_charge_bytes=spec['compact_bound_bytes'],
            resource_check=check)
        del bundle, metadata
        gc.collect()
        wire.need(not psutil.Process().children(recursive=True), 'Every original encoder child joined before READY')
        wire.send(control, dict(status='ready', parent_id=spec['parent_id'], pid=os.getpid(),
            CUDA_initialized=torch.cuda.is_initialized(), encoder_children_joined=True, record=record), fd=fd)
        reply, unexpected = wire.receive(control, check=check, deadline=started+spec['max_seconds'])
        if unexpected is not None:
            os.close(unexpected)
        wire.need(unexpected is None and reply == dict(status='ack', parent_id=spec['parent_id'], hashes=record['hashes']),
                  'Exact parent ACK after read-only map and all-byte authentication')
    except BaseException as error:
        try:
            wire.send(control, dict(status='error', error=repr(error), parent_id=spec['parent_id']))
        except (OSError, ValueError):
            pass
        raise
    finally:
        if fd is not None:
            os.close(fd)
        control.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--control-fd', type=int, required=True)
    parser.add_argument('--spec', required=True)
    parser.add_argument('--spec-sha256', required=True)
    args = parser.parse_args()
    wire.need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'Hide CUDA before scientific imports')
    spec = read_spec(args.spec, args.spec_sha256)
    wire.need(not spec.get('synthetic_only'), 'Production entrypoint cannot select a synthetic producer')
    pins = read_ref(spec['source_manifest_ref'])
    for reference in pins['source_refs']:
        path = ROOT / reference['path']
        wire.need(path.is_relative_to(ROOT) and path.resolve() == path and path.is_file() and not path.is_symlink(), 'Pinned ordinary source')
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(2**20), b''):
                digest.update(block)
        wire.need(digest.hexdigest() == reference['sha256'], 'Pinned producer source changed')
    serve(socket.socket(fileno=args.control_fd), spec)


if __name__ == '__main__':
    main()
