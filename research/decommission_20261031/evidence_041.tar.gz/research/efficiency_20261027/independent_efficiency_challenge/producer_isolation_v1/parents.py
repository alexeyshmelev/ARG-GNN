"""Only the producer backend changes; scheduling, cursor and admission are inherited."""
import gc
from research.efficiency_20261027.execution.adaptive_prefetch_v2 import AdaptiveCompactParents, need
from .codec import close_record


class IsolatedCompactParents(AdaptiveCompactParents):
    def __init__(self, *, produce_record, **kwargs):
        need(callable(produce_record), 'Explicit admitted isolated producer backend')
        self.produce_record = produce_record
        super().__init__(**kwargs)

    def _produce(self, parent, token, credit):
        try:
            self.governor.transfer(token)
            with self.lock:
                need(self.states[parent] == 'queued', 'Exactly one queued owner before preparation')
                self.states[parent] = 'preparing'
                self.preparations[parent] = 1
            self._producer_check('adaptive_parent_start')
            with self.credits.owner(credit):
                record = self.produce_record(parent, input_refs=self.inputs[parent],
                    external_arrays=self.external.get(parent), bound=self.bounds[parent],
                    resource_check=self._producer_check)
            need(record['charged_bytes'] <= self.bounds[parent], 'Actual compact charge exceeds sealed bound')
            gc.collect()
            self._producer_check('adaptive_parent_commit')
            with self.lock:
                need(self.states[parent] == 'preparing', 'Single complete preparation commit')
                self.records[parent] = record
                self.charged += record['charged_bytes']
                del self.pending[parent]
                need(self.charged + sum(self.pending.values()) <= self.maximum, 'Atomic compact charge cap')
                self.states[parent] = 'ready'
                detail = dict(parent_id=parent, parents=len(self.records),
                    compact_charged_bytes=record['charged_bytes'], pool_charged_bytes=self.charged,
                    disk_cache_bytes=0, expanded_bank_sent_over_IPC=False, sealed_memfd=True)
            self.event('compact_parent_ready', detail)
            return parent
        except BaseException as error:
            if 'record' in locals() and self.records.get(parent) is not record:
                close_record(record)
            with self.lock:
                self.states[parent] = 'failed'
                self.pending.pop(parent, None)
                if self.error is None:
                    self.error = error
            self.stop.set()
            raise
        finally:
            self.governor.release(token, credits=self.credits, credit=credit)

    def release_records_after_close(self):
        """Explicit final cleanup after inherited close has joined every producer."""
        need(self.closed and not self.governor.active and not self.credits.active,
             'No mapped compact record released while a producer or user is active')
        for record in self.records.values():
            close_record(record)
        self.records.clear()
        self.charged = 0
