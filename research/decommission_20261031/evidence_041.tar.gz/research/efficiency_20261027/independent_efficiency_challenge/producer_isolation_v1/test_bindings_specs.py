"""Tiny source-binding and immutable producer specification contract tests."""
import os
from pathlib import Path
import tempfile
import unittest
from . import bindings, specs, worker
from .test_cpu import BASE
from research.efficiency_20261027.execution.adaptive_prefetch_v2 import EncoderCredits


class BindingSpecTests(unittest.TestCase):
    def test_integer_binding_is_only_local_episode_replacement(self):
        from research.benchmark_rebuild_20261024.american.treeloom_speed import static_preparation_v2 as preparation
        from research.preprocessing_optimization_20261026.tree import episodes, cut
        from research.efficiency_20261027.execution.adaptive_encoder_hooks_v2 import coordinated_process4_encode_block
        from research.preprocessing_optimization_20261026.integration.hooks import verify_bindings
        original_arrays=episodes.build_clade_episode_arrays_v1
        credits=EncoderCredits(maximum_bytes=136*2**30)
        receipt=bindings.install(credits)
        self.assertIs(preparation.build_episodes,bindings.episodes_v1.build_episodes)
        self.assertIs(preparation.encode_block,coordinated_process4_encode_block)
        self.assertIs(preparation.prepare_cut_plan_v1,cut.prepare_cut_plan_v1)
        self.assertIs(episodes.build_clade_episode_arrays_v1,original_arrays)
        self.assertTrue(verify_bindings(receipt))
        self.assertEqual(len(receipt),6)
        self.assertFalse(credits.active)

    def values(self):
        ref=dict(path='research/tiny_metadata.json',sha256='1'*64)
        refs={key:dict(ref) for key in specs.INPUTS}
        return dict(parent_id='fresh_train_000',parent_registry_ref=ref,input_refs=refs,
            plan_ref=ref,seal=dict(parent_id='fresh_train_000',focal_identity_sha256='2'*64,**refs),
            external_arrays={'bank.genotype':ref},compact_bound_bytes=128*2**20,source_manifest_ref=ref)

    def test_spec_roundtrip_is_observed_only_bound_and_write_once(self):
        value=specs.build(**self.values())
        self.assertEqual(value['coordinator_pid'],os.getpid())
        self.assertEqual(value['phase_bytes'],128*2**30)
        self.assertEqual(value['encoder_allowance_bytes'],8*2**30)
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            reference=specs.write(Path(directory).resolve(),value)
            self.assertEqual(worker.read_spec(reference['path'],reference['sha256']),value)
            with self.assertRaises(FileExistsError):specs.write(Path(directory).resolve(),value)
            with self.assertRaises(ValueError):worker.read_spec(reference['path'],'0'*64)

    def test_truth_or_outside_reference_rejected_before_write(self):
        values=self.values()
        values['input_refs']['truth_ref']=values['plan_ref']
        with self.assertRaisesRegex(ValueError,'no truth'):specs.build(**values)
        with self.assertRaises(ValueError):specs.reference(dict(path='../outside.json',sha256='0'*64))
        with self.assertRaises(ValueError):specs.reference(dict(path='/tmp/outside.json',sha256='0'*64))


if __name__=='__main__':
    unittest.main(verbosity=2)
