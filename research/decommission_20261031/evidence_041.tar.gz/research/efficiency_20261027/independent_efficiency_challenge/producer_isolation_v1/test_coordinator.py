"""Tiny real-subprocess coordinator ordering, credit lifetime and failure tests."""
import tempfile
import threading
import time
import unittest
from .test_cpu import BASE, BOUND, fixtures, spec_file, TinyWholeParent, original
from . import backend, codec, parents
from research.efficiency_20261027.execution.adaptive_prefetch_v2 import AdaptiveMemoryGovernor, EncoderCredits


def pool_for(schedule, produce, *, check=lambda stage:None):
    governor=AdaptiveMemoryGovernor(maximum_bytes=2**40,rss_bytes=lambda:0,
        resource_check=check,reserve_bytes=128*2**30)
    credits=EncoderCredits(maximum_bytes=2**40, family_memory=lambda:dict(bytes=0,recursive_children=0))
    ids=set(schedule)
    return parents.IsolatedCompactParents(produce_record=produce, schedule=schedule,start_cursor=0,
        parent_bounds={parent:BOUND for parent in ids},input_refs={parent:fixtures(parent)[2] for parent in ids},
        external_arrays={},max_cache_bytes=BOUND*len(ids),governor=governor,credits=credits,
        resource_check=check,event=lambda name,value:None,
        prepare=lambda *args,**kwargs: (_ for _ in ()).throw(AssertionError('No thread preparation')))


def wait_until(predicate, timeout=60):
    end=time.monotonic()+timeout
    while not predicate():
        if time.monotonic()>=end:raise AssertionError('Bounded tiny coordinator wait')
        time.sleep(.01)


class CoordinatorTests(unittest.TestCase):
    def test_actual_children_out_of_order_one_preparation_and_durable_cursor(self):
        schedule=('fresh_train_000','fresh_train_001','fresh_train_002','fresh_train_001','fresh_train_000')
        release=threading.Event()
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            specs={parent:spec_file(directory,parent)[0] for parent in set(schedule)}
            actual=backend.CPUProducerBackend(specs=specs,bundle_type=TinyWholeParent,
                                             module=backend.TINY_WORKER,maximum_seconds=60)
            owners=[]
            def produce(parent,**kwargs):
                self.assertIn(128*2**30,pool.governor.active.values())
                self.assertIn(parent,pool.credits.active.values())
                record=actual(parent,**kwargs)
                owners.append(record['mapping_owner'])
                self.assertTrue(actual.receipts[parent]['actual_wait'])
                self.assertIn(parent,pool.credits.active.values())
                if parent==schedule[1]:self.assertTrue(release.wait(60))
                return record
            pool=pool_for(schedule,produce)
            try:
                for index,parent in enumerate(schedule):
                    bundle,metadata=pool.load(parent)
                    expected,expected_metadata,_=fixtures(parent)
                    self.assertEqual(original.exact_signature(bundle,metadata),
                                     original.exact_signature(expected,expected_metadata))
                    self.assertEqual(pool.cursor,index)
                    with pool.training_phase():
                        if index==0:
                            wait_until(lambda:pool.futures[schedule[2]].done())
                            self.assertFalse(pool.futures[schedule[1]].done())
                            self.assertEqual(pool.states[schedule[2]],'ready')
                            self.assertEqual(pool.cursor,0)
                            self.assertIn(schedule[1],pool.credits.active.values())
                            release.set()
                        pool.durable_checkpoint(parent=parent,completed_updates=index+1)
                self.assertEqual(pool.preparations,{parent:1 for parent in set(schedule)})
                self.assertEqual(pool.restorations,{'fresh_train_000':2,'fresh_train_001':2,'fresh_train_002':1})
                self.assertEqual(pool.cursor,len(schedule))
                self.assertEqual(len({receipt['pid'] for receipt in actual.receipts.values()}),3)
            finally:
                release.set()
                pool.close()
                self.assertFalse(pool.governor.active or pool.credits.active)
                pool.release_records_after_close()
                self.assertTrue(all(owner.closed for owner in owners))

    def test_precommit_failure_closes_mapping_and_releases_both_credits(self):
        captured=[]
        def produce(parent,**kwargs):
            bundle,metadata,refs=fixtures(parent)
            fd,wire=codec.pack_memfd_bundle(bundle,metadata,input_refs=refs,max_charge_bytes=BOUND)
            record=codec.receive_record(fd,wire,bundle_type=TinyWholeParent,input_refs=refs,max_charge_bytes=BOUND)
            captured.append(record['mapping_owner'])
            return record
        def check(stage):
            if stage=='adaptive_parent_commit':raise RuntimeError('Synthetic precommit failure')
        pool=pool_for(('fresh_train_000',),produce,check=check)
        try:
            with self.assertRaisesRegex(RuntimeError,'Synthetic precommit failure'):
                pool.load('fresh_train_000')
            self.assertEqual(pool.records,{})
            self.assertTrue(captured[0].closed)
            self.assertFalse(pool.governor.active or pool.credits.active)
        finally:
            pool.close()
            pool.release_records_after_close()


if __name__=='__main__':
    unittest.main(verbosity=2)
