"""Fresh-worker-local bindings; original encoder/cut and qualified integer stores."""
from research.efficiency_20261027.execution.adaptive_encoder_hooks_v2 import install_tree
from research.preprocessing_optimization_20261026.integration import hooks
from research.efficiency_20261027.independent_efficiency_challenge.episode_integer_vectorization import episodes_v1


def install(credits):
    receipt = install_tree(credits)
    owner = 'research.benchmark_rebuild_20261024.american.treeloom_speed.static_preparation_v2'
    original = 'research.preprocessing_optimization_20261026.tree.episodes'
    changed = hooks._install([(owner, 'build_episodes', original, 'build_episodes', episodes_v1.build_episodes)])
    combined = [row for row in receipt if (row['owner_module'], row['attribute']) != (owner, 'build_episodes')] + changed
    hooks.verify_bindings(combined)
    return combined
