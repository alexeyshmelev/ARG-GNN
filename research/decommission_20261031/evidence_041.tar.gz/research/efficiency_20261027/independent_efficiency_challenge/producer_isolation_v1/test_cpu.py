"""Tiny exact CPU codec/process tests. No scientific data, model or GPU execution."""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import fcntl
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import time
from unittest.mock import patch
import unittest
import numpy as np
import torch
from research.reviews.workflow_progress_diagnosis_20261018.treeloom.test_resident_pool_v2 import tiny, TinyWholeParent
from research.reviews.workflow_progress_diagnosis_20261018.treeloom import resident_pool_v2 as original
from research.efficiency_20261027.execution.adaptive_prefetch_v2 import AdaptiveCompactParents, AdaptiveMemoryGovernor, EncoderCredits
from . import codec, backend, parents

BASE = Path(__file__).parent
BOUND = 128*2**20


def fixtures(parent='fresh_train_000'):
    bundle, metadata = tiny(parent)
    refs = {key: getattr(bundle, key) for key in ('observation_ref','focal_registry_ref','native_preparation_ref')}
    return bundle, metadata, refs


def spec_file(directory, parent='fresh_train_000', failure=False):
    _, _, refs = fixtures(parent)
    value = dict(schema='TreeLoom_CPU_producer_spec_v1', synthetic_only=True, synthetic_failure=failure,
        parent_id=parent, coordinator_pid=os.getpid(), input_refs=refs, external_arrays={},
        phase_bytes=4*2**30, max_seconds=60, compact_bound_bytes=BOUND)
    path=Path(directory)/(parent+'.json')
    raw=(json.dumps(value,sort_keys=True)+'\n').encode()
    path.write_bytes(raw)
    return dict(path=str(path.relative_to(backend.ROOT)),sha256=hashlib.sha256(raw).hexdigest()),refs


class ExactMemfdTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def pack(self):
        bundle, metadata, refs = fixtures()
        before = original.exact_signature(bundle, metadata)
        fd, wire = codec.pack_memfd_bundle(bundle, metadata, input_refs=refs, max_charge_bytes=BOUND)
        return bundle, metadata, refs, before, fd, wire

    def test_exact_pack_restore_and_original_record_contract(self):
        bundle, metadata, refs, before, fd, wire = self.pack()
        old = original.pack_bundle(bundle, metadata, input_refs=refs)
        wire = json.loads(json.dumps(wire, sort_keys=True))
        record = codec.receive_record(fd, wire, bundle_type=TinyWholeParent,
                                     input_refs=refs, max_charge_bytes=BOUND)
        try:
            for key in ('plan','hashes','outer','metadata','input_refs','payload_bytes',
                        'expanded_tensor_bytes','read_peak_upper_bound_bytes','external_stamps'):
                self.assertEqual(old[key],record[key],key)
            restored, actual = original.restore_bundle(record,input_refs=refs,verify_integrity=True)
            self.assertEqual(before,original.exact_signature(restored,actual))
            restored.bank.node_time[0] = 987
            again, actual = original.restore_bundle(record,input_refs=refs)
            self.assertEqual(before,original.exact_signature(again,actual))
            self.assertTrue(all(not value.flags.writeable for value in record['stored'].values()))
        finally:
            codec.close_record(record)
        self.assertTrue(record['mapping_owner'].closed)

    def test_kernel_seals_prevent_write_growth_and_numpy_write_enable(self):
        _, _, refs, _, fd, wire = self.pack()
        self.assertEqual(fcntl.fcntl(fd,codec.F_GET_SEALS)&codec.SEALS,codec.SEALS)
        with self.assertRaises(OSError):os.write(fd,b'x')
        with self.assertRaises(OSError):os.ftruncate(fd,wire['allocation_bytes']+1)
        record=codec.receive_record(fd,wire,bundle_type=TinyWholeParent,input_refs=refs,max_charge_bytes=BOUND)
        try:
            with self.assertRaises(ValueError):record['stored']['bank.node_time'].flags.writeable=True
        finally:codec.close_record(record)

    def test_wrong_hash_closes_received_descriptor(self):
        _, _, refs, _, fd, wire = self.pack()
        wire['hashes']['bank.node_time']='0'*64
        with self.assertRaisesRegex(ValueError,'authenticate'):
            codec.receive_record(fd,wire,bundle_type=TinyWholeParent,input_refs=refs,max_charge_bytes=BOUND)
        with self.assertRaises(OSError):os.fstat(fd)

    def test_unsealed_descriptor_rejected(self):
        _, _, refs, _, fd, wire = self.pack()
        os.close(fd)
        unsealed=codec.create_memfd('tiny_unsealed')
        os.ftruncate(unsealed,wire['allocation_bytes'])
        with self.assertRaisesRegex(ValueError,'unsealed'):
            codec.receive_record(unsealed,wire,bundle_type=TinyWholeParent,input_refs=refs,max_charge_bytes=BOUND)
        with self.assertRaises(OSError):os.fstat(unsealed)

    def test_parent_bound_precedes_allocation(self):
        bundle,metadata,refs=fixtures()
        with self.assertRaisesRegex(ValueError,'parent bound'):
            codec.pack_memfd_bundle(bundle,metadata,input_refs=refs,max_charge_bytes=1)

    def test_new_CPU_process_ACK_wait_and_exact_restore(self):
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            spec,refs=spec_file(directory)
            producer=backend.CPUProducerBackend(specs={'fresh_train_000':spec},bundle_type=TinyWholeParent,
                                                module=backend.TINY_WORKER,maximum_seconds=60)
            record=producer('fresh_train_000',input_refs=refs,external_arrays={},bound=BOUND,resource_check=lambda stage:None)
            try:
                restored,metadata=original.restore_bundle(record,input_refs=refs)
                bundle,expected,_=fixtures()
                self.assertEqual(original.exact_signature(bundle,expected),original.exact_signature(restored,metadata))
                receipt=producer.receipts['fresh_train_000']
                self.assertNotEqual(receipt['pid'],os.getpid())
                self.assertEqual(receipt['returncode'],0)
                self.assertTrue(receipt['ACK_before_exit'] and receipt['known_family_absent'])
                self.assertFalse(torch.cuda.is_initialized())
            finally:codec.close_record(record)

    def test_child_failure_never_publishes_record(self):
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            spec,refs=spec_file(directory,failure=True)
            producer=backend.CPUProducerBackend(specs={'fresh_train_000':spec},bundle_type=TinyWholeParent,
                                                module=backend.TINY_WORKER,maximum_seconds=60)
            with self.assertRaisesRegex(ValueError,'Requested synthetic'):
                producer('fresh_train_000',input_refs=refs,external_arrays={},bound=BOUND,resource_check=lambda stage:None)
            receipt=producer.receipts['fresh_train_000']
            self.assertTrue(receipt['actual_wait'])
            self.assertFalse(receipt['published_ready'])

    def test_receive_cancellation_reaps_child_and_leaks_no_descriptor(self):
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            spec,refs=spec_file(directory)
            producer=backend.CPUProducerBackend(specs={'fresh_train_000':spec},bundle_type=TinyWholeParent,
                                                module=backend.TINY_WORKER,maximum_seconds=60)
            descriptors_before=set(os.listdir('/proc/self/fd'))
            def cancel(stage):
                if stage.startswith('receive_'):raise RuntimeError('Synthetic receive cancellation')
            with self.assertRaisesRegex(RuntimeError,'Synthetic receive'):
                producer('fresh_train_000',input_refs=refs,external_arrays={},bound=BOUND,resource_check=cancel)
            self.assertTrue(producer.receipts['fresh_train_000']['actual_wait'])
            self.assertEqual(set(os.listdir('/proc/self/fd')),descriptors_before)

    def test_family_selection_never_claims_shared_session_siblings(self):
        def row(pid,ppid,start):return dict(pid=pid,ppid=ppid,start=start,session=1,pgrp=1)
        leader=row(10,1,100)
        table={1:row(1,0,1),10:leader,11:row(11,10,101),20:row(20,1,102),21:row(21,20,103)}
        self.assertEqual(set(backend.producer_family(table,leader,{10:leader})),{10,11})
        table[10]=row(10,1,999)
        self.assertEqual(backend.producer_family(table,leader,{10:leader}),{})

    def test_coordinator_critical_methods_are_inherited_unchanged(self):
        for name in ('_submit','load','refill','training_phase','durable_checkpoint','close','_reap'):
            self.assertIs(getattr(parents.IsolatedCompactParents,name),getattr(AdaptiveCompactParents,name))


if __name__ == '__main__':
    unittest.main(verbosity=2)
