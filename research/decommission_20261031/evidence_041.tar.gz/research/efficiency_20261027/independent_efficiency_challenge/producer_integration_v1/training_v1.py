"""Isolated attempt8 successor: fresh CPU producers and reviewed async checks.

Numerical runtime, fixed schedule, checkpoint/RNG helpers and execution routing
are imported unchanged. No allocator flush, launch or active-source mutation.
"""
from contextlib import contextmanager
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import threading
import time
from types import MappingProxyType
from research.efficiency_20261027.integration_candidate import training_combined_v5 as original
from research.efficiency_20261027.integration_candidate.training_combined_v5 import (
    c, fresh, _need, _current_rss_bytes, _hash, SETTINGS, LIMITS, PASSES,
    train_loop, _optimizer_counts, validate_resume_checkpoint,
    validate_saved_state, validate_resume_metadata, schedule_identity,
    random_state, restore_random_state, write_json_replace,
    GovernedLayoutCache, GovernedLargeLayoutCache, LayoutMemoryGovernor,
    EncoderCredits, ExplicitFreshTreeLoom, ResourceTiming)
from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1 import specs as producer_specs
from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.backend import CPUProducerBackend
from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.parents import IsolatedCompactParents
from .lifecycle import execute

BASE = 'research/efficiency_20261027/independent_efficiency_challenge/'
PRODUCER_PINS = dict(path=BASE+'producer_isolation_v1/source_pins_v1.json',
    sha256='cb75e3433152aabe583f3aed91e0a37fcc939c88e9f825ed0551cf4d01d63c25')
PINS = BASE+'producer_integration_v1/source_pins_v1.json'
EXECUTION_VARIANT = original.EXECUTION_VARIANT+'_isolated_CPU_async_v1'


def requirements(configuration):
    value = original.requirements(configuration)
    pins = c.read_json(PINS)
    for reference in pins['source_refs']:
        _need(c.file_ref(reference['path']) == reference, 'Isolated successor source changed')
    value['source_refs'] += pins['source_refs'] + [c.file_ref(PINS)]
    value.update(execution_variant=EXECUTION_VARIANT, CPU_producer_processes=2,
        compact_transport='one_sealed_memfd_per_parent', integer_episode_binding='CPU_worker_only',
        async_scan_interval_after_completion_seconds=30, async_scan_freshness_seconds=120,
        same_AdaptiveCompactParents_coordinator=True, allocator_policy_unchanged=True)
    return value


def build_spec(**arguments):
    value = original.build_spec(**arguments)
    value['requirements'] = requirements(value['execution_configuration'])
    return value


def _validate_spec(spec):
    arguments = {key:spec[key] for key in ('parent_registry_ref','train_inputs','output_directory',
        'observation_cache_bytes','max_truth_uncompressed_bytes','resume_checkpoint_ref',
        'resume_evidence_ref','execution_configuration')}
    arguments.update({key:spec['memory_envelope'][key] for key in
        ('max_rss_bytes','preparation_headroom_bytes','training_headroom_bytes')})
    _need(spec == build_spec(**arguments), 'Exact isolated successor specification required')
    return fresh.FreshParentRegistry.from_ref(spec['parent_registry_ref'])


def run_training(spec, *, resource_check):
    result, monitor_receipt = execute(resource_check,
        lambda monitor, resources: _run_training(spec, resource_check=monitor, resources=resources))
    result['async_resource_checks'] = monitor_receipt
    # The monitor has joined and its final scan succeeded. Original callback
    # ownership returns exclusively to this caller for the final prospective write.
    path = c.contained_path(spec['output_directory'])/'training_completed.json'
    raw = (json.dumps(result, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()
    resource_check(len(raw))
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    result['completion_ref'] = c.file_ref(path)
    return result


def _run_training(spec, *, resource_check, resources):
    """Exact saved-update continuation inside the current admitted GPU3/4/5 worker."""
    _need(callable(resource_check), "Current worker resource callback required")
    resource_check("TreeLoom_before_fresh_training")
    registry = _validate_spec(spec)
    worker_resource_check = resource_check
    pool_guard = [None]
    event_lock = threading.RLock()
    monitor_timing = ResourceTiming()
    def resource_check(*args, **kwargs):
        # Failure checks do not inspect/wait on futures under any callback lock.
        if pool_guard[0] is not None:
            pool_guard[0].raise_if_failed()
        # The reviewed monitor exclusively owns the original callback while active.
        # Ordinary callbacks do not acquire a shared scan lock; own RSS stays cheap.
        began = time.perf_counter()
        outer_finished = None
        try:
            worker_resource_check(*args, **kwargs)
            outer_finished = time.perf_counter()
            _need(_current_rss_bytes() <= spec["memory_envelope"]["max_rss_bytes"],
                  "Declared training process RSS cap exceeded")
        finally:
            finished = time.perf_counter()
            outer_end = finished if outer_finished is None else outer_finished
            monitor_timing.record(args[0] if args else "unspecified",
                0., outer_end-began, finished-outer_end)
    resource_check("TreeLoom_explicit_RSS_envelope")
    _need(os.environ.get("ARGGNN_PHYSICAL_GPU") in ("3", "4", "5")
          and os.environ.get("CUDA_VISIBLE_DEVICES", "").startswith("GPU-")
          and "," not in os.environ["CUDA_VISIBLE_DEVICES"]
          and os.environ.get("ARGGNN_GPU_MEMORY_POLICY") == "full_device",
          "One ROOT-verified visible physicalGPU3/4/5 UUID and full-device policy required")
    out = c.contained_path(spec["output_directory"])
    out.mkdir()
    (out/"plans").mkdir()
    (out/"checkpoints").mkdir()
    (out/"CPU_producer_specs").mkdir()
    for name in ("TMPDIR","TMP","TEMP","XDG_CACHE_HOME","TORCH_HOME","TRITON_CACHE_DIR","CUDA_CACHE_PATH"):
        path=out/(".tmp" if name in ("TMPDIR","TMP","TEMP") else ".cache/"+name.lower())
        path.mkdir(parents=True,exist_ok=True);os.environ[name]=str(path)
    tempfile.tempdir=str(out/".tmp")
    os.environ["CUDA_CACHE_MAXSIZE"]=str(16*2**20)
    import setproctitle
    setproctitle.setproctitle("AI Auto Research Pipeline Test")
    import torch
    from arggnn.american_c3_gnn_train_v1 import _cpu_snapshot
    _need(torch.cuda.device_count() == 1, "One admitted visible GPU3/4/5 required")
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    layout_governor = LayoutMemoryGovernor(
        maximum_bytes=spec["memory_envelope"]["max_rss_bytes"],rss_bytes=_current_rss_bytes,
        resource_check=resource_check,reserve_bytes=max(
            spec["memory_envelope"]["preparation_headroom_bytes"],
            spec["memory_envelope"]["training_headroom_bytes"]))
    child_credits = EncoderCredits(maximum_bytes=spec["memory_envelope"]["max_rss_bytes"])
    # All preparation hooks now live solely in the fresh CPU worker.
    selected = spec["execution_configuration"]
    cache_class = GovernedLayoutCache if selected["holds_per_block"]==128 else GovernedLargeLayoutCache
    layout_cache = cache_class(layout_governor,max_bytes=selected["layout_cache_max_bytes"])
    runtime = ExplicitFreshTreeLoom(registry,layout_cache=layout_cache,holds_per_block=selected["holds_per_block"])
    resources.runtime = runtime
    runtime.status_path = out/"training_live.json"
    # Authenticate the inherited full20 observation barrier and saved state
    # before opening any TRAIN truth or starting the background producer.
    model_cpu = runtime.build_model()
    resume_path = c.contained_path(spec["resume_checkpoint_ref"]["path"])
    _need(resume_path.stat().st_size <= 8*2**20 and _hash(resume_path)==spec["resume_checkpoint_ref"],
          "Exact immutable captured complete-update checkpoint required")
    initial_saved = torch.load(resume_path,map_location="cpu",weights_only=True,mmap=True)
    initial_steps = validate_resume_checkpoint(initial_saved,model_cpu,registry,spec)
    barrier_ref = initial_saved["observation_barrier_ref"]
    barrier = c.read_ref(barrier_ref)
    seals = copy.deepcopy(barrier["parents"])
    plans = {parent:dict(c.read_ref(seals[parent]["plan_ref"]),plan_ref=seals[parent]["plan_ref"])
             for parent in registry.ids("train")}
    _need(set(plans)==set(seals)==set(registry.ids("train")), "All20 authenticated frozen plans/seals")
    plans = MappingProxyType({parent:MappingProxyType(plan) for parent,plan in plans.items()})
    seals = MappingProxyType({parent:MappingProxyType(seal) for parent,seal in seals.items()})
    for parent,item in spec["train_inputs"].items():
        _need(c.file_ref(item["focal_registry_ref"]["path"])==item["focal_registry_ref"],
              "Every original small focal registry must authenticate before truth")
    def write_json(path, value):
        resource_check("TreeLoom_metadata_write")
        with path.open("x") as stream:
            json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False)
            stream.write("\n");stream.flush();os.fsync(stream.fileno())
        return c.file_ref(path)
    def event(name,value):
        resource_check("TreeLoom_progress")
        if name == "complete_parent_update":
            value = dict(value, resource_check_timing=monitor_timing.snapshot(labels=False))
        raw=(json.dumps(dict(event=name,observed_unix=time.time(),**value),sort_keys=True,allow_nan=False)+"\n").encode()
        path=out/"progress.jsonl"
        with event_lock:
            _need(len(raw)<=65536 and (path.stat().st_size if path.exists() else 0)+len(raw)<=2*2**20,
                  "Bounded600-update progress")
            with path.open("ab") as stream: stream.write(raw);stream.flush();os.fsync(stream.fileno())
    def prepare_parent(*args, **kwargs):
        raise RuntimeError('Thread-local preparation is forbidden in the isolated successor')
    bounds_ref = c.file_ref("research/reviews/workflow_progress_diagnosis_20261018/treeloom/storage_bound_v2.json")
    bounds = c.read_ref(bounds_ref)
    parent_bounds = {row["parent_id"]:row["complete_compact_cache_upper_bound_bytes"]+160000
                     for row in bounds["parents"]}
    _need(set(parent_bounds)==set(registry.ids("train")),"All20 original compact parent bounds required")
    inputs = {parent:{key:spec["train_inputs"][parent][key] for key in fresh.INPUT_REFS}
              for parent in registry.ids("train")}
    external = {parent:{"bank.genotype":c.read_ref(inputs[parent]["observation_ref"])["genotypes_ref"]}
                for parent in registry.ids("train")}
    schedule = [(epoch,parent) for epoch in range(1,31) for parent in registry.epoch_order(epoch)]
    producer_references = {}
    for parent in registry.ids("train"):
        producer_spec = producer_specs.build(parent_id=parent,parent_registry_ref=registry.reference,
            input_refs=inputs[parent],plan_ref=seals[parent]["plan_ref"],seal=seals[parent],
            external_arrays=external[parent],compact_bound_bytes=parent_bounds[parent],
            source_manifest_ref=PRODUCER_PINS)
        resource_check(len((json.dumps(producer_spec,sort_keys=True,indent=2)+'\n').encode()))
        producer_references[parent] = producer_specs.write(out/"CPU_producer_specs",producer_spec)
    producer = CPUProducerBackend(specs=producer_references,
        bundle_type=runtime.frozen.AmericanTreeLoomWholeParentV1)
    pool = IsolatedCompactParents(produce_record=producer,schedule=[parent for _,parent in schedule],start_cursor=initial_steps,
        parent_bounds=parent_bounds,input_refs=inputs,external_arrays=external,
        max_cache_bytes=spec["observation_cache_bytes"],governor=layout_governor,credits=child_credits,
        resource_check=resource_check,event=event,prepare=prepare_parent)
    resources.pool = pool
    pool_guard[0] = pool
    cursor = [initial_steps]
    def load_parent(parent):
        _need(parent==schedule[cursor[0]][1],"Exact next parent in the saved600-update schedule required")
        bundle,metadata=pool.load(parent)
        return bundle,metadata
    write_json(out/"inherited_observation_barrier.json",dict(
        schema="TreeLoom_inherited_all20_barrier_reuse_v1",observation_barrier_ref=barrier_ref,
        original_all20_observations_already_sealed=True,new_process_encoded_all20_before_first_update=False,
        actual_full_parent_features_required_before_own_TRAIN_labels=True,
        large_observation_payloads_authenticated_lazily_by_original_loader=True,
        CPU_prefetch_workers=2,lookahead_parents=2,maximum_encoder_children=8,lossless_compact_all20_RAM_pool=True,
        inherited_completed_updates=initial_steps,next_parent=schedule[initial_steps][1]))
    event("historical_all20_barrier_authenticated",dict(observation_barrier_ref=barrier_ref,
          actual_complete_parent_updates=initial_steps,next_parent=schedule[initial_steps][1]))
    def resolve_truth(parent):
        _need(registry.split_for(parent)=="train", "No held-out truth resolver")
        return spec["train_inputs"][parent]["truth_ref"]
    joiner=fresh.FreshTrainTargetJoin(registry,resolve_truth,train_inputs=spec["train_inputs"],
                                     max_truth_uncompressed_bytes=spec["max_truth_uncompressed_bytes"])
    def join(parent,bundle,meta):
        # The complete-parent working reserve is active before TRAIN labels.
        return joiner.join(parent,split="train",plan=plans[parent],observation_seal=seals[parent])
    model=model_cpu.to(device="cuda:0",dtype=torch.float32)
    optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001,betas=(.9,.999),eps=1e-8,
                                maximize=False,amsgrad=False,foreach=False,fused=False,
                                capturable=False,differentiable=False)
    _need(not optimizer.state,"Fresh optimizer object required before strict state restore")
    start_steps = 0
    checkpoint_history = {}
    if spec["resume_checkpoint_ref"] is not None:
        resume_ref = spec["resume_checkpoint_ref"]
        resume_path = c.contained_path(resume_ref["path"])
        _need(resume_path.stat().st_size <= 8*2**20 and _hash(resume_path) == resume_ref,
              "Exact bounded durable resume checkpoint required")
        saved = initial_saved
        start_steps = validate_resume_checkpoint(saved, model, registry, spec)
        model.load_state_dict(saved["model_state"], strict=True)
        optimizer.load_state_dict(saved["optimizer_state"])
        restore_random_state(saved["random_state"])
        checkpoint_history.update(saved.get("checkpoint_event_refs", {}))
        if start_steps % 100 == 0:
            checkpoint_history.setdefault(str(start_steps//20), resume_ref)
        _need(set(checkpoint_history) == {str(e) for e in PASSES if e*20 <= start_steps},
              "All earlier periodic checkpoint event hashes must be preserved")
        _need(len(_optimizer_counts(optimizer)) == 49 and set(_optimizer_counts(optimizer)) == {start_steps},
              "All49 loaded optimizer counters must preserve the serialized boundary")
        del saved, initial_saved
        event("resumed_saved_optimizer_boundary", dict(complete_parent_updates=start_steps,
              resume_checkpoint_ref=resume_ref, resume_evidence_ref=spec["resume_evidence_ref"],
              original_optimizer_moments_preserved=True))
    previous=[None]
    def checkpoint(epoch,steps,actual_model,actual_optimizer,latest=False):
        resource_check("TreeLoom_checkpoint_write")
        payload=dict(schema="treeloom_fresh_full_checkpoint_v1",epoch=epoch,complete_parent_updates=steps,
                     model_seed=70001,parent_registry_ref=registry.reference,observation_barrier_ref=barrier_ref,
                     settings=copy.deepcopy(SETTINGS),contract=actual_model.checkpoint_contract(),
                     execution_variant=EXECUTION_VARIANT, execution_requirements=spec["requirements"],
                     resume_checkpoint_ref=spec["resume_checkpoint_ref"],resume_evidence_ref=spec["resume_evidence_ref"],
                     resume_schema="treeloom_exact_complete_update_resume_v1",
                     schedule_identity=schedule_identity(schedule),
                     last_completed_parent=schedule[steps-1][1],next_schedule_index=steps,
                     checkpoint_event_refs=dict(checkpoint_history),random_state=random_state(),
                     model_state=_cpu_snapshot(actual_model.state_dict()),
                     optimizer_state=_cpu_snapshot(actual_optimizer.state_dict()),
                     VAL_truth_read=False,TEST_truth_read=False,checkpoint_selection="fixed_final_epoch30")
        path=out/"checkpoints"/("latest.pt.next" if latest else "epoch_%02d.pt"%epoch)
        with path.open("xb") as stream:
            torch.save(payload,stream);stream.flush();os.fsync(stream.fileno())
        _need(path.stat().st_size<=8*2**20,"Finite full model/optimizer checkpoint")
        if latest:
            target=out/"checkpoints/latest.pt"
            _need(not target.is_symlink(), "Ordinary own-scope latest checkpoint required")
            os.replace(path,target)
            ref=_hash(target)
            write_json_replace(out/"latest_checkpoint.json",dict(checkpoint_ref=ref,
                complete_parent_updates=steps,epoch=epoch,parent_id=schedule[steps-1][1]))
            pool.durable_checkpoint(parent=schedule[steps-1][1],completed_updates=steps)
            cursor[0]=steps
            return ref
        ref=_hash(path)
        if previous[0] is not None:
            old,old_ref=previous[0]
            _need(old.parent==path.parent and not old.is_symlink() and _hash(old)==old_ref,
                  "Rotate only the exact previous new-scope checkpoint")
            old.unlink()
        previous[0]=(path,ref)
        checkpoint_history[str(epoch)]=ref
        event("checkpoint_saved",dict(epoch=epoch,optimizer_updates=steps,checkpoint_ref=ref,
                                     retention="keep1_new_scope_only"))
        return ref
    schedule = [(epoch,parent) for epoch in range(1,31) for parent in registry.epoch_order(epoch)]
    started=time.monotonic()
    @contextmanager
    def parent_training_phase():
        with pool.training_phase():
            yield
    try:
        result=train_loop(registry=registry,runtime=runtime,model=model,optimizer=optimizer,
                          train_inputs=spec["train_inputs"],observation_barrier=barrier,
                          load_parent=load_parent,join_targets=join,checkpoint=checkpoint,event=event,
                          resource_check=resource_check,start_steps=start_steps,initial_checkpoint_refs=checkpoint_history,
                          training_phase=parent_training_phase)
    finally:
        resources.close()
    pool_receipt = resources.pool_receipt
    pool_receipt["layout_cache"] = resources.layout_receipt
    pool_receipt["CPU_producer_receipts"] = dict(producer.receipts)
    _need(set(pool_receipt["preparations"])=={parent for _,parent in schedule[start_steps:]}
          and set(pool_receipt["preparations"].values())=={1},
          "Every remaining scheduled complete parent must prepare once by fixed-final600")
    if start_steps == 600:
        result["checkpoint_ref"] = spec["resume_checkpoint_ref"]
    resource_check("TreeLoom_verify_final_saved_state")
    saved=torch.load(c.contained_path(result["checkpoint_ref"]["path"]),map_location="cpu",weights_only=True,mmap=True)
    saved_states=saved["optimizer_state"]["state"]
    counts=[int(v["step"].item()) for v in saved_states.values()]
    _need(saved["epoch"]==30 and saved["complete_parent_updates"]==600
          and len(saved_states)==49 and set(counts)=={600}
          and all(v["step"].item()==600 for v in saved_states.values())
          and len(saved["model_state"])>0,
          "Actual final saved model and all49 optimizer counters at600 required")
    del saved
    torch.cuda.synchronize(0)
    result.update(schema="treeloom_fresh_full_training_completion_v1",
                  status="completed_full20parents30passes600updates",
                  parent_registry_ref=registry.reference,observation_barrier_ref=barrier_ref,
                  execution_variant=EXECUTION_VARIANT,requirements=spec["requirements"],
                  resumed_from_complete_parent_updates=start_steps,
                  resume_checkpoint_ref=spec["resume_checkpoint_ref"],resume_evidence_ref=spec["resume_evidence_ref"],
                  final_saved_optimizer_parameter_states=49,final_saved_optimizer_steps=[600],
                  checkpoint_retention="only_final_epoch30_file_retained_earlier_event_hashes_preserved",
                  observed_cache_cap_bytes=spec["observation_cache_bytes"],
                  compact_pool_receipt=pool_receipt,observation_disk_cache=False,
                  preprocessing_binding_scope="fresh_CPU_worker_only",
                  producer_source_manifest_ref=PRODUCER_PINS,
                  resource_check_timing=monitor_timing.snapshot(),
                  adaptive_two_parent_production_qualification_required=True,
                  inherited_all20_barrier_reused=True,fresh_all20_eager_encoding=False,
                  CPU_prefetch_workers=2,lookahead_parents=2,maximum_encoder_children=8,expanded_tensor_IPC=False,
                  memory_envelope=copy.deepcopy(spec["memory_envelope"]),
                  elapsed_training_seconds=time.monotonic()-started,
                  actual_worker_wait_and_owned_cleanup_still_required=True)
    return result



def fit_factory(**arguments):
    spec = build_spec(**arguments)
    return dict(module=__name__, function='run_training', spec=spec,
        python='.runtime/env/bin/python', source_refs=spec['requirements']['source_refs'])


def run_task(request, *, resource_check):
    _need(request['stage']=='fit', 'Only unchanged full training continuation')
    return run_training(build_spec(**request['arguments']), resource_check=resource_check)
