"""Preparation-only full-input signature/timing worker for existing ROOT guardian.

No model, optimizer, TRAIN truth, checkpoint restore, CUDA or general supervisor.
The actual existing ResourceCheck and reviewed async wrapper own resource scans.
"""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import time
from concurrent.futures import TimeoutError as FutureTimeout
from .lifecycle import execute
from .training_v1 import PRODUCER_PINS

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
BASE=Path(__file__).parent


def need(ok,message):
    if not ok:raise ValueError(message)


def ref(path):
    path=Path(path)
    if not path.is_absolute():path=ROOT/path
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(reference):
    path=ROOT/reference['path']
    need(path.resolve()==path and path.is_relative_to(ROOT) and path.stat().st_size<=8*2**20
         and ref(path)==reference,'Bounded authenticated ordinary metadata')
    return json.loads(path.read_text())


def write(path,value,check):
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    need(len(raw)<=8*2**20,'Bounded profile metadata')
    check(len(raw))
    with path.open('xb') as stream:
        stream.write(raw);stream.flush();os.fsync(stream.fileno())
    return ref(path)


def verify(digest):
    manifest=BASE/'source_pins_v1.json'
    need(ref(manifest)['sha256']==digest,'Exact independently reviewed integration manifest')
    pins=json.loads(manifest.read_text())
    for item in pins['source_refs']:need(ref(item['path'])==item,'Pinned integration source changed')
    return ref(manifest)


def run(spec,output,check,resources):
    import torch
    from arggnn.benchmarking import contracts as c
    from research.benchmark_rebuild_20261024.american.treeloom_speed import runtime_v2 as fresh
    from research.efficiency_20261027.execution.adaptive_prefetch_v2 import AdaptiveMemoryGovernor,EncoderCredits
    from research.efficiency_20261027.execution.preparation_evidence_v2 import bounded_signature,array_layout,validate_signature
    from research.efficiency_20261027.execution.compare_two_parent_preparation_v2 import CPU_random_signature
    from research.reviews.workflow_progress_diagnosis_20261018.treeloom.resident_pool_v2 import exact_signature,restore_bundle
    from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1 import specs as producer_specs
    from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.backend import CPUProducerBackend
    from research.efficiency_20261027.independent_efficiency_challenge.producer_isolation_v1.parents import IsolatedCompactParents
    torch.set_num_threads(8);torch.set_num_interop_threads(1)
    need(not torch.cuda.is_initialized(),'No CUDA in preparation-only profile')
    pool=None
    def rss():return int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    def checked(stage):
        check(stage)
        need(rss()<=spec['max_actual_family_bytes'],'Profile main RSS bound')
        need(not torch.cuda.is_initialized(),'CPU-only preparation and restoration')
        if pool is not None:pool.raise_if_failed()
    registry=fresh.FreshParentRegistry.from_ref(spec['parent_registry_ref'])
    runtime=fresh.FreshTreeLoom(registry)
    parents=spec['parents'];inputs=spec['observed_inputs']
    barrier=read(spec['observation_barrier_ref'])
    bounds_data=read(spec['bound_ref'])
    bounds={row['parent_id']:row['complete_compact_cache_upper_bound_bytes']+160000 for row in bounds_data['parents']}
    need(len(parents)==2 and len(set(parents))==2 and all(registry.split_for(p)=='train' for p in parents),
         'Two complete fixed registered TRAIN parents')
    external={parent:{'bank.genotype':read(inputs[parent]['observation_ref'])['genotypes_ref']} for parent in parents}
    specs_directory=output/'CPU_producer_specs';specs_directory.mkdir()
    references={}
    for parent in parents:
        seal=barrier['parents'][parent]
        plan=read(seal['plan_ref'])
        need(all(plan[k]==seal[k]==inputs[parent][k] for k in fresh.INPUT_REFS),'Complete original frozen binding')
        value=producer_specs.build(parent_id=parent,parent_registry_ref=registry.reference,
            input_refs=inputs[parent],plan_ref=seal['plan_ref'],seal=seal,external_arrays=external[parent],
            compact_bound_bytes=bounds[parent],source_manifest_ref=PRODUCER_PINS)
        checked(len((json.dumps(value,sort_keys=True,indent=2)+'\n').encode()))
        references[parent]=producer_specs.write(specs_directory,value)
    producer=CPUProducerBackend(specs=references,bundle_type=runtime.frozen.AmericanTreeLoomWholeParentV1)
    governor=AdaptiveMemoryGovernor(maximum_bytes=spec['governor_bytes'],rss_bytes=rss,
        resource_check=checked,reserve_bytes=128*2**30)
    credits=EncoderCredits(maximum_bytes=spec['governor_bytes'])
    events=[];started=time.perf_counter()
    def event(name,row):
        events.append(dict(event=name,seconds=time.perf_counter()-started,**row))
        need(len(events)<32,'Bounded two-parent event record')
    def forbidden(*args,**kwargs):raise RuntimeError('No coordinator preparation')
    pool=IsolatedCompactParents(produce_record=producer,schedule=parents,start_cursor=0,
        parent_bounds=bounds,input_refs=inputs,external_arrays=external,max_cache_bytes=352*2**30,
        governor=governor,credits=credits,resource_check=checked,event=event,prepare=forbidden)
    resources.pool=pool
    before=CPU_random_signature()
    started=time.perf_counter()
    with governor.phase('qualification_foreground_reserve_only',128*2**30):
        for parent in parents:need(pool._submit(parent,optional=False),'Both complete parents admitted')
        for parent in parents:
            while True:
                try:
                    need(pool.futures[parent].result(timeout=1)==parent,'Exact completed parent')
                    break
                except FutureTimeout:
                    if pool.futures[parent].done():raise
                    checked('waiting_complete_parent')
    makespan=time.perf_counter()-started
    signature_refs={};restores={}
    for parent in parents:
        record=pool.records[parent];began=time.perf_counter()
        with governor.phase('qualification_exact_restore',record['read_peak_upper_bound_bytes']):
            bundle,metadata=restore_bundle(record,input_refs=inputs[parent],resource_check=checked)
            signature=bounded_signature(exact_signature(bundle,metadata,resource_check=checked),
                array_metadata=array_layout(bundle),resource_check=checked)
            validate_signature(signature)
            archived=read(spec['archived_signatures'][parent])
            need(signature==archived,'Every original array, structure, scalar and metadata signature must match')
            signature_refs[parent]=write(output/(parent+'.signature.json'),signature,checked)
            restores[parent]=dict(seconds=time.perf_counter()-began,native_nodes=bundle.bank.parent.numel(),
                native_holds=bundle.native_holds,sites=bundle.original_sites,focals=bundle.focal_hold.numel())
            del bundle,metadata,signature,archived
            gc.collect()
    need(before==CPU_random_signature(),'Preparation transport leaves coordinator CPU RNG unchanged')
    resources.close()
    return dict(schema='TreeLoom_isolated_producer_full_input_profile_v1',status='passed',
        spec_ref=ref(BASE/'profile_spec_v1.json'),parents=parents,complete_archived_signatures_exact=True,
        pair_prepare_pack_receive_ACK_exit_seconds=makespan,post_timing_restore_signature=restores,
        signature_refs=signature_refs,events=events,pool_receipt=resources.pool_receipt,
        producer_receipts=producer.receipts,CPU_RNG_unchanged=True,CUDA_initialized=False,
        training_or_truth_or_checkpoint_opened=False,producer_source_manifest_ref=PRODUCER_PINS,
        no_GPU_utilization_or_training_speedup_claim=True,
        historical_pair_timing_directly_comparable=False,outer_actual_wait_and_family_absence_still_required=True)


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--output',required=True)
    parser.add_argument('--source-sha256',required=True)
    args=parser.parse_args()
    source=verify(args.source_sha256)
    output=ROOT/args.output
    need(output.resolve()==output and output.is_relative_to(ROOT/'research/efficiency_20261027/root/runs')
         and not output.exists(),'Fresh ordinary ROOT profile output')
    os.environ['CUDA_VISIBLE_DEVICES']=''
    for key in ('ARGGNN_PHYSICAL_GPU','ARGGNN_READABLE_GPU_FD','ARGGNN_MAX_CUDA_RESERVED_BYTES','ARGGNN_GPU_MEMORY_POLICY'):
        os.environ.pop(key,None)
    output.mkdir()
    spec=json.loads((BASE/'profile_spec_v1.json').read_text())
    from arggnn.benchmarking.paper_campaign.runtime import ResourceCheck
    callback=ResourceCheck(dict(output_directory=str(output.relative_to(ROOT)),max_seconds=5400,
        max_output_bytes=64*2**20,max_rss_bytes=spec['max_actual_family_bytes']))
    result,monitor=execute(callback,lambda check,resources:run(spec,output,check,resources))
    result.update(async_resource_checks=monitor,source_manifest_ref=source)
    need(verify(args.source_sha256)==source,'Source manifest unchanged at completion')
    write(output/'completed.json',result,callback)


if __name__=='__main__':main()
