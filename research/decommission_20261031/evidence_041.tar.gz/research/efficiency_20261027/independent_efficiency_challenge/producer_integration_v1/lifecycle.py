"""Own only this candidate's pool/layout and reviewed resource-monitor lifetime."""
from research.efficiency_20261027.root.async_resource_checks.check_v2 import AsyncResourceCheck


class Resources:
    def __init__(self):
        self.pool = None
        self.runtime = None
        self.pool_receipt = None
        self.layout_receipt = None
        self.closed = False

    def close(self):
        if self.closed:
            return
        self.closed = True
        errors = []
        joined = False
        if self.pool is not None:
            try:
                self.pool.close()
                joined = True
            except BaseException as error:
                errors.append(error)
            if joined:
                try:
                    self.pool_receipt = self.pool.receipt()
                except BaseException as error:
                    errors.append(error)
                try:
                    self.pool.release_records_after_close()
                except BaseException as error:
                    errors.append(error)
        if self.runtime is not None:
            try:
                self.layout_receipt = self.runtime.layout_cache.snapshot()
            except BaseException as error:
                errors.append(error)
            try:
                self.runtime.close_layout_cache()
            except BaseException as error:
                errors.append(error)
        if errors:
            raise BaseExceptionGroup('Isolated training resource cleanup failed', errors)


def execute(callback, work, *, monitor_factory=AsyncResourceCheck):
    """Never report completion until pool/layout cleanup and monitor close pass."""
    monitor = monitor_factory(callback)
    resources = Resources()
    errors = []
    result = None
    try:
        monitor.start()
        result = work(monitor, resources)
    except BaseException as error:
        errors.append(error)
    finally:
        try:
            resources.close()
        except BaseException as error:
            errors.append(error)
        try:
            monitor.close()
        except BaseException as error:
            errors.append(error)
    if errors:
        if len(errors) == 1:
            raise errors[0]
        raise BaseExceptionGroup('Training or ordered cleanup failed', errors)
    return result, monitor.receipt()
