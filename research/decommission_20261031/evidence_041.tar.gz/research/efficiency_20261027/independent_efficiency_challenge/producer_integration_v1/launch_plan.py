"""Print one readable existing-guardian command; this module cannot launch it."""
import argparse
import json
from pathlib import Path
import shlex
from .full_input_profile import ROOT,verify,need


def command_for(directory,peers,gpu,digest):
    output=ROOT/directory
    need(output.resolve()==output and output.is_relative_to(ROOT/'research/efficiency_20261027/root/runs')
         and not output.exists(),'Fresh ROOT-owned full-input profile directory')
    need(gpu in (3,4,5) and peers and len(peers)==len(set(peers)),'Explicit GPU guard index and current unique peers')
    for peer in peers:
        path=ROOT/peer
        need(path.resolve()==path and path.is_relative_to(ROOT/'research/efficiency_20261027/root/runs')
             and path.is_dir(),'Existing ordinary ROOT peer directory')
    command=['.runtime/env/bin/python3.11','-B','research/efficiency_20261027/root/run_guarded_profile_with_peer.py',
        '--directory',directory,'--gpu',str(gpu),'--host-gib','320','--device-gib','0',
        '--wait-seconds','86400','--run-seconds','5520']
    for peer in peers:command+=['--peer-directory',peer]
    return command+['--','.runtime/env/bin/python3.11','-B','-m',
        'research.efficiency_20261027.independent_efficiency_challenge.producer_integration_v1.full_input_profile',
        '--output',str((output/'data').relative_to(ROOT)),'--source-sha256',digest]


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--directory',required=True)
    parser.add_argument('--peer-directory',action='append',required=True)
    parser.add_argument('--gpu',type=int,choices=(3,4,5),required=True)
    parser.add_argument('--source-sha256',required=True)
    args=parser.parse_args()
    manifest=verify(args.source_sha256)
    command=command_for(args.directory,args.peer_directory,args.gpu,args.source_sha256)
    print(json.dumps(dict(mode='review_only_no_launch',argv=command,visible_command=shlex.join(command),
        source_manifest_ref=manifest,host_cap_bytes=320*2**30,output_cap_bytes=64*2**20,
        actual_training_or_GPU_work=False,fresh_ROOT_admission_required=True,
        existing_guardian_storage_ceiling_bytes=995000000000,user_storage_ceiling_bytes=1200000000000,
        inherited_stricter_guard_not_relaxed=True),indent=2))


if __name__=='__main__':main()
