"""Tiny ordered-cleanup and unchanged scientific orchestration checks."""
import ast
import builtins
import importlib
import symtable
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
from . import lifecycle, training_v1 as candidate

BASE=Path(__file__).parent


class FakeMonitor:
    def __init__(self,log,fail=None):self.log=log;self.fail=fail
    def start(self):self.log.append('start');return self
    def close(self):
        self.log.append('monitor_close')
        if self.fail:raise RuntimeError(self.fail)
    def receipt(self):return {'closed':True}


class FakePool:
    def __init__(self,log,fail=None):self.log=log;self.fail=fail
    def close(self):
        self.log.append('pool_close')
        if self.fail=='join':raise RuntimeError('join failure')
    def receipt(self):self.log.append('pool_receipt');return {}
    def release_records_after_close(self):
        self.log.append('record_release')
        if self.fail=='release':raise RuntimeError('release failure')


class FakeRuntime:
    def __init__(self,log):self.log=log;self.layout_cache=self
    def snapshot(self):self.log.append('layout_snapshot');return {}
    def close_layout_cache(self):self.log.append('layout_close')


class FakeCallback:
    def __init__(self,fail=False):
        self.task={'max_seconds':60};self.started=time.monotonic();self.next_check=0
        self.fail=fail;self.calls=[]
    def __call__(self,stage):
        self.calls.append(stage)
        if self.fail and stage=='TreeLoom_async_monitor_final':raise RuntimeError('final scan failure')


class IntegrationTests(unittest.TestCase):
    def work(self,log,fail=None):
        def action(monitor,resources):
            resources.pool=FakePool(log,fail)
            resources.runtime=FakeRuntime(log)
            log.append('work')
            if fail=='work':raise ValueError('work failure')
            return {'complete':True}
        return action

    def test_success_join_release_layout_then_monitor(self):
        log=[]
        result,receipt=lifecycle.execute(None,self.work(log),monitor_factory=lambda _:FakeMonitor(log))
        self.assertEqual(log,['start','work','pool_close','pool_receipt','record_release',
                              'layout_snapshot','layout_close','monitor_close'])
        self.assertEqual(result,{'complete':True});self.assertTrue(receipt['closed'])

    def test_join_failure_never_releases_record_and_still_closes_monitor(self):
        log=[]
        with self.assertRaises(BaseExceptionGroup):
            lifecycle.execute(None,self.work(log,'join'),monitor_factory=lambda _:FakeMonitor(log))
        self.assertNotIn('record_release',log)
        self.assertEqual(log[-1],'monitor_close')
        self.assertIn('layout_close',log)

    def test_record_release_failure_propagates_after_monitor_close(self):
        log=[]
        with self.assertRaises(BaseExceptionGroup):
            lifecycle.execute(None,self.work(log,'release'),monitor_factory=lambda _:FakeMonitor(log))
        self.assertEqual(log[-1],'monitor_close')

    def test_work_and_monitor_failure_are_both_retained(self):
        log=[]
        with self.assertRaises(BaseExceptionGroup) as captured:
            lifecycle.execute(None,self.work(log,'work'),monitor_factory=lambda _:FakeMonitor(log,'monitor failure'))
        self.assertEqual([str(e) for e in captured.exception.exceptions],['work failure','monitor failure'])
        self.assertIn('record_release',log)

    def test_explicit_inner_close_is_not_repeated(self):
        log=[]
        def work(monitor,resources):
            resources.pool=FakePool(log);resources.runtime=FakeRuntime(log)
            resources.close();return {}
        lifecycle.execute(None,work,monitor_factory=lambda _:FakeMonitor(log))
        self.assertEqual(log.count('pool_close'),1)
        self.assertEqual(log.count('record_release'),1)

    def test_completion_is_published_only_after_actual_final_scan(self):
        for fail in (False,True):
            with self.subTest(fail=fail), tempfile.TemporaryDirectory(dir=BASE) as directory:
                spec={'output_directory':str(Path(directory).resolve().relative_to(candidate.c.ROOT))}
                callback=FakeCallback(fail)
                with patch.object(candidate,'_run_training',return_value={'status':'tiny_test'}):
                    if fail:
                        with self.assertRaises(RuntimeError):candidate.run_training(spec,resource_check=callback)
                        self.assertFalse((Path(directory)/'training_completed.json').exists())
                    else:
                        result=candidate.run_training(spec,resource_check=callback)
                        self.assertTrue((Path(directory)/'training_completed.json').is_file())
                        self.assertIn('completion_ref',result)
                        self.assertEqual(callback.calls[-2],'TreeLoom_async_monitor_final')
                        self.assertIs(type(callback.calls[-1]),int)

    def test_original_schedule_state_and_random_helpers_are_identical(self):
        for name in ('train_loop','_optimizer_counts','validate_resume_checkpoint','validate_saved_state',
                     'validate_resume_metadata','schedule_identity','random_state','restore_random_state',
                     'write_json_replace','ExplicitFreshTreeLoom'):
            self.assertIs(getattr(candidate,name),getattr(candidate.original,name),name)
        self.assertIs(candidate.SETTINGS,candidate.original.SETTINGS)
        self.assertIs(candidate.LIMITS,candidate.original.LIMITS)

    def test_checkpoint_and_truth_join_bodies_are_unchanged(self):
        current=ast.parse(Path(candidate.__file__).read_text())
        prior=ast.parse(Path(candidate.original.__file__).read_text())
        def nested(tree,owner,name):
            outer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==owner)
            return next(n for n in outer.body if isinstance(n,ast.FunctionDef) and n.name==name)
        for name in ('checkpoint','join','resolve_truth','load_parent','parent_training_phase'):
            self.assertEqual(ast.dump(nested(current,'_run_training',name)),
                             ast.dump(nested(prior,'run_training',name)),name)
        for node in ast.walk(current):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute):
                self.assertNotEqual(node.func.attr,'empty_cache')

    def test_every_orchestration_global_is_bound_without_heavy_execution(self):
        for name in ('training_v1','lifecycle','full_input_profile','launch_plan'):
            module=importlib.import_module(__package__+'.'+name)
            table=symtable.symtable(Path(module.__file__).read_text(),module.__file__,'exec')
            def inspect(scope):
                for symbol in scope.get_symbols():
                    if symbol.is_global() and symbol.is_referenced():
                        self.assertTrue(symbol.get_name() in vars(module) or symbol.get_name() in vars(builtins),
                                        (name,scope.get_name(),symbol.get_name()))
                for child in scope.get_children():inspect(child)
            inspect(table)

    def test_profile_plan_reuses_existing_guardian_and_cannot_launch(self):
        from . import launch_plan
        command=launch_plan.command_for('research/efficiency_20261027/root/runs/isolated_producer_pair_v1',
            ['research/efficiency_20261027/root/runs/two_parent_preparation_v2'],5,'0'*64)
        self.assertEqual(command[2],'research/efficiency_20261027/root/run_guarded_profile_with_peer.py')
        self.assertEqual(command[command.index('--host-gib')+1],'320')
        self.assertEqual(command[command.index('--device-gib')+1],'0')
        tree=ast.parse(Path(launch_plan.__file__).read_text())
        self.assertFalse(any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
            and n.func.attr in ('Popen','run','system') for n in ast.walk(tree)))


if __name__=='__main__':unittest.main(verbosity=2)
