"""Prospective full-parent paired training. Importing this module runs nothing.

ROOT must admit this GPU process with an external process-family guardian.
No worker/connector changes or subprocess launchers exist here. Both arms use
all original biological inputs and10000 focal targets per complete parent.
"""
from pathlib import Path
import gc,hashlib,json,os,time,threading,traceback

ROOT=Path('/workspace-SR003.nfs2/ARG-GNN')
OWNED=ROOT/'research/efficiency_20261027/architecture'
ARMS=('frozen_current','transport')


def need(condition,message):
    if not condition:raise ValueError(message)


def reference(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return dict(path=str(path.relative_to(ROOT)),sha256=h.hexdigest())


def read(record):
    need(reference(record['path'])==record,'Immutable source reference changed')
    return json.loads((ROOT/record['path']).read_text())


def run(config,*,resource_check):
    need(config.get('execution_enabled') is True and callable(resource_check),
         'Root-admitted execution and actual worker resource callback required')
    need(os.environ.get('ARGGNN_PHYSICAL_GPU') in ('3','4','5') and
         os.environ.get('CUDA_VISIBLE_DEVICES','').startswith('GPU-') and
         ',' not in os.environ['CUDA_VISIBLE_DEVICES'] and
         os.environ.get('ARGGNN_GPU_MEMORY_POLICY')=='full_device',
         'One root-selected visible GPU3/4/5 UUID and existing full-device policy required')
    need(config['max_RSS_bytes']<=320*2**30 and config['max_GPU_reserved_bytes']<=64*2**30
         and config['output_cap_bytes']<=48*2**20 and config['max_seconds']<=86400
         and config['CPU_threads']==8 and config['project_hard_limit_bytes']==1000000000000,
         'Predeclared finite pilot resource ceilings and1TBdecimal project limit')
    need(config['seeds']==[70001] and config['updates_per_arm']==20, 'Exactly one fixed original20-parent pilot epoch')
    need(config['baseline_kind'] in ('explicit_cpu_vjp','explicit_resident_vjp') and
         config['baseline_partitions']==dict(holds_per_block=512,haplotypes_per_gru=64,history_holds_per_window=1024),
         'Explicit separately qualified selected512 current-model execution required')
    need(config['transport_partitions']==dict(holds_per_block=128,haplotypes_per_tile=128,scan_holds_per_block=1024),
         'Qualified full cached Transport partitions required')
    gates=config['qualification_receipts']
    need(all(isinstance(gates.get(k),dict) for k in ('baseline_full','transport_full','baseline_review','transport_review')),
         'ROOT must pin successful full original bridge, Transport resource and independent reviews before enabling')
    baseline=read(gates['baseline_full']);candidate=read(gates['transport_full'])
    need(baseline['status']=='completed' and baseline['scope']['native_holds']==77472 and
         baseline['scope']['supervised_original_focals']==10000, 'Exact full original baseline bridge required')
    matches=[r for r in baseline['records'] if r['kind']==config['baseline_kind'] and r['phase']=='full_first_call']
    need(len(matches)==1 and matches[0]['comparison']['passed'] and matches[0]['comparison']['argmax_disagreements']==0,
         'Selected current-model executor must pass strict original comparison')
    need(candidate['status']=='completed' and candidate['full_original_parent'] and candidate['all55_gradients_finite']
         and candidate['all_Adam_moments_finite'] and candidate['optimizer_updates']==1, 'Full cached candidate resource qualification required')
    for key in ('baseline_review','transport_review'):
        review=read(gates[key])
        need(review.get('pilot_gate_passed') is True and review.get('qualification_ref')==gates['baseline_full' if key=='baseline_review' else 'transport_full'],
             'Explicit independent pilot review must bind the exact full qualification receipt')
    import numpy as np
    import torch
    from arggnn.benchmarking import contracts as c
    from arggnn.american_c3_gnn_dataset_v1 import load_observation
    from arggnn.american_c3_evaluate_v1 import registry as read_focals,verify_prediction
    from research.benchmark_rebuild_20261024.american.treeloom_speed import runtime_v2 as fresh,training_v2 as original_training
    from research.benchmark_rebuild_20261024.american.treeloom_speed.gru_v2 import install_chunked_gru
    from research.preprocessing_optimization_20261026.integration.hooks import install_tree, verify_bindings
    from research.preprocessing_optimization_20261026.observed.prefetch import OneParentLookahead, SerializedCheck
    from .paired_pilot_execution import update, predict
    from .qualify_staged_full_parent import host_arrays
    from .treeloom_transport import TreeLoomTransport
    need(torch.cuda.device_count()==1,'Exactly one admitted logical CUDA device required')
    torch.set_num_threads(config['CPU_threads']);torch.set_num_interop_threads(1)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False
    out=(ROOT/config['output_directory']).resolve()
    need(out.is_relative_to(OWNED/'runs') and not out.exists(),'Fresh owned research output directory required')
    out.mkdir(parents=True)
    start=time.monotonic();deadline=start+config['max_seconds']
    def rss():return int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    callback_lock=threading.RLock()
    def raw_check(stage):
        resource_check(stage)
        need(time.monotonic()<deadline,'Registered wall budget exhausted; do not crop parents or extend silently')
        need(rss()<=config['max_RSS_bytes'],'Declared process RSS budget exceeded')
        if torch.cuda.is_initialized():
            need(torch.cuda.memory_reserved()<=config['max_GPU_reserved_bytes'],'Declared device reserve budget exceeded')
    check=SerializedCheck(raw_check,callback_lock)
    def output_bytes():
        return sum(p.stat().st_size for p in out.rglob('*') if p.is_file() and not p.is_symlink())
    def reserve_output(amount):
        need(output_bytes()+amount<=config['output_cap_bytes'], 'Declared pilot output cap exceeded')
    def write(name,payload):
        check('research_artifact_write');p=out/name;p.parent.mkdir(parents=True,exist_ok=True)
        raw=json.dumps(payload,indent=2,allow_nan=False)+'\n';reserve_output(len(raw.encode()))
        with p.open('x') as stream:stream.write(raw)
        return reference(p)
    def log(payload):
        raw=json.dumps(payload,allow_nan=False)+'\n';reserve_output(len(raw.encode()))
        with (out/'progress.jsonl').open('a') as stream:stream.write(raw)
    result=dict(status='running',schema='TreeLoom_Transport_paired_staged_full_parent_pilot_v2',
                config=config,TEST_opened=False,VAL_truth_opened=False,seeds=[])
    write('config.json',config)
    try:
        for source_ref in config['source_refs']:
            need(reference(source_ref['path'])==source_ref,'Registered source changed before run')
        original=read(config['original_training_job_ref'])['call']['spec']['arguments']
        registry=fresh.FreshParentRegistry.from_ref(original['parent_registry_ref'])
        need(len(registry.ids('train'))==20 and len(registry.ids('validation'))==5,'Original20TRAIN/5VAL cohort required')
        need(set(config['validation_inputs'])==set(registry.ids('validation')),'Every original VAL parent and noTEST required')
        canonical=read(config['original_validation_bindings_source_ref'])
        score_tasks=[task for task in canonical['tasks'] if task['id']=='paper_american_all_methods_score']
        need(len(score_tasks)==1,'One immutable original evaluation bindings task required')
        original_VAL=score_tasks[0]['call']['factory']['kwargs']
        for parent in registry.ids('validation'):
            fpref=original_VAL['focal_preparation_refs_by_parent'][parent];fp=read(fpref)
            expected=dict(native_preparation_ref=fpref,observation_ref=fp['observation_ref'],focal_registry_ref=fp['focals_ref'])
            need(config['validation_inputs'][parent]==expected and
                 config['validation_generation_ready_refs'][parent]==original_VAL['generation_ready_refs_by_parent'][parent],
                 'VAL must equal the exact original canonical inferred observations, focals and generation lineage')
        check('before_lineage_checkpoint_metadata')
        checkpoint_ref=config['observation_barrier_checkpoint_ref']
        need(reference(checkpoint_ref['path'])==checkpoint_ref,'Original lineage checkpoint changed')
        saved=torch.load(ROOT/checkpoint_ref['path'],map_location='cpu',weights_only=True,mmap=True)
        barrier_ref=saved['observation_barrier_ref'];del saved
        barrier=c.read_ref(barrier_ref)
        need(barrier['all20_observations_sealed_before_truth'] is True and
             barrier['parent_registry_ref']==registry.reference and
             set(barrier['parents'])==set(registry.ids('train')),'Original complete observation barrier required')
        plans={}
        for parent,item in original['train_inputs'].items():
            seal=barrier['parents'][parent]
            need(all(item[k]==seal[k] for k in fresh.INPUT_REFS),'Both arms must use exact frozen observed TRAIN bindings')
            plans[parent]=dict(c.read_ref(seal['plan_ref']),plan_ref=seal['plan_ref'])
        runtime=fresh.FreshTreeLoom(registry)
        bindings=install_tree(preparation_workers=4,max_rss_bytes=config['max_RSS_bytes'])
        write('preparation_bindings.json',bindings)
        joiner=fresh.FreshTrainTargetJoin(registry,lambda parent:original['train_inputs'][parent]['truth_ref'],
            train_inputs=original['train_inputs'],max_truth_uncompressed_bytes=original['max_truth_uncompressed_bytes'])
        def prepare(parent,split,preparation_check):
            preparation_check('before_complete_parent_preparation');item=original['train_inputs'][parent] if split=='train' else config['validation_inputs'][parent]
            need(registry.split_for(parent)==split,'Original split must remain unchanged')
            tick=time.perf_counter()
            state=load_observation(item['observation_ref'],item['focal_registry_ref'],dict(
                native_preparation_ref=item['native_preparation_ref'],class_order=list(fresh.CLASSES),
                expected_haplotypes=1600,reference_counts=[200,200,200],input_reference_class_mask=None,input_reference_sample_indices=None))
            bundle,metadata=runtime.prepare_observation(state,split=split,resource_check=preparation_check,
                **{k:item[k] for k in fresh.INPUT_REFS},**original_training.LIMITS)
            del state;gc.collect()
            need(bundle.sequence_length_bp==30000000 and bundle.bank.sample_index.shape[1]==1600 and
                 len(bundle.focal_hold)==10000 and all(getattr(bundle,k)==item[k] for k in fresh.INPUT_REFS),
                 'Complete original30Mb/all1600/all10000 parent support required')
            bundle.validate();preparation_check('complete_parent_prepared')
            return bundle,metadata,dict(seconds=time.perf_counter()-tick,completed_unix=time.time(),host_arrays=host_arrays(bundle))
        overlap_compute_reserve=[config['baseline_compute_reserve_bytes']]
        def admit_overlap():
            # Declared conservative headrooms, not measured analytical maxima.
            # The external process-family guardian remains mandatory.
            return (rss()+overlap_compute_reserve[0]+
                    config['prefetch_preparation_reserve_bytes'] <= config['max_RSS_bytes'])
        def pool_stats(pool):
            return dict(prefetched=pool.prefetched,synchronous=pool.synchronous,deferred=pool.deferred,
                        max_next_parents=1,observation_disk_cache_bytes=0)
        for seed in config['seeds']:
            check('paired_seed_begin');models={};optimizers={};arm_seconds={arm:0. for arm in ARMS};arm_service_seconds={arm:0. for arm in ARMS}
            for arm in ARMS:
                with torch.random.fork_rng(devices=[]):
                    torch.manual_seed(seed)
                    model=install_chunked_gru(runtime.frozen.AmericanTreeLoomC3FullV1(),chunk_holds=1024) if arm=='frozen_current' else TreeLoomTransport()
                models[arm]=model.to('cuda:0')
                optimizers[arm]=torch.optim.AdamW(models[arm].parameters(),lr=.001,weight_decay=.0001,
                    betas=(.9,.999),eps=1e-8,maximize=False,amsgrad=False,foreach=False,fused=False,capturable=False,differentiable=False)
            seed_record=dict(seed=seed,updates=[],common_preparation_seconds=0.,common_target_join_seconds=0.,
                preparation_wait_seconds=0.,checkpoints={},
                predictions={arm:{} for arm in ARMS},validation_predictions=[],observed_preparations=[])
            schedule=list(registry.epoch_order(1))
            need(len(schedule)==20 and set(schedule)==set(registry.ids('train')), 'Exact original one-epoch parent order')
            with OneParentLookahead(schedule,lambda parent,checker:prepare(parent,'train',checker),
                    resource_check=check,admit_overlap=admit_overlap) as pool:
                for step,parent in enumerate(schedule,1):
                    waiting=time.perf_counter();bundle,metadata,prep=pool.take(parent)
                    seed_record['preparation_wait_seconds']+=time.perf_counter()-waiting
                    seed_record['common_preparation_seconds']+=prep['seconds']
                    seed_record['observed_preparations'].append(dict(parent=parent,split='train',**prep))
                    need(bundle.focal_identity_sha256==barrier['parents'][parent]['focal_identity_sha256'], 'Original pretruth seal matches current bank')
                    join_start=time.perf_counter()
                    target=joiner.join(parent,split='train',plan=plans[parent],observation_seal=barrier['parents'][parent])
                    seed_record['common_target_join_seconds']+=time.perf_counter()-join_start
                    labels=target.labels_cpu
                    need(labels.shape==(10000,) and labels.dtype==torch.long, 'All original10000 TRAIN targets')
                    overlap_compute_reserve[0]=max(config['baseline_compute_reserve_bytes'],
                        prep['host_arrays']['named_execution_array_bytes']+config['local_execution_reserve_bytes'])
                    order=ARMS if step%2 else tuple(reversed(ARMS))
                    for arm in order:
                        admitted=pool.start_next()
                        prefetch_before=pool.future is not None and not pool.future.done()
                        log(dict(event='next_parent_prefetch_decision',phase='train',step=step,parent=parent,arm=arm,
                                 admitted=admitted,prefetch_active=prefetch_before,current_RSS_bytes=rss(),
                                 maximum_arm_compute_reserve_bytes=overlap_compute_reserve[0],
                                 next_preparation_reserve_bytes=config['prefetch_preparation_reserve_bytes']))
                        check('paired_update_begin')
                        row=update(arm,models[arm],optimizers[arm],bundle,metadata,labels,step,runtime,config,check)
                        arm_seconds[arm]+=row['update_seconds']
                        arm_service_seconds[arm]+=row['service_seconds']
                        row.update(step=step,parent_id=parent,arm=arm,seed=seed,
                            next_parent_prefetch_active_at_start=prefetch_before,
                            next_parent_prefetch_active_at_end=pool.future is not None and not pool.future.done(),
                            complete_native_holds=bundle.native_holds,native_nodes=len(bundle.bank.parent),
                            sites=bundle.original_sites,supervised_focals=10000,
                            cumulative_arm_update_seconds=arm_seconds[arm])
                        seed_record['updates'].append(row);log(row);check('paired_update_complete')
                    del target,labels,bundle,metadata,prep;gc.collect();torch.cuda.empty_cache()
                seed_record['TRAIN_prefetch']=pool_stats(pool)
            for arm in ARMS:
                path=out/f'seed_{seed}/{arm}_final.pt';path.parent.mkdir(parents=True,exist_ok=True)
                reserve_output(8*2**20)
                with path.open('xb') as stream:
                    torch.save(dict(model_state={k:v.detach().cpu() for k,v in models[arm].state_dict().items()},seed=seed,
                        updates=20,architecture=arm,parent_registry_ref=registry.reference),stream)
                need(path.stat().st_size<=8*2**20,'Small final model checkpoint cap')
                seed_record['checkpoints'][arm]=reference(path)
                models[arm].eval()
            validation_parents=tuple(registry.ids('validation'))
            seed_record['VAL_preparation_seconds']=0.
            # No validation truth resolver exists in this process. Preparation
            # receives only the frozen observation/focal/lineage bindings.
            with OneParentLookahead(validation_parents,lambda parent,checker:prepare(parent,'validation',checker),
                    resource_check=check,admit_overlap=admit_overlap) as pool:
                for parent in validation_parents:
                    bundle,metadata,prep=pool.take(parent)
                    seed_record['VAL_preparation_seconds']+=prep['seconds']
                    seed_record['observed_preparations'].append(dict(parent=parent,split='validation',**prep))
                    item=config['validation_inputs'][parent];records=read_focals(item['focal_registry_ref'])
                    overlap_compute_reserve[0]=max(config['baseline_compute_reserve_bytes'],
                        prep['host_arrays']['named_execution_array_bytes']+config['local_execution_reserve_bytes'])
                    for arm in ARMS:
                        pool.start_next()
                        probabilities,profile=predict(arm,models[arm],bundle,metadata,runtime,config,check)
                        prediction={k:records[k] for k in fresh.IDENTITY};prediction['probabilities']=probabilities
                        verify_prediction(prediction,records)
                        path=out/f'seed_{seed}/predictions/{arm}/{parent}.npz';path.parent.mkdir(parents=True,exist_ok=True)
                        reserve_output(8*2**20)
                        with path.open('xb') as stream:np.savez(stream,**prediction)
                        need(path.stat().st_size<=8*2**20,'Complete focal prediction artifact cap')
                        seed_record['predictions'][arm][parent]=reference(path)
                        seed_record['validation_predictions'].append(dict(arm=arm,parent=parent,**profile))
                        del probabilities,prediction
                    del bundle,metadata,records,prep;gc.collect();torch.cuda.empty_cache()
                seed_record['VAL_prefetch']=pool_stats(pool)
            need(all(set(v)==set(registry.ids('validation')) for v in seed_record['predictions'].values()),
                 'All original fiveVAL parents for both arms must seal before separate CPU truth scoring')
            seed_record['all10_VAL_predictions_sealed_before_truth']=True
            seed_record['arm_update_seconds']=arm_seconds
            seed_record['arm_service_seconds']=arm_service_seconds
            common=seed_record['common_preparation_seconds']+seed_record['common_target_join_seconds']
            seed_record['standalone_serial_cost_accounting']={arm:dict(
                update_seconds=arm_seconds[arm],service_seconds=arm_service_seconds[arm],charged_preparation_and_join_seconds=common,
                total_seconds=arm_service_seconds[arm]+common,
                supervised_focals_per_second=200000/(arm_service_seconds[arm]+common)) for arm in ARMS}
            seed_record['throughput_limit']='Standalone cost accounting charges shared preparation to each method. Paired wall time and cross-arm prefetch overlap are not measured standalone throughput.'
            result['seeds'].append(seed_record);write(f'seed_{seed}/sealed.json',seed_record)
            del models,optimizers;gc.collect();torch.cuda.empty_cache()
        verify_bindings(bindings)
        result.update(status='completed_training_and_all_VAL_prediction_seals',elapsed_seconds=time.monotonic()-start,
            parent_registry_ref=registry.reference,observation_barrier_ref=barrier_ref,
            initialization='Both fresh seed70001; lineage checkpoint model/optimizer state never loaded into either arm.',
            observed_CPU_lifetime='Current expanded parent is shared across both arms. At most one next observed parent is retained, then current is released. No observation disk cache.',
            prefetch_overlap='Next preparation may overlap either arm only after reserving the larger arm compute headroom plus next-parent preparation. Alternating TRAIN arm order and per-update overlap flags make contention visible; this remains a paired study, not isolated standalone throughput.',
            accuracy_preservation_established=False,full_parent_resource_qualification_only_if_run_completes=True,
            project_hard_limit_bytes=1000000000000,output_cap_bytes=config['output_cap_bytes'],
            external_GPU_activity_and_process_family_telemetry_required=True)
        for source_ref in config['source_refs']:
            need(reference(source_ref['path'])==source_ref, 'Registered source changed during run')
        return write('completed.json',result)
    except BaseException as error:
        failure=dict(status='failed_or_budget_exhausted',error_type=type(error).__name__,message=str(error),
            traceback=traceback.format_exc(),elapsed_seconds=time.monotonic()-start,
            partial_update=getattr(error,'pilot_partial',None),partial_seeds=result['seeds'],
            retained_current_seed=locals().get('seed_record'),no_input_cropping=True,no_automatic_retry=True)
        p=out/'failed.json'
        with p.open('x') as stream:json.dump(failure,stream,indent=2,allow_nan=False);stream.write('\n')
        raise


def main():
    import argparse
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--config',required=True)
    args=parser.parse_args()
    path=(ROOT/args.config).resolve()
    need(path.is_relative_to(OWNED), 'Architecture-owned explicit pilot configuration')
    config=json.loads(path.read_text())
    # ROOT must supply its external process-group admission/guardian around this
    # process; internal RSS/GPU/time/output checks remain independently active.
    need(config.get('external_guardian_required') is True, 'External guardian contract required')
    run(config,resource_check=lambda stage:None)


if __name__=='__main__':
    main()
