"""Bounded CPU recurrence diagnostic: native spans, two synthetic columns.

Only the two 32-channel recurrence modules use FP32 execution. A NumPy FP64
serial scalar-affine recurrence is a diagnostic reference, not model training.
No native tree feature encoder, target reader, optimizer or CUDA is invoked.
"""
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import time

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')
OWNED = ROOT / 'research/efficiency_20261027/architecture'
TREES = ROOT / 'experiments/results/benchmark_campaign_20261018/fresh_american/argformer_american_train_000/inference/observed/tsinfer_tsdate_sanitized.trees'
TREE_SHA = '2ba88d5f02523c33736611283cae445fbed435593b3ef1768599105c801d3a9b'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def ref(path):
    return dict(path=str(path.relative_to(ROOT)), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def check():
    need(time.monotonic() - START < 180, 'Bounded recurrence diagnostic time exceeded')
    need(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024 < 4 * 2**30,
         'Bounded recurrence diagnostic RSS exceeded four GiB')


def max_error(actual, expected):
    import numpy as np
    delta = np.abs(actual.astype(np.float64) - expected)
    at = tuple(int(v) for v in np.unravel_index(delta.argmax(), delta.shape))
    return dict(max_abs=float(delta[at]), at_hold_column_channel=list(at),
                actual=float(actual[at]), reference=float(expected[at]),
                rms=float(np.sqrt(np.mean(delta * delta))))


def serial(alpha, beta, reverse):
    import numpy as np
    result = np.empty(beta.shape, dtype=np.float64)
    carry = np.zeros(beta.shape[1:], dtype=np.float64)
    order = range(len(beta) - 1, -1, -1) if reverse else range(len(beta))
    for i in order:
        carry = alpha[i] * carry + beta[i]
        result[i] = carry
        if i % 8192 == 0:
            check()
    return result


def main():
    import numpy as np
    import torch
    import tskit
    from .treeloom_transport import TreeLoomTransport, affine_scan
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'Explicit CPU-only process required')
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    need(not torch.cuda.is_initialized(), 'CUDA must remain uninitialized')
    need(TREES.stat().st_size < 64 * 2**20 and ref(TREES)['sha256'] == TREE_SHA,
         'Exact small observed tree file required')
    ts = tskit.load(TREES)
    spans = torch.from_numpy(np.diff(ts.breakpoints(as_array=True)).astype(np.float32))
    need(len(spans) == 77472 and float(spans.sum()) == 30000000. and bool((spans > 0).all()),
         'Every positive original TRAIN000 span is required')
    del ts
    previous = torch.cat((spans.new_zeros(1), .5 * (spans[1:] + spans[:-1])))
    following = torch.cat((.5 * (spans[1:] + spans[:-1]), spans.new_zeros(1)))
    geometry = torch.stack((spans.log1p(), previous.log1p(), following.log1p()), -1) / math.log(2000001.)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(70001)
        model = TreeLoomTransport()
    # Two deterministic bounded columns, explicitly not inferred native leaves.
    index = torch.arange(len(spans), dtype=torch.float32)[:, None, None]
    channel = torch.arange(32, dtype=torch.float32)[None, None, :]
    column = torch.arange(2, dtype=torch.float32)[None, :, None]
    leaf = torch.sin(index * .0013 + channel * .37 + column * 1.1)
    features = torch.cat((leaf, geometry[:, None].expand(-1, 2, -1)), -1)
    rows = []
    with torch.no_grad():
        for round_index, layer in enumerate(model.rounds):
            rate_pre = layer.log_rate + layer.rate(features).tanh()
            forcing = layer.force(features).tanh()
            exponent = -spans[:, None, None] * torch.exp(rate_pre)
            alpha = torch.exp(exponent)
            beta = -torch.expm1(exponent) * forcing
            # FP64 reference retains the exact same FP32 feature/linear outputs;
            # only exponential coefficient arithmetic and serial recurrence differ.
            e64 = -spans.numpy().astype(np.float64)[:, None, None] * np.exp(rate_pre.numpy().astype(np.float64))
            a64 = np.exp(e64)
            b64 = -np.expm1(e64) * forcing.numpy().astype(np.float64)
            for reverse in (False, True):
                output = torch.empty_like(beta)
                carry = torch.zeros((2, 32))
                blocks = [(a, min(a + 1024, len(spans))) for a in range(0, len(spans), 1024)]
                for a, b in reversed(blocks) if reverse else blocks:
                    aa, bb = alpha[a:b], beta[a:b]
                    if reverse:
                        aa, bb = aa.flip(0), bb.flip(0)
                    value = affine_scan(aa, bb, initial=carry)
                    carry = value[-1].clone()
                    output[a:b] = value.flip(0) if reverse else value
                exact_coeff_reference = serial(a64, b64, reverse)
                arithmetic_error_reference = serial(alpha.numpy(), beta.numpy(), reverse)
                need(bool(torch.isfinite(output).all()), 'All full-history recurrence states must remain finite')
                rows.append(dict(round=round_index, reverse=reverse,
                    output_min=float(output.min()), output_max=float(output.max()),
                    rounded_coefficient_serial_reference=max_error(output.numpy(), arithmetic_error_reference),
                    high_precision_coefficient_serial_reference=max_error(output.numpy(), exact_coeff_reference),
                    alpha_min=float(alpha.min()), alpha_max=float(alpha.max()),
                    alpha_zero_count=int((alpha == 0).sum()), alpha_one_count=int((alpha == 1).sum()),
                    alpha_one_nonzero_beta_count=int(((alpha == 1) & (beta != 0)).sum()),
                    force_abs_max=float(forcing.abs().max()),
                    exponent_min=float(exponent.min()), exponent_max=float(exponent.max())))
                check()
                del output, exact_coeff_reference, arithmetic_error_reference
            del rate_pre, forcing, exponent, alpha, beta, e64, a64, b64
            gc.collect()
    need(not torch.cuda.is_initialized(), 'CUDA must remain uninitialized after the diagnostic')
    receipt = dict(schema='Transport_full_native_span_bounded_recurrence_diagnostic_v1', status='completed',
        tree_ref=ref(TREES), source_refs=[ref(Path(__file__)), ref(OWNED / 'treeloom_transport.py')],
        native_holds=77472, native_bp=30000000, span_min=float(spans.min()), span_max=float(spans.max()),
        sample_columns=2, channels=32, feature_source='Deterministic bounded synthetic sine features, not native leaf representations',
        seed=70001, scan_chunk=1024, learned_weights=False, optimizer_created=False,
        FP32_model_and_recurrence=True, FP64_scope='NumPy scalar-affine recurrence/coefficient reference only; no model or tree encoder converted to FP64',
        rows=rows, wall_seconds=time.monotonic()-START,
        peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        CPU_threads=2, CUDA_initialized=False, truth_opened=False,
        mathematical_bound='In exact arithmetic, alpha=exp(-positive span*positive rate) is in [0,1], beta=(1-alpha)*force with force in [-1,1]. Zero-initialized states stay in [-1,1].',
        limitations=['This diagnoses both initialized recurrence modules on actual full-length spans and synthetic features only.',
                     'It does not prove stability after training, actual learned leaf behavior, gradients over full history, or predictive quality.',
                     'Unbounded learned log_rate can overflow/underflow; finite guards remain necessary. Alpha rounding to one can break exact convex-combination arithmetic.',
                     'GPU FP32 kernels may differ; the actual full-parent GPU qualification must independently check logits, gradients, moments and parameters.'])
    path = OWNED / 'long_recurrence_stability_v1.json'
    with path.open('x') as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(receipt, allow_nan=False), flush=True)


START = time.monotonic()
if __name__ == '__main__':
    main()
