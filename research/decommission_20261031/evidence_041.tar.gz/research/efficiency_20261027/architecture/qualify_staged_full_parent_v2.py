"""ROOT-admitted single full TRAIN000 cached Transport update; no monolithic arm.

FP32 only. Original full observation/10k TRAIN target preparation is reused.
The result qualifies one resource execution, not accuracy or parity of training
trajectories. No production source, checkpoint or observation cache is written.
"""
import argparse
import gc
import json
import os
import resource
import time
import traceback
from pathlib import Path
from types import SimpleNamespace
from .staged_gpu_128_qualification_v3 import ROOT, OWNED, need, reference, clock, rss, StageMeter

MANIFEST = OWNED / 'qualify_staged_full_parent_sources_v2.json'
GPU128_RECEIPT = OWNED / 'staged_transport_gpu5_v1/data/completed.json'


def host_arrays(bundle):
    """Payload sums plus named execution arrays; not an RSS maximum proof."""
    from dataclasses import fields, is_dataclass
    import torch
    seen = set()
    def payload(value):
        if torch.is_tensor(value):
            key = (str(value.device), value.untyped_storage().data_ptr(), value.untyped_storage().nbytes())
            if key in seen:
                return 0
            seen.add(key)
            return value.untyped_storage().nbytes()
        if is_dataclass(value):
            return sum(payload(getattr(value, f.name)) for f in fields(value))
        if isinstance(value, dict):
            return sum(payload(v) for v in value.values())
        if isinstance(value, (tuple, list)):
            return sum(payload(v) for v in value)
        return 0
    original = payload(bundle)
    t, h = bundle.bank.sample_index.shape
    n = len(bundle.bank.parent)
    full = t * h * 32 * 4
    tile = t * min(h, 128) * 32 * 4
    nodes = n * 32 * 4
    boundaries = 2 * ((t + 1023) // 1024) * min(h, 128) * 32 * 4
    named = 4 * full + 6 * tile + 2 * nodes + boundaries
    return dict(original_unique_tensor_storage_bytes=original,
                history_bytes=full, tile_bytes=tile, all_node_state_bytes=nodes,
                four_history_arrays_bytes=4 * full, six_tile_scratch_bytes=6 * tile,
                two_node_arrays_bytes=2 * nodes, incoming_boundaries_bytes=boundaries,
                named_execution_array_bytes=named, original_plus_named_bytes=original + named,
                excludes='One-block topology/index copies, autograd tapes, allocator/cache, library workspaces, Python metadata and preparation transients; not an RSS guarantee.')


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--output', required=True)
    parser.add_argument('--max-rss-gib', type=int, default=320)
    parser.add_argument('--max-gpu-reserved-gib', type=int, default=24)
    parser.add_argument('--max-seconds', type=int, default=7200)
    parser.add_argument('--gpu-predecessor-directory', required=True)
    args = parser.parse_args()
    need(args.gpu_predecessor_directory == 'research/efficiency_20261027/root/runs/selected_full_gpu5_v1',
         'Exact ROOT-selected full current-model predecessor required')
    need(os.environ.get('ARGGNN_PHYSICAL_GPU') == '5' and
         os.environ.get('CUDA_VISIBLE_DEVICES', '').startswith('GPU-') and
         ',' not in os.environ['CUDA_VISIBLE_DEVICES'] and
         os.environ.get('ARGGNN_GPU_MEMORY_POLICY') == 'full_device',
         'ROOT-admitted GPU5 UUID/full-device policy required')
    need(0 < args.max_rss_gib <= 320 and 0 < args.max_gpu_reserved_gib <= 24 and
         0 < args.max_seconds <= 7200, 'Do not enlarge prepared resource allowances')
    output = (ROOT / args.output).resolve()
    need(output.is_relative_to(OWNED) and not output.exists(), 'Fresh architecture-owned output required')
    output.mkdir(parents=True)
    started = clock()
    deadline = time.monotonic() + args.max_seconds
    output_limit = 48 * 2**20  # Leaves16MiB in the enclosing64MiB study scope.
    last_output_check = [0.]
    def output_bytes():
        return sum(p.stat().st_size for p in output.rglob('*') if p.is_file() and not p.is_symlink())
    def write(name, value):
        raw = json.dumps(value, indent=2, allow_nan=False) + '\n'
        need(output_bytes() + len(raw.encode()) <= output_limit, 'Declared diagnostic output budget exceeded')
        with (output / name).open('x') as stream:
            stream.write(raw)
        return reference(output / name)
    meter = execution = None
    try:
        manifest_ref = reference(MANIFEST)
        manifest = json.loads(MANIFEST.read_text())
        pins = manifest['source_refs'] + manifest['input_refs']
        for pin in pins:
            need(reference(pin['path']) == pin, 'Frozen source/input changed: ' + pin['path'])
        small = json.loads(GPU128_RECEIPT.read_text())
        need(small['status'] == 'passed' and len(small['records']) == 12 and
             all(row['comparison']['passed'] and row['comparison']['argmax_changes'] == 0 for row in small['records']),
             'Prior strict observed128 staged qualification required')
        import setproctitle
        setproctitle.setproctitle('AI Auto Research Pipeline Test')
        import torch
        from torch.nn import functional as F
        from research.benchmark_rebuild_20261024.american.treeloom_speed import runtime_v2 as fresh
        from research.scalability_20261024.profiling.run_profile import prepare
        from research.preprocessing_optimization_20261026.integration.hooks import install_tree, verify_bindings
        from .treeloom_transport import TreeLoomTransport
        from .staged_transport import StagedTransport
        torch.set_num_threads(8)
        torch.set_num_interop_threads(1)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        def check(stage):
            need(time.monotonic() < deadline, 'Full-parent wall budget exceeded at ' + stage)
            need(rss() <= args.max_rss_gib * 2**30, 'Full-parent RSS budget exceeded at ' + stage)
            if time.monotonic() - last_output_check[0] >= 30.:
                need(output_bytes() <= output_limit, 'Full-parent output cap exceeded')
                last_output_check[0] = time.monotonic()
            if torch.cuda.is_initialized():
                need(torch.cuda.memory_reserved() <= args.max_gpu_reserved_gib * 2**30,
                     'Full-parent current GPU reserve exceeded at ' + stage)
        write('invocation.json', dict(arguments=vars(args), start=started, source_manifest_ref=manifest_ref,
              source_refs=pins, physical_gpu=os.environ['ARGGNN_PHYSICAL_GPU'],
              visible_UUID=os.environ['CUDA_VISIBLE_DEVICES'], FP32=True, CPU_threads=8,
              external_process_group_guardian_required=True, total_study_output_cap_bytes=64 * 2**20,
              project_hard_limit_bytes=1000000000000, observation_disk_cache_bytes=0,
              predecessor_GPU128_ref=reference(GPU128_RECEIPT), monolithic_full_parent=False,
              tree_block=128, haplotype_tile=128, scan_block=1024, cache_first_nodes=True))
        checkpoint = ROOT / 'research/repairs/TreeLoom_resume94_RAM_headroom_v1/checkpoint.pt'
        saved = torch.load(checkpoint, map_location='cpu', weights_only=True, mmap=True)
        registry = fresh.FreshParentRegistry.from_ref(saved['parent_registry_ref'])
        runtime = fresh.FreshTreeLoom(registry)
        bindings = install_tree(preparation_workers=4, max_rss_bytes=args.max_rss_gib * 2**30)
        write('preparation_bindings.json', bindings)
        need(not torch.cuda.is_initialized(), 'Full observation preparation before CUDA initialization required')
        prep_start = clock()
        bundle, metadata, labels, _, scope = prepare(SimpleNamespace(mode='full'), runtime, saved, check)
        prep_end = clock()
        del saved
        need(bundle.parent_id == 'argformer_american_train_000' and bundle.native_holds == 77472 and
             len(bundle.bank.parent) == 205369272 and bundle.original_sites == 227474 and
             bundle.bank.sample_index.shape == (77472, 1600) and len(labels) == 10000 and
             bundle.sequence_length_bp == 30000000, 'Exact original complete TRAIN000 support required')
        bundle.validate()
        accounting = host_arrays(bundle)
        # Reserve beyond already-resident inputs before retaining learned arrays.
        need(rss() + accounting['named_execution_array_bytes'] + 32 * 2**30 <= args.max_rss_gib * 2**30,
             'Measured resident bank plus named arrays and32GiB local overhead reserve do not fit')
        write('full_scope_and_host_plan.json', dict(scope=scope, host_accounting=accounting,
              current_RSS_bytes=rss(), additional_local_overhead_reserve_bytes=32 * 2**30,
              preparation_start=prep_start, preparation_end=prep_end,
              spans_min_bp=float(bundle.bank.spans.min()), spans_max_bp=float(bundle.bank.spans.max()),
              preparation_is_shared_cost_not_free=True))
        from research.efficiency_20261027.execution.deferred_gpu_gate import wait_before_cuda
        need(not torch.cuda.is_initialized(), 'CPU preparation must finish without initializing CUDA')
        gate = wait_before_cuda(torch, check, predecessor_directory=args.gpu_predecessor_directory,
            output=output, gpu_index=5, gpu_budget_bytes=args.max_gpu_reserved_gib * 2**30,
            timeout_seconds=args.max_seconds, poll_seconds=5)
        write('gpu_predecessor_gate.json', gate)
        need(torch.cuda.device_count() == 1, 'One admitted CUDA device required')
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(70001)
            model = TreeLoomTransport()
        model = model.to('cuda:0').train()
        optimizer = torch.optim.AdamW(model.parameters(), lr=.001, weight_decay=.0001,
            betas=(.9, .999), eps=1e-8, maximize=False, amsgrad=False, foreach=False,
            fused=False, capturable=False, differentiable=False)
        optimizer.zero_grad(set_to_none=True)
        meter = StageMeter(torch, check, args.max_gpu_reserved_gib * 2**30)
        meter.switch('full_update_setup')
        update_start = clock()
        execution = StagedTransport(model, bundle.bank, bundle.episodes.flags.node_flags,
            metadata['episode_metadata']['native_nodes_per_tree'], holds_per_block=128,
            haplotypes_per_tile=128, scan_holds_per_block=1024,
            cache_first_nodes=True, resource_check=meter.callback)
        meter.switch('full_forward_logits_and_loss')
        forward_start = clock()
        with torch.autocast(device_type='cuda', enabled=False):
            logits = execution.forward_focals(bundle.focal_hold, bundle.focal_sample_column)
            loss = F.cross_entropy(logits, labels.to('cuda:0'))
        torch.cuda.synchronize()
        forward_end = clock()
        need(logits.shape == (10000, 3) and bool(torch.isfinite(logits).all()) and bool(torch.isfinite(loss)),
             'Every original focal must have finite FP32 logits/loss')
        meter.switch('full_loss_and_explicit_backward')
        backward_start = clock()
        loss.backward()
        need(logits.grad is not None and bool(torch.isfinite(logits.grad).all()) and
             all(p.grad is None for p in model.parameters()), 'Complete finite focal VJP before explicit stage backward required')
        execution.backward_focals(logits.grad)
        torch.cuda.synchronize()
        backward_end = clock()
        need(execution.state is None, 'All staged states must be consumed before optimizer update')
        meter.switch('full_gradient_and_TRAIN_metrics')
        gradients = {name: p.grad.detach().cpu().clone() for name, p in model.named_parameters() if p.grad is not None}
        need(len(gradients) == 55 and all(bool(torch.isfinite(g).all()) for g in gradients.values()),
             'All55 finite connected full-parent parameter gradients required')
        predictions = logits.detach().argmax(-1).cpu()
        scalar_metrics = dict(TRAIN_mean_CE=float(loss), TRAIN_focal_accuracy=float((predictions == labels).float().mean()),
            TRAIN_class_recall={str(c): float((predictions[labels == c] == c).float().mean()) if bool((labels == c).any()) else None for c in range(3)},
            label_counts={str(c): int((labels == c).sum()) for c in range(3)},
            probability_rows=10000, parameter_tensors=55,
            predictive_scope='One fresh random initialization before one update; TRAIN diagnostics only, not validation or learned accuracy.')
        meter.switch('full_clip_AdamW_update')
        update_math_start = clock()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        optimizer.step()
        torch.cuda.synchronize()
        update_math_end = clock()
        meter.close()
        update_end = clock()
        need(len(optimizer.state) == 55 and all(int(v['step']) == 1 for v in optimizer.state.values()) and
             all(bool(torch.isfinite(p).all()) for p in model.parameters()) and
             all(bool(torch.isfinite(v).all()) for row in optimizer.state.values()
                 for v in row.values() if torch.is_tensor(v)), 'One finite AdamW update and moments for every parameter required')
        numerical = dict(logits=logits.detach().cpu(), loss=loss.detach().cpu(), gradients=gradients,
            parameters={name: p.detach().cpu().clone() for name, p in model.named_parameters()},
            moments={str(i): {k: v.detach().cpu().clone() if torch.is_tensor(v) else v for k, v in row.items()}
                     for i, row in optimizer.state_dict()['state'].items()})
        path = output / 'full_update_numerical.pt'
        need(output_bytes() + 8 * 2**20 <= output_limit, 'Reserve numerical artifact bytes before save')
        with path.open('xb') as stream:
            torch.save(numerical, stream)
        need(path.stat().st_size <= 8 * 2**20, 'Numerical artifact exceeded its allowance')
        verify_bindings(bindings)
        for pin in pins:
            need(reference(pin['path']) == pin, 'Frozen source/input changed during full qualification')
        need(reference(MANIFEST) == manifest_ref, 'Source manifest changed during full qualification')
        seconds = update_end['monotonic_seconds'] - update_start['monotonic_seconds']
        write('completed.json', dict(schema='TreeLoom_Transport_cached_full_TRAIN000_qualification_v2', status='completed',
            start=started, end=clock(), scope=scope, source_manifest_ref=manifest_ref,
            gpu_predecessor_gate=gate,
            scalar_metrics=scalar_metrics, gradient_norm=float(norm), optimizer_updates=1,
            all55_gradients_finite=True, all_Adam_moments_finite=True, full_original_parent=True, full_history_holds=77472,
            no_truncated_history=True, cache_first_nodes=True, host_accounting=accounting,
            forward_seconds=forward_end['monotonic_seconds'] - forward_start['monotonic_seconds'],
            backward_seconds=backward_end['monotonic_seconds'] - backward_start['monotonic_seconds'],
            clip_optimizer_seconds=update_math_end['monotonic_seconds'] - update_math_start['monotonic_seconds'],
            update_seconds=seconds, supervised_focals_per_update_second=10000 / seconds,
            native_holds_per_update_second=77472 / seconds, preparation_seconds=scope['preparation_seconds'],
            update_start=update_start, update_end=update_end, forward_start=forward_start,
            forward_end=forward_end, backward_start=backward_start, backward_end=backward_end,
            stages=meter.rows, GPU_peak_allocated_bytes=max(x['GPU_peak_allocated_bytes'] for x in meter.rows),
            GPU_peak_reserved_bytes=max(x['GPU_peak_reserved_bytes'] for x in meter.rows),
            process_RSS_bytes=rss(), process_lifetime_peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            numerical_ref=reference(path), VAL_truth_opened=False, TEST_opened=False,
            device_activity_requires_external_telemetry=True, observation_disk_cache_bytes=0,
            accuracy_preservation_established=False, full_monolithic_parity_claim=False,
            limitations=['One actual full-parent update; stable throughput and convergence are unmeasured.',
                         'Fresh random model differs from trained current-model checkpoint; timings are scoped diagnostics, not matched predictive efficiency.',
                         'Allocator stage peaks are measured; sampled process-group telemetry remains required for complete host accounting.',
                         'Synchronization and resource instrumentation are included in update timings; output-size scans are throttled to30seconds except before writes.']))
        print(json.dumps(dict(status='completed', output=str(output), update_seconds=seconds, **scalar_metrics)), flush=True)
    except BaseException as error:
        write('failed.json', dict(status='failed', error_type=type(error).__name__, message=str(error),
              traceback=traceback.format_exc(), start=started, end=clock(),
              recorded_stages=meter.rows if meter is not None else [],
              open_stage=meter.current if meter is not None else None))
        raise
    finally:
        if execution is not None:
            execution.release()


if __name__ == '__main__':
    main()
