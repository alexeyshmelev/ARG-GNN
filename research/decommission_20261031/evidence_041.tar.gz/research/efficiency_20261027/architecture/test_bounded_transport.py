"""CPU-only numerical candidate-vs-candidate test; no ancestry targets."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
import json,time,copy,resource,hashlib
from pathlib import Path
from dataclasses import fields
import numpy as np
import torch
from arggnn.mutation_routed_whole_tree_gnn_v1 import MutationRoutedWholeTreeInputsV1
from research.repairs.benchmark_recovery_20261020.runtime.episodes import build_episodes
from research.efficiency_20261027.architecture.treeloom_transport import TreeLoomTransport,prepare_transport_plan
from research.efficiency_20261027.architecture.bounded_transport import BoundedTransport

torch.set_num_threads(4);torch.manual_seed(9030)
base=Path('research/efficiency_20261027/architecture');t=7
packet=Path('research/scalability_20261024/execution/representative_slice.npz')
with np.load(packet,allow_pickle=False) as z:
    n=int(z['node_offsets'][t]);arrays={};selected=z['site_hold']<t
    for field in fields(MutationRoutedWholeTreeInputsV1):
        key=field.name
        if key in ('upward_levels','upward_children','upward_parent_rank','downward_levels'):
            names=sorted((k for k in z.files if k.startswith(key+'_')),key=lambda k:int(k.rsplit('_',1)[1]))
            values=[]
            for name in names:
                if key=='upward_parent_rank':
                    children=z[name.replace('upward_parent_rank','upward_children')]
                    values.append(z[name][children<n])
                else:values.append(z[name][z[name]<n])
            arrays[key]=tuple(values)
        elif key in ('parent','node_time','edge_geometry','branch_support_true','branch_support_sham'):
            arrays[key]=z[key][:n]
        elif key in ('genotype','log_donor_allele_frequency','donor_call_mask','panel_allele_frequency','site_entropy','site_hold'):
            arrays[key]=z[key][selected]
        elif key in ('sample_index','spans','readout_hold'):arrays[key]=z[key][:t]
        else:arrays[key]=z[key]
    counts=np.diff(z['node_offsets'][:t+1]).tolist()
bank=MutationRoutedWholeTreeInputsV1.from_arrays(arrays)
episodes,metadata=build_episodes(bank,max_payload_bytes=2**30,isolated_hold_indices=(0,))
plan=prepare_transport_plan(bank.parent,episodes.flags.node_flags)
model=TreeLoomTransport();candidate=copy.deepcopy(model)
# Numerical probes deliberately include reference and query sample columns.
hold=torch.tensor([i%t for i in range(28)],dtype=torch.long)
column=torch.tensor([(37+i*59)%1600 for i in range(28)],dtype=torch.long)
weights=torch.randn(28,3)
started=time.perf_counter()
reference=model.forward_all_samples(bank,plan)[hold,column]
(reference*weights).sum().backward()
print('stage: monolithic observed diagnostic complete',flush=True)
executor=BoundedTransport(candidate,bank,episodes.flags.node_flags,counts,
                          holds_per_block=3,haplotypes_per_tile=128,scan_holds_per_block=3)
actual=executor.forward_focals(hold,column)
(actual*weights).sum().backward()
print('stage: checkpointed blocked diagnostic complete',flush=True)
torch.testing.assert_close(actual,reference,atol=1e-6,rtol=1e-4)
rows=[]
for (name,a),(other,b) in zip(model.named_parameters(),candidate.named_parameters()):
    assert name==other and a.grad is not None and b.grad is not None
    torch.testing.assert_close(a.grad,b.grad,atol=1e-6,rtol=1e-4)
    rows.append(dict(name=name,max_abs_error=float((a.grad-b.grad).abs().max()),finite=bool(torch.isfinite(b.grad).all())))
assert all(x['finite'] for x in rows)
assert not torch.cuda.is_initialized()
r=dict(atol=1e-6,rtol=1e-4,schema='TreeLoom_Transport_bounded_CPU_parity_v1',status='passed',native_holds=t,
       native_nodes=n,sites=len(bank.genotype),haplotypes=1600,isolated_holds=[0],
       tree_holds_per_block=3,scan_holds_per_block=3,haplotypes_per_tile=128,
       complete_supplied_sequence_carry_in_both_directions=True,blocks_have_ragged_final_piece=True,
       logits_max_abs_error=float((actual-reference).abs().max()),gradient_details=rows,
       gradients_max_abs_error=max(x['max_abs_error'] for x in rows),parameter_tensors=len(rows),
       elapsed_seconds=time.perf_counter()-started,process_peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
       source_sha256={name:hashlib.sha256((base/name).read_bytes()).hexdigest() for name in ('treeloom_transport.py','bounded_transport.py','test_bounded_transport.py')},
       ancestry_targets_opened=False,optimizer_updates=0,CUDA_initialized=False,
       limitation='Seven original holds for numerical parity only; no full-parent resource, ancestry accuracy or GPU throughput qualification.')
with (base/'bounded_CPU_parity_strict_v3.json').open('x') as stream:json.dump(r,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in r.items() if k!='gradient_details'},indent=2))
