#!/usr/bin/env bash
# PREPARED ONLY. The pinned config remains disabled pending full-run evidence.
# ROOT must use its process-family guardian and actual physical GPU UUID.
set -euo pipefail
cd /workspace-SR003.nfs2/ARG-GNN
source scripts/project_env.sh
test "${ARGGNN_GPU_MEMORY_POLICY:?ROOT must set existing policy}" = "full_device"
test -n "${CUDA_VISIBLE_DEVICES:?ROOT must admit one physical GPU UUID}"
PYTHONPATH='/workspace-SR003.nfs2/ARG-GNN:/workspace-SR003.nfs2/ARG-GNN/src' \
  .runtime/env/bin/python -B -m research.efficiency_20261027.architecture.paired_pilot_v2 \
  --config research/efficiency_20261027/architecture/paired_pilot_config_v2.json
