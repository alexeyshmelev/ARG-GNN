#!/usr/bin/env bash
# PREPARED ONLY. ROOT supplies GPU5 UUID admission and external process guardian.
# The single update uses full TRAIN000, all original10000 labels and cached nodes.
set -euo pipefail
cd /workspace-SR003.nfs2/ARG-GNN
source scripts/project_env.sh
test "${ARGGNN_PHYSICAL_GPU:?ROOT must admit physical GPU5}" = "5"
test "${ARGGNN_GPU_MEMORY_POLICY:?ROOT must set the existing policy}" = "full_device"
test -n "${CUDA_VISIBLE_DEVICES:?ROOT must select the admitted GPU5 UUID}"
PYTHONPATH='/workspace-SR003.nfs2/ARG-GNN:/workspace-SR003.nfs2/ARG-GNN/src' \
  .runtime/env/bin/python -B -m research.efficiency_20261027.architecture.qualify_staged_full_parent_v2 \
  --output research/efficiency_20261027/architecture/staged_transport_full_gpu5_v2/data \
  --max-rss-gib 320 \
  --max-gpu-reserved-gib 24 \
  --max-seconds 7200 \
  --gpu-predecessor-directory research/efficiency_20261027/root/runs/selected_full_gpu5_v1
