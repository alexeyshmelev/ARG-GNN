"""Small CPU test of original decoder capture and prediction focal ordering."""
import json
import os
from pathlib import Path
import resource
import time


def main():
    import torch
    from torch import nn
    from torch.nn import functional as F
    from research.benchmark_rebuild_20261024.american.treeloom_speed.decoder_v2 import decode_parent_backward
    from .paired_pilot_execution import DecoderCapture, predict_from_context, metrics
    def need(ok,message):
        if not ok:
            raise ValueError(message)
    need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','CPU-only test')
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.manual_seed(70001)
    class Model(nn.Module):
        def __init__(self):
            super().__init__();self.classifier=nn.Linear(96,3)
        def scan_context(self,context,geometry,*,direction):
            values=context+geometry.sum(-1)[:,None,None]
            history=values.cumsum(0) if direction=='forward' else values.flip(0).cumsum(0).flip(0)
            return history,None
    model=Model();context=torch.randn(7,1600,32,requires_grad=True);geometry=torch.randn(7,3)
    hold=torch.tensor([6,0,3,3,1,6,2,0,4]);column=torch.tensor([1599,0,65,65,127,1023,900,64,13])
    labels=torch.tensor([0,1,2,1,2,0,2,1,0]);started=time.monotonic()
    capture=DecoderCapture(torch,model,column,64)
    try:
        loss,vjp,detail=decode_parent_backward(model,context,geometry,hold,column,labels,tile_haplotypes=64)
        actual=capture.result()
    finally:capture.close()
    with torch.no_grad():
        forward,_=model.scan_context(context,geometry,direction='forward')
        reverse,_=model.scan_context(context,geometry,direction='reverse')
        expected=model.classifier(torch.cat((context[hold,column],forward[hold,column],reverse[hold,column]),-1))
        prediction=predict_from_context(model,context,geometry,hold,column,tile=64,check=lambda stage:None)
    torch.testing.assert_close(actual,expected,atol=1e-6,rtol=1e-5)
    torch.testing.assert_close(prediction,expected,atol=1e-6,rtol=1e-5)
    torch.testing.assert_close(loss,F.cross_entropy(expected,labels),atol=1e-6,rtol=1e-5)
    result=metrics(torch,actual,labels,loss)
    need(result['TRAIN_focal_accuracy']==float((expected.argmax(-1)==labels).float().mean()),'Correct original-row accuracy')
    need(not torch.cuda.is_initialized(),'No CUDA initialization')
    receipt=dict(status='passed',original_decoder_used=True,synthetic_model=True,holds=7,samples=1600,
        original_order_focals=9,duplicate_coordinate_with_distinct_targets=True,endpoint_columns=True,
        maximum_capture_error=float((actual-expected).abs().max()),maximum_prediction_error=float((prediction-expected).abs().max()),
        scalar_metrics=result,full_history_per_tile=detail['full_sequence_per_tile'],
        CUDA_initialized=False,wall_seconds=time.monotonic()-started,
        peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        scope='Metric/prediction row routing and same-decoder loss only; not an actual-model GPU or full-parent qualification.')
    path=Path(__file__).with_name('paired_pilot_metric_CPU_test_v1.json')
    with path.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    main()
