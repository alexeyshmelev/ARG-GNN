"""Explicit current-model and staged Transport execution for a gated paired pilot.

No data/truth readers or launchers. Metrics preserve original focal row order.
The baseline branch is selected explicitly by a separately qualified config.
"""
from contextlib import contextmanager
import gc
import time
from .staged_gpu_128_qualification_v3 import StageMeter, need, clock, rss
from .qualify_staged_full_parent import host_arrays


class Profile:
    def __init__(self, torch, check, cap):
        self.meter = StageMeter(torch, check, cap)
        self.timings = {}

    @contextmanager
    def stage(self, name):
        top = name.startswith('profile_')
        if top:
            self.meter.switch(name)
        started = time.perf_counter()
        primary = None
        try:
            yield
        except BaseException as error:
            primary = error
            raise
        finally:
            row = self.timings.setdefault(name, dict(calls=0, host_seconds=0.))
            row['calls'] += 1
            row['host_seconds'] += time.perf_counter() - started
            if top:
                try:
                    self.meter.close()
                except BaseException as telemetry_error:
                    if primary is None:
                        raise
                    primary.pilot_telemetry_error = str(telemetry_error)

    def mark(self, name, **values):
        pass


def focal_groups(torch, columns, tile):
    return [rows for first in range(0, 1600, tile)
            if len(rows := ((columns >= first) & (columns < first + tile)).nonzero(as_tuple=True)[0])]


class DecoderCapture:
    """Original decoder visits nonempty haplotype tiles in increasing order."""
    def __init__(self, torch, model, focal_column, tile):
        self.torch = torch
        self.groups = focal_groups(torch, focal_column, tile)
        self.logits = torch.empty((len(focal_column), 3), dtype=torch.float32)
        self.index = 0
        self.hook = model.classifier.register_forward_hook(self.capture)

    def capture(self, module, inputs, output):
        need(self.index < len(self.groups), 'Exactly one classifier call per nonempty original tile')
        rows = self.groups[self.index]
        need(output.shape == (len(rows), 3) and bool(self.torch.isfinite(output).all()),
             'Finite classifier outputs align with original focal tile')
        self.logits[rows] = output.detach().cpu()
        self.index += 1

    def close(self):
        self.hook.remove()

    def result(self):
        need(self.index == len(self.groups), 'All original focal logits must be captured')
        return self.logits


def metrics(torch, logits, labels, loss):
    need(logits.shape == (len(labels), 3) and bool(torch.isfinite(logits).all()), 'Complete finite TRAIN logits')
    prediction = logits.argmax(-1).cpu()
    return dict(TRAIN_mean_CE=float(loss), TRAIN_focal_accuracy=float((prediction == labels).float().mean()),
        TRAIN_class_recall={str(c): float((prediction[labels == c] == c).float().mean())
                            if bool((labels == c).any()) else None for c in range(3)},
        class_counts={str(c): int((labels == c).sum()) for c in range(3)})


def build_baseline(model, bundle, metadata, runtime, config, check, profile):
    from research.efficiency_20261027.execution.large_block_executors import build_executor
    from research.efficiency_20261027.execution.large_layout_cache import LargeBlockLayoutCache
    cache = LargeBlockLayoutCache(max_bytes=config['baseline_layout_cache_bytes'],
        admit=lambda amount, stage: need(rss() + amount <= config['max_RSS_bytes'], 'Layout allocation exceeds host cap'))
    resident = config['baseline_kind'] == 'explicit_resident_vjp'
    if resident:
        import torch
        from research.efficiency_20261027.root.compare_selected_full import resident_admission
        free, _ = torch.cuda.mem_get_info()
        resident_admission(bundle.native_holds, free, config['max_GPU_reserved_bytes'], 16)
    execution = build_executor(model, bundle, metadata, resident_context=resident, layout_cache=cache,
        frozen_module=runtime.frozen, resource_check=check, profile=profile, **config['baseline_partitions'])
    return execution, cache


def build_transport(model, bundle, metadata, config, check):
    from .staged_transport import StagedTransport
    arrays = host_arrays(bundle)
    need(rss() + arrays['named_execution_array_bytes'] + config['local_execution_reserve_bytes'] <= config['max_RSS_bytes'],
         'Actual resident inputs plus full cached execution arrays and local reserve must fit')
    return StagedTransport(model, bundle.bank, bundle.episodes.flags.node_flags,
        metadata['episode_metadata']['native_nodes_per_tree'], cache_first_nodes=True,
        resource_check=check, **config['transport_partitions'])


def update(arm, model, optimizer, bundle, metadata, labels, step, runtime, config, check):
    import torch
    from torch.nn import functional as F
    from research.benchmark_rebuild_20261024.american.treeloom_speed.decoder_v2 import decode_parent_backward, geometry_from_spans
    from research.efficiency_20261027.root.context_residency import decode_resident_parent_backward
    execution = context = vjp = capture = cache = record = None
    profile = Profile(torch, check, config['max_GPU_reserved_bytes'])
    start = clock()
    model.train()
    optimizer.zero_grad(set_to_none=True)
    try:
        with torch.autocast(device_type='cuda', enabled=False):
            if arm == 'transport':
                with profile.stage('profile_transport_layout_and_forward'):
                    execution = build_transport(model, bundle, metadata, config, profile.meter.callback)
                    logits = execution.forward_focals(bundle.focal_hold, bundle.focal_sample_column)
                    loss = F.cross_entropy(logits, labels.to('cuda:0'))
                with profile.stage('profile_transport_full_backward'):
                    loss.backward()
                    need(logits.grad is not None and bool(torch.isfinite(logits.grad).all()), 'Finite complete focal VJP')
                    execution.backward_focals(logits.grad)
                    need(execution.state is None, 'Staged learned state consumed before update')
                full_logits = logits.detach().cpu()
            else:
                with profile.stage('profile_baseline_layout'):
                    execution, cache = build_baseline(model, bundle, metadata, runtime, config, check, profile)
                with profile.stage('profile_baseline_context'):
                    context = execution.context_forward()
                with profile.stage('profile_baseline_decoder'):
                    capture = DecoderCapture(torch, model, bundle.focal_sample_column, config['baseline_partitions']['haplotypes_per_gru'])
                    decoder = decode_resident_parent_backward if config['baseline_kind'] == 'explicit_resident_vjp' else decode_parent_backward
                    loss, vjp, detail = decoder(model, context, geometry_from_spans(bundle.bank.spans),
                        bundle.focal_hold, bundle.focal_sample_column, labels,
                        tile_haplotypes=config['baseline_partitions']['haplotypes_per_gru'], profile=profile, resource_check=check)
                    full_logits = capture.result()
                    capture.close(); capture = None
                with profile.stage('profile_baseline_trunk_backward'):
                    context.backward(vjp)
        with profile.stage('profile_metrics_clip_and_optimizer'):
            need(bool(torch.isfinite(loss)) and all(p.grad is not None and bool(torch.isfinite(p.grad).all())
                 for p in model.parameters()), 'Every model gradient and loss must be finite')
            expected = 55 if arm == 'transport' else 49
            need(len(list(model.parameters())) == expected, 'Exact parameter tensor count')
            scalars = metrics(torch, full_logits, labels, loss)
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
            optimizer.step()
            need(len(optimizer.state) == expected and all(int(row['step']) == step for row in optimizer.state.values())
                 and all(bool(torch.isfinite(p).all()) for p in model.parameters())
                 and all(bool(torch.isfinite(v).all()) for row in optimizer.state.values() for v in row.values() if torch.is_tensor(v)),
                 'One finite AdamW step per parameter with exact exposure')
        torch.cuda.synchronize()
        end = clock()
        seconds = end['monotonic_seconds'] - start['monotonic_seconds']
        record = dict(**scalars, gradient_norm=float(norm), update_start=start, update_end=end,
            update_seconds=seconds, supervised_focals_per_update_second=len(labels)/seconds,
            native_holds_per_update_second=bundle.native_holds/seconds,
            GPU_peak_allocated_bytes=max(r['GPU_peak_allocated_bytes'] for r in profile.meter.rows),
            GPU_peak_reserved_bytes=max(r['GPU_peak_reserved_bytes'] for r in profile.meter.rows),
            process_RSS_bytes=rss(), stages=profile.meter.rows, nested_host_timings=profile.timings,
            all_gradients_parameters_moments_finite=True, original_focal_order_metrics=True,
            baseline_kind=config['baseline_kind'] if arm == 'frozen_current' else None,
            GPU_activity_scope='External telemetry aligned by Unix update/stage intervals; host duration alone is not GPU duty.')
        return record
    except BaseException as error:
        error.pilot_partial = dict(arm=arm, step=step, stages=profile.meter.rows, open_stage=profile.meter.current,
            telemetry_error=getattr(error,'pilot_telemetry_error',None), started=start)
        raise
    finally:
        if capture is not None:
            capture.close()
        if execution is not None:
            execution.release() if arm == 'transport' else execution.release_layout()
        context = vjp = execution = cache = capture = None
        optimizer.zero_grad(set_to_none=True)
        gc.collect()
        torch.cuda.empty_cache()
        if record is not None:
            service_end=clock()
            record['service_end']=service_end
            record['service_seconds']=service_end['monotonic_seconds']-start['monotonic_seconds']
            record['supervised_focals_per_service_second']=len(labels)/record['service_seconds']
            record['service_scope']='Update plus release, gradient cleanup, garbage collection and CUDA allocator cache release.'


def predict_from_context(model, context, geometry, hold, column, *, tile, check):
    """Same original complete-sequence decoder with focal row scatter and no loss."""
    import torch
    device = next(model.parameters()).device
    logits = torch.empty((len(hold), 3), dtype=torch.float32)
    geometry = geometry.to(device)
    seen = 0
    for first in range(0, context.shape[1], tile):
        last = min(first + tile, context.shape[1])
        rows = ((column >= first) & (column < last)).nonzero(as_tuple=True)[0]
        if not len(rows):
            continue
        check('VAL_decoder_complete_history_tile')
        leaf = context[:, first:last].to(device).contiguous()
        forward, _ = model.scan_context(leaf, geometry, direction='forward')
        reverse, _ = model.scan_context(leaf, geometry, direction='reverse')
        hh, cc = hold[rows].to(device), (column[rows]-first).to(device)
        value = model.classifier(torch.cat((leaf[hh, cc], forward[hh, cc], reverse[hh, cc]), -1))
        need(value.shape == (len(rows), 3) and bool(torch.isfinite(value).all()), 'Finite complete VAL focal logits')
        logits[rows] = value.cpu()
        seen += len(rows)
        del leaf, forward, reverse, value
    need(seen == len(hold), 'All original VAL focals exactly once')
    return logits


def predict(arm, model, bundle, metadata, runtime, config, check):
    import torch
    from research.benchmark_rebuild_20261024.american.treeloom_speed.decoder_v2 import geometry_from_spans
    execution = context = cache = None
    profile = Profile(torch, check, config['max_GPU_reserved_bytes'])
    start = clock()
    model.eval()
    try:
        with torch.no_grad(), torch.autocast(device_type='cuda', enabled=False):
            with profile.stage('profile_VAL_layout_and_context'):
                if arm == 'transport':
                    execution = build_transport(model, bundle, metadata, config, profile.meter.callback)
                    logits = execution.forward_focals(bundle.focal_hold, bundle.focal_sample_column).detach().cpu()
                else:
                    execution, cache = build_baseline(model, bundle, metadata, runtime, config, check, profile)
                    context = execution.context_forward()
            if arm == 'frozen_current':
                with profile.stage('profile_VAL_decoder'):
                    logits = predict_from_context(model, context, geometry_from_spans(bundle.bank.spans),
                        bundle.focal_hold, bundle.focal_sample_column,
                        tile=config['baseline_partitions']['haplotypes_per_gru'], check=check)
            need(logits.shape == (10000, 3) and bool(torch.isfinite(logits).all()), 'All original VAL predictions')
            probabilities = logits.softmax(-1).cpu().numpy()
        end = clock()
        return probabilities, dict(start=start, end=end, seconds=end['monotonic_seconds']-start['monotonic_seconds'], stages=profile.meter.rows)
    finally:
        if execution is not None:
            execution.release() if arm == 'transport' else execution.release_layout()
        execution = context = cache = None
        gc.collect()
        torch.cuda.empty_cache()
