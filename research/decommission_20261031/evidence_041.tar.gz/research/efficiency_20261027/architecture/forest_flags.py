"""Observation-only exact local clade flags, including empty and forest holds."""
import hashlib
import numpy as np


def prepare_forest_clade_flags(parent, sample_index, node_offsets):
    """Keep native interval boundaries; no virtual root or internal ID matching.

    Flags match the existing deepest-unary representative convention. Proper
    clades contain 2..H-1 sampled descendants, even in a forest. All terminal
    nodes must be sampled, and every node must belong to its supplied interval.
    """
    parent=np.asarray(parent);samples=np.asarray(sample_index)
    offsets=np.asarray(node_offsets)
    if parent.ndim!=1 or parent.dtype.kind!='i' or samples.ndim!=2 or samples.dtype.kind!='i':
        raise ValueError('Signed integer parent and sample arrays required')
    t,h=samples.shape;n=len(parent)
    if offsets.shape!=(t+1,) or offsets[0]!=0 or offsets[-1]!=n or np.any(np.diff(offsets)<=0):
        raise ValueError('Complete nonempty native interval node blocks required')
    if np.any(parent < -1) or np.any(parent >= n):
        raise ValueError('Invalid parent index')
    flags=np.zeros((n,2),dtype=np.uint8)
    previous={};counts=[];root_counts=[];unary_counts=[]
    for hold,(start,stop) in enumerate(zip(offsets[:-1],offsets[1:])):
        start,stop=int(start),int(stop)
        local_parent=parent[start:stop]
        row=samples[hold]
        if len(np.unique(row))!=h or np.any(row<start) or np.any(row>=stop):
            raise ValueError('Each native interval must contain every distinct sampled leaf')
        if np.any((local_parent>=0)&((local_parent<start)|(local_parent>=stop))):
            raise ValueError('Native tree edge crosses interval boundaries')
        children=[[] for _ in range(stop-start)]
        roots=[]
        for node,ancestor in enumerate(local_parent,start):
            if ancestor<0:roots.append(node)
            else:children[int(ancestor)-start].append(node)
        order=[];stack=list(roots)
        while stack:
            node=stack.pop();order.append(node)
            stack.extend(children[node-start])
        if len(order)!=stop-start:
            raise ValueError('Cyclic or unreachable native nodes')
        sampled={int(node):1<<column for column,node in enumerate(row)}
        masks={};current={};unary=0;terminal=0
        for node in reversed(order):
            descendants=children[node-start]
            if not descendants:
                if node not in sampled:raise ValueError('Unsampled terminal native node')
                mask=sampled[node];terminal+=1
            else:
                if node in sampled:raise ValueError('Sampled interior nodes are unsupported')
                mask=0
                for child in descendants:mask|=masks[child]
            masks[node]=mask
            if 1<mask.bit_count()<h:
                if mask in current:
                    if len(descendants)!=1 or masks[descendants[0]]!=mask:
                        raise ValueError('Equal clades must form a unary chain')
                    unary+=1
                else:current[mask]=node
        union=0
        for root in roots:union|=masks[root]
        if terminal!=h or union!=(1<<h)-1:
            raise ValueError('Each native forest must contain exactly the full sampled panel')
        if hold:
            for mask,node in previous.items():
                if mask not in current:flags[node,1]=1
            for mask,node in current.items():
                if mask not in previous:flags[node,0]=1
        previous=current
        counts.append(len(current));root_counts.append(len(roots));unary_counts.append(unary)
    metadata=dict(schema='TreeLoom_Transport_forest_local_flags_v1',native_holds=t,
        native_nodes=n,haplotypes=h,root_counts=root_counts,proper_clade_counts=counts,
        unary_duplicates=unary_counts,gained_count=int(flags[:,0].sum()),lost_count=int(flags[:,1].sum()),
        representative_policy='deepest_structural_node_in_equal_clade_unary_chain',
        empty_intervals_retained=True,virtual_roots_added=False,observation_only=True,
        ancestry_targets_used=False,node_flags_sha256=hashlib.sha256(flags.tobytes()).hexdigest())
    return flags,metadata
