"""Tiny CPU metadata fixtures only; no child, native, scientific, or model run."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
from unittest.mock import patch
from research.efficiency_20261027.execution.european_short_val_runner import contracts_v2 as contracts, worker_v2 as worker

BASE = Path('research/efficiency_20261027/fidelity').resolve()
FIXTURE = BASE / 'shortval_runner_v2_boundary_fixture'
FIXTURE.mkdir()
checks = []

class Clock:
    wall = 2000000000.0
    tick = 100.0
    def time(self): return self.wall
    def monotonic(self): return self.tick

clock = Clock()
pid, parent = os.getpid(), os.getppid()
def row(identifier, ppid, start):
    return dict(pid=identifier, ppid=ppid, start=start, session=identifier,
                pgrp=identifier, state='S', rss_bytes=1)
table = {pid: row(pid, parent, 12), parent: row(parent, 1, 11)}
process_reads = []
def processes():
    process_reads.append(clock.tick)
    return copy.deepcopy(table)
argv = ['--metadata-fixture']
command = ['.runtime/env/bin/python3.11', '-B', '-m', contracts.MODULE, *argv]
request = dict(command=command, host_cap_bytes=contracts.HOST_CAP,
               output_cap_bytes=contracts.RESERVATION, operating_stop_bytes=contracts.OPERATING,
               max_seconds=contracts.MAX_SECONDS, CUDA_VISIBLE_DEVICES='',
               aggregate_directory=str(FIXTURE.relative_to(contracts.ROOT)),
               supervisor_pid=parent, supervisor_start_ticks='11',
               created_unix=clock.wall, deadline_unix=clock.wall + contracts.MAX_SECONDS)
launch = dict(actual_argv=command, pid=pid, process_start_ticks='12')
for name, value in [('request.json', request), ('launch.json', launch), ('release.json', {})]:
    (FIXTURE / name).write_text(json.dumps(value))
status = FIXTURE / 'status.json'
def set_status(age=0):
    status.write_text(json.dumps(dict(status='running', observed_unix=clock.wall-age)))
set_status()
original_read = Path.read_bytes
def read_bytes(path):
    if str(path) == '/proc/self/cmdline': return ('\0'.join(command)+'\0').encode()
    return original_read(path)
def reject(callback):
    try: callback()
    except ValueError: return
    raise AssertionError('Expected the metadata check to fail closed')

with patch.object(worker, 'AGGREGATE', FIXTURE), patch.object(contracts, 'AGGREGATE', FIXTURE), \
     patch.object(worker, 'process_table', processes), patch.object(worker, 'time', clock), \
     patch.object(Path, 'read_bytes', read_bytes), patch.dict(os.environ, {'CUDA_VISIBLE_DEVICES': ''}):
    check, remaining = worker.execution_checker(contracts.ref(FIXTURE/'request.json'),
        contracts.ref(FIXTURE/'launch.json'), contracts.ref(FIXTURE/'release.json'), request, launch, argv)
    assert remaining == contracts.MAX_SECONDS
    baseline = len(process_reads)
    for _ in range(100): check()
    assert len(process_reads) == baseline
    clock.tick += 1
    barrier = threading.Barrier(12)
    errors = []
    def concurrent_callback():
        try:
            barrier.wait(timeout=5)
            check()
        except BaseException as error: errors.append(repr(error))
    threads = [threading.Thread(target=concurrent_callback) for _ in range(12)]
    for thread in threads: thread.start()
    for thread in threads: thread.join(timeout=5)
    assert not errors and not any(thread.is_alive() for thread in threads)
    assert len(process_reads) == baseline + 1
    checks.append('One successful process sample for twelve simultaneous callbacks; one hundred hot callbacks add none')
    saved_wall, saved_tick = clock.wall, clock.tick
    clock.wall = request['deadline_unix']; reject(check); clock.wall = saved_wall
    clock.tick = 100.0 + contracts.MAX_SECONDS; reject(check); clock.tick = saved_tick
    assert len(process_reads) == baseline + 1
    checks.append('Unix and monotonic deadline equality each rejects before any cached process sample')
    (FIXTURE/'execution_hold').write_text('Tiny CPU fixture hold\n'); reject(check)
    assert len(process_reads) == baseline + 1
    checks.append('ROOT hold rejects immediately with a fresh successful cached sample')
    # Retain the first hold fixture as evidence and use a separate patched path
    # for the remaining metadata test, without deleting any file.
    with patch.object(Path, 'exists', lambda path: False if path == FIXTURE/'execution_hold' else Path.is_file(path)):
        clock.tick += 1
        set_status(age=11)
        before_failure = len(process_reads)
        reject(check); reject(check)
        assert len(process_reads) == before_failure + 2
        checks.append('A failed stale-status sample is never marked fresh; same-second retry fails closed again')

assert 'torch' not in sys.modules
result = dict(schema='European_short_VAL_runner_independent_CPU_boundaries_v1', passed=True,
              checks=checks, children_launched=False, native_tools_executed=False,
              generation_executed=False, model_or_scoring_executed=False, torch_imported=False,
              fixture_path=str(FIXTURE.relative_to(contracts.ROOT)),
              worker_sha256=hashlib.sha256(Path(worker.__file__).read_bytes()).hexdigest())
output = BASE/'EUROPEAN_SHORT_VAL_ROOT_RUNNER_V2_INDEPENDENT_CPU.json'
with output.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps(dict(passed=True, checks=len(checks), result_path=str(output.relative_to(contracts.ROOT)),
                     sha256=hashlib.sha256(output.read_bytes()).hexdigest()), sort_keys=True))
