"""Validate the prepared candidate without publishing a gate or starting work."""
import datetime
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path('/workspace-SR003.nfs2/ARG-GNN')
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
from arggnn.benchmarking.paper_campaign import runtime as r
from research.joint_evaluation_20261029.queue import successor_v2_gpu as gpu
from research.joint_evaluation_20261029.root import finish_coordinator_storage_v2 as finish

BASE = 'research/joint_evaluation_20261029'
FOLDER = BASE + '/queue/gpu_priority_after_fits_20261030_v1'
CANDIDATE = FOLDER + '/release_candidate_v1.json'
AMENDMENT = FOLDER + '/policy_amendment_v1.json'
EXPECTED_CANDIDATE = '2422c456731bcdbad4bf2fd81007fc44ea024cd444016c2e8874394d4380ef8c'
EXPECTED_AMENDMENT = 'e11dabe5edcf0919395e3aa4e03a94ca4897d2d7632dd430aed1d7eb8468db7c'


def need(value, message):
    if not value:
        raise ValueError(message)


def blocked_write(*args, **kwargs):
    raise AssertionError('Consumer validation must not write or publish')


candidate_ref = r.ref(CANDIDATE)
amendment_ref = r.ref(AMENDMENT)
need(candidate_ref['sha256'] == EXPECTED_CANDIDATE, 'Candidate hash changed')
need(amendment_ref['sha256'] == EXPECTED_AMENDMENT, 'Amendment hash changed')
candidate = r.read(candidate_ref)
amendment = r.read(amendment_ref)
need(candidate['amendment_ref'] == amendment_ref, 'Exact amendment binding required')
need(candidate['priority_only'] and not candidate['all_predictions_complete'], 'Honest priority-only scope required')
need(candidate['argmix_scope'] == 'fit_only', 'ARGMix fit-only scope required')
need(candidate['remaining_ARGMix_predictions_preserved'] == 9, 'Remaining prediction work preserved')
production_gate = r.path(amendment['publication_destination'])
need(not production_gate.exists() and not production_gate.is_symlink(), 'Root gate is already present')

for source in amendment['source_refs']:
    finish.check_reference(source)
plan = finish.verify_reference(amendment['finish_plan_ref'])
config = r.read(plan['successor_config_ref'])
template = dict(r.read(config['successor_template_ref']), handoff_config_ref=plan['successor_config_ref'])
candidate_template = dict(template, root_gpu_priority_release_path=CANDIDATE)
native_plan = finish.verify_reference(amendment['native_execution_plan_ref'])
task = next(row for row in native_plan['tasks'] if row['id'] == amendment['immediate_target_task_id'])
need(task['argv'] == amendment['original_native_task_argv'], 'Original native argv changed')
for key, value in amendment['original_native_task_limits'].items():
    need(task[key] == value, 'Original native resource changed: ' + key)
for source in task['source_refs']:
    finish.check_reference(source)
fit_wait = finish.waited(amendment['fit_inputs_actual_wait_ref'])
need(fit_wait['actual_returncode'] == 0, 'Native fit inputs lack genuine success')
waits = {name: finish.waited(reference) for name, reference in candidate['completed_models'].items()}
need(not r.path(task['output_directory']).exists(), 'Native train output already exists')
need(template['root_gpu_priority_release_path'] == amendment['publication_destination'], 'Destination changed')
need(gpu.LOCK_PATH == amendment['original_GPU3_mutex_path'], 'Shared GPU3 lock changed')

with patch.object(finish, 'immutable', blocked_write), patch.object(r, 'save', blocked_write):
    release_ref = gpu.root_release(candidate_template)
    allowed = gpu.allowed(candidate_template)
    chains = finish.chain_completions(plan)
    finisher_release = finish.maybe_release(plan, candidate_template, chains)
need(release_ref == candidate_ref == finisher_release, 'Consumers rejected exact candidate')
need(allowed == [3], 'Current candidate admission is not GPU3-only')
need(set(chains) == {'american_joint', 'european_four_joint'}, 'Unexpected full-chain completion map')
need('argmix_joint' not in chains, 'ARGMix must not be declared full-chain complete')
need(not production_gate.exists() and not production_gate.is_symlink(), 'Validation published a gate')

receipt = dict(
    schema='GPU_priority_candidate_consumer_validation_v1',
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    passed=True, candidate_ref=candidate_ref, amendment_ref=amendment_ref,
    validation_source_ref=r.ref(__file__), source_refs=amendment['source_refs'],
    native_plan_ref=amendment['native_execution_plan_ref'], native_source_refs_checked=len(task['source_refs']),
    genuine_wait_refs=candidate['completed_models'], fit_inputs_wait_ref=amendment['fit_inputs_actual_wait_ref'],
    allowed_physical_GPUs=allowed, full_chain_completions=chains,
    consumer_root_release_ref=release_ref, consumer_finisher_release_ref=finisher_release,
    all_predictions_complete=False, ARGMix_full_GPU_chain_complete=False,
    production_gate_absent=True, launches=0, signals=0, production_gate_writes=0,
    source_plan_state_rewrites=0, only_output=FOLDER + '/consumer_validation_v1.json')
receipt_path = r.path(receipt['only_output'])
with receipt_path.open('x') as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'passed': True, 'receipt_ref': r.ref(receipt_path), 'allowed': allowed,
                  'full_chain_completions': sorted(chains), 'production_gate_absent': True}, indent=2))
