"""Test exact European reservation credit and adversarial provenance failures."""
import copy
import unittest
from unittest.mock import patch
from arggnn.benchmarking.paper_campaign import runtime as r
from research.joint_evaluation_20261029.queue import storage_credit_v1 as credit


class StorageCreditTests(unittest.TestCase):
    def setUp(self):
        self.plan = {'handoff_config_ref': {'path': 'config.json', 'sha256': 'config'}}
        self.credit_ref = {'path': 'credit.json', 'sha256': 'credit'}
        self.config = {'storage_ledger_ref': {'path': 'ledger.json', 'sha256': 'ledger'}}
        self.evidence = dict(schema='european_reservation_release_evidence_v1', root_authorized=True,
            original_successor_config_ref=self.plan['handoff_config_ref'], original_storage_ledger_ref=self.config['storage_ledger_ref'],
            allowance_name=credit.ALLOWANCE, prior_allowance_bytes=160*2**30, revised_allowance_bytes=128*2**30,
            credit_bytes=32*2**30, full_future_attempt_bytes=128_983_236_608,
            fit_allowance_bytes=2*2**30, small_work_allowance_bytes=2**29, additional_other_work_allowance_bytes=2**30,
            reservation_basis_refs=[{'path': 'basis.json', 'sha256': 'basis'}], terminal_runs=[])
        self.values = {'credit.json': self.evidence, 'config.json': self.config, 'basis.json': {}}
        for i, scope in enumerate(sorted(credit.EXPECTED_SCOPES)):
            wait_path = scope + '/actual_wait.json'
            identity = dict(pid=90000+i, start_ticks=str(1000+i))
            self.evidence['terminal_runs'].append(dict(scope=scope, actual_wait_ref={'path': wait_path, 'sha256': 'wait'},
                worker_identity=identity, supervisor_identity=dict(pid=91000+i, start_ticks=str(2000+i)),
                logical_bytes=900_000_000, allocated_bytes=920_000_000))
            self.values[wait_path] = dict(pid=identity['pid'], process_start_ticks=identity['start_ticks'],
                actual_wait=True, actual_returncode=1, owned_family_absent=True, owned_group_absent=True,
                adopted_waits=[], tracked_family=[{'pid': identity['pid'], 'start': int(identity['start_ticks']), 'session': identity['pid']}])
        self.before = dict(items={credit.ALLOWANCE:160*2**30, 'Other full writer reservations':1_047_494_436_265},
                           total_bytes=1_219_293_128_105, ceiling_bytes=1_200_000_000_000, admitted=False)

    def evaluate(self, usage=None, sessions=None, process=None):
        with patch.object(r, 'read', side_effect=lambda ref: self.values[ref['path']]), patch.object(credit.original, 'commitment', return_value=copy.deepcopy(self.before)), patch.object(credit, 'scope_usage', return_value=usage or dict(logical_bytes=900_000_000, allocated_bytes=920_000_000)), patch.object(credit.processes, 'session_members', return_value=sessions or []), patch.object(credit, 'identity', return_value=process):
            return credit.commitment(self.plan, self.credit_ref, argmix_override_bytes=25*2**30)

    def test_exact_credit_keeps_full_future_work(self):
        result = self.evaluate()
        self.assertEqual(result['total_bytes'], 1_184_933_389_737)
        self.assertTrue(result['admitted'])
        self.assertEqual(result['before_credit_total_bytes']-result['total_bytes'], 32*2**30)
        self.assertEqual(result['items']['Other full writer reservations'], self.before['items']['Other full writer reservations'])
        self.assertEqual(result['prospective_european_reservation_revision']['full_future_attempt_bytes'], 128_983_236_608)
        self.assertFalse(result['prospective_european_reservation_revision']['files_deleted'])

    def test_root_authority_required(self):
        self.evidence['root_authorized'] = False
        with self.assertRaisesRegex(ValueError, 'Root-authorized'):
            self.evaluate()

    def test_owner_config_cannot_change(self):
        self.evidence['original_successor_config_ref'] = {'path': 'other', 'sha256': 'other'}
        with self.assertRaisesRegex(ValueError, 'different original'):
            self.evaluate()

    def test_credit_cannot_be_larger(self):
        self.evidence['credit_bytes'] += 1
        with self.assertRaisesRegex(ValueError, 'Only exact'):
            self.evaluate()

    def test_unconsumed_wait_cannot_release(self):
        self.values[self.evidence['terminal_runs'][0]['actual_wait_ref']['path']]['actual_wait'] = False
        with self.assertRaisesRegex(ValueError, 'genuine consumed failed'):
            self.evaluate()

    def test_successful_wait_cannot_replace_failed_evidence(self):
        self.values[self.evidence['terminal_runs'][0]['actual_wait_ref']['path']]['actual_returncode'] = 0
        with self.assertRaisesRegex(ValueError, 'genuine consumed failed'):
            self.evaluate()

    def test_surviving_worker_or_supervisor_session_fails(self):
        with self.assertRaisesRegex(ValueError, 'session is still live'):
            self.evaluate(sessions=[90001])

    def test_surviving_worker_identity_fails(self):
        with self.assertRaisesRegex(ValueError, 'process is still live'):
            self.evaluate(process={'start_ticks': '1000'})

    def test_changed_worker_start_identity_fails(self):
        self.values[self.evidence['terminal_runs'][0]['actual_wait_ref']['path']]['process_start_ticks'] = 'changed'
        with self.assertRaisesRegex(ValueError, 'start identity differs'):
            self.evaluate()

    def test_new_retained_growth_fails(self):
        with self.assertRaisesRegex(ValueError, 'scope grew'):
            self.evaluate(usage=dict(logical_bytes=900_000_001, allocated_bytes=920_000_000))

    def test_missing_or_extra_scope_fails(self):
        self.evidence['terminal_runs'][0]['scope'] = 'unrelated'
        with self.assertRaisesRegex(ValueError, 'Exact four'):
            self.evaluate()

    def test_revised_allowance_must_cover_future_work(self):
        for run in self.evidence['terminal_runs']:
            run['allocated_bytes'] = 3*2**30
        with self.assertRaisesRegex(ValueError, 'cannot cover'):
            self.evaluate()

    def test_credit_cannot_be_applied_twice(self):
        self.before['items'][credit.ALLOWANCE] = 128*2**30
        with self.assertRaisesRegex(ValueError, 'already changed'):
            self.evaluate()


if __name__ == '__main__':
    unittest.main()
