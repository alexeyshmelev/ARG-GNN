# H061 manuscript candidate

Supplement-only, uncompiled candidate based on the exact canonical source hash recorded in provenance.v1.json. The new final subsection contains two paragraphs and one compact five-row table. Removing H061_supplement_insert.tex reproduces the original manuscript byte for byte, preserving every existing table, formula, TODO, figure and name. Main text is unchanged.

The score acceptance is SHA100a5745a6ab055f722f7b754cfa8eb0e1a4d35af116ba06aeb237ebb1d2ff04. Scores are SHAcfec78f32637ca32dafb76e79e04dda0e06aaf31817bc7836d24249c5c036d6f. The protocol, registration, actual train completion and score completion are also bound in provenance.v1.json. No raw data, truth, checkpoint or prediction payload was read.

Table cells round actual aggregate seed means/sample SDs and frozen comparator errors to three decimals. Bold marks NoMem MAE and Full RMSE, the numerical minima. The text retains the negative registered memory utility result and paired +0.259820 case MAE difference with conditional95%13-week block interval [0.105412,0.427353]. Chronology shuffling supports reliance only. Uncertainty is conditional on one fixed graph/time series and three initialization seeds. No native GST/GRU comparison, ancestry transfer result, broad superiority or changing-topology claim is added.

The addition is deliberately compact, contains no pagebreak and is designed for at most one extra page. Pagination has not been measured because compilation was prohibited. No canonical file edit, compile, resource or Git action occurred. ROOT owns integration and final layout checks. candidate.diff is the exact unified source diff.
