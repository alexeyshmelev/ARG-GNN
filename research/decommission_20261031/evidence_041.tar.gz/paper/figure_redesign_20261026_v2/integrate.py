"""Integrate the reviewed drawings without changing any result table."""
from pathlib import Path
import re
import json
import hashlib
import shutil
from zipfile import ZipFile, ZIP_DEFLATED
root=Path.cwd()
out=root/'paper/figure_redesign_20261026_v2'
paper=root/'paper'
p=paper/'current_full_panel_working.tex'
before=p.read_text()
fig1=r'''\begin{figure*}[!t]
\centering
\includegraphics[width=\textwidth]{figures/TreeLoom_architecture.pdf}
\caption{\textbf{a,} Ordered marginal trees, observed alleles and reference ancestry. Samples retain their identities across trees. The age cut defines descendant groups.
\textbf{b,} Each round traverses every tree upward and downward. The four drawings show these traversals, with weights shared between rounds. Structural correction $s$ and memory correction $\delta$ update the original features before round 2. Figure~\ref{fig:operators} expands the node operations.
\textbf{c,} At the marked ancestor in $T_2$, upward and outside states $u+o$ project to group context $f_2$. Copies enter separate forward and reverse memory tracks for haplotypes r1 and r2. The inset expands one update. Averaging directions, then current group members, subtracting $f_2$, and projecting back gives $\delta$. The same haplotype carries history when its group changes. Other intervals' context inputs are omitted for clarity.
\textbf{d,} Query embeddings enter one BiGRU layer, a classifier and softmax. Symbols $\parallel$, $\tfrac12\Sigma$ and $\times$ denote concatenation, averaging two vectors and scalar multiplication. Colors are defined in the legend. Values are illustrative.}
\label{fig:architecture}
\end{figure*}'''
fig2=r'''\begin{figure*}[!t]
\centering
\includegraphics[width=\textwidth]{figures/TreeLoom_operators.pdf}
\caption{\textbf{a,} Upward node update. Each child state passes through a linear map and its edge gate. Their arithmetic mean joins the node input $b$, then passes through a linear map, tanh, a residual addition and layer normalization. This operation repeats from leaves to root.
\textbf{b,} Downward node update. Parent outside state $o_p$, input $b_p$ and mean child message $a_p$ are combined, excluding the recipient's normalized contribution $m_{q\to p}$. Two linear maps, an edge gate, tanh and normalization produce the child's outside state. This repeats from root to leaves, starting with zero outside state at the root. Edge features generate each directional gate through a linear map and sigmoid.
\textbf{c,} Structural corrections replace the previously named clade adapters. Descendant groups appear, disappear or persist across trees. Binary flags select two factored transformations of the current upward state $u$. The examples mark loss at $T_1$, gain at $T_2$ and persistence across all three trees. Neighboring hidden states do not enter these circuits. Matrices have separate weights between the two corrections. The symbol $\odot$ is elementwise multiplication, $\parallel$ is concatenation, and $\times$ multiplies by a scalar. Diagram state $u$ is the upward state $h_v$ in the equations.}
\label{fig:operators}
\end{figure*}'''
pattern=r'\\begin\{figure\*\}\[!t\].*?\\label\{fig:architecture\}\s*\\end\{figure\*\}'
assert len(re.findall(pattern,before,flags=re.S))==1
s=re.sub(pattern,lambda m:fig1+'\n\n'+fig2,before,flags=re.S)
s=s.replace('Both graph traversals include the complete inferred tree.', 'The encoder makes two rounds through each complete inferred tree, each comprising an upward traversal and a downward traversal. These are four full traversals, with the same node operator reused at every tree depth rather than a fixed stack of four message passing layers.')
oldtables=re.findall(r'\\begin\{table\*?\}.*?\\end\{table\*?\}',before,re.S)
newtables=re.findall(r'\\begin\{table\*?\}.*?\\end\{table\*?\}',s,re.S)
assert oldtables==newtables and len(oldtables)==8
p.write_text(s)
(out/'caption_overview.tex').write_text(fig1+'\n')
(out/'caption_operators.tex').write_text(fig2+'\n')
for name in ['TreeLoom_architecture','TreeLoom_operators']:
    for ext in ['pdf','svg','png']:
        shutil.copy2(out/(name+'.'+ext),paper/'figures'/(name+'.'+ext))
receipt={'source_before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(s.encode()).hexdigest(),'all_eight_result_tables_unchanged':True,'experiments_remain_stopped':True,'new_training_or_simulation':False}
(out/'integration.json').write_text(json.dumps(receipt,indent=2)+'\n')
for d in ['build','overleaf_build']:(out/d).mkdir(exist_ok=True)
source_bbl=paper/'figure_redesign_20261026/build/current_full_panel_working.bbl'
if source_bbl.exists():shutil.copy2(source_bbl,out/'build/current_full_panel_working.bbl')
readme='TreeLoom development manuscript. Compile main.tex with pdfLaTeX and BibTeX. Figures 1 and 2 show the tree encoder, haplotype memory and node operations. All result tables are unchanged. This is not a completed matched benchmark.\n'
with ZipFile(paper/'current_full_panel_overleaf_working.zip','w',ZIP_DEFLATED) as z:
    z.writestr('main.tex',s)
    for f in ['current_full_panel_refs.bib','aaai2027.sty','aaai2027.bst','figures/TreeLoom_architecture.pdf','figures/TreeLoom_operators.pdf']:
        z.write(paper/f,f)
    z.writestr('README.txt',readme)
with ZipFile(paper/'current_full_panel_overleaf_working.zip') as z:z.extractall(out/'overleaf_build')
print('Integrated two figures and preserved all eight table blocks.')
