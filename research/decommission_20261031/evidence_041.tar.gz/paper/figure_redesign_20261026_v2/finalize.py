"""Verify manuscript preservation and record final figure/build provenance."""
from pathlib import Path
import json,re,hashlib,subprocess
root=Path.cwd();out=root/'paper/figure_redesign_20261026_v2'
old=subprocess.run(['git','show','HEAD:paper/current_full_panel_working.tex'],check=True,capture_output=True,text=True).stdout
new=(root/'paper/current_full_panel_working.tex').read_text()
pattern=r'\\begin\{table\*?\}.*?\\end\{table\*?\}'
tables=re.findall(pattern,new,re.S)
print('Table count',len(tables),'unchanged',re.findall(pattern,old,re.S)==tables,flush=True)
assert re.findall(pattern,old,re.S)==tables and len(tables)==8
logs=[out/'build/current_full_panel_working.log',out/'overleaf_build/main.log']
for p in logs:
    problems=re.findall(r'LaTeX Warning:.*|Overfull.*|^!.*',p.read_text(),re.M)
    print(p.name,'blocking warnings',problems,flush=True)
    assert not problems
pdfs=[root/'paper/current_full_panel_working.pdf',out/'overleaf_build/main.pdf']
texts=[]
for p in pdfs:
    texts.append(subprocess.run([str(root/'.runtime/env/bin/pdftotext'),'-layout',str(p),'-'],check=True,capture_output=True,text=True).stdout)
print('Compiled text matches',texts[0]==texts[1],flush=True)
assert texts[0]==texts[1]
byte_match=pdfs[0].read_bytes()==pdfs[1].read_bytes()
receipt=json.loads((out/'integration.json').read_text())
receipt.update({'source_after_sha256':hashlib.sha256(new.encode()).hexdigest(),'pages':11,'figure_pages':[3,4],'canonical_build_exit':0,'extracted_overleaf_build_exit':0,'canonical_and_overleaf_text_identical':True,'canonical_and_overleaf_pdf_byte_identical':byte_match,'latex_warnings':[],'underfull_box_diagnostics':3,'visual_inspection':'Both standalone renders, all-page contact sheet and figure pages inspected','image_only_review':'Independent image reader, no source or manuscript, targeted final review found no blocking diagram error','implementation_audit':'Frozen model operations and saved toy tree sequence checked','experiments_remain_stopped':True,'tables_unchanged':8})
files=['paper/current_full_panel_working.tex','paper/current_full_panel_working.pdf','paper/current_full_panel_overleaf_working.zip','paper/figure_redesign_20261026_v2/build_figures.py']
for stem in ['TreeLoom_architecture','TreeLoom_operators']:
    files.extend('paper/figures/'+stem+'.'+ext for ext in ['pdf','svg','png'])
receipt['artifacts']={f:{'bytes':(root/f).stat().st_size,'sha256':hashlib.sha256((root/f).read_bytes()).hexdigest()} for f in files}
(out/'integration.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ['paper/README.md','paper/CURRENT_FULL_PANEL_README.md']:
    p=root/name;s=p.read_text()
    s=s.replace('ten-page','eleven-page').replace('pages 1–6','pages 1–7').replace('pages 7–10','pages 8–11')
    start=s.index('Figure 1 was redesigned on 26 October.')
    end=s.index('\n\n',start)
    s=s[:start]+'Figures 1 and 2 were redesigned on 26 October. The overview retains the biological inputs and prediction readout, shows all four tree traversals in two rounds, and draws separate haplotype memory tracks across trees. The companion figure expands the exact node updates and structural corrections. Every color has a consistent meaning and a visible legend. [Overview](figures/TreeLoom_architecture.png) · [Node operations](figures/TreeLoom_operators.png) · [Generator and review](figure_redesign_20261026_v2/README.md).'+s[end:]
    start=s.index('The manuscript and extracted Overleaf bundle compile')
    end=s.index('\n\n',start)
    s=s[:start]+'The manuscript and extracted Overleaf bundle compile to eleven pages, with no errors, undefined references, overfull boxes or oversized floats. Figures 1 and 2 occupy pages 3 and 4. Three underfull-box diagnostics remain and were visually inspected. All eight result tables are unchanged. [Build and review record](figure_redesign_20261026_v2/integration.json).'+s[end:]
    p.write_text(s)
p=root/'README.md';s=p.read_text();a=s.index('<!-- figure-redesign-current:start -->');b=s.index('<!-- figure-redesign-current:end -->',a)
s=s[:a]+'''<!-- figure-redesign-current:start -->
**TreeLoom figures redesigned, 26 October:** four directed tree traversals in two rounds, explicit haplotype memory tracks, and a companion figure with the exact GNN node updates and structural corrections. Every color has a legend. [Overview](paper/figures/TreeLoom_architecture.png) · [Node operations](paper/figures/TreeLoom_operators.png) · [Updated 11-page paper](paper/current_full_panel_working.pdf) · [Editable figures and review](paper/figure_redesign_20261026_v2/README.md). All eight result tables are unchanged. Experiments remain stopped.
''' +s[b:];p.write_text(s)
print('Final verification and documentation complete.',flush=True)
