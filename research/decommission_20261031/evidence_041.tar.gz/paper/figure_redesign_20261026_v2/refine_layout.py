from pathlib import Path
p=Path('paper/figure_redesign_20261026_v2/build_figures.py')
s=p.read_text()
s=s.replace("ax.add_patch(Circle((xp[rep],yp[rep]),.045,fc=WHITE,ec=INK,lw=1.1,zorder=7))", "ax.add_patch(Rectangle((xp[rep]-.040,yp[rep]-.040),.080,.080,fc='none',ec=INK,lw=.85,zorder=7))")
start=s.index('# (c) A worked example')
end=s.index('# Readout retains',start)
s=s[:start]+r'''# (c) Memory is visibly indexed by sampled haplotype and genomic interval.
# The tracks show stored states. The small arithmetic cell expands one update.
panel(.12,4.17,'c')
left=tree_glyph(1,.57,5.18,w=.77,h=.83,cut=True,rep=8)
text(.57,4.23,'$T_2$',8.5)
x1=.57-.77/2+.77/4;x2=.57
line([(x1,5.26),(x1,5.31),(x2,5.31),(x2,5.26)],.65)
text((x1+x2)/2,5.46,'r1  r2',7.5)
arrow([left[8],(1.10,left[8][1]),(1.10,4.84),(1.20,4.84)],lw=.65)
mat(1.20,4.70,.22,.28,'32→8')
arrow([(1.42,4.84),(1.60,4.84)],lw=.65)
vector(1.62,4.78,.22,.12,3)
text(1.73,4.58,'$f_2$',8)
# Three positions and two directions show that histories are propagated.
cols=[2.65,3.65,4.65]
for j,x in enumerate(cols):text(x,4.24,'$T_'+str(j+1)+'$',8)
for y,name in [(4.64,'r1'),(5.57,'r2')]:
    text(2.18,y+.19,name,8)
    for yy,forward in [(y,True),(y+.38,False)]:
        for x in cols:vector(x-.11,yy-.055,.22,.11,3)
        for a,b in zip(cols[:-1],cols[1:]):
            points=[(a+.11,yy),(b-.11,yy)] if forward else [(b-.11,yy),(a+.11,yy)]
            arrow(points,lw=.7)
        # The same current group context is copied to the two member tracks.
        fy=yy-.20 if forward else yy+.20
        vector(3.58,fy-.035,.14,.07,2)
        text(3.38,fy,'$f_2$',7)
        arrow([(3.65,fy+(.035 if forward else -.035)),(3.65,yy+(-.055 if forward else .055))],lw=.55)
    # Current directional states are averaged before group pooling.
    arrow([(3.76,y),(3.98,y),(3.98,y+.115)],lw=.55)
    arrow([(3.76,y+.38),(3.98,y+.38),(3.98,y+.265)],lw=.55)
    op(3.98,y+.19,'½Σ',.075,7)
    arrow([(4.055,y+.19),(5.10,y+.19),(5.10,5.24 if name=='r1' else 5.42)],lw=.6)
op(5.10,5.33,'½Σ',.09,7.5)
arrow([(5.19,5.33),(5.50,5.33)],lw=.65)
op(5.59,5.33,'−',.09,10)
vector(5.48,5.77,.22,.11,3);text(5.84,5.825,'$f_2$',8)
arrow([(5.59,5.77),(5.59,5.42)],lw=.6)
arrow([(5.68,5.33),(6.00,5.33)],lw=.65)
mat(6.00,5.17,.23,.32,'8→32')
arrow([(6.23,5.33),(6.56,5.33),(6.56,5.72)],lw=.6)
vector(6.44,5.74,.24,.12,3);text(6.80,5.80,r'$\delta$',8)
right=tree_glyph(1,6.29,6.96,w=.77,h=.83,cut=True,rep=8)
arrow([(6.56,5.86),(6.56,6.13),(right[8][0],6.13),(right[8][0],right[8][1]-.04)],lw=.6)
# One magnified update gives the operation used at every step of both tracks.
# This avoids four repeated arithmetic circuits and retains visible recurrence.
box(.20,5.77,4.63,1.21,dashed=True)
vector(.34,6.27,.25,.11,3);text(.47,6.10,r'$m_{t-1}^{\to}$',7.5)
arrow([(.59,6.325),(.90,6.325)],lw=.65)
op(.98,6.325,'×',.075,9);text(.98,6.10,r'$\alpha_t$',7.5)
arrow([(1.055,6.325),(2.20,6.325)],lw=.65)
op(2.29,6.325,'+',.09,11)
vector(1.35,5.95,.22,.10,3);text(1.23,6.00,'$f_t$',7.5)
arrow([(1.57,6.00),(1.80,6.00)],lw=.6)
op(1.88,6.00,'×',.075,9);text(1.88,5.83,r'$1-\alpha_t$',7)
arrow([(1.955,6.00),(2.29,6.00),(2.29,6.235)],lw=.6)
arrow([(2.38,6.325),(2.64,6.325)],lw=.65)
vector(2.66,6.27,.27,.11,3);text(2.795,6.10,r'$m_t^{\to}$',7.5)
arrow([(2.93,6.325),(3.18,6.325)],lw=.65)
text(3.45,6.325,r'$T_{t+1}$',8)
text(2.50,6.76,r'$\alpha_t=\exp(-|I_t|/\ell)$',8)
''' + s[end:]
# The neutral key covers every non-ancestry mark, including the representative.
s=s.replace("vector(.24,8.44,.14,.08,2);text(.45,8.48,'Features',7.3,ha='left')", "vector(.24,8.44,.14,.08,2);text(.45,8.48,'Features / weights',7.0,ha='left')")
s=s.replace("line([(1.66,8.48),(1.80,8.48)],.8);text(1.88,8.48,'Structure / operations',7.3,ha='left')", "line([(2.00,8.48),(2.14,8.48)],.8);text(2.22,8.48,'Structure / operations',7.0,ha='left')")
s=s.replace("text(5.09,8.48,'HG: hunter-gatherer',7.3,ha='left')", "ax.add_patch(Rectangle((4.88,8.44),.08,.08,fc='none',ec=INK,lw=.7));dot(4.92,8.48,None,.010)\ntext(5.06,8.48,'Group ancestor',7.0,ha='left')")
s=s.replace("('Anatolian farmer (Ana)',.24,8.70),('Caucasus HG (CHG)',3.55,8.70),\n        ('Western HG (WHG)',.24,8.91),('Eastern HG (EHG)',3.55,8.91)", "('Anatolian farmer (Ana)',.24,8.70),('Caucasus hunter-gatherer (CHG)',3.55,8.70),\n        ('Western hunter-gatherer (WHG)',.24,8.91),('Eastern hunter-gatherer (EHG)',3.55,8.91)")
# No crossing wires in the shared projected-state branch.
start=s.index("for y,tag in [(3.57,'U')")
end=s.index('# Persistence has',start)
s=s[:start]+r'''for y,tag in [(3.57,'V'),(3.94,'U'),(4.31,'W')]:
    line([(2.42,3.32),(2.42,y),(2.61,y)],.6)
    mat(2.61,y-.11,.19,.22)
    text(2.70,y+.23,tag,7.5)
    arrow([(2.80,y),(2.98,y)],lw=.6)
    vector(3.00,y-.05,.22,.10,3)
arrow([(3.22,3.57),(3.60,3.57)],lw=.6);op(3.68,3.57,'⊙',.075,9)
arrow([(3.22,4.31),(3.60,4.31)],lw=.6);op(3.68,4.31,'⊙',.075,9)
line([(3.22,3.94),(3.68,3.94)],.6)
arrow([(3.68,3.94),(3.68,3.645)],lw=.6)
arrow([(3.68,3.94),(3.68,4.235)],lw=.6)
arrow([(3.755,3.57),(3.99,3.57)],lw=.6);op(4.07,3.57,'×',.075,9);text(4.07,3.35,'g',8)
arrow([(3.755,4.31),(3.99,4.31)],lw=.6);op(4.07,4.31,'×',.075,9);text(4.07,4.53,'l',8)
arrow([(4.145,3.57),(4.40,3.57),(4.40,3.86)],lw=.6)
arrow([(4.145,4.31),(4.40,4.31),(4.40,4.02)],lw=.6)
op(4.40,3.94,'−',.08,10)
arrow([(4.48,3.94),(4.65,3.94)],lw=.6);mat(4.65,3.81,.23,.26,'O')
arrow([(4.88,3.94),(5.06,3.94)],lw=.6);vector(5.08,3.88,.25,.12,3)
text(5.20,4.25,'$s_f$',8)
''' + s[end:]
s=s.replace("arrow([(5.33,4.125),(5.83,4.125),(5.83,4.87)],lw=.6)", "arrow([(5.33,3.94),(5.83,3.94),(5.83,4.87)],lw=.6)")
s=s.replace("text(x+.42,y,sym,8)", "text(x+.42,y,sym,8)")
s=s.replace("text(.86,4.69,'descendant groups',7.5)", "text(.86,4.65,'descendant groups',7.5)\ntext(1.12,4.88,r'$g,l,e\in\{0,1\}$',7.5)")
# Explicitly name the interval at which each example is evaluated.
s=s.replace("(1.66,3.52,'lost','l'),(1.66,3.90,'gained','g'),(1.66,4.28,'persists','e')", "(1.66,3.52,'lost',r'$l_1$'),(1.66,3.90,'gained',r'$g_2$'),(1.66,4.28,'persists',r'$e_{1:3}$')")
# Give the second figure a complete legend rather than unexplained initials.
s=s.replace("figsize=(7,6.30)","figsize=(7,6.55)").replace("ylim=(7.20,0)","ylim=(7.48,0)")
start=s.index('# A complete palette key is present')
s=s[:start]+r'''# Every color is defined on this figure independently.
line([(.18,6.60),(6.91,6.60)],.55)
for color,(name,x,y) in zip(ANC,[('Anatolian farmer',.23,6.79),('Caucasus hunter-gatherer',3.55,6.79),('Western hunter-gatherer',.23,7.00),('Eastern hunter-gatherer',3.55,7.00)]):
    ax.add_patch(Rectangle((x,y-.05),.12,.10,fc=color,ec='none'));text(x+.20,y,name,7.3,ha='left')
vector(.23,7.23,.13,.08,2);text(.45,7.27,'Features / weights',7.3,ha='left')
line([(2.30,7.27),(2.44,7.27)],.8);text(2.52,7.27,'Structure / operations',7.3,ha='left')
dot(4.90,7.27,0,.035);text(5.02,7.27,'Query',7.3,ha='left')
save('TreeLoom_operators')
print('Rendered overview and operator detail in',OUT)
'''
p.write_text(s)
