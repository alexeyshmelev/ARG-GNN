Set main.tex as the main document. Compile with pdfLaTeX and BibTeX. This is a working research draft.
