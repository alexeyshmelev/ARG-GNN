Working scientific manuscript. Select main.tex and compile with pdfLaTeX and BibTeX in Overleaf. Important research TODOs remain visible. Source code: https://github.com/alexeyshmelev/ARG-GNN
