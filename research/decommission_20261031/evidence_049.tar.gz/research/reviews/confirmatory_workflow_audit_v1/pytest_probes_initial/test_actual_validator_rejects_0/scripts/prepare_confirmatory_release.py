#!/usr/bin/env python
"""Lock-first existing-artifact custody release; no simulation or inference."""
import argparse
import json
from arggnn.confirmatory_custodian import custodian_schema_values, prepare_confirmatory_release


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--schema", action="store_true", help="Print prospective schema only")
    for name in ("lock", "expected-lock-sha256", "request", "expected-request-sha256", "output"):
        parser.add_argument("--"+name)
    args = parser.parse_args(argv)
    if args.schema:
        if any(getattr(args, name.replace("-", "_")) is not None for name in
               ("lock", "expected-lock-sha256", "request", "expected-request-sha256", "output")):
            parser.error("--schema cannot be combined with an actual release")
        print(json.dumps(custodian_schema_values(), sort_keys=True, indent=2))
        return
    if any(getattr(args, name.replace("-", "_")) is None for name in
           ("lock", "expected-lock-sha256", "request", "expected-request-sha256", "output")):
        parser.error("Release requires explicit lock/request paths and SHA256s plus fresh output")
    result = prepare_confirmatory_release(args.lock, args.expected_lock_sha256, args.request,
        args.expected_request_sha256, output_directory=args.output)
    print(json.dumps({"path": result.path, "sha256": result.sha256,
        "admitted_parents": result.receipt["admitted_parents"],
        "expected_prediction_cells": result.receipt["expected_prediction_cells"],
        "positive_confirmation_authorized": False}, sort_keys=True))


if __name__ == "__main__":
    main()

