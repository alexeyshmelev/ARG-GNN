# Synthetic unit-test source, no real fitting.
def fit_temperature(records):
    return 1.0
