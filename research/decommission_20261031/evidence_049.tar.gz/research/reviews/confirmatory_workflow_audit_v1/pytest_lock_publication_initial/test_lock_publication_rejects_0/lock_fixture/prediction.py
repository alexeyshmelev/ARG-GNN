# Synthetic unit-test workflow stand-in, not production.
def main(records):
    return [dict(row) for row in records]
