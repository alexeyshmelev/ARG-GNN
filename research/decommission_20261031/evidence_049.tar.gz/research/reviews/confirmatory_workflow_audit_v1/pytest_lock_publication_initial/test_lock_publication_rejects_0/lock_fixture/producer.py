# Synthetic receipt producer bytes, never executed.
