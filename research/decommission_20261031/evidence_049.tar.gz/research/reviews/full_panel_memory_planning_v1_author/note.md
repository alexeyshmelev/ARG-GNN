# Full952 memory planning, metadata only

The four observation receipts contain995,979,932 and903 genuine marginal holds,
far fewer than the roughly4000 holds of each H036 tsinfer parent. They do not
record the total complete-union/augmented forest vertices or edges. Exact counts
cannot be obtained under this metadata-only request. The table's vertex/edge
counts are conditional binary-tree estimates, not measurements:952tips imply
1903vertices and1902edges per connected binary tree. Native unary/additional
vertices have not been counted and must be retained in the real qualification.
H038 adds no analytic census cut nodes.

| Parent | Holds | Original VCF / inferred SNPs | Estimated vertices / edges | Vertex-scaled peak GB |
| --- | ---: | ---: | ---: | ---: |
| ap_full_train_000 | 995 | 13,684 / 13,644 | 1,893,485 / 1,892,490 | 18.6 |
| ap_full_train_001 | 979 | 13,781 / 13,750 | 1,863,037 / 1,862,058 | 18.3 |
| ap_full_train_002 | 932 | 13,354 / 13,330 | 1,773,596 / 1,772,664 | 17.4 |
| ap_full_discovery_holdout_000 | 903 | 12,968 / 12,938 | 1,718,409 / 1,717,506 | 16.9 |

Using root's H036 anchor1.70millionvertices/16.7GB, these conditional estimates
suggest16.9–18.6GB for the same width32 FP32 tree computation, not a prediction
near80GB. This is a planning ratio, not a measured H038 peak. Full-parent
recurrence has0.860–0.947million sampled leaf/hold rows; one width32 FP32 leaf
state is110–121MB. Readout logits for about20000bins*686queries*4classes are
about220MB. Additional GRU reserve, gradients, site-chunk temporaries and native
unary vertices remain unqualified. Keep the shape/output-count distinction:
952leaves alone does not imply3.4times the entire H036 forest because there are
many fewer holds. Static bank residency for all40inner parents is separate from
the active parent's autograd graph and must be included in the real peak.

If the first real fresh TRAIN qualification approaches the device allowance,
checkpoint the site-to-leaf plus whole-tree encoder in contiguous packs of
complete trees, using a fixed observed-vertex budget such as50000. Include every
native vertex/edge, every site's containing hold, every952leaf vector and the
frozen genuine/sham support. Each pack returns only its ordered leaf states.
Use torch.utils.checkpoint with use_reentrant=False; concatenate outputs with
ordinary torch.cat so every pack retains a parameter-gradient path. No detach,
ancestor cutoff, resampling, dropped unary node or omitted hold is introduced.
Bank slicing rebases local parent/sample/level indices mechanically, with roots
remaining-1 and source/query/sample order unchanged.

Run the bidirectional GRU over the complete concatenated parent sequence with
all original spans/distances. Do not truncate or detach history. It can itself
be checkpointed as one complete-sequence operation if its reserve becomes a
limit. Gather every original686query readout. If dense R*Q tensors cause pressure,
compute exact loss/readout blocks over all bins and accumulate the unchanged
full-parent normalization; seal all prediction blocks in original order. This
reduces temporary readout storage while retaining every output and all gradients.

Root should record exact native-union/unary vertices, edges and leaf rows on
one real fresh TRAIN parent, then measure FP32 PyG forward/backward peak with the
actual residency policy before fitting. No dummy profile, GPU launch, bank
construction or source implementation occurred here. Only observed JSON metadata
was read, including the outer parent's observation receipt; no truth arrays.
