H038 ARGformer current-release shared-panel adapter
==================================================

This source-only adapter is distinct from the required future original-paper
numerical benchmark. The paper used AmericanAdmixture4B18,1600 samples,30Mb,
European/African/EastAsian sources and tsinfer/tsdate. H038 supplies952 observed
haps,686 queries includingBAA14,266 unequal source proxies,2Mb post-size Relate,
and actual heterochronous ages. The pinned f7545be7bca0 release is preserved.
No code/data benchmark result or numerical paper reproduction is claimed.

Root accepted these differences before implementation. Release temperature0.3
and its current uniform class-weight fallback are retained, distinct from paper
default0.05/inverse-frequency wording. The MLM collator's special-token exclusion
and80/10/10 corruption are retained, distinct from the simplified paper mask-only
description. Native k1 is the source retrieval default; k5 is a separately sealed
sensitivity consistent with explicit real-population retrieval, not a proven
simulated-LAI paper setting. PCA clustering is not substituted or invented.

prepare_parent_v1 calls the frozen strict full-panel observed reader and pinned
path bridge. It preserves actual952 sample IDs/ages and topology, extracts every
sample-then-tree full leaf-to-root path, deduplicates before skip/truncation, and
keeps every full-path occurrence. Each namespace is parent_id:tree_SHA256.
Native node vocabulary sorts real node IDs after PAD0/MASK1/CLS2/SEP3. The same
seed42 shuffled unique-path90/10 split supplies all952 leaves' MLM rows; only266
observed pure-reference leaves supply C4 contrastive labels. Unequal donors and
34 older source-deme prototypes remain. Query ancestry, census and population
annotations never enter features or labels. Dates are verified, not added as new
tokens. The original source prep script with placeholder paths/source-folder
writes is not executed. Root-generated primitive pickle files feed native loaders.

fit_parent_v1 always starts a fresh same-ARG model. There is no argument to borrow
an old or another parent's checkpoint. It loads literal native YAMLs, changes only
owned dataset/base-config/output/logging paths, and uses source model/data-loader/
optimizer/scheduler/algorithm factories. MLM remains5epochs,seed17,logical and
microbatch512,bf16,mask0.30/eval0.15,source AdamW/warmup/clipping,128 positions,
full12x768/3072/12head RoPE/FA2/RMSNorm and source sliding/global attention.
Contrastive uses that same parent's final MLM encoder,1epoch,seed36,full4096/fp32,
mean head,temperature0.3 and native global attention/optimizer/scheduler settings.
Every loaded encoder key is checked against this parent's MLM checkpoint. The
unused3-logit classification layer must remain unchanged. It is not an ancestry
head. Corpus shortfalls fail; no phantom rows, batch reduction or GradCache exists.

The old v7 wrapper's forced MLM64 and mean-exp local readout are not inherited.
Its native backbone/encoder-initializer definitions are reused in isolated
namespaces. Its fixed reduced parents, reservations and checkpoint authorities
grant no permission for this full-panel task.

Native fitting remains within-ARG transductive, including observed-only internal
VAL ARGs. TRAIN/VAL biological labels are not ancestry-supervised model selection.
Each of40 scored inner ARGs needs its own vocabulary and two fresh fits. Report
this compute/regime separately from an inductive whole-tree GNN or Dense model.

infer_parent_v1 reloads only the exact fresh same-parent contrastive checkpoint,
embeds every full path without max_samples truncation, and retains full-path IDs
even when token inputs or vectors coincide. All donor paths across native train
and path-val splits form the reference corpus; query paths cover every686query
at every retained original100bp center and SNP. Native ensure_l2_normalized and
topk_indices_streaming are called independently for k1 andk5 with source defaults
q_batch1024/e_chunk100000. This preserves actual Torch/device ties at eachk.
No ANN, same-coordinate donor restriction, mean-exp readout, class balance,
temperature softmax, pseudocount, calibration or probability floor is introduced.
C4 raw votes, native neighbor IDs/cosine scores and complete physical joins are
sealed separately. Zero votes remain zero; raw NLL may be infinite. No tails are
extrapolated. Root owns scoring after prediction seals and all outer authority.

Root supplies a write guard and GPU-authorizer callback under the existing native
prefix. The callback must validate the shared lease, logical memory reservation,
at-most-two-physical-device policy and eligible GPU2/3/4/5, then return its actual
canonical UUID. The adapter sets/verifies AI Auto Research Pipeline Test before
CUDA and checks the real driver-context UUID against that lease. All caches,
TMP and disabled WandB/offline Hugging Face paths stay inside the fresh owned
output. No actual root admission/launcher is fabricated here. Native persistent
loader workers are drained before guarded checkpoint publication, keeping their
transient filesystem IPC out of the post-fit boundary.

Full952 vocabulary sizes, path counts, full512/full4096 memory, exact fit runtime
and exhaustive retrieval costs remain unmeasured. Root schedules one genuine
resource qualification on each actual corpus as needed. Unsupported memory,
backend or corpus conditions fail and are disclosed; shorter sequences, smaller
negative sets, borrowed vocabularies or old checkpoints cannot silently fix them.
Original-paper 4B18 reproduction remains a separate later benchmark requirement.

Verification was AST compilation/import and hashing the pinned60-file release.
No actual tree/path/target arrays, native model, worker, GPU, package install,
budget mutation or Git operation was executed by the author. Source/API/config
references and exact disclosure are in receipt.json.
