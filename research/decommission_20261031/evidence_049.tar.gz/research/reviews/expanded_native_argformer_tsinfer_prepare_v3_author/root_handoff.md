# Deferred VAL000 resume preparation v3

V2 infrastructure required a .trees binary in reservation consumer_bindings even though the guard permits source/runtime-authority metadata. Root's successful metadata-only800MB reservation therefore failed v2 validation before any corpus execution/output. Every v2 source, stats file, authority, failure log, wait receipt and old800MB reservation is preserved.

NEW source: src/arggnn/resume_expanded_native_argformer_tsinfer_preparation_v3.py. Original full stats SHA79741bcafc5e82883dec7e578d4e6c6638dc02995fc555199edf300e28e98bc3, observation bea9e207..., tree db6594a2..., original v2 d8f888aa... and unchanged v1 scientific/native condition are reused. There is no stats or inference CLI and no data, model, date, genotype, path, coordinate, batch or numerical setting change.

metadata_consumer_refs_v3(spec) returns only .py sources and .json metadata: new/frozen source closure, original v9 stub, scientific config, sealed observation JSON, roster JSON, runtime JSON, original stats JSON and retired accounting sources. Raw sealed_tree_ref remains exact in the active input, absent from budget consumer bindings.

execute_v3 checks the exact v3 input, compares raw-tree/roster refs to the hash-bound successful observation manifest, explicitly SHA-checks both via the canonical no-symlink checked-ref API, then calls the unchanged native observed reader which independently verifies them before loading. This preserves actual binary-data proof without asking the budget API to treat a binary as authority metadata.

Only v2 infrastructure is isolated/adapted: v3 identity/admission, metadata-only reservation closure, explicit binary proof, new resource provenance and completion schema. Original v1 native preparation, full-path ordering/deduplication/vocabulary, seed42 split, protocol4 products, grid/SNP joins and512/4096 settings remain unchanged. Source checks show guard/full-corpus/owned-directory function bytecode equal to frozen v2; mock-only declaration/hash-reader ordering passes and mismatched binary refs reject. No actual binary verification, tree/array load or numerical tests were performed by the author.

The old800MB scope cannot host a new v3 writer: immutable consumer bindings include v2, not v3. The guard requires reservation equality with journal replay and offers no consumer-binding amendment API. No relabeling, allowance extension, ledger mutation or new guard is proposed.

Fresh output: data/expanded_native_argformer_tsinfer_VAL000_prepared_v3. Cap650,000,000; fixed accounting metadata65,536; projected addition650,065,536. Original exact primitive plus conservative uncompressed join/ZIP bound557,765,233 leaves92,234,767 bytes (16.5%) for allocation rounding, fresh metadata and owned scratch. RSS8GiB/wall600s/counts remain unchanged. No payload is removed.

Scheduling is DEFERRED. Root reported~738MB remaining room and gives H039's650MB continuation repair priority. These two scopes cannot be admitted together. Wait for compatible allowance reclamation/migration after relevant native fits/active guards are terminal. Root owns all capacity and live actions; do not admit baseline v3 now.

Metadata-only CLI:

    .runtime/env/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v3
    .runtime/env/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v3 --admission-draft

Later, once root confirms compatible capacity, use unchanged retire_inactive_scopes_before_fast_cache_v1.py ref/save/authority/inspect/pins. Essential consumer construction:

    spec = resume_v3.admission_draft_v3()
    authority = root_utils.authority("reserve")
    consumers = resume_v3.metadata_consumer_refs_v3(spec)
    consumers += list(authority["bindings"].values())
    consumers += [root_utils.ref("src/arggnn/project_budget_v9_consumer.py")]
    authority["reservation"] = dict(
        key="H038/" + spec["job_id"], output=str(ROOT / spec["output_directory"]),
        auxiliary_scopes=[], reserved_bytes=650000000, consumer_bindings=consumers)

Save a NEW v3 root packet and authority, then apply_reserve_v1 with unchanged CORE/BASE only when allowed. Preserve receipt.value exactly in storage.reservation. Build source/JSON-only budget_components, job/output/cap/expiry and fresh initial_ledger_pins. Set input status=active, execution_authorized=True, active expiry and storage; keep every other draft field unchanged. Validator bindings: source_ref=new v3, config_ref=scientific_config_ref, runtime_ref=existing native preparation runtime. Never add sealed_tree_ref to consumers.

Eventual direct CPU command, owned and waited by root:

    CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .runtime/conda/envs/argformer_native_v1/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v3 --execute --input <NEW_V3_INPUT.json> --expected-input-sha256 <SHA>

Success is new output/resume_completed.json, schema native_argformer_VAL000_resumed_preparation_completed_v3. Prepared manifest retains v1 scientific source/config/schema for unchanged fitting compatibility and adds explicit v3 metadata-reservation/binary-proof provenance. No old file/output is edited. No admission, stats/inference rerun, preparation, training, GPU, commit or journal action occurred.
