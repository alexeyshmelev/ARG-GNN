from pathlib import Path
import importlib.util,json,time,sys,traceback
R=Path("/workspace-SR003.nfs2/ARG-GNN");P=R/"research/reviews/expanded_full_panel_v1_root"
s=importlib.util.spec_from_file_location("expanded_dispatch_fixed",P/"dispatch_first16_v1_retry.py")
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def run():
 live=[];complete=[];failed=[]
 for i in range(8,16):
  parent=f"ap_expanded_train_{i:03d}";packet=P/parent;inp=m.read(str((packet/"input.json").relative_to(R)))
  assert not(packet/"launch.json").exists()
  cmd=[str(R/".runtime/env/bin/python"),"-B","-m","arggnn.prepare_expanded_full_panel_v1",
   "--execute","--config",m.CONFIG,"--expected-config-sha256",m.ref(m.CONFIG)["sha256"],
   "--expected-source-sha256",m.ref(m.SOURCE)["sha256"],"--parent",parent,"--stage","all",
   "--admission",str((packet/"input.json").relative_to(R))]
  item=dict(parent=parent,packet=packet,input_ref=m.ref(packet/"input.json"),output=inp["output_directory"],command=cmd)
  live.append((item,m.launch(item)))
 while live:
  for item,child in list(live):
   code=child.poll()
   if code is None:continue
   actual=R/item["output"]/"expanded_parent_completed.json"
   event=dict(parent_id=item["parent"],worker_pid=child.pid,returncode=code,
    completed_ref=m.ref(actual) if actual.exists() else None,CPU_only=True)
   m.save(item["packet"],"launcher_exit.json",event)
   okay=code==0 and actual.exists()
   if okay:
    d=json.loads(actual.read_text());okay=d["generation_completed"] and d["Relate_completed"]
   (complete if okay else failed).append(event);live.remove((item,child))
   print(json.dumps(event),flush=True)
  if live:time.sleep(1)
 m.save(P,"remaining8_completed.json",dict(completed=complete,failures=failed,scientific_completed_count=len(complete),models_trained=False,outer_truth_scored=False))
if __name__=="__main__":
 try:run()
 except Exception:
  traceback.print_exc(file=sys.stdout);raise SystemExit(1)
