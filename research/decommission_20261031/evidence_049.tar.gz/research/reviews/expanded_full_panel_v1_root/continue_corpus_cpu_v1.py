"""Root scheduler: reuse completed H038 parents, close CPU allowances and finish development."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,hashlib,json,os,subprocess,time,traceback,sys
sys.path.insert(0,"/workspace-SR003.nfs2/ARG-GNN")
from arggnn import project_storage_cpu_closed_scopes_v1 as accounting
from scripts import project_budget_v9 as budget
R=Path("/workspace-SR003.nfs2/ARG-GNN")
P=R/"research/reviews/expanded_full_panel_v1_root"
CORE="483d78bf2ef3c917d65ecf1dde5a7809bfadc21194c9f9a90394ce5c532fdd5e"
BASE="a8049bc103afb1cbbbce6f8fc3707a21de9613b23034599641b688994fc5caa3"
HELPER=accounting.SOURCE
PRODUCER="src/arggnn/prepare_expanded_full_panel_v1.py"
CONFIG="configs/expanded_full_panel_v1.json"
REGISTRATION="research/reviews/expanded_full_panel_v1_root/registration.json"
LIMIT=3000000000

def ref(p):return budget.v4.reference(R,p)
def read(p):return json.loads((R/p).read_text())
def save(packet,name,value):
 packet.mkdir(parents=True,exist_ok=True);q=packet/name
 with q.open("x") as f:json.dump(value,f,indent=2,sort_keys=True);f.write("\n")
 return ref(q)
def inspect():return accounting.inspect_v1(expected_source_sha256=CORE,expected_launcher_sha256=BASE)
def pins(v):return {k:v[k] for k in ("legacy_ledger_sha256","supplemental_ledger_sha256","journal_tail_sha256","cpu_overlay_tail_sha256")}
def authority(operation,view):
 return dict(kind="project_budget_cpu_overlay_root_admission_v1",root_authorizer="root_agent",
  active=True,operation=operation,accounting_mode=accounting.MODE,
  bindings=dict(implementation=ref(budget.SOURCE_REL),launcher=ref(budget.LAUNCHER_REL),cpu_overlay=ref(HELPER)),
  expected_before=pins(view),all_budget_writers_use_scheduler_mutex=True,
  all_consumers_and_launchers_use_cpu_overlay_guard=True,historical_records_mutation_authorized=False,
  global_rebase_authorized=False,scientific_execution_authorized=False,GPU_authorized=False,
  expires_at_utc=(datetime.now(timezone.utc)+timedelta(hours=23)).isoformat())

def close(parent):
 packet=P/parent;proof=P/"CPU_completed_credits_v1"/parent
 if (packet/"relate_resume_v1/launcher_exit.json").exists():packet=packet/"relate_resume_v1"
 if (proof/"receipt.json").exists():return read(str((proof/"receipt.json").relative_to(R)))
 v=inspect();a=authority("close",v)
 a.update(scope_write_authority_revoked_for_all_cooperative_project_jobs=True,
  closed_scope_future_writes_and_relaunch_revoked=True,external_NFS_writers_outside_observation=True,
  closure=dict(key="H038/"+parent,parent_id=parent,storage_ref=ref(packet/"storage.json"),
   completion_ref=ref("data/expanded_full_panel_v1/"+parent+"/expanded_parent_completed.json"),
   launcher_exit_ref=ref(packet/"launcher_exit.json"),launch_ref=ref(packet/"launch.json")))
 ar=save(proof,"authority.json",a)
 result=accounting.apply_close_v1(ar,expected_source_sha256=CORE,expected_launcher_sha256=BASE)
 save(proof,"receipt.json",result);print(json.dumps(dict(stage="CPU_complete",parent_id=parent,retained_GB=result["retained_bytes"]/1e9)),flush=True)
 return result

def reserve(parent):
 cfg=read(CONFIG);output=cfg["output_root"]+"/"+parent;packet=P/parent
 now=datetime.now(timezone.utc);expiry=(now+timedelta(hours=23)).isoformat()
 job="expanded-full-panel-"+parent.replace("_","-")
 rt=save(packet,"runtime.json",dict(status="active",device="cpu",CUDA_VISIBLE_DEVICES="",
  parent_id=parent,job_id=job,output_directory=output,source_ref=ref(PRODUCER),config_ref=ref(CONFIG),
  created_at_utc=now.isoformat(),expires_at_utc=expiry,max_project_GPUs=2,no_GPU_used=True,
  native_threads_per_parent=8,maximum_concurrent_CPU_parents=8))
 consumers=[ref(PRODUCER),ref(CONFIG),ref(REGISTRATION),rt,ref(HELPER),
  ref("src/arggnn/project_storage_closed_scopes_v1.py"),ref("src/arggnn/project_budget_v9_consumer.py"),
  ref(budget.SOURCE_REL),ref(budget.LAUNCHER_REL),ref("src/arggnn/prepare_ancestralpaths_full_panel_discovery_v1.py")]
 dependencies=cfg["dependencies"].values() if isinstance(cfg["dependencies"],dict) else cfg["dependencies"]
 consumers.extend(dict(path=x["path"],sha256=x["sha256"]) for x in dependencies)
 a=authority("reserve",inspect());a["reservation"]=dict(key="H038/"+parent,output=str(R/output),
  auxiliary_scopes=[],reserved_bytes=LIMIT,consumer_bindings=consumers)
 ar=save(packet,"cpu_overlay_reserve_authority.json",a)
 receipt=accounting.apply_reserve_v1(ar,expected_source_sha256=CORE,expected_launcher_sha256=BASE)
 save(packet,"cpu_overlay_reserve_receipt.json",receipt)
 return dict(parent=parent,packet=packet,output=output,job=job,runtime=rt,
  reservation=receipt["value"],expiry=expiry,created=now.isoformat())

def finish_input(item,view):
 cfg=read(CONFIG)
 storage=dict(kind="project_budget_v9_storage_record",active=True,consumer_uses_v9_guard=True,
  accounting_mode=accounting.MODE,job_id=item["job"],output_directory=item["output"],
  reserved_new_bytes=LIMIT,reservation=item["reservation"],expires_at_utc=item["expiry"],
  initial_ledger_pins=pins(view),budget_components=dict(implementation=ref(budget.SOURCE_REL),
   launcher=ref(budget.LAUNCHER_REL),consumer_adapter=ref(HELPER)))
 save(item["packet"],"storage.json",storage)
 inp=dict(schema="expanded_full_panel_v1_root_admission",root_authorizer="root_agent",
  execution_authorized=True,status="active",parent_id=item["parent"],allowed_stages=["all"],
  job_id=item["job"],output_directory=item["output"],source_ref=ref(PRODUCER),config_ref=ref(CONFIG),
  config_content_sha256=budget.digest(cfg),parent_registry_sha256=budget.digest(cfg["parent_registry"]),
  runtime_ref=item["runtime"],expires_at_utc=item["expiry"],storage=storage,storage_adapter_ref=ref(HELPER),
  registration_ref=ref(REGISTRATION),outer_evaluation_authorized=False,
  no_scientific_modifications_to_original_generation=True)
 item["input_ref"]=save(item["packet"],"input.json",inp)

def launch(item):
 cmd=[str(R/".runtime/env/bin/python"),"-B","-m","arggnn.project_storage_cpu_closed_scopes_v1",
  "--prepare-expanded","--admission",item["input_ref"]["path"],"--expected-admission-sha256",item["input_ref"]["sha256"],
  "--config",CONFIG,"--expected-config-sha256",ref(CONFIG)["sha256"],
  "--expected-producer-sha256",ref(PRODUCER)["sha256"],"--parent",item["parent"],"--stage","all"]
 env=dict(os.environ,CUDA_VISIBLE_DEVICES="",OMP_NUM_THREADS="8",MKL_NUM_THREADS="8",PYTHONDONTWRITEBYTECODE="1")
 with (item["packet"]/"launch.log").open("xb") as log:
  child=subprocess.Popen(cmd,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 save(item["packet"],"launch.json",dict(pid=child.pid,parent_id=item["parent"],command=cmd,
  input_ref=item["input_ref"],launched_utc=datetime.now(timezone.utc).isoformat(),device="cpu",
  CUDA_VISIBLE_DEVICES="",returncode=None))
 print(json.dumps(dict(stage="CPU_parent_launched",parent_id=item["parent"],pid=child.pid)),flush=True)
 return child

def run(expected_helper):
 assert ref(HELPER)["sha256"]==expected_helper
 for i in range(16):close(f"ap_expanded_train_{i:03d}")
 cfg=read(CONFIG);pending=[x["parent_id"] for x in cfg["parent_registry"] if x["split"]!="outer" and not (R/cfg["output_root"]/x["parent_id"]/"expanded_parent_completed.json").exists()]
 for offset in range(0,len(pending),8):
  ids=pending[offset:offset+8];items=[reserve(p) for p in ids];v=inspect()
  for item in items:finish_input(item,v)
  live=[(item,launch(item)) for item in items];failures=[]
  while live:
   for item,child in list(live):
    code=child.poll()
    if code is None:continue
    path=R/item["output"]/"expanded_parent_completed.json"
    event=dict(parent_id=item["parent"],worker_pid=child.pid,returncode=code,
     completed_utc=datetime.now(timezone.utc).isoformat(),completed_ref=ref(path) if path.exists() else None,
     native_children_waited_by_original_inference_code=True,CPU_only=True)
    save(item["packet"],"launcher_exit.json",event);live.remove((item,child))
    if code!=0 or not path.exists():failures.append(event)
    print(json.dumps(dict(stage="CPU_parent_exited",**event)),flush=True)
   if live:time.sleep(1)
  if failures:raise RuntimeError("Preserved failed parent(s), no replacement or automatic scientific rerun: "+str(failures))
  for p in ids:close(p)
 save(P,"all40_development_completed_v1.json",dict(completed_development_parents=40,TRAIN=32,VAL=8,outer_generated=0,models_trained=False,top1_claim=False))

if __name__=="__main__":
 parser=argparse.ArgumentParser();parser.add_argument("--expected-helper-sha256",required=True)
 args=parser.parse_args()
 try:run(args.expected_helper_sha256)
 except Exception:traceback.print_exc();raise SystemExit(1)
