"""Root admission and actual wait for the H039 matched continuation."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import importlib.util,json,os,subprocess,traceback
R=Path("/workspace-SR003.nfs2/ARG-GNN")
P=R/"research/reviews/expanded_full_panel_v1_root/H039_shared_continuation_v2"
U=R/"research/reviews/expanded_full_panel_v1_root/retire_inactive_scopes_before_fast_cache_v1.py"
s=importlib.util.spec_from_file_location("root_H039_util",U);u=importlib.util.module_from_spec(s);s.loader.exec_module(u)
def run():
 from arggnn import train_directed_clade_exchange_full_panel_v2 as w
 old=u.read("research/reviews/expanded_full_panel_v1_root/full_panel_pyg_fits_v4/aligned/input.json")
 closure=u.read("research/reviews/next_accuracy_architecture_fresh_v2/directed_clade_exchange_source_closure_v2.json")
 assert set(closure)==w.ALLOWED_SOURCE_PATHS
 assert all(u.ref(p)["sha256"]==h for p,h in closure.items())
 complete=u.ref("experiments/results/mutation_routed_full_panel_pyg_v1_aligned_seed101_GPU2/completed.json")
 selected=u.read(complete["path"])["selected"]["checkpoint"]
 cfg=u.read(w.CONFIG)
 assert cfg["output_cap_bytes"]==650000000 and cfg["execution_guard_ready"] in (False,True)
 cfg.update(status="active",execution_guard_ready=True,warmstart_completion_ref=complete,warmstart_checkpoint_ref=selected,
  functional_validation="root_authorized_tiny_handmade_FP32_CRF_check_passed")
 (R/w.CONFIG).write_text(json.dumps(cfg,indent=2,sort_keys=True)+"\n")
 w.validate_protocol_v1(cfg)
 P.mkdir(exist_ok=True)
 assert not (P/"launch.json").exists() and not (P/"reserve_receipt.json").exists(),"Existing launched/reserved scope requires explicit resume"
 now=datetime.now(timezone.utc);expiry=(now+timedelta(hours=23)).isoformat()
 job="directed-clade-exchange-full-panel-seed101-v2"
 out="experiments/results/directed_clade_exchange_full_panel_v2_seed101_GPU2"
 protocol=u.ref(P/"registration.json") if (P/"registration.json").exists() else u.save(P,"registration.json",dict(hypothesis_id="H039",linked="H038",registered_utc=now.isoformat(),
  question="Does nonseparable directed observed clade-exchange evidence improve ancestry beyond same-W unary evidence, generic persistence and equal additional optimization?",
  config_ref=u.ref(w.CONFIG),source_sha256=closure,arms=cfg["arms"],additional_updates_per_arm=320,
  warmstart_completion=complete,warmstart_checkpoint=selected,outer_evaluated=False,top1_claim=False,novelty_claim=False))
 d=u.read("research/experiment_decisions.json")
 if not any(e["id"]=="H039" for e in d["decisions"]):
  d["decisions"].append(dict(id="H039",hypothesis="Directed clade-exchange interaction improves local ancestry beyond same-W unary evidence and generic smoothing.",
   status="registered_320_additional_updates_each_three_matched_models",
   method="Same selected H038 width32 whole-tree PyG warm start, FP32 seed101, reset AdamW for all arms. Plain continuation, B+A control and directed B+A+J. Ten complete32-parent passes, accuracy selection at5/10. No outer access.",
   conclusion="Prospectively registered. Only tiny handmade CRF correctness check completed. Actual witness preparation and training pending.",
   repeat_policy="New directed coupling condition linked to H038, with equal extra-optimization control. Do not repeat an unchanged answered cell.",
   evidence=[protocol["path"],w.CONFIG,"research/reviews/next_accuracy_architecture_fresh_v2/directed_clade_exchange_tiny_crf_check_v1.json"]))
 e=next(e for e in d["decisions"] if e["id"]=="H039")
 e.update(status="checkpoint_loading_repair_v2_registered_shared_320_updates_each",conclusion="v1 completed all40 observation witnesses then stopped before optimizer updates at unhashable checkpoint reference. v2 fixes actual retained-record lookup, reuses sealed witnesses, verifies actual selected checkpoint before bank reads. Same model, seed, controls and optimization budget. Training pending actual updates.")
 for p in [protocol["path"],w.CONFIG,"research/reviews/expanded_full_panel_v1_root/H039_shared_continuation_v1/root_wait.json"]:
  if p not in e["evidence"]:e["evidence"].append(p)
 d["last_root_update_utc"]=now.isoformat()
 (R/"research/experiment_decisions.json").write_text(json.dumps(d,indent=2)+"\n")
 rows=subprocess.run(["nvidia-smi","--query-gpu=index,uuid,memory.used,utilization.gpu","--format=csv,noheader,nounits"],check=True,capture_output=True,text=True).stdout.splitlines()
 row=next(x for x in rows if x.split(",")[0].strip()=="2")
 fields=[x.strip() for x in row.split(",")]
 compute=subprocess.run(["nvidia-smi","--query-compute-apps=gpu_uuid","--format=csv,noheader"],check=True,capture_output=True,text=True).stdout
 assert fields[0]=="2" and fields[1] not in compute and int(fields[2])<500,"GPU2 occupied by a compute process"
 u.save(P,"GPU2_before_launch.json",dict(index=2,uuid=fields[1],memory_MiB=int(fields[2]),utilization_percent=int(fields[3]),checked_utc=now.isoformat()))
 rt=u.save(P,"runtime.json",dict(status="active",device="cuda",physical_GPU=2,process_title="AI Auto Research Pipeline Test",
  created_at_utc=now.isoformat(),expires_at_utc=expiry,job_id=job,output_directory=out,torch="2.6.0+cu124",torch_geometric="2.7.0"))
 refs=dict(old["refs"]);refs.pop("storage");refs.update(config=u.ref(w.CONFIG),runtime=rt,warmstart_completion=complete,witness_sidecar_manifest=cfg["reused_witness_manifest_ref"])
 a=u.authority("reserve")
 consumers=[dict(path=p,sha256=h) for p,h in closure.items()]+list(refs.values())+list(a["bindings"].values())+[cfg["base_fit_config"],u.ref("src/arggnn/project_budget_v9_consumer.py"),u.ref(__file__),protocol]
 consumers=list({(r["path"],r["sha256"]):r for r in consumers}.values())
 assert len(consumers)<=64
 a["reservation"]=dict(key="H039/"+job,output=str(R/out),auxiliary_scopes=[],reserved_bytes=650000000,consumer_bindings=consumers)
 ar=u.save(P,"reserve_authority.json",a)
 res=u.m.apply_reserve_v1(ar,expected_source_sha256=u.CORE,expected_launcher_sha256=u.BASE)
 u.save(P,"reserve_receipt.json",res)
 storage=dict(kind="project_budget_v9_storage_record",active=True,consumer_uses_v9_guard=True,accounting_mode=u.m.MODE,
  job_id=job,output_directory=out,reserved_new_bytes=650000000,reservation=res["value"],expires_at_utc=expiry,
  initial_ledger_pins=u.m._pins(u.inspect()),budget_components=dict(implementation=u.ref(u.m.budget.SOURCE_REL),launcher=u.ref(u.m.budget.LAUNCHER_REL),consumer_adapter=u.ref(u.m.SOURCE)))
 sr=u.save(P,"storage.json",storage);refs["storage"]=sr
 spec=dict(old,schema="directed_clade_exchange_full_panel_input_v2",hypothesis_id="H039",arm="joint_three_arm",arms=cfg["arms"],
  job_id=job,output_directory=out,created_at_utc=now.isoformat(),expires_at_utc=expiry,refs=refs,source_sha256=closure)
 ir=u.save(P,"input.json",spec)
 command=[str(R/".runtime/env/bin/python"),"-B","-m","scripts.launch_reserved_gpu_terminal_retired_scopes_v1","--gpu","2","--job",job,
  "--storage-record",sr["path"],"--expected-storage-sha256",sr["sha256"],"--expected-budget-source-sha256",u.CORE,
  "--expected-launcher-sha256",u.BASE,"arggnn.train_directed_clade_exchange_full_panel_v2","--execute","--input",ir["path"],"--expected-input-sha256",ir["sha256"]]
 env=dict(os.environ,PYTHONPATH=str(R)+":"+str(R/"scripts")+":"+str(R/"src"),OMP_NUM_THREADS="4",MKL_NUM_THREADS="4")
 with (P/"launch.log").open("xb") as log:
  child=subprocess.Popen(command,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  u.save(P,"launch.json",dict(pid=child.pid,gpu=2,input_ref=ir,command=command,additional_updates_per_arm=320,arms=cfg["arms"]))
  print(json.dumps(dict(stage="H039_actual_worker_launched",pid=child.pid,gpu=2,additional_updates_per_arm=320)),flush=True)
  rc=child.wait()
 cp=R/out/"completed.json"
 u.save(P,"root_wait.json",dict(pid=child.pid,returncode=rc,actual_direct_launcher_wait=True,completed_ref=u.ref(cp) if cp.exists() else None,finished_utc=datetime.now(timezone.utc).isoformat()))
 print(json.dumps(dict(stage="H039_actual_wait",returncode=rc,completed=cp.exists())),flush=True)
 if rc or not cp.exists():raise RuntimeError("Preserved failed/partial H039, no automatic replay")
if __name__=="__main__":
 try:run()
 except BaseException:print(traceback.format_exc(),flush=True);raise SystemExit(1)
