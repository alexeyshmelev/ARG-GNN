"""Resume only inference on the eight preserved H038 simulations, then finish corpus."""
from pathlib import Path
import importlib.util,json,os,subprocess,sys,time,traceback
R=Path("/workspace-SR003.nfs2/ARG-GNN");sys.path.insert(0,str(R))
P=R/"research/reviews/expanded_full_panel_v1_root"
sp=importlib.util.spec_from_file_location("root_h038_dispatch",P/"continue_corpus_cpu_v1.py")
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def run():
 prep=R/"data/expanded_full_panel_pyg_cache_v3/started.json"
 deadline=time.monotonic()+120
 while not prep.exists():
  if time.monotonic()>deadline:raise RuntimeError("Repaired cache prep did not pass first admission")
  time.sleep(1)
 items=[];view=m.inspect()
 for i in range(16,24):
  parent=f"ap_expanded_train_{i:03d}";base=P/parent;packet=base/"relate_resume_v1"
  old=m.read(str((base/"input.json").relative_to(R)));exit=m.read(str((base/"launcher_exit.json").relative_to(R)))
  assert exit["returncode"]==1 and not Path("/proc",str(exit["worker_pid"])).exists()
  log=(base/"launch.log").read_text()
  assert "bound source or authority bytes changed" in log
  out=R/old["output_directory"]
  assert (out/"generation.json").exists() and not (out/"expanded_parent_completed.json").exists()
  m.accounting.budget_check_v9(old["storage"],boundary=True)
  if (out/"relate").exists():(out/"relate").rename(out/"relate_failed_source_guard_v1")
  m.save(packet,"recovery_reason.json",dict(parent_id=parent,reason="Unfinished inference interrupted by changing an admitted cache-prep source. Frozen original source restored, new repair isolated. Reuse same simulation, mutation streams and original inference seeds.",original_exit=m.ref(base/"launcher_exit.json"),generation=m.ref(out/"generation.json"),simulation_regenerated=False))
  storage=dict(old["storage"],initial_ledger_pins=m.pins(view))
  m.save(packet,"storage.json",storage)
  inp=dict(old,allowed_stages=["relate"],storage=storage)
  ir=m.save(packet,"input.json",inp)
  item=dict(parent=parent,packet=packet,output=old["output_directory"],input_ref=ir)
  cmd=[str(R/".runtime/env/bin/python"),"-B","-m","arggnn.project_storage_cpu_closed_scopes_v1","--prepare-expanded","--admission",ir["path"],"--expected-admission-sha256",ir["sha256"],"--config",m.CONFIG,"--expected-config-sha256",m.ref(m.CONFIG)["sha256"],"--expected-producer-sha256",m.ref(m.PRODUCER)["sha256"],"--parent",parent,"--stage","relate"]
  env=dict(os.environ,CUDA_VISIBLE_DEVICES="",OMP_NUM_THREADS="8",MKL_NUM_THREADS="8")
  with (packet/"launch.log").open("xb") as stream:child=subprocess.Popen(cmd,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  m.save(packet,"launch.json",dict(pid=child.pid,parent_id=parent,command=cmd,input_ref=ir,device="cpu",CUDA_VISIBLE_DEVICES="",returncode=None))
  items.append((item,child));print(json.dumps(dict(stage="resume_same_parent_inference",parent_id=parent,pid=child.pid)),flush=True)
 failures=[]
 while items:
  for item,child in list(items):
   code=child.poll()
   if code is None:continue
   complete=R/item["output"]/"expanded_parent_completed.json"
   event=dict(parent_id=item["parent"],worker_pid=child.pid,returncode=code,completed_ref=m.ref(complete) if complete.exists() else None,native_children_waited_by_original_inference_code=True,CPU_only=True)
   m.save(item["packet"],"launcher_exit.json",event);items.remove((item,child))
   if code!=0 or not complete.exists():failures.append(event)
   print(json.dumps(dict(stage="inference_resume_exited",**event)),flush=True)
  if items:time.sleep(1)
 if failures:raise RuntimeError("Preserved failed inference resume, no regeneration: "+str(failures))
 for i in range(16,24):m.close(f"ap_expanded_train_{i:03d}")
 m.run(m.ref(m.HELPER)["sha256"])
if __name__=="__main__":
 try:run()
 except Exception:traceback.print_exc(file=sys.stdout);raise SystemExit(1)
