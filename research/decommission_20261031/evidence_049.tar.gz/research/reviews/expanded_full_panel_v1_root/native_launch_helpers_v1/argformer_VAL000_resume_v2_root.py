"""ROOT-only recovery/admission helper; default metadata only, never native execution."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import hashlib
import importlib.util
import json
import os
from arggnn import resume_expanded_native_argformer_tsinfer_preparation_v2 as resume

R = resume.ROOT
P = R / "research/reviews/expanded_full_panel_v1_root"
SELF = P / "native_launch_helpers_v1/argformer_VAL000_resume_v2_root.py"
PACKET = P / "argformer_VAL000_resume_preparation_v2"
UTIL = P / "retire_inactive_scopes_before_fast_cache_v1.py"
UTIL_SHA = "97ae77c6a5173b787e62b7fd3226c3184729477dfdba94b711d51dca315725ec"
COMMAND_ITEM = "exec-035c5199-7ffc-415b-99c0-a2c06267ed91"
THREAD_ID = "01a1232a-0b95-7ee1-ba15-894ba034e072"
RAW_STATS = "{\n  \"GPU_used\": false,\n  \"coordinate_joins_uncompressed_payload_bound_bytes\": 192885624,\n  \"diagnostic_peak_RSS_bytes\": 2535411712,\n  \"donors\": 266,\n  \"elapsed_seconds\": 44.205305519513786,\n  \"exact_path_ID_JSON_bytes\": {\n    \"contrastive/train/path_ids.json\": 4775191,\n    \"contrastive/val/path_ids.json\": 531402,\n    \"mlm/train/path_ids.json\": 16091247,\n    \"mlm/val/path_ids.json\": 1788115\n  },\n  \"full_corpus_before_skip_truncation\": true,\n  \"full_path_node_tokens\": 17851712,\n  \"full_path_occurrences\": 4997048,\n  \"maximum_full_path_length\": 23,\n  \"minimum_full_path_length\": 2,\n  \"model_or_numeric_tests\": false,\n  \"namespace\": \"ap_expanded_val_000:db6594a2ca5eb1437cca81744e9019f228b2ecd0ee60e665c8f5207b9dd386e8\",\n  \"native_inference_rerun\": false,\n  \"native_seed42_path_split_counts\": {\n    \"train\": {\n      \"contrastive\": 434108,\n      \"mlm\": 1553765\n    },\n    \"val\": {\n      \"contrastive\": 48309,\n      \"mlm\": 172641\n    }\n  },\n  \"no_array_pickle_tree_outputs_written\": true,\n  \"observation_ref\": {\n    \"path\": \"data/expanded_native_argformer_tsinfer_canary_v1/parents/ap_expanded_val_000/observation/observation_manifest.json\",\n    \"sha256\": \"bea9e2078652f752f814bf8fbac3503bb50026c3fc369d50a810e03dc7689fe6\"\n  },\n  \"parent_id\": \"ap_expanded_val_000\",\n  \"prepared_retained_byte_bound_before_margin\": 557765233,\n  \"protocol4_serialized_bytes\": {\n    \"contrastive/train/labels.pkl\": 869217,\n    \"contrastive/train/raw_sequences_and_vocab.pkl\": 14775782,\n    \"contrastive/val/labels.pkl\": 96739,\n    \"contrastive/val/raw_sequences_and_vocab.pkl\": 1760174,\n    \"corpus.pkl\": 201486930,\n    \"embedding/all/raw_all_sequences_and_vocab.pkl\": 60135223,\n    \"mlm/train/raw_sequences_and_vocab.pkl\": 54129404,\n    \"mlm/val/raw_sequences_and_vocab.pkl\": 6133379\n  },\n  \"queries\": 686,\n  \"reference_unique_full_paths\": 482417,\n  \"samples\": 952,\n  \"schema\": \"native_argformer_VAL000_corpus_stats_v2\",\n  \"scientific_config_ref\": {\n    \"path\": \"research/reviews/expanded_native_argformer_tsinfer_v1_author/config.draft.json\",\n    \"sha256\": \"929b48db93b7cac2c2be3e33c9a8c5f15a14f53124c138279e4e984c00adc024\"\n  },\n  \"source_ref\": {\n    \"path\": \"src/arggnn/resume_expanded_native_argformer_tsinfer_preparation_v2.py\",\n    \"sha256\": \"d8f888aa577cbeb6ed034b9a1701923aade14a9996c811d7fe2b72740f7c4b99\"\n  },\n  \"suggested_new_output_cap_bytes\": 800000000,\n  \"suggested_preparation_RSS_cap_bytes\": 8589934592,\n  \"suggested_preparation_wall_seconds\": 600,\n  \"truth_read\": false,\n  \"unique_full_paths\": 1726406,\n  \"vocabulary_size\": 8589\n}\n"


def utilities():
    if hashlib.sha256(UTIL.read_bytes()).hexdigest() != UTIL_SHA:
        raise ValueError("Frozen ROOT retired-authority utility changed")
    if resume.ref(resume.SOURCE)["sha256"] != json.loads(RAW_STATS)["source_ref"]["sha256"]:
        raise ValueError("Already executed stats driver changed")
    sp = importlib.util.spec_from_file_location("ROOT_VAL000_resume_utilities_v2", UTIL)
    u = importlib.util.module_from_spec(sp); sp.loader.exec_module(u)
    return u


def save_stats():
    u = utilities()
    PACKET.mkdir(exist_ok=False)
    path = PACKET / "stats.json"
    with path.open("xb") as stream:
        stream.write(RAW_STATS.encode())
    stats_ref = u.ref(path)
    u.save(PACKET, "stats_recovery.json", dict(kind="exact_original_tool_stdout_recovery_v1",
        command_item=COMMAND_ITEM, thread_id=THREAD_ID, original_exit_code=0,
        original_output_truncated=False, stats_ref=stats_ref,
        bytes_preserved_verbatim=True, values_reconstructed=False, diagnostic_rerun=False))
    print(json.dumps(dict(stage="ROOT_original_stats_saved", stats_ref=stats_ref)), flush=True)


def admit():
    u = utilities()
    if Path.cwd().resolve() != R or os.environ.get("CUDA_VISIBLE_DEVICES") != "":
        raise ValueError("ROOT repository and explicit CPU visibility required")
    stats_path = PACKET / "stats.json"
    if stats_path.read_bytes() != RAW_STATS.encode():
        raise ValueError("Exact original stats stdout bytes required")
    stats_ref = u.ref(stats_path)
    spec = resume.admission_draft_v2(stats_ref)
    u.save(PACKET, "input.draft.json", spec)
    if (spec["output_cap_bytes"] != 800000000 or spec["CPU_RSS_cap_bytes"] != 8589934592
        or spec["CPU_wall_seconds"] != 600 or (R / spec["output_directory"]).exists()):
        raise ValueError("Measured800MB/8GiB/600s and fresh VAL000-only prepared output required")
    authority = u.authority("reserve")
    refs = [spec[k] for k in ("source_ref", "scientific_config_ref", "observation_ref",
        "sealed_tree_ref", "sealed_roster_ref", "runtime_ref", "stats_ref", "storage_adapter_ref")]
    refs += [dict(path=p, sha256=h) for p, h in spec["source_sha256"].items()]
    refs += list(authority["bindings"].values()) + [
        u.ref(SELF), u.ref(UTIL), u.ref("src/arggnn/project_budget_v9_consumer.py")]
    refs = list({(r["path"], r["sha256"]): r for r in refs}.values())
    authority["reservation"] = dict(key="H038/" + spec["job_id"],
        output=str(R / spec["output_directory"]), auxiliary_scopes=[],
        reserved_bytes=spec["output_cap_bytes"], consumer_bindings=refs)
    authority_ref = u.save(PACKET, "reserve_authority.json", authority)
    receipt = u.m.apply_reserve_v1(authority_ref, expected_source_sha256=u.CORE,
                                  expected_launcher_sha256=u.BASE)
    u.save(PACKET, "reserve_receipt.json", receipt)
    expiry = (datetime.now(timezone.utc) + timedelta(hours=22)).isoformat()
    storage = dict(kind="project_budget_v9_storage_record", active=True, consumer_uses_v9_guard=True,
        accounting_mode=u.m.MODE, job_id=spec["job_id"], output_directory=spec["output_directory"],
        reserved_new_bytes=spec["output_cap_bytes"], reservation=receipt["value"],
        expires_at_utc=expiry, initial_ledger_pins=u.m._pins(u.inspect()),
        budget_components=dict(implementation=u.ref(u.m.budget.SOURCE_REL),
            launcher=u.ref(u.m.budget.LAUNCHER_REL), consumer_adapter=u.ref(u.m.SOURCE)))
    u.save(PACKET, "storage.json", storage)
    spec.update(status="active", execution_authorized=True, expires_at_utc=expiry, storage=storage)
    input_ref = u.save(PACKET, "input.json", spec)
    command = [str(R / ".runtime/conda/envs/argformer_native_v1/bin/python"), "-B", "-m",
        "arggnn.resume_expanded_native_argformer_tsinfer_preparation_v2", "--execute",
        "--input", input_ref["path"], "--expected-input-sha256", input_ref["sha256"]]
    u.save(PACKET, "admitted.json", dict(input_ref=input_ref, stats_ref=stats_ref,
        output_cap_bytes=800000000, CPU_RSS_cap_bytes=8589934592, CPU_wall_seconds=600,
        execute_command=command, executed=False, GPU_authorized=False))
    print(json.dumps(dict(stage="ROOT_VAL000_resume_admitted", input_ref=input_ref,
        execute_command=command, executed=False)), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--save-stats", action="store_true")
    mode.add_argument("--admit", action="store_true")
    args = parser.parse_args()
    if args.save_stats:
        save_stats()
    elif args.admit:
        admit()
    else:
        print(json.dumps(dict(status="source_only_no_save_admission_execution",
            original_command_item=COMMAND_ITEM, original_thread_id=THREAD_ID,
            original_stats_bytes=len(RAW_STATS.encode()),
            original_stats_sha256=hashlib.sha256(RAW_STATS.encode()).hexdigest(),
            resume_source_ref=json.loads(RAW_STATS)["source_ref"],
            future_stats_path=str((PACKET / "stats.json").relative_to(R)),
            commands=["--save-stats", "--admit"], native_execution_included=False), indent=2))


if __name__ == "__main__":
    main()
