# ROOT exact stats recovery and VAL000 preparation admission

The original completed command stdout survives in Codex ARG-GNN command item exec-035c5199-7ffc-415b-99c0-a2c06267ed91, exit0, output.truncated=false. Its exact full JSON is embedded verbatim in argformer_VAL000_resume_v2_root.py. Original CLI had no file redirection; no stats JSON was found in the checked remote native helper, author or scoped temporary paths.

No counts or omitted fields were reconstructed. Exact elapsed=44.205305519513786; unique paths1726406; occurrences4997048; vocabulary8589; retained bound557765233; suggested new preparation cap800MB, RSS8GiB, wall600s. The author has not run helper save/admit or native preparation.

From /workspace-SR003.nfs2/ARG-GNN after sourcing scripts/project_env.sh:

    CUDA_VISIBLE_DEVICES= .runtime/env/bin/python -B research/reviews/expanded_full_panel_v1_root/native_launch_helpers_v1/argformer_VAL000_resume_v2_root.py --save-stats
    CUDA_VISIBLE_DEVICES= .runtime/env/bin/python -B research/reviews/expanded_full_panel_v1_root/native_launch_helpers_v1/argformer_VAL000_resume_v2_root.py --admit

First saves original stdout bytes without reserialization as research/reviews/expanded_full_panel_v1_root/argformer_VAL000_resume_preparation_v2/stats.json, plus command-transcript recovery provenance. Second invokes the existing v2 admission-draft API and existing ROOT retired utility to reserve exactly800MB for the fresh prepared output. It binds all required sources, observation/tree/roster/science/runtime/stats refs, six accounting components and original v9 stub. No native execution is included.

The admit output and admitted.json include the exact execute_command vector with active input SHA. Root may directly run that emitted command in the qualified native runtime, or execute the following wrapper which owns and waits for the actual child:

    CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .runtime/env/bin/python -B - <<'PY'
    from pathlib import Path
    import json, os, subprocess
    path=Path("research/reviews/expanded_full_panel_v1_root/argformer_VAL000_resume_preparation_v2/admitted.json")
    admitted=json.loads(path.read_text())
    subprocess.run(admitted["execute_command"], check=True, env=dict(os.environ))
    PY

The child command uses .runtime/conda/envs/argformer_native_v1/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v2 --execute with exact bound input and SHA. It reuses the successful sealed observation; no reinference, training or GPU is authorized.

Existing complete method/API/source-only handoff: research/reviews/expanded_native_argformer_tsinfer_prepare_v2_author/root_handoff.md. Frozen resume source SHA d8f888aa577cbeb6ed034b9a1701923aade14a9996c811d7fe2b72740f7c4b99 remains unchanged. Preserve all old outputs and source files.
