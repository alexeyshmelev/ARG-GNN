# Proposal: donor-preserving tree-change transport

2026-10-11. Source/literature proposal only. H036's initial 20 updates produced all-ANA predictions at 43.9749% and NLL 1.27546. Its exact-state continuation to 160 updates is unresolved here. Neither the initial outcome nor the ~29% fieldwise support displacement proves final model failure or an optimizer cause. Await that continuation before choosing this protocol. No implementation, target/data run, GPU use, install or Git action was performed. The user-authorized 1 TB limit supersedes AGENTS.md's 500 GB statement.

## Hypothesis and claim boundary

Keep genomic state indexed by **actual observed pure-reference haplotypes**, and retain that index until the ancestry readout. At a genuine local-tree boundary, move probability specifically from donors whose whole-tree support declined to donors whose support increased for the same query. This tests something H025–H036 have not explicitly retained: competition among individual reference haplotypes over linked original SNPs, before compression into C4 or an unconstrained hidden vector.

A directly supervised donor projection provides a recoverable class signal and a transparent gradient path. It could be more learnable than H036's label embedding followed by repeated normalized nonlinear mixing. This is a hypothesis, not a diagnosis of H036. Raw donor copying, normalized transport and reference kernels are established. The prospective contribution is only the **paired-tree, donor-specific loss-to-gain transition**, if it beats equally informed copying and generic donor-memory controls.

## Observations and biology

Use one frozen inferred-tree producer and all native marginal trees, branches, original phased multiallelic SNPs and real sample dates. Retain all 280 leaves in reduced discovery or all 952 in the full-panel condition. The whole-tree encoder sees every sampled and internal node. Donor IDs are verified (parent, subject, haplotype) joins, never numeric embeddings. Queries and mixed context leaves carry no reference labels. Full-panel donor count is 266 and scored query count is 686. Use the actual reference roster, without class balancing by subsampling.

The output remains population at census350. Pure-reference cohort labels are source proxies. Older references stay at their observed sampling nodes, with no downward projection, invented descendants or census target. A posterior over copying donors is a predictor-side state, **not a posterior over true ancestors or calibrated census ancestry**. Related populations and old proxies can produce copying across source labels. HAPMIX/FLARE's explicit miscopying/ancestry state is a material limitation of the simple projection below, not a feature to claim newly.

Trees inferred from these SNPs are not independent genetic evidence. The topology and allele factors below form a supervised composite predictor; no generative likelihood calibration follows. No raw simulated genealogy, census flags, populations, true mutation placement, ancestry paths, cohort mixture fractions, teacher or competitor logits enter features.

## Concrete layer

Let j index original tree holds, q a query, r an observed pure reference, and c_r its observed proxy class. Use class-balanced donor base weights pi_r = 1/(4 n_{c_r}), with n_c the complete observed donor count. All four classes must be present. Labels remain in this fixed basis; a free C4 bias/head is excluded.

**Whole-tree potential.** A standard width-32, label-free two-sweep cavity GNN encodes observed ages, topology and site callability/allele-summary features. It does not encode c_r. Every native edge receives a nonnegative scalar cost

k_j(e) = (duration_e / tau_age) softplus(f_theta(h_child,h_parent,geometry_e)).

Set a_j(q,r) = -sum_{e on the actual q–r path} k_j(e). Use actual sample ages and paths, including every native unary edge. Center each donor row by its pi-weighted mean, then apply a shared bounded monotone map and center again to obtain b_j(q,r). The bound and tau_age are frozen protocol choices. LCA/root-distance actions compute the path sum without a dense all-node graph. The exponential path affinity is established kernel machinery; it is an input to the new transition, not the claimed novelty.

**Original-site evidence.** At called site s with A_s alleles, use the categorical copying factor

L_s(q,r) = (1-mu_sqr) 1[g_sq=g_sr] + mu_sqr/A_s.

A shared small function of observed pair age/path geometry and site entropy gives bounded 0<mu<1. Missing either call gives L=1; an A=1 site is neutral. No learned allele-index embedding, ancestral polarization, site filtering, 10kb composite or class-frequency pooling is needed. This retains individual donor haplotype patterns that H028/H031 compressed.

**Ordinary donor memory.** Between sites/boundaries, use a standard copying generator

Q0(r,s) = rho_within 1[c_s=c_r]/n_{c_r} + rho_between pi_s, r != s,
Q0(r,r) = -sum_{s != r} Q0(r,s).

This is the established two-scale donor/label-switching idea, not an admixture-time estimator. Rates use declared genomic distance and may depend on observed query age through shared parameters. The positive unnormalized state u evolves through each constant tree hold as

u(x+d) = exp{d [Q0^T + beta diag(b_j)]} u(x),

and each original SNP multiplies u_r by L_s(q,r). Normalize and retain log scaling. beta is a learned composite-potential strength, not evidence independence. The matrix is diagonal plus at most five rank-one terms, permitting positive matrix-vector actions in O(R) per solver term. A fixed-tolerance positive uniformization or equivalent verified action is required; no unqualified solver/runtime claim is made.

**Proposed boundary transport.** At the real boundary j-1 -> j, using the same q/r identities, define

delta_r = b_j(q,r) - b_{j-1}(q,r),
ell_r = [-delta_r]_+, gain_r = [delta_r]_+,
s_r = exp(-gamma ell_r),
v_r = pi_r gain_r / sum_a pi_a gain_a,
B(q,j) = diag(s) + (1-s) v^T.

If every delta is zero, B=I and v need not be evaluated. Pi-centering ensures a nonzero delta has both loss and gain. Gamma is one nonnegative shared scalar initially, rather than a donor ID parameter. The exact update is

u_new,r = s_r u_old,r + v_r sum_a (1-s_a)u_old,a.

Thus B is nonnegative and row stochastic. It preserves total donor mass and retains each surviving donor's provenance. Only losing donors donate mass; only gaining donors receive it. A topology-wide constant score shift cannot trigger it. It introduces no native internal-ID correspondence, clade-overlap history, donor Gram or signed A_new T - T A_old residual.

The complete model has one forward model and its exact backward adjoints. In particular, backward boundary action is B beta, **not** a separately invented reverse loss-to-gain filter. At any requested center, normalize alpha_r beta_r to w_r and return p_c = sum_{r:c_r=c} w_r. Both scans span the full parent with no artificial tile resets or detached history. Holds lacking SNPs or scoring centers still participate. Splitting an unchanged hold leaves its evolution unchanged and creates no extra B event.

For fixed learned potentials, consistently renaming C4 labels permutes outputs. This is a useful representational constraint. It does not guarantee balanced predictions: date/geometry differences or training can still favor ANA.

## Smallest defensible comparison

First fit **one common whole-tree/copying emission model on TRAIN only** under a fixed prospective budget, then freeze theta, mu, beta, base donor weights, site factors and tree potentials before comparative VAL access. This makes the decisive decoder contrasts use numerically identical emissions, not merely identical input schemas. A separate emitter is a controlled representation stage, not frozen ancestry logits or a teacher. Do not independently refit emissions and then call the transition intervention exact.

Use the same full-parent examples, loss weights, observation seals, initialization, distance/rate contract and optimizer schedule for these small decoder conditions:

| Condition | Retained donor state and instantaneous evidence | Changed operation |
|---|---|---|
| A: genuine flux | Full R, identical frozen emissions | B from actual paired-tree delta |
| B: no flux, ordinary donor memory | Full R, identical frozen emissions | B=I; same learnable Q0 rates |
| C: donor GRU controller | Full R, identical frozen emissions and delta inputs | A shared scalar donor GRU generates survival gates and destination weights, replacing the explicit loss/gain rule |
| D: provenance sham | Full R, identical frozen emissions | Same B formula, delta rows permuted among donor diploid blocks |

A vs D is the clean same-active-parameter mechanism comparison; A vs B tests whether the extra transition helps an informed copying model; A vs C tests the stochastic constraint against generic TGN-like donor memory. Report C's extra active parameters and live states instead of asserting capacity equality. C receives current, previous and changed donor potentials, site factors, distances and the same aggregate donor summaries. Its deterministic controller memory gives s_r=sigmoid(f(m_r)) and v=softmax(g(m_r)+log pi), then uses the same diagonal-plus-resampling stochastic B template. Cache these observation-conditioned factors and use their ordinary backward HMM actions; do not invent a different reverse controller for smoothing. Its R controller scalars add live state beyond the R donor probability scalars and must be reported. Controller and donor propagation persist across the same full parent. B already retains donor memory, so a win cannot merely be called “memory beats no memory.”

Freeze D's one parent-wide permutation within source class and younger/older proxy family, moving both haplotypes together. This keeps pi, class-level innovation totals and observed input labels intact while breaking the association between a donor's history/current allele pattern and its innovation. It tests provenance, not class-level loss/gain alone. Report actual donor and probability-mass displacement; sparse/unchanged delta can make this sham uninformative. Predeclare a >=50% moved nonzero innovation-entry gate and a source-only meaningful flux-mass gate before truth access. A weak sham yields an inconclusive attribution, as H036's fieldwise gate did.

Select the earliest minimum equal-parent primary NLL checkpoint, with no accuracy reselection. A practical discovery go/no-go margin is A exceeding B, C and qualified D by >=0.20 accuracy percentage points with positive direction on both reused VAL parents, while beating the existing 85.94% smoother descriptively. Also inspect NLL, each class/cohort, short tracts/boundaries, prediction variation and net correct-to-wrong changes. This margin is not a significance claim. A likelihood-only win misses the requested accuracy objective. Gamma collapsing to zero, negligible transported mass, a tie with B/C, or qualified D matching A falsifies useful donor-specific flux in this pilot. A/D both beating B supports flexible donor transitions, not true alignment.

This changes donor-level SNP access as well as the readout relative to H036; historical accuracy differences cannot isolate either change. Reused VAL remains discovery only. A lead should be confirmed on the frozen full952 panel and fresh outer parents, against native competitors including a strong copying baseline. No extra seeds, unchanged H025–H035 reruns or broad numerical matrix are proposed.

## Cost and feasibility

Tree encoding costs O(N D^2) with D=32; donor potentials, emissions and decoder actions cost O((T+S+J_solver) Q R), not O(Q R^2). Boundary B and its adjoint each cost O(QR). Path/LCA observation joins can be streamed per hold rather than storing TQR indexes.

Full-panel Q R = 686*266 = 182,476 scalars: one FP32 donor vector bank is ~0.73MB, two directional states ~1.46MB. However, storing every site state is expensive: at an **illustrative**, unmeasured S=20,000, one such bank is ~14.6GB. Native full trees and solver terms add cost. Stream/checkpoint complete-tree blocks and genomic blocks; exact independent query chunks can accumulate one parent gradient without detaching genomic history. Full-tree width32 activation banks must not be naively retained over the whole parent. Peak memory then depends on block sizes and actual native N/T/S, which require root qualification. No donor dropping, path truncation, artificial boundary reset or speed claim is justified. A 1TB storage allowance does not establish GPU feasibility.

## Closest prior art and novelty confidence

[Li–Stephens](https://doi.org/10.1093/genetics/165.4.2213) and [ChromoPainter](https://doi.org/10.1371/journal.pgen.1002453) establish linked-site donor mosaics and donor posterior expectations. [HAPMIX](https://doi.org/10.1371/journal.pgen.1000519) and [FLARE](https://doi.org/10.1016/j.ajhg.2022.12.010) are particularly close: donor memory and ancestry-scale versus within-population switches predate this proposal. FLARE's state (ancestry,donor) is richer than fixed donor-label projection. [Recomb-Mix](https://doi.org/10.1093/bioinformatics/btaf227) already turns site-based copying into graph optimization/collapsing. Merely calling copying a GNN is insufficient.

[RFMix](https://doi.org/10.1016/j.ajhg.2013.06.020) uses RF-defined window ancestry potentials and a CRF. [Gnomix](https://doi.org/10.1038/s41467-026-75391-0) uses base ancestry classifiers followed by learned smoothing, with explicit training-distribution considerations. Their inspected predictors do not retain individual donor posterior states in the proposed way; that difference is mostly inherited from copying HMMs.

[tsinfer](https://doi.org/10.1038/s41588-019-0483-y) already modifies Li–Stephens copying for ancestral haplotypes and uses incrementally updated tree sequences. [diCal2](https://doi.org/10.1073/pnas.1905060116) supplies genealogy-based conditional sampling HMMs. This focused inspection does not establish priority over all genealogy-conditioned copying methods.

Tree-LSTM/cavity sweeps, TGN memory, GraphSSM dynamics, stochastic replacement and positive matrix exponentials are established. A sufficiently flexible TGN can implement B, so no expressiveness separation is claimed. The precise difference from the inspected published operators and project controls is the constrained donor-indexed, mass-conserving paired-tree loss/gain update before class compression. A new general message-passing/SSM primitive is **not** established. Historical novelty confidence is low; confidence that this is a distinct, interpretable test from H025–H036 is higher. A successful result would initially justify a narrow genealogy-conditioned copying/representation contribution, not architecture priority or publication outcome.
