"""One handmade H038/native ARGMix metadata, SNP, split and archive join check."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import numpy as np
import torch
from arggnn import expanded_native_argmix_v1 as a

ROOT=a.ROOT


def reject(action):
    try:action()
    except ValueError:return
    raise AssertionError("Expected contract rejection")


def main():
    rows=[];old={"WHG":12,"EHG":10,"Ana":2,"CHG":10}
    cohorts=[("present_day",182),("Bronze_Age",162),("BAA",14),("Neo",302),("Yam",26),
             ("WHG",102),("EHG",86),("Ana",50),("CHG",28)]
    classes={"Ana":0,"CHG":1,"WHG":2,"EHG":3}
    for cohort,count in cohorts:
        for within in range(count):
            i=len(rows);donor=cohort in classes
            rows.append(dict(sample_index=i,sample_id="tsk_%d"%(i//2),haplotype=i%2,
                inferred_tree_node_id=i,observed_node_id=i,source_observed_node_id=1000+i,
                observed_cohort=cohort,age_generations=400 if donor and within<old[cohort] else
                    200 if donor else 0 if cohort=="present_day" else 50,
                role="pure_source_reference" if donor else "query",
                observed_reference_class=classes[cohort] if donor else None))
    metadata,roster=a.validate_slot_metadata_v1(rows)
    assert len(metadata)==952 and len(roster.query_nodes)==686 and len(roster.reference_nodes)==266
    assert {name:sum(row[1]==name for row in metadata) for name in a.CLASS_ORDER}==dict(ANA=50,CHG=28,WHG=102,EHG=86)
    assert sum(row[1]!="QUERY" and row[2]>350 for row in metadata)==34
    bad=deepcopy(rows)
    for i in (0,1):bad[i]["inferred_tree_node_id"]=bad[i]["observed_node_id"]=1-i
    reject(lambda:a.validate_slot_metadata_v1(bad))
    bad=deepcopy(rows);bad[0]["observed_reference_class"]=0
    reject(lambda:a.validate_slot_metadata_v1(bad))
    queries=rows[:686]
    intervals=np.array([[0.,101.],[101.,2000000.]],dtype=np.float64)
    labels=np.stack((np.arange(686)%4,(np.arange(686)+2)%4))
    local=np.array([0,5,30],dtype=np.int64);physical=local.astype(np.float64)+100
    raw=np.arange(1000,1686)
    truth=a.snp_truth_v1(intervals,labels,raw,queries,local,physical)
    np.testing.assert_array_equal(truth["truth__hap_labels"],labels[[0,1,1]])
    assert truth["truth__sample_ids"].shape==(343,) and truth["ancestry_names"].tolist()==a.CLASS_ORDER
    reject(lambda:a.snp_truth_v1(intervals,labels,raw+1,queries,local,physical))
    cfg=a.load_config_v1(a.record_v1(ROOT/a.DRAFT));cfg["execution_guard_ready"]=True
    class NoReads:
        def decode_json(self,*args,**kw):raise AssertionError("No read before outer rejection")
    reject(lambda:a.prepare_observed_parent_v1("ap_expanded_outer_000",{"path":"unused"},"unused",cfg,
        guard=lambda n:None,reader=NoReads()))
    reject(lambda:a.assemble_development_v1({},"unused",cfg,guard=lambda n:None))
    a._source_clone(a.native.stock_train,cfg,[
        ('"official_argmix_biological_stock_fit_v1"','"expanded_native_argmix_stock_fit_v1"')])
    a._source_clone(a.native.infer_and_seal,cfg,[
        ('"official_argmix_biological_stock_fit_v1"','"expanded_native_argmix_stock_fit_v1"'),
        ('len(coords["grid_indexes"]), 120, 4','len(coords["grid_indexes"]), 686, 4'),
        ('if len(seals) != 2:','if len(seals) != 8:'),
        ('Both observed VAL parents must be sealed','All eight observed VAL parents must be sealed')])
    guarded=[]
    with tempfile.TemporaryDirectory(prefix="h038_argmix_handmade_",dir=ROOT/".runtime/tmp") as name:
        directory=Path(name);paths=[]
        for value in (1,2):
            path=directory/("handmade_%d.pt"%value)
            with path.open("xb") as stream:
                np.savez(stream,input_ids=np.full((1,1024,16),4+value,dtype=np.int64),
                    tmrca=np.full((1,1024,16,16),value,dtype=np.int16),
                    labels=np.full((1,1024),value,dtype=np.int64),row_mask=np.ones((1,1024),dtype=np.uint8),
                    cm_features=np.full((1,1024,2),value/100,dtype=np.float32),
                    metadata=np.array([2,0,1024,512,15,0,14,0,1,2,3,9],dtype=np.int64))
            paths.append(path)
        merged=directory/"merged.pt"
        a.concatenate_native_archives_v1(paths,merged,guarded.append)
        assert a.archive_layout_v1(merged)["chunks"]==2
        with np.load(merged,allow_pickle=False) as z:
            for key in a.ARCHIVE_FIELDS:
                with np.load(paths[0],allow_pickle=False) as first,np.load(paths[1],allow_pickle=False) as second:
                    np.testing.assert_array_equal(z[key],np.concatenate((first[key],second[key]),axis=0))
            assert z["metadata"].tolist()==[2,0,1024,512,15,0,14,0,1,2,3,9]
        assert guarded[0]>=sum(p.stat().st_size for p in paths) and guarded[-1]==0
    assert not torch.cuda.is_initialized()
    result=dict(status="one_handmade_native_ARGMix_contract_join_check_PASS",checks={
        "full952_actual_slots_ages_donor266_query686":True,
        "unequal_donor_counts_and34older_retained":True,
        "noncontiguous_native_slot_ids_rejected":True,"query_ancestry_input_rejected":True,
        "SNP_local_original_and_raw_query_identity_join":True,"wrong_raw_query_identity_rejected":True,
        "outer_parent_rejected_before_reads":True,"incomplete32TRAIN8VAL_assembly_rejected":True,
        "stock_fit_and_full8VAL_clone_literals_compile":True,
        "streamed_native_archive_bytes_dtypes_masks_order_preserved":True},
        source_ref=a.record_v1(ROOT/a.SOURCE),config_ref=a.record_v1(ROOT/a.DRAFT),
        test_source_ref=a.record_v1(Path(__file__).resolve()),actual_observed_or_truth_arrays_read=False,
        native_Rust_or_author_model_executed=False,GPU_launches=0,CUDA_context_created=False,
        optimizer_updates=0,native_actual_full_parent_qualification_pending=True)
    print(json.dumps(result,sort_keys=True,indent=2))
    return result


if __name__=="__main__":main()
