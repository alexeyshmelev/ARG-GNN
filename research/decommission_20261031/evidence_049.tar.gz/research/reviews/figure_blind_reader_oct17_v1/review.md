# Figure assessment

Image: `paper/figures/TreeLoom_architecture.png`  
SHA256: `6a72495567c1057e191037ef996d36ec7fb4827b81b85d09ebaa5fc5f7013fa3`  
Native size: 1540 x 1452 pixels.

**Independence disclosure.** I viewed the PNG and formed the initial interpretation before opening repository text. A subsequent administrative AGENTS.md check returned architecture-related instructions as well as safety rules. Consequently, this is not a pristine blind review. No caption, manuscript, model implementation, or earlier review was opened. The account below is restricted to visible features and ambiguities in the PNG.

## What I can reconstruct from the image

Panel a shows a genealogy in time and genomic position, divided into three intervals over 0–10 kb, with boundaries at 1.46 and 6.65 kb. A magenta square appears to identify the query. Diamonds and the R legend appear to mark reference samples. The arrow leads to three local trees.

Panel b explicitly labels those trees T1, T2, T3 and repeats the solid, diagonal, and crosshatched interval codes. All three contain r1–r4 and magenta q1, with different leaf orders. Each leaf has a binary entry, collectively labeled g_(t,q). The first displayed vector is 0,1,1,1,1; the other two are 0,0,0,1,1 in their displayed leaf orders. A three-entry box containing tau,0,0 attaches to an internal node of T2. Reference samples have four-entry one-hot ancestry vectors, while q1 has an unknown label. Their colors match the four-class legend.

Panel c appears to encode inputs with an MLP into b_v, then apply an upward and downward tree GNN. Its output feeds a structural branch labeled Delta_str and a sample-memory branch. The memory is arranged as persistent sample rows across T1–T3, with arrows in both directions between adjacent trees, followed by a Linear layer. These two branches and a bypass from b_v meet at addition. A second upward/downward GNN produces a sample-by-tree embedding table labeled e_(t,q). This enters a one-layer BiGRU, also receiving an interval-coded input l_t. A bypass from e_(t,q) joins the recurrent output at a concatenation symbol. An MLP produces ancestry probabilities p_(t,q), and argmax gives a local ancestry track for q1. In this toy output, every interval is purple/WHG.

That is a useful qualitative reconstruction. The image alone does not specify the full architecture, its input encoding, or its mathematical operations.

## Where the reading is uncertain

1. **Binary g is undefined.** The values may encode a relation to the query, but their rule is not recoverable reliably. They are not simply an indicator of query identity, because other leaves also receive 1. The tau,0,0 tuple is also unexplained. It is unclear exactly which of these features and reference labels enter the MLP, and what features internal nodes receive.

2. **“Sample memory” states a purpose, not an operation.** The bidirectional arrows suggest communication along the ordered trees for each sample. They do not identify the update mechanism, aggregation, state persistence, initialization, or whether the block is recurrent. The figure should not be read as establishing those details.

3. **The repeated GNN blocks lose explicit tree indexing.** The two miniatures inside each block are plausibly the upward and downward passes on the same tree. They could initially look like two different trees. Both blocks use the same theta, suggesting shared parameters, but sharing is not explicitly stated. Delta_str and the precise meaning of its additive update are not defined.

4. **Identity is partly successful.** q1 is readily tracked through magenta leaves and rows. Reference identity can be tracked through labels even when leaf order changes. T1–T3 are explicit in panel b and both embedding tables. Their individual paths through the generic GNN blocks are implicit, and the output segments have neither T labels nor the hatch codes. Ordering and segment widths suggest correspondence, but the reader must carry it mentally.

5. **Layout is legible at native resolution, but dense.** I see no major text-on-text collision. The leaf labels, binary boxes, and g labels are crowded. The tree miniatures and small arrows are harder to inspect than the main labels. The long right-hand return from addition to the second GNN and the low embedding bypass are traceable but impose substantial visual work. Printed-size readability was not tested.

## Highest-value changes

- Give g a short phrase naming its actual meaning, and define the tau tuple. Show which observed feature groups feed the first MLP.
- Name the actual operation inside Sample memory, with a short indication that rows preserve sample identity across ordered trees.
- Mark each GNN as operating “for each T_t.” Label the miniatures as sequential upward/downward passes, and explicitly state parameter sharing if intended.
- Preserve T indexing through the central computation and label the three output segments T1–T3. Small consistent interval tags would suffice.
- Briefly name the structural update and baseline at the addition, and label the long return as the input to the second tree pass.

These changes would make the method easier to read without turning the schematic into a collection of equations.
