# VAL000 sealed-observation resume preparation v2

Actual v1 observation succeeded:8585 nodes,5249 trees,13661 original/native sites,13631 common SNPs,952 samples with actual dates and explicit native IDs. Connected shared internal IDs7633; reuse2,417,602. Observation took208.3s at sampled817MB RSS. The old preparation extracted the complete corpus in33.9s and reached sampled2.21GB RSS before the planning check failed.

The exact native extractor loops every sample then every marginal tree, giving4,997,048 occurrences. This is below the10M occurrence cap and passed the preceding native-tree shape gate. Thus the failed limit is uniquely the1M unique-full-path cap. The exact unique count was not persisted, because the check is before output creation. The complete vocabulary is8589 (952 sampled plus7633 connected internal IDs plus4 special tokens). Unique paths are >1M and <=4,997,048; exact lengths, donor-path counts and serialized bytes need the scoped diagnostic below.

NEW source src/arggnn/resume_expanded_native_argformer_tsinfer_preparation_v2.py keeps all frozen v1 files and failed artifacts. It pins the successful observation manifest bea9e207... and tree db6594a2... at their existing paths. It never invokes tsinfer/tsdate, never copies or rewrites that genealogy, and never admits a GPU or fits a model.

## Root diagnostic, one existing VAL000 only

From /workspace-SR003.nfs2/ARG-GNN after sourcing scripts/project_env.sh:

    CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .runtime/conda/envs/argformer_native_v1/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v2 --stats --root-authorized

Root captures stdout as a fresh ROOT metadata JSON file. The author has not run this command. It performs only the original observed reader, exact native full path extraction/vocabulary and seed42 original90/10 split, followed by protocol4 serialization byte counting into a counting byte sink. It writes no arrays, pickles or tree output, does no inference, no model/numerical tests and no data substitutions. Actual donor labels are used only to count native contrastive rows and exact existing payload sizes; no query ancestry is read.

The diagnostic reports exact unique paths, full occurrences, vocabulary, full path lengths/token count, donor unique paths and internal MLM/contrastive train/val counts; exact protocol4 byte counts for all native pickle products and exact path-ID JSON sizes; and the conservative uncompressed coordinate-join byte bound. It also reports actual process peak RSS and elapsed time. Boundary stop allowances are8GiB RSS and600s, based on the prior actual2.21GB/33.9s extraction, not the old48GiB/4h blanket. These are boundary checks, not OS limits; root can externally supervise the diagnostic if required.

New retained-output allowance is rounded to100MB from 1.25*(exact primitive bytes +1.01*uncompressed joins +64KiB manifest allowance)+64MB. The join bound includes both full686 query grid/SNP path-ID matrices and every published vector/reference-path array. The1% allowance bounds zip/container overhead; compression can only reduce the larger uncompressed estimate. Resume RSS allowance is rounded toGiB from the diagnostic peak +largest serialized payload +four full join buffers +1GiB, with minimum8GiB. The wall allowance is max600s or10times diagnostic duration. These become concrete one-parent bounds only after the actual diagnostic, and are not a measured preparation claim.

## Root draft and resume

After capturing the actual stats file and SHA:

    .runtime/env/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v2 --admission-draft --stats-ref <ROOT_STATS.json> --expected-stats-sha256 <SHA>

This is metadata only. Root binds the resulting NEW input to a fresh retired-scopes reservation, active expiry and exact source/runtime/scientific-config/observation/tree/roster/stats refs. All six accounting components and the original project_budget_v9_consumer.py stub are in the source closure. Suggested output is data/expanded_native_argformer_tsinfer_VAL000_prepared_v2, with the measured one-parent allowance. No authority or journal operation is included in the author action.

Root then executes in the already qualified native preparation interpreter:

    CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .runtime/conda/envs/argformer_native_v1/bin/python -B -m arggnn.resume_expanded_native_argformer_tsinfer_preparation_v2 --execute --input <ACTIVE_ROOT_INPUT.json> --expected-input-sha256 <SHA>

The driver constructs fresh isolated release globals, preserving the native preparation function, full path ordering/deduplication/vocabulary, pickle protocol/content, grid/SNP joins and all numerical model settings. Only the infrastructure corpus-cap callback now requires the exact actual diagnostic counts instead of the defeated provisional1M limit. It also adds owned runtime scratch and explicit v2 resource-policy provenance to the new prepared manifest. A changed complete corpus, time/memory/storage failure or native512/4096 count shortfall stops without reduction; the old source/output remains untouched.

The prepared manifest preserves the unchanged v1 scientific source/config/schema required by the released fitting APIs, and explicitly adds preparation_driver_ref, resource_policy_input_ref, resource_policy_stats_ref and v1_unique_path_planning_cap_superseded_explicitly. This distinguishes the unchanged method condition from the NEW resource-admission policy. Root can call the original guarded8VAL fit/retrieval APIs with this manifest and the original scientific config; there is no old-checkpoint reuse or model change.

Success receipt: new output/resume_completed.json, binding the old successful observation, exact actual stats and native prepared manifest with measured completion counts/time/peak RSS. This driver is only the existing VAL000 resume; remaining VAL protocols need their own observations and measured per-parent admission.

## Root integration details

admission_draft_v2(stats_ref) returns the exact input template. Root storage.validate_storage_v9 receives source_ref=new driver, config_ref=scientific_config_ref and runtime_ref=the pinned actual successful preparation runtime report e3429d18... . Reservation consumer_bindings must contain source/config/observation/tree/roster/runtime/stats/storage adapter plus every source_sha256 ref, including the v9 stub. Use the existing ROOT retire_inactive_scopes_before_fast_cache_v1.py ref/save/authority/inspect/pins utilities to create a separate fresh reservation; preserve the original failed scope and all old receipts.

Execution is direct CPU-only; root owns the subprocess/log and actual wait. Only the fresh prepared output is written. Model algorithm and old scientific config remain unchanged; resource admission is explicit v2 provenance. No source/artifact deletion, inference rerun, storage journal operation, native preparation, diagnostic or training was performed by this authoring task.
