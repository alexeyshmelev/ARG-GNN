"""Independent source/AST/RAM review of sealed blocked CPU pipeline v1. No production imports."""
from pathlib import Path
from types import SimpleNamespace,FunctionType,CodeType
from datetime import datetime,timezone,timedelta
from contextlib import contextmanager,redirect_stdout
import ast,argparse,copy,hashlib,io,json
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN");REL="research/reviews/frozen_TRAIN001_019_preparation_pipeline_source_20261017_v1"
W=REL+"/worker_entry_v1.py";B=REL+"/batch_ROOT_v1.py";C=REL+"/close_unit_ROOT_v1.py";M=REL+"/source_manifest.v1.json"
OLD="research/reviews/frozen_TRAIN002_019_batch_continuation_source_20261017_v3";OBS="research/reviews/frozen_TRAIN001_observe_ready_20261017_v2"
checks=[]
def need(ok,msg="Independent RAM condition"):
 if not ok:raise ValueError(msg)
def yes(n,ok=True):need(ok,n);checks.append(n)
def ref(p):return dict(path=p,sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest())
def doc(p):return json.loads((ROOT/p).read_text())
def fn(path,name,e):
 text=(ROOT/path).read_text();n=next(n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name==name)
 f=FunctionType(next(c for c in compile(text,path,"exec").co_consts if isinstance(c,CodeType)and c.co_name==name),e,name,tuple(ast.literal_eval(x)for x in n.args.defaults))
 f.__kwdefaults__={k.arg:ast.literal_eval(v)for k,v in zip(n.args.kwonlyargs,n.args.kw_defaults)if v is not None};return f
def astfn(path,name):
 return ast.dump(next(n for n in ast.parse((ROOT/path).read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name==name),include_attributes=False)
m=doc(M);h=doc(REL+"/HANDOFF.v1.json")
yes("sealed_handoff_exact",ref(REL+"/HANDOFF.v1.json")["sha256"]=="047f13e12b8740471a1cb52565fb0b48157041378915fa2e968b84a7ea8879f8")
yes("sealed_manifest_exact",ref(M)["sha256"]=="496d2016e3fe811ddb386818f14015164ee19ff3d711a2c8429ecb5f02ed6aa5")
for rr in m["refs"]:need(ref(rr["path"])==rr)
yes("all19_concrete_refs_authenticated",len(m["refs"])==19)
for name in("original_owned","available_original_slots","available_memory","terminal","argv","group_call","state","guard"):
 yes("same_reviewed_v3_"+name,astfn(B,name)==astfn(OLD+"/batch_ROOT_v1.py",name))
current_group=astfn(B,"run_group");old_group=astfn(OLD+"/batch_ROOT_v1.py","run_group")
current_assignment=ast.dump(ast.parse("end_work=deadline_epoch-180").body[0],include_attributes=False)
old_assignment=ast.dump(ast.parse("end_work=min(deadline_epoch,time.time()+10800)-180").body[0],include_attributes=False)
yes("aggregate_monitor_only_stage_specific_outer_deadline_delta",current_group.replace(current_assignment,old_assignment)==old_group)
yes("finite_group_call_deadline_inherited",astfn(B,"group_call")==astfn(OLD+"/batch_ROOT_v1.py","group_call"))
yes("unchanged_original_writer_wrapper",astfn(W,"_OriginalWriterCurrentGuard")==astfn(OBS+"/worker_entry_v1.py","_OriginalWriterCurrentGuard"))
condition=m["condition"];oldcond=doc(OBS+"/source_manifest.v1.json")["condition"]
yes("original_inference_template_runtime_caps_unchanged",condition["stage_templates"]["infer"]==oldcond["inference_template_inactive"]and condition["stage_runtime_refs"]["infer"]==oldcond["inference_runtime_ref"]and condition["stage_caps"]["infer"]==oldcond["caps_proposed"])
yes("original_native_template_provenance_unchanged",condition["stage_templates"]["native_paths"]==dict(doc(condition["original_native_config_provenance_ref"]["path"]),execution_enabled=False,observation_ref=None))
yes("original_registered_seed_registry_unchanged",condition["registry"]==doc(condition["registry_provenance_ref"]["path"]))
yes("unchanged_shared_two_slot_pool",m["synchronization_pool"]==doc(OLD+"/source_manifest.v1.json")["synchronization_pool"])
# Exact real initializer code reaches the missing key before any original driver or guard load.
loaded=[];context=SimpleNamespace(read=lambda rr:doc(rr["path"]),ref=ref)
def load(p,sha,name):loaded.append(p);return context
e=dict(c=None,d=None,ROOT=ROOT,REL=REL,SOURCE=W,DRIVER=W,WORKER=W,MANIFEST=M,
 OLD="research/reviews/American_C3_VAL003004_current_Census_preparation_source_20261016_v1",OLD_CONTRACT_SHA="507b364df4bb697d2f0e56617502de461305fa18bb4528e1e8204894579dcb71",
 PARENT="american_c3_train_002",STAGE="infer",PHASE="infer_train_002",stage_status=lambda stage:"completed_current_C3_inference",_load_initial=load,need=need)
try:fn(W,"initialize",e)()
except KeyError as ex:yes("independently_reproduced_missing_condition_pool_KeyError",ex.args==("synchronization_pool",)and len(loaded)==1)
else:raise AssertionError("Expected concrete initializer blocker")
yes("manifest_pool_exists_only_top_level","synchronization_pool"in m and "synchronization_pool"not in condition)
# Exact queue wrappers: acquisition-only timeout queues; identical error after yield is fatal.
for path,name,core in((W,"admit","admit_under_coordinator"),(C,"close_once","close_under_coordinator")):
 for case in("before_yield","after_yield","other_error","fresh","aged"):
  events=[];now=datetime.now(timezone.utc);q=dict(batch_control_input_ref={},created_at_utc=(now-timedelta(seconds=300 if case=="aged"else 1)).isoformat())
  @contextmanager
  def coordinator(rr):
   events.append("enter")
   if case=="before_yield":raise ValueError("Finite shared ROOT accounting coordinator wait")
   if case=="other_error":raise ValueError("Different source/accounting error")
   yield
   events.append("exit")
  def operation(rr):
   events.append("operation")
   if case=="after_yield":raise ValueError("Finite shared ROOT accounting coordinator wait")
   return dict(status="CORE_RAN")
  env=dict(read=lambda rr:q,accounting_transaction=coordinator,support=lambda:None,datetime=datetime,timezone=timezone,**{core:operation})
  if case in("after_yield","other_error"):
   try:fn(path,name,env)({})
   except ValueError:yes(name+"_no_replay_after_yield_or_other_error_"+case)
   else:raise AssertionError("Unsafe queue reclassification")
  else:
   result=fn(path,name,env)({})
   if case=="before_yield"or(case=="aged"and path==W):yes(name+"_queued_before_actual_operation_"+case,result["status"]=="QUEUED_BEFORE_OPERATION"and result["accounting_operation_started"]is False and "operation"not in events)
   else:yes(name+"_actual_core_once_"+case,result["status"]=="CORE_RAN"and events.count("operation")==1)
# Native focal identity helper is exact AST extracted and the original science receives original cfg.
src=(ROOT/W).read_text();bridge=ast.unparse(next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name=="execute_in_admitted_context_v1"))
yes("original_science_execute_and_writer_no_replacement","science.execute(cfg, writer)"in bridge and "american_c3_observe_v3 as science"in bridge and "american_c3_paths_v1 as science"in bridge)
yes("focal_identity_exact_original_helper_and_all10000_fields",'n.name=="identity_sha"'in src and 'v.id=="IDENTITY"'in src and 'namespace["identity_sha"](records)'in src and 'len(records["record_ids"])==10000'in src and 'publish_focal_seal(read(result),writer)'in src)
# Every class/source is explicit and all default CLIs inert without initializers.
for path in(W,B,C):
 env=dict(argparse=argparse,json=json,__doc__="RAM")
 with redirect_stdout(io.StringIO())as stream:r=fn(path,"main",env)([])
 yes("default_inactive_"+Path(path).name,r==0 and json.loads(stream.getvalue())["status"]=="SOURCE_ONLY_INACTIVE")
print(json.dumps(dict(schema="CPU_preparation_pipeline_independent_source_findings_v1",status="SOURCE_BLOCKED",checks_passed=len(checks),checks=checks,
 blocker="worker.initialize reads absent manifest.condition.synchronization_pool; pool is top-level. Exact initialize reproduces KeyError before driver/guard/science/admission.",
 source_manifest_ref=ref(M),reviewed_sources=h["executed_sources"],actual_guard_runtime_imports_configurations_resource_process_GPU_probes_admissions_launches_closes=0,scientific_payload_truth_checkpoint_reads_or_hashes=0),sort_keys=True,indent=2))
