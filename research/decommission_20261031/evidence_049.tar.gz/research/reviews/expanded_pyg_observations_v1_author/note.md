Source-only expanded inner PyG preparation CLI
=================================================

The new module preloads completed registered TRAIN/VAL observations once with
eight spawn workers and retains them in host RAM while later entries become ready.
It fits the unchanged legacy geometry bins from all 32 TRAIN parents, then calls
the unchanged full preparation and strict bank validator for all 40 inner parents.
It publishes through the unchanged full cache writer with the pinned CPU overlay
guard. Producer, inference, outer parents and target archives are never invoked.

The source receipt records the CLI, exact source/config/registration references
and required admission fields. The input hash is provided on the CLI separately
from the reservation to avoid a self-reference cycle. Source, fixed generation
config, registration and runtime references must all appear in consumer bindings.
The generation config is copied only to substitute the admitted output byte cap
for storage validation. Its on-disk bytes are unchanged.

Each parent's load time, native hold/site/vertex/haplotype counts, preparation time
and worker peak RSS are recorded. Publication records actual compressed bytes and
guard-boundary timing, with total elapsed time and sampled main-plus-worker RSS.
Guard intervals include the previous write and current encode. No array readback
is performed merely for timing or reporting.

A complete output can be reused after exact metadata provenance verification.
An incomplete output is preserved and rejected, requiring a fresh admitted output.
Owned native temporary snapshots are deleted by the loader, empty owned scratch
directories are removed after tracked workers drain. Failure is printed promptly
and written to guarded logs when storage authority permits.

Verification was AST parsing, source compilation and import only. No preparation,
native inference, package installation, Git operation or budget mutation occurred.

CPU preload repair: Linux memfd filelike tree loading uses an isolated loader namespace, with libc fallback because current Python lacks os.memfd_create. Workers create no filesystem temporary paths. Preparation returns NumPy arrays and the parent reconstructs Torch inputs. One tiny synthetic tskit memfd roundtrip passed. Existing failed runtime scope was preserved, and no actual parent was loaded during this verification.
