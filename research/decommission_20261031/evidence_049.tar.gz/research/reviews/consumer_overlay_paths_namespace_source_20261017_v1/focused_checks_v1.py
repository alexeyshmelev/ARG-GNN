"""Focused source-authentication and RAM namespace tests, no guard imports."""
from pathlib import Path
from contextlib import contextmanager
import copy,hashlib,json,types
R=Path('/workspace-SR003.nfs2/ARG-GNN')
D=R/'research/reviews/consumer_overlay_paths_namespace_source_20261017_v1'
positive=[];negative=[]
def check(ok,label):
 if not ok:raise AssertionError(label)
 positive.append(label)
def rejected(fn,label):
 try:fn()
 except (ValueError,KeyError,AssertionError,TypeError,AttributeError):negative.append(label);return
 raise AssertionError('Accepted '+label)
def execute_source(path,name):
 env=dict(__name__=name,__file__=str(path))
 exec(compile(path.read_bytes(),str(path),'exec',dont_inherit=True,optimize=0),env)
 return env
C=execute_source(D/'overlay_paths_namespace_v1.py','RAM_component')
A=execute_source(R/C['PINS']['adapter']['path'],'RAM_existing_adapter')
class RamLock:
 def __enter__(self):return self
 def __exit__(self,*args):return False
ramthreads=types.SimpleNamespace(active_count=lambda:1,Lock=RamLock,local=types.SimpleNamespace)
C['threading']=ramthreads;A['threading']=ramthreads
pins=C['PINS'];resolutions=[];redirect=set()
class RamPath:
 def __init__(self,value):
  key=str(value);self.key=key if Path(key).is_absolute()else '/RAM_project/'+key
 def is_absolute(self):return True
 def __eq__(self,other):return self.key==str(other)
 def __str__(self):return self.key
 @property
 def parents(self):return Path(self.key).parents
 @property
 def parts(self):return Path(self.key).parts
 def resolve(self):
  resolutions.append(self.key)
  return RamPath(self.key+'/changed')if self.key in redirect else self
def module(record,name):
 return types.ModuleType(name)
def bind(m,name,code):
 f=types.FunctionType(code,m.__dict__,name);setattr(m,name,f);return f
def code(record,name):
 return C['child_code_v1'](C['compiled_v1'](record),name)
def family():
 v4=types.ModuleType('RAM_v4');v4.__file__=str(R/pins['v4']['path'])
 v4.Path=RamPath
 for name in ['canonical','file_bytes','reference','scope_spec','mutex']:
  bind(v4,name,code(pins['v4'],name))
 v4.mutex=contextmanager(v4.mutex)
 v4.paths_overlap=lambda a,b:False
 budget=types.ModuleType('RAM_budget');budget.__file__=str(R/pins['budget']['path']);budget.v4=v4
 bind(budget,'successor_paths',code(pins['budget'],'successor_paths'))
 owners=[]
 for i,row in enumerate(pins['overlays']):
  m=types.ModuleType('RAM_overlay_'+str(i));m.__file__=str(R/row['path']);m.budget=budget;m.ROOT=Path('/RAM_project')
  m.JOURNAL='RAM/journal'+str(i);m.SOURCE=row['path']
  m._POLICY_REF=dict(path='research/reviews/RAM_policy_'+str(i)+'.json',sha256=str(i)*64)
  m._SELECTOR_REF=dict(path='research/reviews/RAM_selector_'+str(i)+'.json',sha256=str(i)*64)
  m.require=lambda ok,message:None if ok else (_ for _ in ()).throw(ValueError(message))
  bind(m,'_paths',code(row,'_paths'));owners.append(m)
 bottom=types.ModuleType('RAM_bottom');bottom.__file__=str(R/pins['bottom']['path']);bottom._paths=lambda own:[];bottom._CONFIGURED={'_paths':bottom._paths};bottom.budget=budget
 for i,m in enumerate(owners):m._BASE=owners[i+1]if i+1<len(owners)else bottom
 handle=A['TransactionMemoAdapter'](v4,expected_source_path=R/pins['v4']['path'],expected_source_sha256=pins['v4']['sha256'])
 handle.namespace_callers=frozenset((*handle.namespace_callers,
  C['child_code_at_v1'](v4.scope_spec.__code__,'<listcomp>',182),
  C['child_code_at_v1'](budget.successor_paths.__code__,'<genexpr>',54)))
 handle.receipt.update(namespace_extension_schema='resource_guard_consumer_namespace_memo_v1',
  namespace_extension_ref=copy.deepcopy(pins['namespace']),original_memo2_ref=copy.deepcopy(pins['adapter']),
  consumer_role='read_only_consumer',root_mutation_installation_authorized=False)
 handle.install()
 return handle,owners
def extend(h,owners,**kw):
 return C['extend_future_consumer_v1'](h,owners[0],consumer_role=kw.get('consumer_role','read_only_consumer'),
  lifecycle_role=kw.get('lifecycle_role','future_before_first_guard'))
def state():
 return dict(raw={},canonical={},entries=0,charge=0,raw_hits=0,raw_misses=0,raw_bytes_missed=0,
  canonical_hits=0,canonical_misses=0,capacity_bypasses=0,capacity_bypass_bytes=0)
h,owners=family();before_ids={n:id(getattr(h.module,n))for n in ['canonical','file_bytes','mutex']}
receipt=extend(h,owners)
check(receipt['additional_callers']==8 and len(h.namespace_callers)==12,'Exactly8authenticated overlay callers added to exact existing4')
check({n:id(getattr(h.module,n))for n in before_ids}==before_ids,'Original installed wrapper objects never replaced')
check(h.max_bytes==256*2**20 and h.max_entries==16384 and h.tls.__dict__=={},'Original limits and unused lifecycle preserved')
check([r['source_ref']for r in receipt['source_code_bindings']]==pins['overlays'],'Exact ordered8source identities disclosed')
bindings=json.loads((R/'research/reviews/Census_numerical_actual_timeout_diagnosis_20261017_v1/H058_exact8_paths_bindings.v1.json').read_text())
check(all(o._paths.__code__==code(r,'_paths')for o,r in zip(owners,pins['overlays']))
 and [r['first_line']for r in receipt['source_code_bindings']]==[r['line']for r in bindings['bindings']],
 'All8exact compiled code objects and source lines match authenticated binding definitions')
# Pure RAM namespace resolution counts. No guard/state or scientific call.
baseline,baseowners=family();baseline.tls.state=state();resolutions.clear()
for _ in range(5):baseowners[0]._paths({})
baseline_count=len(resolutions);baseline.tls.state=None
check(baseline_count==50,'Unextended fixture repeats10fixed namespace resolutions on each of5recursive calls')
h.tls.state=state();resolutions.clear()
for _ in range(5):owners[0]._paths({})
check(len(resolutions)==10 and h.tls.state['canonical_hits']==40,'Extension reuses exactly10fixed namespace keys within one RAM operation')
h._validate_snapshot(h.tls.state)
check(len(resolutions)==20,'Unchanged original final validation resolves every one of10cached paths uncached')
h.tls.state=None
h.tls.state=state();resolutions.clear();owners[0]._paths({})
check(len(resolutions)==10,'New RAM operation begins with cold namespace cache')
# No unlisted caller is admitted.
resolutions.clear()
for _ in range(2):h.module.canonical(Path('/RAM_project'),'research/reviews/RAM_unlisted.json')
check(len(resolutions)==2,'Unlisted direct callers remain uncached')
key=next(iter(h.tls.state['canonical'].values()))[2].key;redirect.add(key)
rejected(lambda:h._validate_snapshot(h.tls.state),'Final original uncached namespace revalidation rejects changed path')
redirect.clear();h.tls.state=None
rejected(lambda:extend(h,owners),'Duplicate extension rejected')
for label,mutate in [
 ('active operation',lambda h,o:setattr(h,'active_count',1)),
 ('prior operation',lambda h,o:setattr(h.tls,'last',dict(success=True))),
 ('uninstalled handle',lambda h,o:h.receipt.update(installed=False)),
 ('extra caller',lambda h,o:setattr(h,'namespace_callers',frozenset((*h.namespace_callers,(lambda:0).__code__)))),
 ('enlarged byte cap',lambda h,o:setattr(h,'max_bytes',256*2**20+1)),
 ('changed source callable',lambda h,o:setattr(o[0],'_paths',lambda own:[])),
 ('replaced installed wrapper',lambda h,o:setattr(h.module,'canonical',lambda r,p:p)),
 ('broken source chain',lambda h,o:setattr(o[0],'_BASE',o[-1])),
 ('different budget module',lambda h,o:setattr(o[0],'budget',types.SimpleNamespace(v4=h.module)))]:
 hh,oo=family();mutate(hh,oo);rejected(lambda hh=hh,oo=oo:extend(hh,oo),'Reject '+label)
hh,oo=family()
rejected(lambda:extend(hh,oo,consumer_role='ROOT_mutation'),'ROOT mutation role rejected')
rejected(lambda:extend(hh,oo,lifecycle_role='existing_running_consumer'),'Live consumer lifecycle rejected')
before=copy.deepcopy(pins['overlays'][0]);pins['overlays'][0]['sha256']='0'*64
rejected(lambda:extend(hh,oo),'Changed pinned source digest rejected before extension')
pins['overlays'][0]=before
original=type(hh)._validate_snapshot;type(hh)._validate_snapshot=lambda self,s:None
rejected(lambda:extend(hh,oo),'Tampered final revalidation method rejected')
type(hh)._validate_snapshot=original
result=dict(schema='consumer_overlay_paths_focused_RAM_checks_v1',status='AUTHOR_COMPONENT_SOURCE_RAM_PASS_PENDING_INDEPENDENT_REVIEW',
 positive=len(positive),negative=len(negative),checks=positive,negative_cases=negative,
 source_ref=dict(path=str((D/'overlay_paths_namespace_v1.py').relative_to(R)),sha256=hashlib.sha256((D/'overlay_paths_namespace_v1.py').read_bytes()).hexdigest()),
 actual_guard_imports=0,actual_guard_calls=0,actual_mutex_process_resource_probes=0,actual_cache_installations_into_guard=0,
 actual_state_or_accounting_operations=0,scientific_arrays_or_model_or_GPU_operations=0,Git_actions=0,
 source_compilation_and_function_definitions_only=True,RAM_dummy_namespace_only=True,
 fixture_namespace_resolution_counts=dict(unextended5calls=baseline_count,extended5calls_plus_final=20),
 runtime_speed_or_current_training_progress_claim=False,whole_route_accepted=False)
(D/'focused_checks.result.v1.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],positive=len(positive),negative=len(negative))))
