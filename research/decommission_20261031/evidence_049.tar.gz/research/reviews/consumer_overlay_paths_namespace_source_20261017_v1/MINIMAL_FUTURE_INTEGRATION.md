# Minimal future benchmark integration

1. Obtain independent review of this exact component source manifest and focused RAM result. Keep current H058 and all live/frozen sources untouched.
2. In a separately reviewed future fixed TreeLoom/H050 benchmark consumer copy, select the exact original Census guard and install the existing accepted consumer namespace memo as already done by guard_v1's consumer-only block.
3. Immediately after that original installation and before the first validate_storage/budget_check/writer/resource guard operation, call the extension on the returned exact handle and same selected guard:

    extension.extend_future_consumer_v1(
        existing_namespace_handle, selected_guard,
        consumer_role="read_only_consumer",
        lifecycle_role="future_before_first_guard")

Load extension only from the exact reviewed source ref authenticated by the future integration. This call goes inside the existing first-install consumer block. Do not place it after a completed guard, into ROOT admission/close/retirement interpreters, or into the running worker.

4. Preserve the existing wrapper and memo object. Do not replace common guard callbacks or suppress their calls. The extension adds only authenticated caller eligibility and a disclosure receipt.
5. Review the entire future integration, including exact source closure and real executed refs. If the route is already at64slots, consolidate source genuinely within existing executed roles rather than adding an omitted role or raising the ceiling.
6. ROOT alone decides genuine fresh controls/admission and original once-only benchmark execution. The scientific model and training budget stay frozen. No source component pass constitutes admission, runtime fit, speedup or an optimizer update.

No active installation command or request is supplied. No repeated numerical retirement attempt is recommended. Original300second pre-mutex clock,120second freshness and final original uncached validation remain unchanged.
