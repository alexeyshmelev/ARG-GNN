"""Inactive future-consumer-only overlay namespace extension. Import performs no I/O.
This component does not import/configure a guard, create a cache or change checks.
Only the exact accepted existing consumer handle before its first operation may extend.
"""
from pathlib import Path
import ast,copy,hashlib,marshal,os,stat,threading,types
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
SOURCE="research/reviews/consumer_overlay_paths_namespace_source_20261017_v1/overlay_paths_namespace_v1.py"
PINS={'v4': {'path': 'src/arggnn/project_budget_v4.py', 'sha256': 'a093c7d86f57fee569cb99f4712250e9505a1119f3950fa44282c7ba8c57df47'}, 'budget': {'path': 'scripts/project_budget_v9.py', 'sha256': '483d78bf2ef3c917d65ecf1dde5a7809bfadc21194c9f9a90394ce5c532fdd5e'}, 'adapter': {'path': 'research/reviews/resource_guard_hotpath_source_audit_v1/transaction_memo_adapter_v2.py', 'sha256': 'c972e9a779d424ceafdb258848614bf40994d1004e2c73fc5cd225ae99621364'}, 'namespace': {'path': 'research/reviews/current_mutex_contention_20261015_v1/consumer_namespace_memo_v1.py', 'sha256': '17a1377320f61c3c0cc8d3816d0259f9dae3121ed91bf7206a7ee63fcab8eb7f'}, 'overlays': [{'path': 'research/reviews/Census_observation_two_scope_retention_source_20261017_v1/census_observation_retention_v1.py', 'sha256': '72f6dc51844b2a261b581f5e69bd2a22982e6244c059f24549747a7b851faeeb'}, {'path': 'research/reviews/Relate_failed64GiB_retention_successor_source_20261017_v1/relate_failed64_retention_v1.py', 'sha256': 'b8b696a0df45c12b931e563600c2b52e89e73dd19c7d160351063687dcfb5164'}, {'path': 'research/reviews/native7_H050_stopped_retention_successor_source_20261016_v1/stopped_retention_v1.py', 'sha256': 'c9392ed88b76a5a6c1394d13ff78b55df83c1b16d8186d23b4d3110b46008e8f'}, {'path': 'research/reviews/native14_stopped_retention_successor_source_20261016_v3/native14_stopped_retention_v1.py', 'sha256': '60d010e393bda25f662381051b3fd3d4e4decfa034b10c3baad3c3f30a6a196c'}, {'path': 'research/reviews/prospective980_Census_fit2_retention_source_20261016_v1/prospective_980gb_Census_fit2_v1.py', 'sha256': 'fab6bb67bc1f4be989df9bb16e7a3a17d24652ca8238617ca060a56cb8c89d43'}, {'path': 'research/reviews/prospective980_H020_legacy_source_20261016_v3/prospective_980gb_H020_v3.py', 'sha256': 'ec475ecf59f0335397ee8b310cd0cb406ce4e03161e7c791861c6583799e6635'}, {'path': 'research/reviews/prospective_980GB_capacity_source_v1/prospective_980gb_v1.py', 'sha256': 'fc71030865e0a3d5da31120d4daa2caa0b2d39ec7dd212b8c46c476b5a866d56'}, {'path': 'research/reviews/concurrent_completed_scope_credits_v3/completed_scope_credits_v3.py', 'sha256': 'ea14c12c41b9385a86182aa9c24058f7b1276107fc5706c70e47828e8b2c31ef'}], 'bottom': {'path': 'research/reviews/H039_failed_scope_capacity_v2/failed_scope_capacity_v2.py', 'sha256': '40c3e45fc148ffd07119bb0c90e5c7182c7fb84829f9df2b4bb4fa978af42281'}}

def need(ok,message):
 if not ok:raise ValueError(message)

def source_bytes_v1(record):
 need(type(record)is dict and set(record)=={"path","sha256"},"Exact pinned source ref")
 relative=Path(record["path"]);path=ROOT/relative
 need(not relative.is_absolute()and ".."not in relative.parts and str(relative)==record["path"]
  and path.resolve()==path and ROOT in path.parents,"Exact canonical contained source")
 before=path.lstat()
 need(stat.S_ISREG(before.st_mode)and before.st_nlink==1 and before.st_size<=2**20,"Bounded singly linked source")
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,"rb")as stream:
  opened=os.fstat(stream.fileno());raw=stream.read(2**20+1);after=os.fstat(stream.fileno())
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 need(identity(before)==identity(opened)==identity(after)==identity(path.lstat())
  and len(raw)==before.st_size and hashlib.sha256(raw).hexdigest()==record["sha256"],"Exact stable pinned source bytes")
 return raw

def compiled_v1(record):
 return compile(source_bytes_v1(record),str(ROOT/record["path"]),"exec",dont_inherit=True,optimize=0)

def child_code_v1(parent,name):
 found=[c for c in parent.co_consts if isinstance(c,types.CodeType)and c.co_name==name]
 need(len(found)==1,"One exact source code object "+name)
 return found[0]

def child_code_at_v1(parent,name,line):
 found=[c for c in parent.co_consts if isinstance(c,types.CodeType)and c.co_name==name and c.co_firstlineno==line]
 need(len(found)==1,"One exact source child code and line "+name)
 return found[0]

def exact_function_v1(module,name,code):
 fn=getattr(module,name,None)
 need(isinstance(fn,types.FunctionType)and fn.__globals__ is module.__dict__
  and fn.__module__==module.__name__ and fn.__name__==name and fn.__code__==code,
  "Exact unchanged module callable "+name)
 return fn

def extend_future_consumer_v1(handle,guard,*,consumer_role,lifecycle_role):
 """Explicit future-only extension. ROOT mutation callers and live consumers fail."""
 need(consumer_role=="read_only_consumer"and lifecycle_role=="future_before_first_guard",
  "Only explicitly admitted future read-only consumer before first guard")
 need(threading.active_count()==1,"Install only before future consumer threads")
 with handle.lifecycle_lock:
  need(handle.active_count==0 and handle._state()is None and not hasattr(handle.tls,"last"),
   "No active or earlier guard operation, never extend a live consumer")
  receipt=handle.receipt
  need(receipt.get("installed")is True and receipt.get("schema")=="resource_guard_transaction_memo_adapter_v2"
   and receipt.get("namespace_extension_schema")=="resource_guard_consumer_namespace_memo_v1"
   and receipt.get("namespace_extension_ref")==PINS["namespace"]
   and receipt.get("original_memo2_ref")==PINS["adapter"]
   and receipt.get("consumer_role")=="read_only_consumer"
   and receipt.get("root_mutation_installation_authorized")is False
   and "overlay_paths_namespace_extension"not in receipt,
   "Exact accepted installed namespace consumer only, once")
  need(0<handle.max_bytes<=256*2**20 and 0<handle.max_entries<=16384,
   "Original bounded memo limits never enlarged")
  adapter=compiled_v1(PINS["adapter"]);cls=child_code_v1(adapter,"TransactionMemoAdapter")
  # Authenticate every class method, including cache keys, clearing, final
  # original revalidation and original mutex lifecycle, without executing it.
  for expected in [c for c in cls.co_consts if isinstance(c,types.CodeType)]:
   actual=getattr(type(handle),expected.co_name,None)
   need(isinstance(actual,types.FunctionType)and actual.__code__==expected
    and Path(actual.__globals__["__file__"])==ROOT/PINS["adapter"]["path"],
    "Unchanged accepted memo method "+expected.co_name)
   need(getattr(getattr(handle,expected.co_name),"__func__",None)is actual,
    "No instance override of accepted memo method")
  v4=handle.module;budget=guard.budget
  need(Path(v4.__file__)==ROOT/PINS["v4"]["path"]and budget.v4 is v4
   and Path(budget.__file__)==ROOT/PINS["budget"]["path"],"Same exact original v4/budget modules")
  for name,maker in (("canonical","_make_canonical"),("file_bytes","_make_file_bytes"),("mutex","_make_mutex")):
   wrapper=getattr(handle,name+"_wrapper")
   need(getattr(v4,name)is wrapper,"Actual exact installed consumer wrapper "+name)
   fn=getattr(wrapper,"__wrapped__",wrapper)
   expected=child_code_v1(getattr(type(handle),maker).__code__,name)
   closure=dict(zip(fn.__code__.co_freevars,(cell.cell_contents for cell in (fn.__closure__ or ()))))
   need(fn.__code__==expected and fn.__globals__ is getattr(type(handle),maker).__globals__
    and closure.get("self")is handle and closure.get("original")is handle.original[name],
    "Exact accepted wrapper closure and original capability "+name)
  v4code=compiled_v1(PINS["v4"]);budgetcode=compiled_v1(PINS["budget"])
  for name in ("canonical","file_bytes","mutex"):
   fn=handle.original[name];fn=getattr(fn,"__wrapped__",fn)
   need(isinstance(fn,types.FunctionType)and fn.__code__==child_code_v1(v4code,name)
    and fn.__globals__ is v4.__dict__,"Original unchanged "+name)
  scope=exact_function_v1(v4,"scope_spec",child_code_v1(v4code,"scope_spec"))
  reference=exact_function_v1(v4,"reference",child_code_v1(v4code,"reference"))
  successor=exact_function_v1(budget,"successor_paths",child_code_v1(budgetcode,"successor_paths"))
  expected=frozenset((handle.original["file_bytes"].__code__,reference.__code__,
   child_code_at_v1(scope.__code__,"<listcomp>",182),child_code_at_v1(successor.__code__,"<genexpr>",54)))
  need(len(expected)==4 and handle.namespace_callers==expected,"Only exact four previously accepted callers")
  owner=guard;codes=[];records=[]
  for record in PINS["overlays"]:
   need(isinstance(owner,types.ModuleType)and Path(owner.__file__)==ROOT/record["path"]
    and owner.budget is budget,"Exact configured overlay source/chain/budget")
   compiled=compiled_v1(record);code=child_code_v1(compiled,"_paths")
   fn=exact_function_v1(owner,"_paths",code)
   codes.append(fn.__code__);records.append(dict(source_ref=copy.deepcopy(record),definition="_paths",
    first_line=code.co_firstlineno,compiled_code_identity_verified=True,marshal_code_sha256_diagnostic=hashlib.sha256(marshal.dumps(code)).hexdigest()))
   owner=owner._BASE
  need(Path(owner.__file__)==ROOT/PINS["bottom"]["path"],"Exact inherited bottom, never drop an ancestor")
  source_bytes_v1(PINS["bottom"])
  extended=frozenset((*expected,*codes))
  need(len(codes)==len(set(codes))==8 and len(extended)==12,"Exactly eight additional authenticated callers")
  need(handle.active_count==0 and handle._state()is None and not hasattr(handle.tls,"last"),
   "Future handle remains unused throughout authentication")
  result=dict(schema="consumer_exact8_overlay_paths_namespace_extension_v1",source_path=SOURCE,
   consumer_role=consumer_role,lifecycle_role=lifecycle_role,source_code_bindings=records,
   original_callers=4,additional_callers=8,total_callers=12,
   max_bytes=handle.max_bytes,max_entries=handle.max_entries,
   cache_lifetime="unchanged_one_original_mutex_operation",cross_operation_cache=False,
   original_final_uncached_namespace_and_source_identity_validation=True,
   journal_fingerprint_inventory_callers_added=False,guard_boundaries_or_predicates_changed=False,
   root_mutation_installation_authorized=False,live_consumer_installation_authorized=False)
  # Only the allowlist and a disclosed receipt change. Original wrapper/check,
  # lifecycle, limits, callbacks, source/state/expiry/proof/math remain unchanged.
  handle.namespace_callers=extended
  receipt["overlay_paths_namespace_extension"]=copy.deepcopy(result)
  return result
