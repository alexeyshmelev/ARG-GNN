"""Source-only next CPU preparation calls for full-panel native baselines.

Root imports these helpers from an admitted wrapper and supplies its existing
write guard, runtime-admitted modules and archive bounds. No work at import.
Direct invocation prints the source-only status, never starts preparation.
"""
from __future__ import annotations

import json
from pathlib import Path

from arggnn import prepare_full_panel_native_supervised_v1 as bridge

INNER = ("ap_full_train_000", "ap_full_train_001", "ap_full_train_002")
TRAIN = INNER[:2]


def _completed(completed_record):
    done = json.loads(bridge.checked(completed_record).read_text())
    bridge.require(
        done.get("status") == "completed_native_inner_frames_and_ARGMix_targets"
        and set(done["frames"]) == set(done["targets"]) == set(INNER)
        and done["GPU_used"] is False and done["models_fitted"] is False
        and done["native_Rust_run"] is False and done["outer_truth_read"] is False,
        "Completed bound inner-frame/target receipt required",
    )
    return done


def prepare_ap_next(completed_record, inner_input_record, output_dir, *, guard):
    """Prepare two source-native AP feature banks and realized TRAIN rows."""
    bridge._guard(guard, 0)
    done = _completed(completed_record)
    bridge.require(done["input_ref"] == inner_input_record, "Input lineage differs")
    specification = json.loads(bridge.checked(inner_input_record).read_text())
    bridge.require(set(specification["parents"]) == set(INNER), "Exact inner inputs required")
    output = bridge.new_directory(output_dir, guard)
    observations, features, training = {}, {}, {}
    for parent in TRAIN:
        item = specification["parents"][parent]
        observation = bridge.read_completed_parent(
            parent, item["inference"], item["completion"],
            require_argmix_native_ids=False,
        )
        bridge.require(
            observation["tree_record"] == done["frames"][parent]["tree"]
            and observation["inference_record"] == done["frames"][parent]["inference"],
            "AP source observations differ from completed inner frame",
        )
        observations[parent] = observation
        features[parent] = bridge.prepare_ap_features(
            observation, output/"features"/parent, guard=guard,
        )
    # Both observed feature manifests seal before either sampler opens truth.
    feature_seal = bridge.write_json(
        output/"all_TRAIN_AP_features_sealed.json",
        {"features": {p: features[p]["manifest"] for p in TRAIN},
         "truth_opened": False, "parents": list(TRAIN)}, guard,
    )
    for parent in TRAIN:
        training[parent] = bridge.prepare_ap_training(
            observations[parent], features[parent]["manifest"],
            specification["parents"][parent]["truth"],
            output/"training"/parent, guard=guard,
        )
    result = {
        "kind": "full_panel_native_AP_next_preparation_v1",
        "completed_inner_frames_targets": completed_record,
        "input": inner_input_record, "feature_seal": feature_seal,
        "features": features, "training": training,
        "realized_rows": sum(t["realized_rows"] for t in training.values()),
        "requested_rows": sum(t["requested_rows"] for t in training.values()),
        "models_fitted": False, "GPU_used": False, "outer_access": False,
        "internal_VAL_used": False, "native_head_classes": 6,
    }
    result["manifest"] = bridge.write_json(output/"ap_prepared.json", result, guard)
    bridge._guard(guard, 0)
    return result


def prepare_argmix_next(completed_record, output_dir, *, guard,
                        admitted_cli_record, native_modules,
                        archive_write_upper_bound_bytes):
    """Prepare stock train.pt/val.pt from the already completed bound products."""
    bridge._guard(guard, 0)
    done = _completed(completed_record)
    return bridge.prepare_argmix_archives(
        done["frames"], done["targets"], output_dir,
        guard=guard, admitted_cli_record=admitted_cli_record,
        native_modules=native_modules,
        archive_write_upper_bound_bytes=archive_write_upper_bound_bytes,
    )


if __name__ == "__main__":
    print(json.dumps({
        "status": "source_only_not_executed",
        "source": str(Path(__file__)),
        "entry_points": ["prepare_ap_next", "prepare_argmix_next"],
        "root_supplies": ["bound_records", "write_guard", "qualified_native_modules",
                         "native_archive_write_bounds"],
        "actual_data_jobs": False, "models_fitted": False, "GPU_used": False,
    }))
