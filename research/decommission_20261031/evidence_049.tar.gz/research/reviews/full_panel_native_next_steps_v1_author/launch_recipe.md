# Next full-panel native baseline steps

Source-only handoff, 2026-10-12 local date. No actual preparation, fitting, target-array read, GPU launch, installation or Git operation ran for this handoff. The new helper's default invocation only imports the bridge and reports source-only status. Root owns execution and its existing admission/guard.

## Completed starting point

[data/full_panel_native_preparation_v1/inner_frames_targets_v1/completed.json](../../../data/full_panel_native_preparation_v1/inner_frames_targets_v1/completed.json), SHA256 **33dba70edda5bcb9887865c59c620b952724b503ab7fa0d5e1f9b3b024269ef3**, confirms all three inner observed frames and ARGMix SNP target NPZs completed in45.25s. It records no Rust run, model fitting or outer truth access.

TRAIN is ap_full_train_000/001; internal VAL is ap_full_train_002. Its bound input is research/reviews/full_panel_inner_frames_targets_v1_root/input.json, SHA256 **00584051a7cb38d563b1777aba5fcceb9026bd4b328ab357f1f6d872c9c43b99**. Reuse these products; do not rerun the frame/target stage.

Immediate CPU work is two independent preparations: AP shell features plus realized six-path TRAIN rows, and stock ARGMix Rust train/val archives. The prior100MB frames/targets admission covers those completed stages only; root supplies a bound guard appropriate to the next outputs. No budget redesign is needed.

## Minimal preparation helper and exact calls

[prepare_next.py](prepare_next.py), SHA256 **99451a68af1964830865fb47b9ad3d9a20fb007636a6ee488a2147cdb9c6ce26**, exposes two functions with no import-time work. Root can load it using the bridge's pinned_module(NEXT_SOURCE_REF, "full_panel_native_next"). Its functions take a mandatory root guard, use exclusive new output directories, and call the existing frozen algorithms. No no-op guard is supplied.

**AP, main project CPU environment:**

~~~bash
source scripts/project_env.sh
CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 .runtime/env/bin/python \
  research/reviews/full_panel_native_next_steps_v1_author/prepare_next.py
~~~

That command is the read-only/default check, already passed. In the root-admitted execution wrapper, call:

~~~python
ap = next_steps.prepare_ap_next(
    DONE_REF, INPUT_REF,
    "data/full_panel_native_preparation_v1/ap_training_v1",
    guard=guard,
)
~~~

The helper calls read_completed_parent() and prepare_ap_features() for000/001, seals both observed feature manifests, then calls prepare_ap_training(observation, features["manifest"], bound_truth_record, ..., guard=guard). It never calls AP training preparation on002. Exact reused implementation is prepare_full_panel_native_supervised_v1.py; its pinned optimized cache only changes the reviewed280→952 cardinality literal. Its sampler is unchanged sample_realized_source_rows() from scripts/train_ancestralpaths_biological_v2.py, preserving /3 overhead, float stride passes, cohort order, caps, replacement duplicates and realized-row shortfalls.

Expected outputs per TRAIN parent: features/<parent>/<parent>.npz, .json and features.json; training/<parent>/training_rows.npz, <parent>_training_selection.npz, <parent>_sampler.json and training.json. The top-level ap_prepared.json binds them and reports actual/requested rows, at most325,000 requested across both parents. Every feature is5×9 and target is native six-path one-hot.

**ARGMix, qualified native CPU runtime:**

~~~bash
source scripts/project_env.sh
export ARGMIX_NATIVE_PROFILE=cu129
source configs/official_argmix_native_environment_v1/containment.env.sh
export PYTHONPATH="$ARGGNN_ROOT/src:$ARGMIX_NATIVE_SOURCE/src"
~~~

Use .runtime/official_argmix_abi210_v1/cu129/env/bin/python (Python3.12, Torch2.10.0+cu129), not the main project/PyG interpreter. CUDA visibility remains explicitly empty for archives. The existing build/admission records are:

- experiments/results/argmix_native_abi210_execution_v1/v6/build/receipt.json, SHA256 fa1898dc4f55638d4e106a2da9b6fb7df139f2719b50b664b433c7955e0dd0dd.
- .runtime/official_argmix_abi210_v1/cu129/admission/v6/receipt.json, SHA256 592561fe97bd74e8678ba2ebb1bf749c0c09124c13eda03d0ded98d120c99a39.

Root's qualified wrapper can reuse the exact existing library admission functions:

~~~python
policy = bridge.protocol()["policy"]
native_ref = next(r for r in policy["helper_algorithm_refs"]
                  if r["path"] == "src/arggnn/official_argmix_biological.py")
native = bridge.pinned_module(native_ref, "full_panel_native_argmix_runtime")
native.runtime_admission(BUILD_REF, CPU_REF, native.policy())
modules = native.source_imports()[:5]  # torch, ancpath, joint, trainer, loader
build = json.loads(bridge.checked(BUILD_REF).read_text())
cli_ref = next(r for r in build["native_artifacts"]
               if bridge.local(r["path"]) == native.CLI)
prepared = next_steps.prepare_argmix_next(
    DONE_REF, "data/full_panel_native_preparation_v1/argmix_archives_v1",
    guard=guard, admitted_cli_record=cli_ref, native_modules=modules,
    archive_write_upper_bound_bytes=ROOT_APPROVED_ARCHIVE_BOUNDS,
)
~~~

ROOT_APPROVED_ARCHIVE_BOUNDS must contain positive train/val byte bounds supplied by root. This calls existing prepare_argmix_archives() directly with done["frames"] and done["targets"]. It checks binding, full roster, native IDs, vocabulary and author-loaded archive tensors. It writes train_pairs.yaml, val_pairs.yaml, local_uniform_map.tsv, backend.yaml, train.pt, val.pt, train/val.Rust.log, command receipts and native_prepared.json.

The exact unchanged native subprocesses inside that API are:

~~~bash
.runtime/official_argmix_abi210_v1/cu129/source/src/rust/ancpath/target/cli/release/build_training \
  --config /workspace-SR003.nfs2/ARG-GNN/data/full_panel_native_preparation_v1/argmix_archives_v1/backend.yaml \
  --split train \
  --output /workspace-SR003.nfs2/ARG-GNN/data/full_panel_native_preparation_v1/argmix_archives_v1/train.pt

.runtime/official_argmix_abi210_v1/cu129/source/src/rust/ancpath/target/cli/release/build_training \
  --config /workspace-SR003.nfs2/ARG-GNN/data/full_panel_native_preparation_v1/argmix_archives_v1/backend.yaml \
  --split val \
  --output /workspace-SR003.nfs2/ARG-GNN/data/full_panel_native_preparation_v1/argmix_archives_v1/val.pt
~~~

Use the bridge instead of running these binaries bare: it provides source/binding validation, admitted bulk writes, logs and stock archive validation.

## Native fits after preparation

**Released AP Dense, root-admitted CPU fit.** Existing qualified interpreter is .runtime/conda/envs/ancestralpaths_cpu_v1/bin/python, TensorFlow-CPU2.15.1/Keras2.15.0. Native author baselines retain their original framework, separate from the user's PyTorch/PyG requirement for our models. The full-panel wrapper should concatenate both prepared training_rows.npz arrays without deduplicating/reweighting, then call exactly:

~~~python
tf.config.threading.set_intra_op_parallelism_threads(2)
tf.config.threading.set_inter_op_parallelism_threads(2)
tf.config.experimental.enable_op_determinism()
tf.keras.utils.set_random_seed(101)
model = ancestralpaths_native_bridge.build_native_keras_model(tf.keras)
history = model.fit(x, native_targets_onehot6, epochs=5,
                    batch_size=32, shuffle=True, verbose=2)
model.save(root_owned_output / "native_dense_epoch5.keras")
~~~

This preserves Flatten45→Dense512/ReLU→Dropout0.2→Dense6/softmax, Adam and categorical CE. Keep final epoch5, no002 selection or C4 retraining. Record the native6 checkpoint/history first; common C4 collapse later is (p1+p5,p2+p6,p3,p4).

**Released ARGMix, root-admitted GPU fit.** The direct author train CLI already accepts the generic prepared archives. Execute under the admitted ABI210/cu129 environment and root GPU launcher/title/lease:

~~~bash
.runtime/official_argmix_abi210_v1/cu129/env/bin/python \
  .runtime/official_argmix_abi210_v1/cu129/source/src/train_joint_model.py \
  --config data/full_panel_native_preparation_v1/argmix_archives_v1/backend.yaml \
  --train-pt data/full_panel_native_preparation_v1/argmix_archives_v1/train.pt \
  --val-pt data/full_panel_native_preparation_v1/argmix_archives_v1/val.pt \
  --checkpoint-output data/full_panel_native_preparation_v1/argmix_archives_v1/stock_checkpoint.path
~~~

Do not source containment *after* assigning CUDA visibility without restoring the leased visibility: containment deliberately clears it for CPU stages. Source seed50, native Transformer+bidirectional-GRU architecture, batch16, smoothing0.1, AdamW, patience2 and native unweighted batch-mean VAL selection remain in the unchanged code/backend. Expected best checkpoint is backend paths.save_dir/<native run_name>/best_model.pt, with its absolute path written to stock_checkpoint.path.

Old train_ancestralpaths_biological_v2.py CLI and official_argmix_biological.stock_train() are pilot-bound and reject these full-panel products. Reuse their algorithm functions/native author CLI through a new root full-panel fit envelope; do not relax those frozen pilot guards. This handoff implements only CPU preparation helpers, not that fitting envelope, prediction sealing or scoring. Outer observations/targets are outside the next steps.
