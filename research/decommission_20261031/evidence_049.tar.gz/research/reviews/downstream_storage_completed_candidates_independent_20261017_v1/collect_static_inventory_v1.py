"""Static source/compact-receipt inventory only. No guard imports or operations.
Reads only explicit accounting JSON, exact completed.json markers, sources and named
receipts. Writes only this new review directory. No payloads or measurements.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, stat
ROOT=Path("/workspace-SR003.nfs2/ARG-GNN")
OUT=ROOT/"research/reviews/downstream_storage_completed_candidates_independent_20261017_v1"
def relative(p):
    p=Path(p)
    return str(p.relative_to(ROOT)) if p.is_absolute() else str(p)
def ref(p):
    p=Path(p); p=p if p.is_absolute() else ROOT/p
    return dict(path=relative(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):
    return json.loads((ROOT/p).read_text()) if not Path(p).is_absolute() else json.loads(Path(p).read_text())
def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()
def write(name,x):
    with (OUT/name).open("x") as f:
        json.dump(x,f,indent=2,sort_keys=True);f.write("\n")
DIRS=["project_budget_v9","project_budget_cpu_closed_scopes_v1","project_budget_terminal_scopes_v1","concurrent_completed_scope_credits_v3","prospective_980gb_v1","prospective_980gb_H020_v3","prospective_980gb_Census_fit2_v1","native14_stopped_retention_v3","native7_H050_stopped_retention_v1","Relate_failed64GiB_retention_v1"]
legacy=read(".runtime/storage/project_budget_v4.json")
reservations={k:(v,ref(".runtime/storage/project_budget_v4.json")) for k,v in legacy["reservations"].items()}
closed={}; journals=[]; all_refs=[]; current=[]
for name in DIRS:
    directory=ROOT/".runtime/storage"/name; paths=sorted(directory.glob("*.json"))
    previous=None; events=[]
    for n,p in enumerate(paths,1):
        r=ref(p);x=json.loads(p.read_text());all_refs.append(r)
        assert x["sequence"]==n and x["previous_sha256"]==previous,(name,n)
        previous=r["sha256"];events.append(x)
        op=x["operation"];v=x["value"]
        key=v.get("key") or v.get("proof",{}).get("key") or v.get("request",{}).get("key") or x.get("key")
        assert key,(name,n,op)
        if op=="reserve":
            assert key not in reservations
            reservations[key]=(v,r)
        elif "close" in op or "retire" in op:
            assert key not in closed
            closed[key]=dict(operation=op,event_ref=r,measurement=v.get("measurement"),original_request=v.get("request"))
        else:raise AssertionError(op)
    journals.append(dict(path=relative(directory),events=len(paths),tail_sha256=previous,event_refs=[ref(p) for p in paths],hash_chain_valid=True))
    if name==DIRS[-1]:current=events
selector_path="research/reviews/Relate_failed64GiB_retention_ROOT_activation_20261017_v1/explicit_child_selector.root_active_v1.json"
policy_path="research/reviews/Relate_failed64GiB_retention_ROOT_activation_20261017_v1/activation_policy.root_active_v1.json"
guard_path="research/reviews/Relate_failed64GiB_retention_successor_source_20261017_v1/relate_failed64_retention_v1.py"
pins={selector_path:"e27d47a22d0da1b2e8f0bdf0818cb2c6c473d8c9ddb5424618bf97e704928642",policy_path:"fdec761f8cae04022093299955655f8ffa27166829653817165126d7ada6a65c",guard_path:"b8b696a0df45c12b931e563600c2b52e89e73dd19c7d160351063687dcfb5164"}
for p,h in pins.items():assert ref(p)["sha256"]==h
policy=read(policy_path);selector=read(selector_path)
guard_ast=ast.parse((ROOT/guard_path).read_text())
defs={n.name:n for n in guard_ast.body if isinstance(n,ast.FunctionDef)}
guard_checks={}
for name in ["_proof","_completed_identity","_measurement","apply_close_completed_v1","operation_draft_v1","load_selected_guard_v1"]:
    n=defs[name]
    guard_checks[name]=dict(line=n.lineno,AST_sha256=hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest())
added=sum(x["value"]["reserved_bytes"] for x in current if x["operation"]=="reserve")
credit=0
for x in current:
    if x["operation"]!="reserve":
        v=x["value"];key=v.get("key") or v.get("request",{}).get("key") or v["proof"]["key"]
        credit+=reservations[key][0]["reserved_bytes"]-v["measurement"]["conservative_scope_bytes"]
projected=policy["base_projected_bytes"]+policy["bootstrap_metadata_charge_bytes"]+added-credit+len(current)*policy["per_event_metadata_charge_bytes"]
open_rows=[]
exclusions=set(policy["never_credit_keys"]+policy["ordinary_completed_close_excluded_keys"])
for key,(own,event_ref) in sorted(reservations.items()):
    if key in closed:continue
    marker=Path(own["output"])/"completed.json"
    row=dict(key=key,cap_bytes=own["reserved_bytes"],output=own["output"],auxiliary_scopes=own.get("auxiliary_scopes",[]),reservation_ref=event_ref,reservation_sha256=digest(own),policy_excluded=key in exclusions)
    try:
        metadata=marker.lstat()
    except FileNotFoundError:
        row.update(completion_marker_present=False,proof_necessary_condition="MISSING_REQUIRED_OUTPUT_COMPLETED_JSON")
    else:
        row["completion_marker_present"]=True
        row["marker_regular_no_follow"]=stat.S_ISREG(metadata.st_mode)
        row["completion_metadata_bytes"]=metadata.st_size
        if stat.S_ISREG(metadata.st_mode) and metadata.st_size<=1048576:
            value=json.loads(marker.read_text())
            identity={k:value[k] for k in ["schema","status","completed_utc","parent_id","stage","phase","hypothesis_id"] if k in value}
            row["completed_ref"]=ref(marker);row["completed_identity_metadata"]=identity
            status=value.get("status");schema=value.get("schema")
            row["fits_completion_identity_necessary_condition"]=(isinstance(status,str) and status.startswith("completed")) or (schema in ["expanded_native_ap_driver_completed_v2","expanded_native_argmix_preparation_v1_root_admission_completed","expanded_pyg_observations_v5_completed"] and isinstance(value.get("completed_utc"),str))
        else:row["fits_completion_identity_necessary_condition"]=False
        row["ordinary_close_proven"]=False
    open_rows.append(row)
markers=[r for r in open_rows if r["completion_marker_present"]]
upper=sum(r["cap_bytes"] for r in markers)
assert upper<35000000000
candidates=[]
c3meta="research/reviews/C3_VAL003_completed_close_preparation_independent_20261017_v1/original_metadata.v1.json"
cm=read(c3meta);c3key=cm["key"]
assert c3key in reservations and c3key not in closed
for r in cm["refs"].values():
    assert ref(r["path"])==r
c3wait=read(cm["refs"]["direct_wait"]["path"])
c3outer=read(cm["refs"]["actual_outer_terminal"]["path"])
candidates.append(dict(key=c3key,cap_bytes=33554432,status="GENUINE_COMPLETION_DIRECT0_DRAIN_OUTER0_SOURCE_RECIPE_READY_ROOT_CLOSE_PENDING",original_metadata_ref=ref(c3meta),exact_existing_recipe_ref=ref("research/reviews/C3_VAL003_completed_close_preparation_independent_20261017_v1/ROOT_recipe.v1.json"),actual_ROOT_preparation_ref=ref("research/reviews/C3_VAL003_completed_close_ROOT_actual_20261017_v1/ROOT_actual_metadata_preparation.root_v1.json"),actual_request_ref=ref("research/reviews/C3_VAL003_completed_close_ROOT_actual_20261017_v1/close_request.root_v1.json"),known_PID_targets=cm["known_numeric_PID_targets"],known_group_targets=cm["known_numeric_group_targets"],historical_starts="UNKNOWN as genuinely recorded",ordinary_close_possible_through_unchanged_current_child=True,remaining=["ROOT fresh current-child open/prefix acceptance","ROOT chooses truthful fresh finite authority","ROOT owns all current targeted observations/revocation","actual guard no-follow full original-scope measurement, apply close, consumed outer0 and final chain acceptance"],credit_bytes=None))
specs=[
("TRAIN","TreeLoom_Chickenpox_CPU_ROOT_actual_20261017_v1","H061_TRAIN_ROOT_acceptance_20261017_v1/TRAIN_acceptance.root_active_v1.json","H061_TRAIN_ROOT_acceptance_20261017_v1/actual_outer_terminal.root_v1.json"),
("freeze","H061_postselection_ROOT_actual_freeze_tx_20261017_v1","H061_freeze_ROOT_acceptance_20261017_v1/freeze_acceptance.root_active_v1.json","H061_postselection_ROOT_preparation_freeze_tx_20261017_v1/actual_execution_outer_consumed.root_v1.json"),
("predict","H061_postselection_ROOT_actual_predict_tx2_20261017_v1","H061_predict_ROOT_acceptance_20261017_v1/prediction_acceptance.root_active_v1.json","H061_predict_ROOT_acceptance_20261017_v1/ROOT_barrier_authentication.root_v1.json"),
("score","H061_postselection_ROOT_actual_score_tx_20261017_v1","H061_score_ROOT_acceptance_20261017_v1/score_acceptance.root_active_v1.json","H061_score_ROOT_acceptance_20261017_v1/actual_outer_terminal_consumed.root_v1.json")]
for label,d,acc,outer in specs:
    directory="research/reviews/"+d
    storage=read(directory+"/storage.json");own=storage["reservation"];key=own["key"]
    assert reservations[key][0]==own and key not in closed
    wait=read(directory+"/worker_aux/actual_wait.json");launch=read(directory+"/worker_aux/launch.json")
    a=read("research/reviews/"+acc)
    assert wait["returncode"]==0 and wait["actual_direct_launcher_wait"] is True and wait["all_owned_processes_and_groups_drained"] is True
    assert not wait["cleanup_errors"] and wait["operational_failure"] is None and not wait["adopted_waits"]
    assert launch["pid"]==wait["pid"]
    assert a["outer_terminal_consumed"] is True and a["outer_terminal_exit_code"]==0
    assert a["actual_wait_ref"]==ref(directory+"/worker_aux/actual_wait.json")
    assert a["completed_ref"]==wait["completed_ref"]==ref(Path(own["output"])/"completed.json")
    assert Path(own["output"])==ROOT/storage["output_directory"]
    candidates.append(dict(label="H061_"+label,key=key,cap_bytes=own["reserved_bytes"],status="GENUINE_COMPLETION_DIRECT0_DRAIN_OUTER0_ROOT_OBSERVATION_AND_CLOSE_PREPARATION_PENDING",ordinary_close_possible_through_unchanged_current_child=True,reservation_sha256=digest(own),reservation_ref=reservations[key][1],storage_ref=ref(directory+"/storage.json"),storage_locator=[],launch_ref=ref(directory+"/worker_aux/launch.json"),launch_pid_locator=["pid"],direct_wait_ref=ref(directory+"/worker_aux/actual_wait.json"),wait_pid_locator=["pid"],wait_exit_locator=["returncode"],completed_ref=a["completed_ref"],ROOT_acceptance_ref=ref("research/reviews/"+acc),outer_evidence_ref=ref("research/reviews/"+outer),known_PID_targets=sorted(set(wait["known_owned_pids"]+[wait["supervisor_pid"]])),known_group_targets=sorted(set(wait["known_owned_process_groups"]+[wait["supervisor_process_group"]])),worker_start_ticks=launch["ownership"]["owned_identities"][0]["start"],supervisor_start_ticks="UNKNOWN unless another original serialized record supplies it",scope_paths=[own["output"]]+own.get("auxiliary_scopes",[]),remaining=["Authenticate source-owned complete bounded PID roster against actual launcher/supervisor sources","ROOT permanent scoped launch/resume/write revocation while preserving read-only reuse","ROOT fresh numeric PID/group ESRCH observations","ROOT fresh original14-field request, current child prefix/authority, actual complete scope measurement","ROOT genuine close receipt, consumed actual outer0 and final current-child acceptance"],credit_bytes=None))
native_key="H041/native-VAL000-verified22000-continuation-v12_root01_oct16"
native_row=next(r for r in open_rows if r["key"]==native_key)
milestone_path="research/reviews/research_execution_ROOT_20261017_v17/verified_training_milestone.root_v1.json"
milestone=read(milestone_path)
assert milestone["producer_completion_ref"]==native_row["completed_ref"]
native=dict(key=native_key,cap_bytes=native_row["cap_bytes"],completed_ref=native_row["completed_ref"],milestone_ref=ref(milestone_path),status="PRODUCER_COMPLETE_ONLY_NOT_ORDINARY_CLOSE_READY",native_actual_wait_exists_in_original_ROOT_receipt=milestone["native_actual_wait_exists"],native_supervisor_terminal_accepted_in_original_ROOT_receipt=milestone["native_supervisor_terminal_accepted"],missing=["genuine native direct0 and owned drain receipt","ROOT-consumed same native outer0","complete saved owned PID/group roster and fresh targeted absence","permanent old launch/resume/write revocation","fresh exact current-child close authority and actual full scope measurement"],credit_bytes=None)
for r in all_refs:assert ref(r["path"])==r
for j in journals:assert [relative(p) for p in sorted((ROOT/j["path"]).glob("*.json"))]==[r["path"] for r in j["event_refs"]]
inventory=dict(schema="downstream_storage_completed_candidates_static_inventory_v1",source_only=True,created_utc=datetime.now(timezone.utc).isoformat(),status="NO_35GB_ORDINARY_COMPLETED_CLOSE_CAPACITY_AVAILABLE",current_selector_ref=ref(selector_path),current_policy_ref=ref(policy_path),current_guard_ref=ref(guard_path),raw_legacy_reservation_ledger_ref=ref(".runtime/storage/project_budget_v4.json"),static_snapshot_stable=True,guard_state_or_mutex_called=False,raw_reservation_count=len(reservations),raw_closed_or_retired_key_count=len(closed),raw_open_reservation_count=len(open_rows),journals=journals,current_projection_static_arithmetic=dict(base_projected_bytes=policy["base_projected_bytes"],new_cap_sum_bytes=added,already_recorded_credit_bytes=credit,event_count=len(current),projected_bytes=projected,scheduling_headroom_bytes=980000000000-projected,accepted_ROOT_context_projected_bytes=941896507341,matches_ROOT_context=projected==941896507341),upper_bound=dict(open_completed_marker_count=len(markers),sum_original_caps_bytes=upper,requested_release_bytes=35000000000,shortfall_even_if_every_marker_scope_had_zero_retained_bytes=35000000000-upper,not_measured_credit=True,includes_policy_exclusions_invalid_status_missing_wait_or_roster_and_all_retained_bytes=True,native_payload_65GiB_bytes=65*1024**3,native65GiB_funding_shortfall_before_additional_admin_and_future_fits_bytes=65*1024**3-(980000000000-projected),native65GiB_funding_shortfall_after_impossible_all_marker_zero_retained_bound_bytes=65*1024**3-(980000000000-projected+upper)),strong_small_candidates=candidates,contingent_native_candidate=native,open_reservations=open_rows,already_closed_or_retired_large_keys=[dict(key=k,**v) for k,v in closed.items() if reservations[k][0]["reserved_bytes"]>=1000000000],ordinary_helper_source_AST=guard_checks,operations_performed=dict(guard_imports=0,guard_state_or_mutex=0,measurements=0,resource_or_process_probes=0,journal_mutations=0,scientific_payload_reads=0,execution_or_installs_or_Git=0))
write("candidate_inventory.v1.json",inventory)
print(json.dumps(dict(status=inventory["status"],projection=projected,open_marker_count=len(markers),open_marker_cap_upper=upper,strong_small_count=len(candidates),strong_small_cap_sum=sum(r["cap_bytes"] for r in candidates),inventory_ref=ref(OUT/"candidate_inventory.v1.json")),sort_keys=True))
