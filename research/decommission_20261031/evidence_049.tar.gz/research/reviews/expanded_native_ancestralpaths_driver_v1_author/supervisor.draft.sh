#!/usr/bin/env bash
set -euo pipefail
cd /workspace-SR003.nfs2/ARG-GNN
source scripts/project_env.sh
export CUDA_VISIBLE_DEVICES=''
# Root must bind active admission, exact runtime and terminal-success reservation.
# No launch is performed by the author. Root supplies these two arguments.
if [ "$#" -ne 2 ]; then
  echo "Usage: supervisor.draft.sh ROOT_INPUT_PATH ROOT_INPUT_SHA256" >&2
  exit 2
fi
.runtime/env/bin/python -B -m arggnn.run_expanded_native_ancestralpaths_v1 \
  --supervise --input "$1" --expected-input-sha256 "$2"
