from pathlib import Path
import hashlib,json,subprocess,datetime
ROOT=Path.cwd()
explicit=['README.md','research/experiment_decisions.json','research/experiment_ledger.md','research/experiment_ledger.json','configs/anchor_compact_cuda_bootstrap_v2.json','configs/gpu_pool_research_v3.json','docs/anchor_compact_cuda_bootstrap_v2.md','docs/gpu_pool_research_v3.md','scripts/gpu_pool_research_v3.py','src/arggnn/anchor_compact_cuda_bootstrap_v2.py','tests/test_anchor_compact_cuda_bootstrap_v2.py','tests/test_gpu_pool_research_v3.py','configs/official_argformer_tsinfer_biological_v2.json','docs/official_argformer_tsinfer_biological_v2.md','src/arggnn/official_argformer_tsinfer_biological_v2.py','tests/test_official_argformer_tsinfer_biological_v2.py','configs/official_argformer_tsinfer_parent_v1.json','docs/official_argformer_tsinfer_parent_v1.md','scripts/prepare_official_argformer_tsinfer_parent_v1.py','tests/test_official_argformer_tsinfer_parent_v1.py']
dirs=['research/reviews/anchor_compact_cuda_bootstrap_v2_author','research/reviews/anchor_compact_cuda_bootstrap_v2_independent','research/reviews/gpu_pool_research_v3_author','research/reviews/gpu_pool_research_v3_independent','research/reviews/census_native_qualification_runner_v1_independent','research/reviews/official_argformer_tsinfer_biological_v2_author','research/reviews/official_argformer_tsinfer_biological_v2_independent','research/reviews/official_argformer_tsinfer_parent_v1_author','research/reviews/official_argformer_tsinfer_parent_v1_independent','experiments/results/anchor_compact_actual_qualification_v1_root','experiments/results/anchor_compact_actual_qualification_v2_root','experiments/results/root_storage_observation_v20261010T2230','experiments/results/official_argformer_tsinfer_parent_train000_v1_root','experiments/results/census_native_actual32_inspect_v1_root','experiments/results/root_comparison_progress_v20261010T2300']
paths={Path(p) for p in explicit if Path(p).is_file()}
for name in dirs:
 base=Path(name)
 if not base.exists():continue
 for p in base.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  relative=p.relative_to(base)
  if any(x in {'.runtime','tmp','cache','config','data','handmade_fixture','fixtures','.pytest_cache','__pycache__'} or 'tmp' in x.lower() or x.startswith(('pytest_temp','basetemp')) for x in relative.parts[:-1]):continue
  if p.suffix not in {'.json','.py','.md','.txt','.csv','.xml','.log','.stdout','.stderr'} or p.stat().st_size>1048576:continue
  if p.name in ['stage_compact.py','commit_manifest.json']:continue
  paths.add(p)
visible=set(subprocess.run(['git','ls-files','--cached','--others','--exclude-standard','-z'],check=True,capture_output=True).stdout.decode().split('\x00'))
paths=sorted([p for p in paths if str(p) in visible],key=str)
for p in paths:
 if not p.resolve().is_relative_to(ROOT.resolve()) or '.runtime' in p.parts:raise ValueError('Outside allowed scope: '+str(p))
records=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
receipt=Path('experiments/results/root_comparison_progress_v20261010T2300/commit_manifest.json')
with receipt.open('w') as f:f.write(json.dumps({'kind':'explicit_source_compact_evidence_staging','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file_count':len(records),'total_bytes':sum(r['bytes'] for r in records),'excluded':'runtime, raw arrays, large manifests, caches, temporary and sparse handmade fixtures, active GPU cell outputs, in-progress v2 repair','files':records},sort_keys=True,indent=2)+'\n')
r=subprocess.run(['git','add','--',*[str(p) for p in paths],str(receipt)],capture_output=True,text=True)
print(json.dumps({'git_add_exit':r.returncode,'stderr':r.stderr,'selected_file_count':len(paths),'total_bytes':sum(r['bytes'] for r in records)}),flush=True)
if r.returncode:raise RuntimeError('git add failed')
r=subprocess.run(['git','diff','--cached','--stat'],check=True,text=True,capture_output=True)
print(r.stdout[-6000:],flush=True)
