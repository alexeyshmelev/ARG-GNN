Compile main.tex with pdfLaTeX and BibTeX. AAAI2027 working draft. Development ancestry results and separately held-out county forecasts are distinguished. Visible scientific TODOs remain.
