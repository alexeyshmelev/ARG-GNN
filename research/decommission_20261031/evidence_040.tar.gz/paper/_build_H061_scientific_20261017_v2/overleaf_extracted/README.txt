Compile main.tex with pdfLaTeX and BibTeX. AAAI2027 working draft. Development ancestry results and held-out county forecasts remain distinguished. Visible scientific TODOs remain.
