Compile main.tex with pdfLaTeX and BibTeX. Two figures explain the prediction pipeline and its expanded tree encoder. This is a development manuscript, not a completed matched benchmark.
