TreeLoom working manuscript

Upload every file in this archive to an Overleaf project. Set main.tex as the main document and use pdfLaTeX with BibTeX. The official AAAI 2027 style and bibliography files are included.

Local compilation: pdflatex main.tex, bibtex main, pdflatex main.tex, pdflatex main.tex.

This is a scientific working draft with visible TODOs. Numerical results are unchanged from the repository receipts. The feature values and predictions in Figure 1 are illustrative. The editable vector figure and its generator are available in the repository at paper/figure_redesign_20261016_v4/.
