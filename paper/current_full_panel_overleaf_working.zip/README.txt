Compile main.tex with pdfLaTeX and BibTeX. Two figures trace tensors through TreeLoom. This is a development manuscript, not a completed matched benchmark.
