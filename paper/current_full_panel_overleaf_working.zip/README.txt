Compile main.tex with pdfLaTeX and BibTeX. Two compact figures explain the TreeLoom prediction flow and context mechanisms. This is a development manuscript, not a completed matched benchmark.
