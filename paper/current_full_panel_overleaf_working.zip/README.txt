Compile main.tex with pdfLaTeX and BibTeX. The three figures describe the architecture, haplotype memory and node operators. This is a development manuscript, not a completed matched benchmark.
