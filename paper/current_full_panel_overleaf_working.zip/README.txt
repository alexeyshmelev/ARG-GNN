Set main.tex as the main document. Compile using pdfLaTeX and BibTeX. Working research draft.
