Upload to Overleaf and compile main.tex with pdfLaTeX and BibTeX. This AAAI2027 working draft reports development results and retains visible scientific TODOs.
