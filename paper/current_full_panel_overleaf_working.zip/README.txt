AAAI development manuscript, updated2026-10-16

Main document: current_full_panel_working.tex
Compiler: pdfLaTeX. Run pdfLaTeX, BibTeX, then pdfLaTeX twice.
Official aaai2027.sty and aaai2027.bst are unchanged AuthorKit27 assets.
TikZ architecture is embedded. No external graphics are required.
The draft option is for internal working use. Select the proper submission mode and venue page limit before submission.

Root compiled and visually checked8pages. Current evidence includes completedH045 and its matched own-state control.
This is a development manuscript, not a submission-ready paper or proof of novelty/top1.
Eight reused development simulations, one optimizer seed, method-specific native inputs/training/selection.
American native ARGformer/FLARE, independent test confirmation, distinct useful novelty and broader empirical validation remain unfinished.

All model and experimental artifacts remain on the allocation server and in the GitHub evidence records.
